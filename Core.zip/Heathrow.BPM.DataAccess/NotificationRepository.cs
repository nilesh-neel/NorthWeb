﻿using System.Data.SqlClient;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Threading.Tasks;


namespace Heathrow.BPM.DataAccess
{
    public class NotificationRepository : GenericRepository<Notification>, INotification, ILookup
    {
        public NotificationRepository(BaggageDbContext context) : base(context)
        { }
        public async Task<int> Save(Notification _notification)
        {
            var lookupLocation = GetLookupDetailsById(1);
            var lookupAudience = GetLookupDetailsById(4);
            var lookupTopic = GetLookupDetailsById(3);
            var lookupRec = GetLookupDetailsById(2);            
            List<string> Locations = new List<string>();
            try
            {
                foreach (var locid in _notification.SelectLocationId)
                {
                    foreach (var id in lookupLocation.Where(obj => obj.RowID == (locid)))
                    {
                        {

                            var x = id.LookupTypeName;
                            Locations.Add(x);
                        }
                    }
                }
                foreach (var id in lookupAudience.Where(obj => obj.RowID == _notification.SelectedAudienceGroup))
                {
                    {
                        _notification.Audience = id.LookupTypeName;
                    }
                }
                foreach (var id in lookupRec.Where(obj => obj.RowID == _notification.SelectedRecipients))
                {
                    {
                        _notification.Recipient = id.LookupTypeName;
                    }
                }
                foreach (var id in lookupTopic.Where(obj => obj.RowID == _notification.SelectedTopic))
                {
                    {
                        _notification.Topic = id.LookupTypeName;
                    }
                }                                           
                var objNotification = await Task.Run(() => ((BaggageDbContext)Context).usp_ConfigureNewNotification
                 (_notification.NotificationID, _notification.Description, _notification.SelectedRecipients,
                     string.Join(",", _notification.SelectLocationId), _notification.SelectedAudienceGroup, _notification.Topic, _notification.HelpUrl, DateTime.Parse(_notification.StartDate), DateTime.Parse(_notification.EndDate), _notification.CreatedBy, _notification.ModifiedBy,
                     _notification.ModifiedDate,  _notification.IsOnScreen, _notification.IsEmail, _notification.IsMobile, _notification.TopicID, string.Join(",", Locations), _notification.Audience, _notification.Recipient)
                );
                 return (objNotification == 1) ? 1 : -1;              
                //   //To Do: Save list of notifications for this.NotificationID and this.UserID
            }
            catch (Exception ex)
            {
                throw ex;
            }
         
        }
        public async Task<int> UpdateNotification(Notification _notification)
             {
                var lookupLocation = GetLookupDetailsById(1);
                 var lookupAudience = GetLookupDetailsById(4);
                 var lookupTopic = GetLookupDetailsById(3);
                 var lookupRec = GetLookupDetailsById(2);

       
                 List<string> Locations = new List<string>();
                 try
                 {
               if (_notification.SelectLocationId == null)
                {
                    var objNotification = await Task.Run(() => ((BaggageDbContext)Context).usp_UpdateNotification(
                      _notification.NotificationID,"", 0,    "", 0, "",  "", DateTime.Now, DateTime.Now,  "", "","", false,false, false,0,_notification.DisableNotification, "",
                    "", ""));
                    return (objNotification == 1) ? 1 : -1;

                }
              else  if (_notification.Recipient== null && _notification.SelectedTopic!=0)
                {
                    foreach (var locid in _notification.SelectLocationId)
                    {
                        foreach (var id in lookupLocation.Where(obj => obj.RowID == (locid)))
                        {
                            {
                                var x = id.LookupTypeName;
                                Locations.Add(x);
                            }
                        }
                    }
                    foreach (var id in lookupTopic.Where(obj => obj.RowID == _notification.SelectedTopic))
                    {
                        {

                            _notification.Topic = id.LookupTypeName;
                        }
                    }
                    var objNotification = await Task.Run(() => ((BaggageDbContext)Context).usp_UpdateNotification(
                        _notification.NotificationID, _notification.Description, 0,
                  string.Join(",", _notification.SelectLocationId), 0, _notification.Topic,
                  "", DateTime.Now, DateTime.Now,"", "", "", _notification.IsOnScreen, _notification.IsEmail, _notification.IsMobile,
                  _notification.SelectedTopic,false, string.Join(",", Locations),
                      "", ""));
                    return (objNotification == 1) ? 1 : -1;

                }
                else
                {
                       foreach (var locid in _notification.SelectLocationId)
                       {
                           foreach (var id in lookupLocation.Where(obj => obj.RowID == (locid)))
                           {                       
                               {
                                   var x = id.LookupTypeName;
                                   Locations.Add(x);
                               }
                           }
                       }
                           foreach (var id in lookupAudience.Where(obj => obj.RowID == _notification.SelectedAudienceGroup))
                           {                      
                               {
                                   _notification.Audience = id.LookupTypeName;
                           }
                           }
                           foreach (var id in lookupRec.Where(obj => obj.RowID == _notification.SelectedRecipients))
                           {
                               {
                                   _notification.Recipient = id.LookupTypeName;
                           }
                           }
                       foreach (var id in lookupTopic.Where(obj => obj.RowID == _notification.SelectedTopic))
                       {                  
                          {

                               _notification.Topic = id.LookupTypeName;
                           }
                       }

                      var objNotification = await Task.Run(() => ((BaggageDbContext)Context).usp_UpdateNotification(
                          _notification.NotificationID, _notification.Description, _notification.SelectedRecipients,
                    string.Join(",", _notification.SelectLocationId), _notification.SelectedAudienceGroup, _notification.Topic,
                    _notification.HelpUrl, DateTime.Parse(_notification.StartDate), DateTime.Parse(_notification.EndDate),
                    _notification.CreatedBy,_notification.CreatedDate, _notification.ModifiedBy,
                    _notification.IsOnScreen, _notification.IsEmail, _notification.IsMobile,
                    _notification.SelectedTopic,false, string.Join(",", Locations),
                        _notification.Audience, _notification.Recipient));

                             return (objNotification == 1) ? 1 : -1;
                }
                
             

            }

                   catch (Exception ex)
                    {
                        throw ex;
                    }
       
        }
        public async Task<Notification> GetNotificationByNotificationId(string _notificationId)
        {
           
            try
            {

                  var objnotif = await Task.Run(() => ((BaggageDbContext)Context).usp_GetNotificationById(_notificationId));
                  var a = objnotif.FirstOrDefault();
                  return  new Notification
                  {
                      NotificationID = _notificationId,
                      Description = a.Notification_Description,
                      CreatedDate = a.Created_Date.ToString(),
                      ModifiedBy = a.Modified_By,
                      ModifiedDate = a.Modified_Date,
                      CreatedBy = a.Created_By,
                      HelpUrl = a.Help_URL,
                      StartDate = a.Start_Date.ToString(),
                      EndDate = a.End_Date.ToString(),
                      SelectedAudienceGroup = a.AudienceGroup_ID,
                      SelectedRecipients = a.Recipient_ID,
                      SelectedTopic = a.Topic_ID,
                      Locations = a.Locations,
                     
                      IsOnScreen = (bool)a.isOnScreen,
                      IsEmail = (bool)a.isEmail,
                      IsMobile = (bool)a.isMobile,
                      SelectLocationId= a.Location_ID.Split(',').Select(int.Parse).ToArray(),
                      DisableNotification=(bool)a.Disable_Notification

                  };
  
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }
        public async Task<IEnumerable<Notification>> GetTodaysNotification()
        {
          
         try
            {
                var objnotif = await Task.Run(() => ((BaggageDbContext)Context).usp_GetAllNotifications());
                return objnotif?.Select(a => new Notification
                {
                    NotificationID = a.Notification_ID,
                    Description= a.Notification_Description,
                    Topic = a.Topic,
                    Locations =a.Locations ,
                    ModifiedBy = a.Modified_By,
                    DisableNotification = (bool)a.Disable_Notification,
                    CreatedBy = a.Created_By,
                    HelpUrl = a.Help_URL,
                    StartDate = a.Start_Date.ToString(),
                    EndDate = a.End_Date.ToString(),
                    ModifiedDate =a.Modified_By ,
                    DateAndTime = a.Notification_DateTime.ToString(),
                    SelectedAudienceGroup = a.AudienceGroup_ID,
                    SelectedRecipients =a.Recipient_ID ,
                     SelectedTopic=a.Topic_ID,
                    Audience = a.Audience,
                    Recipient = a.Recipients,
                   
                    IsOnScreen = (bool)a.isOnScreen,
                    IsEmail =(bool)a.isEmail ,
                    IsMobile = (bool)a.isMobile

                }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
          
        }
        public IEnumerable<LookupEnt> GetLookupDetailsById(int iLookupTypeId)
        {
            /*  try
              {
                  var objalerts = await Task.Run(() => ((BaggageDbContext)Context).usp_GetLookupItems(iLookupTypeId));

                  return objalerts?.Select(a => new LookupEnt
                  {
                      IsActive = a.isActive,
                      LookupID = a.LookUp_ID,
                      LookupName = a.LookUp_Name,
                      LookupTypeID = a.LookUpItem_ID,
                      LookupTypeName = a.LookUpItem_Name,
                      RowID = (int)a.id

                  }).ToList();

              }
              catch (Exception)
              {
                  throw;
              }*/

            DbConnection oDal = new DbConnection();
            LookupEnt oLookupDetailsEnt = null;
            List<LookupEnt> lstLookupDetails = null;
            try
            {

                DataSet dsType = new DataSet();

                oDal.ExecuteDataSet(ProcedureConstants.GetLocation, out dsType,
                       new List<SqlParameter>()
                       {
                           new SqlParameter() { ParameterName = "@id", DbType = DbType.String, Value = iLookupTypeId }
                       });

                // if (this.Errorno == 0)
                {

                    if (dsType.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsType.Tables[0].Rows)
                        {
                            if (lstLookupDetails == null)
                                lstLookupDetails = new List<LookupEnt>();
                            oLookupDetailsEnt = new LookupEnt();
                            oLookupDetailsEnt.RowID = Convert.ToInt32(dr["id"]);
                            oLookupDetailsEnt.LookupName = Convert.ToString(dr["LookUp_Name"]);
                            oLookupDetailsEnt.LookupTypeName = Convert.ToString(dr["LookUpItem_Name"]);
                            oLookupDetailsEnt.LookupTypeID = Convert.ToInt32(dr["LookUpItem_ID"]);
                            oLookupDetailsEnt.LookupID = Convert.ToInt32(dr["LookUp_ID"]);
                            oLookupDetailsEnt.IsActive = Convert.ToBoolean(dr["isActive"]);
                            lstLookupDetails.Add(oLookupDetailsEnt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                oDal.CloseConnection();
            }
            return lstLookupDetails;


        }

     
        public async Task<IEnumerable<LookupEnt>> GetAllTopic()
        {
            try
            {
                var objalerts = await Task.Run(() => ((BaggageDbContext)Context).usp_GetMeasureCategory());

                   return objalerts?.Select(a => new LookupEnt
                   {
                       RowID = a.MeasureCategoryID,
                       LookupTypeName = a.Description,
                       IsActive = false,
                       LookupID = 1,
                       LookupName = "",
                       LookupTypeID = 1
                   }).ToList();

            }
            catch (Exception e)
            {
                throw;
            }

        }
        public async Task<IEnumerable<LookupEnt>> GetAllLocation()
        {
            try
            {
                var objalerts = await Task.Run(() => ((BaggageDbContext)Context).usp_GetLocation());

                return objalerts?.Select(a => new LookupEnt
                {
                    RowID = a.TerminalFacilityID,
                    LookupTypeName = a.Name,
                    IsActive = false,
                    LookupID = 1,
                    LookupName = "",
                    LookupTypeID = 1
                }).ToList();

            }
            catch (Exception e)
            {
                throw;
            }

        }
   
     
    }
}
 