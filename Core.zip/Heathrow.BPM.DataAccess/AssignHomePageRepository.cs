﻿using System;
using System.Data.SqlClient;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System.Data;
using System.Collections.Generic;
using System.Linq;

namespace Heathrow.BPM.DataAccess
{
   public class AssignHomePageRepository:IAssignHomePage
    {
        public int Save(AssignHomePage _assignhomepage)
        {
            DbConnection oDAL = new DbConnection();
            try
            {

                DataSet dsAssignList = new DataSet();

                oDAL.ExecuteDataSet(ProcedureConstants.AssignHomePage, out dsAssignList,
                   new List<SqlParameter>()
                   {
                        new SqlParameter() { ParameterName = "@audienceGroup", DbType = DbType.String, Value = _assignhomepage.AudienceGroup },
                        new SqlParameter() { ParameterName = "@recipients", DbType = DbType.String, Value =_assignhomepage.Recipients}
                     
                   });

                //return dsRegList.Tables != null && dsRegList.Tables[0].Rows.Count > 0
                //   ? Convert.ToInt32(Convert.ToString(dsRegList.Tables[0].Rows[0][0]).Equals("success") ? 0 : 999)
                // : 999;

                return 1;


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }


        public IEnumerable<AssignHomePage> Get()
        {
            DbConnection oDAL = new DbConnection();
            try
            {
                DataSet dsAssignHomeList = new DataSet();
                oDAL.ExecuteDataSet(ProcedureConstants.GetAssignHomePage, out dsAssignHomeList);
                return dsAssignHomeList.Tables != null &&
                    dsAssignHomeList.Tables[0].Rows.Count > 0 ? BindAllDataToEntity(dsAssignHomeList) : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }
        
        private List<AssignHomePage> BindAllDataToEntity(DataSet dsAssignHome)
        {
            try
            {
                return (from drAlert in dsAssignHome.Tables[0].AsEnumerable()
                        select (new AssignHomePage
                        {
                            AudienceGroup = Convert.ToString(dsAssignHome.Tables[0].Rows[0]["Description"])
                          
                             //get list of recipients
                         
                        })).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            //return null;
        }
    }
}
