﻿//----------------------------------------------------------------------
//Class Name   : NotesRepository 
//Purpose      : This is Data Service js file use to connect with the server side api/controller call. 
//               Whit this ajax call we can achive promise in javascripts. 
//Created By   : Vignesh AshokKumar
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using System.Collections.Generic;
using Heathrow.BPM.DataAccess.Common;
using Heathrow.BPM.Core.Entity;
using System;
using System.Data;
using System.Data.SqlClient;
using static System.Convert;
using Heathrow.BPM.Core.Interface;
using System.Threading.Tasks;
using System.Linq;

namespace Heathrow.BPM.DataAccess
{
    public class NotesRepository : GenericRepository<Notes>, INotes
    {
        public NotesRepository(BaggageDbContext context) : base(context)
        {

        }

        #region Notes Repository
        public async Task<IList<Notes>> SaveNotes(Notes _note)
        {
            try
            {
                var oSaveNotes = await Task.Run(() => ((BaggageDbContext)Context).usp_SaveNotes(_note.Notedesc,_note.Bagtag,_note.Flightnumber,_note.Organization,Convert.ToBoolean(_note.Ispublic),_note.UserId));
                return oSaveNotes?.Select(a => new Notes
                {
                    NotesId=a.Notes_ID,
                    Notedesc=a.Notes_Desc,
                    Flightnumber=a.Flight_Number,
                    Organization=a.Organization,
                    Ispublic= ToInt16(a.Is_Public),
                    Isdeleted=ToInt16(a.Is_Deleted),
                    UserId=a.Created_User,
                    CreatedDate=a.Created_Datetime
                }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IList<Notes>> FetchNotes(string Bagtag, string Flightnumber, string Organization,string UserId)
        {
            try
            {
                var oFetchNotes = await Task.Run(() => ((BaggageDbContext)Context).usp_FetchNotes(Bagtag, Flightnumber, Organization, UserId));
                return oFetchNotes?.Select(a => new Notes
                {

                    NotesId = a.Notes_ID,
                    Notedesc = a.Notes_Desc,
                    Flightnumber = a.Flight_Number,
                    Organization = a.Organization,
                    Ispublic = ToInt16(a.Is_Public),
                    Isdeleted = ToInt16(a.Is_Deleted),
                    UserId = a.Created_User,
                    CreatedDate = a.Created_Datetime
                }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IList<Notes>> DeleteNotes(int NotesId, string Bagtag, string Flightnumber, string Organization, string UserId)
        {
            try
            {
                var oDeleteNotes = await Task.Run(() => ((BaggageDbContext)Context).usp_DeleteNotes(NotesId,Bagtag, Flightnumber, Organization, UserId));
                return oDeleteNotes?.Select(a => new Notes
                {

                    NotesId = a.Notes_ID,
                    Notedesc = a.Notes_Desc,
                    Flightnumber = a.Flight_Number,
                    Organization = a.Organization,
                    Ispublic = ToInt16(a.Is_Public),
                    Isdeleted = ToInt16(a.Is_Deleted),
                    UserId = a.Created_User,
                    CreatedDate = a.Created_Datetime
                }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

    }
}
