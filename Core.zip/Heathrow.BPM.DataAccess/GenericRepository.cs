﻿//----------------------------------------------------------------------
//Class Name   : GenericRepository
//Purpose      : To Connect with database with entity framework DAL layer have this file 
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------


using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using Heathrow.BPM.DataAccess.Common;

namespace Heathrow.BPM.DataAccess
{
    public class GenericRepository<TEntity> : IRepository<TEntity> where TEntity : class
    {
        internal DbContext Context;
        internal DbSet<TEntity> DbSet;
        private bool _disposed;


        public GenericRepository(DbContext context)
        {
            Context = context;
            Context.Configuration.ProxyCreationEnabled = false;
            DbSet = context.Set<TEntity>();
        }

        public IEnumerable<TEntity> All()
        {
            return DbSet.AsNoTracking().ToList();
        }

        public IEnumerable<TEntity> AllInclude
        (params Expression<Func<TEntity, object>>[] includeProperties)
        {
            return GetAllIncluding(includeProperties).ToList();
        }

        public IEnumerable<TEntity> FindByInclude(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includeProperties)
        {
            var query = GetAllIncluding(includeProperties);
            IEnumerable<TEntity> results = query.Where(predicate).ToList();
            return results;
        }

        private IQueryable<TEntity> GetAllIncluding(params Expression<Func<TEntity, object>>[] includeProperties)
        {
            IQueryable<TEntity> queryable = DbSet.AsNoTracking();

            return includeProperties.Aggregate
              (queryable, (current, includeProperty) => current.Include(includeProperty));
        }
        public IEnumerable<TEntity> FindBy(Expression<Func<TEntity, bool>> predicate)
        {

            IEnumerable<TEntity> results = DbSet.AsNoTracking()
              .Where(predicate).ToList();
            return results;
        }

        public TEntity FindByKey(int id)
        {
            Expression<Func<TEntity, bool>> lambda = Utilities.BuildLambdaForFindByKey<TEntity>(id);
            return DbSet.AsNoTracking().SingleOrDefault(lambda);
        }

        public void Insert(TEntity entity)
        {
            DbSet.Add(entity);
            Context.SaveChanges();
        }

        public void Update(TEntity entity)
        {
            DbSet.Attach(entity);
            Context.Entry(entity).State = EntityState.Modified;
            Context.SaveChanges();
        }

        public void Delete(int id)
        {
            var entity = FindByKey(id);
            DbSet.Remove(entity);
            Context.SaveChanges();

        }

        public IEnumerable<TEntity> ExecuteQuery(string spQuery, object[] parameters)
        {
            return Context.Database.SqlQuery<TEntity>(spQuery, parameters).ToList();
        }

        public TEntity ExecuteQuerySingle(string spQuery, object[] parameters)
        {

            return Context.Database.SqlQuery<TEntity>(spQuery, parameters).FirstOrDefault();

        }

        #region "Async Call"
        public virtual IQueryable<TEntity> Table => DbSet;

        public virtual async Task<TEntity> GetByIdAsync(object id)
        {
            return await DbSet.FindAsync(id);
        }

        public async Task<IEnumerable<TEntity>> AllAsync()
        {
            return await DbSet.AsNoTracking().ToListAsync();
        }

        public virtual async Task InsertAsync(TEntity entity)
        {
            try
            {
                if (entity == null)
                    throw new ArgumentNullException(nameof(entity));

                DbSet.Add(entity);

                await Context.SaveChangesAsync();
            }
            catch (DbEntityValidationException dbEx)
            {
                var msg = string.Empty;

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                    foreach (var validationError in validationErrors.ValidationErrors)
                        msg += $"Property: {validationError.PropertyName} Error: {validationError.ErrorMessage}" + Environment.NewLine;

                var fail = new Exception(msg, dbEx);
                throw fail;
            }
        }

        public virtual async Task UpdateAsync(TEntity entity)
        {
            try
            {
                if (entity == null)
                    throw new ArgumentNullException(nameof(entity));

                await Context.SaveChangesAsync();
            }
            catch (DbEntityValidationException dbEx)
            {
                var msg = string.Empty;

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                    foreach (var validationError in validationErrors.ValidationErrors)
                        msg += Environment.NewLine +
                               $"Property: {validationError.PropertyName} Error: {validationError.ErrorMessage}";

                var fail = new Exception(msg, dbEx);
                throw fail;
            }
        }


        public virtual async Task DeleteAsync(TEntity entity)
        {
            try
            {
                if (entity == null)
                    throw new ArgumentNullException(nameof(entity));

                DbSet.Remove(entity);

                await Context.SaveChangesAsync();
            }
            catch (DbEntityValidationException dbEx)
            {
                var msg = string.Empty;

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                    foreach (var validationError in validationErrors.ValidationErrors)
                        msg += Environment.NewLine +
                               $"Property: {validationError.PropertyName} Error: {validationError.ErrorMessage}";

                var fail = new Exception(msg, dbEx);
                throw fail;
            }
        }

        public virtual async Task DeleteAllAsync(List<TEntity> entity)
        {
            try
            {
                foreach (var item in entity)
                {
                    DbSet.Remove(item);
                }
                await Context.SaveChangesAsync();
            }
            catch (DbEntityValidationException dbEx)
            {
                var msg = string.Empty;

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                    foreach (var validationError in validationErrors.ValidationErrors)
                        msg += Environment.NewLine +
                               $"Property: {validationError.PropertyName} Error: {validationError.ErrorMessage}";

                var fail = new Exception(msg, dbEx);

                throw fail;
            }
        }
        IQueryable<TEntity> IRepository<TEntity>.GetAllIncluding(params Expression<Func<TEntity, object>>[] includeProperties)
        {
            IQueryable<TEntity> result = DbSet;
            foreach (var property in includeProperties) result = result.Include(property);
            return result;
        }

        public async Task<ICollection<TEntity>> FindByAsyn(Expression<Func<TEntity, bool>> predicate)
        {
            return await DbSet.Where(predicate).ToListAsync();
        }
        public async Task<IEnumerable<TEntity>> ExecuteQueryAsync(string spQuery)
        {

            return await Context.Database.SqlQuery<TEntity>(spQuery).ToListAsync();
        }
        public async Task<TEntity> ExecuteQuerySingleAsync(string spQuery)
        {
            return await Context.Database.SqlQuery<TEntity>(spQuery).FirstOrDefaultAsync();
        }
        public async Task<IEnumerable<TEntity>> ExecuteQueryAsync(string spQuery, object[] parameters)
        {
            return await Context.Database.SqlQuery<TEntity>(spQuery, parameters).ToListAsync();
        }
        #endregion "End Of Async Call"

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    Context.Dispose();
                }
            }
            _disposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }


    }
}