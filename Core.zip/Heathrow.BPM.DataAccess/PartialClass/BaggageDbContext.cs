﻿//----------------------------------------------------------------------
//Class Name   : BaggageDbContext
//Purpose      : This is the default entity framework partial class use to initialize the connection string
//               and other entity framework task 
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------


using Heathrow.BPM.Security;
using System;
using System.Data.Entity;
using System.Configuration;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Linq;

namespace Heathrow.BPM.DataAccess
{
    public partial class BaggageDbContext : DbContext
    {
        private static readonly string EncryptionKey = ConfigurationManager.AppSettings["EncryptionKey"];
        private static readonly string SConnString = ConfigurationManager.ConnectionStrings["BaggageDbContext"].ToString();
        private static string _sConnName;
        public static string ConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(_sConnName))
                {
                    AesEncryption sec = new AesEncryption();
                    _sConnName = sec.Decrypt(SConnString, EncryptionKey);
                    return _sConnName;
                }
                return _sConnName;
            }
        }
        public BaggageDbContext()
            : base(ConnectionString)
        {
        }

    }
}
