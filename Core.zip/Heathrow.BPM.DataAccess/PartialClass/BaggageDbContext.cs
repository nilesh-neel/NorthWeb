﻿//----------------------------------------------------------------------
//Class Name   : BaggageDbContext
//Purpose      : This is the default entity framework partial class use to initialize the connection string
//               and other entity framework task 
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------


using Heathrow.BPM.Security;
using System;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;

namespace Heathrow.BPM.DataAccess
{
    public partial class BaggageDbContext
    {
        private static readonly string EncryptionKey = ConfigurationManager.AppSettings["EncryptionKey"];
        private static readonly string SConnString = ConfigurationManager.ConnectionStrings["BaggageDbContext"].ToString();
        private static string _sConnName;
        public static string ConnectionString
        {
            get
            {
                if (String.IsNullOrEmpty(_sConnName))
                {
                    AesEncryption sec = new AesEncryption();
                    _sConnName = sec.Decrypt(SConnString, EncryptionKey);
                    return _sConnName;
                }
                return _sConnName;
            }
        }
        public BaggageDbContext()
            : base(ConnectionString)
        {
        }

        public virtual DbSet<JobRole> JobRoles { get; set; }

        public virtual DbSet<Location> Locations { get; set; }

        public virtual DbSet<Menu> Menus { get; set; }

        public virtual DbSet<MenuItem> MenuItems { get; set; }


        public virtual ObjectResult<usp_GetMenu_Result> usp_GetMenu()
        {

            return ((IObjectContextAdapter)this).ObjectContext.ExecuteFunction<usp_GetMenu_Result>("usp_GetMenu");
        }


        public virtual ObjectResult<usp_GetFavourites_Result> usp_GetFavourites(string userId)
        {

            var userIdParameter = userId != null ?
                new ObjectParameter("UserId", userId) :
                new ObjectParameter("UserId", typeof(string));


            return ((IObjectContextAdapter)this).ObjectContext.ExecuteFunction<usp_GetFavourites_Result>("usp_GetFavourites", userIdParameter);
        }


        public virtual ObjectResult<Nullable<int>> usp_SaveFavourites(string userId, Nullable<int> menuId, Nullable<int> favouriteId)
        {

            var userIdParameter = userId != null ?
                new ObjectParameter("UserId", userId) :
                new ObjectParameter("UserId", typeof(string));


            var menuIdParameter = menuId.HasValue ?
                new ObjectParameter("MenuId", menuId) :
                new ObjectParameter("MenuId", typeof(int));


            var favouriteIdParameter = favouriteId.HasValue ?
                new ObjectParameter("FavouriteId", favouriteId) :
                new ObjectParameter("FavouriteId", typeof(int));


            return ((IObjectContextAdapter)this).ObjectContext.ExecuteFunction<Nullable<int>>("usp_SaveFavourites", userIdParameter, menuIdParameter, favouriteIdParameter);
        }

    }
}
