﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;

namespace Heathrow.BPM.DataAccess
{
    public class LookupRepository: ILookup
    {
        public int Status;      
     /*   public List<LookupEnt> GetLookupType()
        {
            LookupEnt oLookupDetailsEnt = null;
            List<LookupEnt> lstLookup = null;
            try
            {
                DbConnection oDAL = new DbConnection();
                DataSet dsType = new DataSet();

                this.Errorno = oDAL.Select(ProcedureConstants.GetLookupTypes, out dsType);

                if (this.Errorno == 0)
                {

                    if (dsType.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsType.Tables[0].Rows)
                        {
                            if (lstLookup == null)
                                lstLookup = new List<LookupEnt>();
                            oLookupDetailsEnt = new LookupEnt();
                            oLookupDetailsEnt.LookupTypeID = Convert.ToInt32(dr["LookUpTypeID"]);
                            oLookupDetailsEnt.LookupTypeName = Convert.ToString(dr["LookUpTypeName"]);
                            lstLookup.Add(oLookupDetailsEnt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw;

            }

            return lstLookup;
        }
    /*    public void SetLookupDetails(LookupEnt oLookupDetailsEnt)
        {
            try
            {
                DbConnection oDAL = new DbConnection();

                this.Errorno = oDAL.Insert(ProcedureConstants.InsertLookupDetails,
                                oDAL.CreateParameter("@LookUpName", DbType.String, oLookupDetailsEnt.LookupName),
                                oDAL.CreateParameter("@LookUpTypeId", DbType.Int32, oLookupDetailsEnt.LookupTypeID),
                                oDAL.CreateParameter("@IsActive", DbType.Boolean, oLookupDetailsEnt.IsActive),
                                oDAL.CreateParameter("@CreatedBy", DbType.String, "261866"));
                if (Errorno == 0)
                {
                    Status = 0;
                }

            }
            catch (Exception ex)
            {
                throw;

            }
        }*/
        public IEnumerable<LookupEnt> GetLookupDetailsById(int iLookupTypeId)
        {
            DbConnection oDal = new DbConnection();
            LookupEnt oLookupDetailsEnt = null;
            List<LookupEnt> lstLookupDetails = null;
            try
            {
                
                DataSet dsType = new DataSet();
                
                oDal.ExecuteDataSet(ProcedureConstants.GetLocation, out dsType,
                       new List<SqlParameter>()
                       {
                           new SqlParameter() { ParameterName = "@id", DbType = DbType.String, Value = iLookupTypeId }
                       });

               // if (this.Errorno == 0)
                {

                    if (dsType.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsType.Tables[0].Rows)
                        {
                            if (lstLookupDetails == null)
                            lstLookupDetails = new List<LookupEnt>();
                            oLookupDetailsEnt = new LookupEnt();
                            oLookupDetailsEnt.RowID = Convert.ToInt32(dr["id"]);
                            oLookupDetailsEnt.LookupName = Convert.ToString(dr["LookUp_Name"]);
                            oLookupDetailsEnt.LookupTypeName = Convert.ToString(dr["LookUpItem_Name"]);
                            oLookupDetailsEnt.LookupTypeID = Convert.ToInt32(dr["LookUpItem_ID"]);
                            oLookupDetailsEnt.LookupID = Convert.ToInt32(dr["LookUp_ID"]);
                            oLookupDetailsEnt.IsActive = Convert.ToBoolean(dr["isActive"]);
                            lstLookupDetails.Add(oLookupDetailsEnt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                oDal.CloseConnection();
            }
            return lstLookupDetails;
        }

        public List<LookupEnt> GetLookups()
        {

            LookupEnt oLookupsDetailsEnt = null;
            List<LookupEnt> lstLookups = null;
            try
            {
                
                DbConnection oDal = new DbConnection();
                DataSet dsType = new DataSet();
             oDal.ExecuteDataSet(ProcedureConstants.GetLocation, out dsType,
                        new List<SqlParameter>()
                        {
                           new SqlParameter() { ParameterName = "@id", DbType = DbType.String, Value = 1 }
                        });
                
                {

                    if (dsType.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsType.Tables[0].Rows)
                        {
                            if (lstLookups == null)
                                lstLookups = new List<LookupEnt>();
                            oLookupsDetailsEnt = new LookupEnt();
                            oLookupsDetailsEnt.LookupTypeID = Convert.ToInt32(dr["LookUpTypeID"]);
                            oLookupsDetailsEnt.LookupID = Convert.ToInt32(dr["LookUpID"]);
                            oLookupsDetailsEnt.LookupName = Convert.ToString(dr["LookUpName"]);
                            lstLookups.Add(oLookupsDetailsEnt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }

            return lstLookups;
        }

        public string GetLookupItemName(int itemNameId)
        {

            string itemName="";
            DbConnection oDal = new DbConnection();
            try
            {

                DataSet dsType = new DataSet();

                oDal.ExecuteDataSet(ProcedureConstants.GetLookupItemName, out dsType,
                       new List<SqlParameter>()
                       {
                           new SqlParameter() { ParameterName = "@id", DbType = DbType.String, Value = itemNameId }
                       });

                // if (this.Errorno == 0)
                {

                    if (dsType.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsType.Tables[0].Rows)
                        {                          
                          itemName= Convert.ToString(dr["LookUpItem_Name"]);                                                      
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                oDal.CloseConnection();
            }
            return itemName;

        }
    }
}



