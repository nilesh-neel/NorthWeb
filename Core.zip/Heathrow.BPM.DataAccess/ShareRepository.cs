﻿//----------------------------------------------------------------------
//Class Name   : ShareRepository 
//Purpose      : This is Data Service js file use to connect with the server side api/controller call. 
//               Whit this ajax call we can achive promise in javascripts. 
//Created By   : Vignesh AshokKumar
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using Heathrow.BPM.Core.Entity;
using System.Data;
using System.Data.SqlClient;
using static System.Convert;
using Heathrow.BPM.DataAccess.Common;
using System.IO;
using System.Text;
using System.Web.UI;
using System.Net;
using System.Net.Mail;

//using System.Web.Mail;

namespace Heathrow.BPM.DataAccess
{
    public class ShareRepository : Core.Interface.IShare
    {
        public ShareRepository() { }

        public IList<Share> FetchAudienceGrp()
        {
            DbConnection oDal = null;
            DataSet dsAudienceGrp = null;
            try
            {
                oDal = new DbConnection();
                dsAudienceGrp = new DataSet();

                oDal.ExecuteDataSet(ProcedureConstants.FetchAudienceGrp, out dsAudienceGrp);


                if ((dsAudienceGrp != null) && (dsAudienceGrp.Tables.Count > 0) && (dsAudienceGrp.Tables[0].Rows.Count > 0))
                {
                    // Dataset Data to collection
                    return ConvertDatatoCollection(dsAudienceGrp);
                }
                else
                    return new List<Share> { };
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }

        public IList<Share> FetchRecipients(int AudienceGrpId)
        {
            DbConnection oDal = null;
            DataSet dsGrpRecipients = null;
            try
            {
                if (AudienceGrpId != 0)
                {
                    oDal = new DbConnection();
                    dsGrpRecipients = new DataSet();

                    oDal.ExecuteDataSet(ProcedureConstants.FetchGrpRecipients, out dsGrpRecipients,
                       new List<SqlParameter>()
                       {
                       new SqlParameter() { ParameterName = "@Audiencegrpid", DbType = DbType.Int32, Value = AudienceGrpId },


                       });

                    if ((dsGrpRecipients != null) && (dsGrpRecipients.Tables.Count > 0) && (dsGrpRecipients.Tables[0].Rows.Count > 0))
                    {
                        // Dataset Data to collection
                        return ConvertDatatoCollection(dsGrpRecipients);
                    }
                    else
                        return new List<Share> { };
                }
                else
                    return new List<Share> { };
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }

        public string SendEmail(string selectedrecipients, string Url)
        {
            #region oldmethod for Sending Email
            try
            {
                StringBuilder stringBuilder = new StringBuilder();
                StringWriter writer = new StringWriter(stringBuilder);
                HtmlTextWriter htmlWriter = new HtmlTextWriter(writer);
                //divRptAttachment.RenderControl(htmlWriter);

                //string divRptAttachment_innerHTML = stringBuilder.ToString();
                //SendMail("vigneshashok.kumar@cognizant.com", "RE: Test Mail", divRptAttachment_innerHTML);
                //SendMail("vigneshashok.kumar@cognizant.com", "RE: Test Mail", " Hi, \r\n This is a Test Mail");
                //SendMail("vigneshashok.kumar@cognizant.com", "RE: Test Mail", Url);


                //SendMail(selectedrecipients, "RE: Test Mail", Url);// Send mail using SMTP Server

                SendO365Mail(selectedrecipients, "RE: Test Mail", Url); // Send Mail using Office365
                return "Success";

            }
            catch (Exception ex)
            {
                throw ex;
            }

            #endregion
            
        }

        private void SendO365Mail(string recipient, string subject, string body)
        {
            try
            {
                string Username = "LHRASHOKKUMARV";
                string Password = "cJS0YH&H";
                string SmtpServer = "smtp.office365.com";
                //string From = Username + "@cognizant.com";
                string From = "devivishnupriya.elangovan@heathrow.com";

                SmtpClient smtpClient = new SmtpClient();
                //NetworkCredential basicCredential = new NetworkCredential(Username, Password, "uk.baa.com");
                NetworkCredential basicCredential = new NetworkCredential("devivishnupriya.elangovan@heathrow.com", "heathrow@345");
                MailMessage message = new MailMessage();
                MailAddress fromAddress = new MailAddress(From);

                // setup up the host, increase the timeout to 5 minutes
                smtpClient.Host = SmtpServer;
                //smtpClient.Port = 25;
                smtpClient.Port = 587;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.EnableSsl = true;
                smtpClient.Credentials = basicCredential;
                smtpClient.Timeout = (60 * 5 * 1000);

                message.From = fromAddress;
                message.Subject = subject + " - " + DateTime.Now.Date.ToString().Split(' ')[0];
                message.IsBodyHtml = true;
                message.Body = body.Replace("\r\n", "<br>");
                message.To.Add("vigneshashok.kumar@cognizant.com"); // Hardcoded to Test

                // Commented the above line and added below -- This will add all the selected recipients in To addresss in mail
                //string[] strRecipientslist = recipient.Split(',');
                //for (int i = 0; i < strRecipientslist.Length; i++)
                //{
                //    message.To.Add(strRecipientslist[i].ToString());
                //}

                smtpClient.Send(message);
                //smtpClient.Send("devivishnupriya.elangovan@heathrow.com", "devivishnupriya.elangovan@heathrow.com", subject, body);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void SendMail(string recipient, string subject, string body)
        {
            try
            {
                string Username = "LHRASHOKKUMARV";
                string Password = "cJS0YH&H";
                string SmtpServer = "10.28.42.240";
                string From = Username + "@cognizant.com";

                SmtpClient smtpClient = new SmtpClient();
                NetworkCredential basicCredential = new NetworkCredential(Username, Password, "uk.baa.com");
                MailMessage message = new MailMessage();
                MailAddress fromAddress = new MailAddress(From);

                // setup up the host, increase the timeout to 5 minutes
                smtpClient.Host = SmtpServer;
                smtpClient.Port = 25;
                //smtpClient.Port = 587;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = basicCredential;
                smtpClient.Timeout = (60 * 5 * 1000);

                message.From = fromAddress;
                message.Subject = subject + " - " + DateTime.Now.Date.ToString().Split(' ')[0];
                message.IsBodyHtml = true;
                message.Body = body.Replace("\r\n", "<br>");
                //message.To.Add(recipient);

                // Commented the above line and added below -- This will add all the selected recipients in To addresss in mail
                string[] strRecipientslist = recipient.Split(',');
                for (int i = 0; i < strRecipientslist.Length; i++)
                {
                    message.To.Add(strRecipientslist[i].ToString());
                }

                smtpClient.Send(message);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private IList<Share> ConvertDatatoCollection(DataSet ds)
        {
            IList<Share> shareList = null;
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                shareList = new List<Share>();

                if (ds.Tables[0].Columns.Contains("Recipient_ID") && ds.Tables[0].Columns.Contains("Recipient_Name"))
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        shareList.Add(new Share
                        {
                            GroupId = ToInt32(row["Group_ID"]),
                            Groupname = Convert.ToString(row["Group_Name"]),
                            RecipientId = ToInt32(row["Recipient_ID"]),
                            Recipientname = Convert.ToString(row["Recipient_Name"]),
                        });
                    }

                }
                else
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        shareList.Add(new Share
                        {
                            GroupId = ToInt32(row["Group_ID"]),
                            Groupname = Convert.ToString(row["Group_Name"]),
                        });
                    }
                }
            }
            return shareList;
        }

    }
}
