﻿//----------------------------------------------------------------------
//Class Name   : ShareRepository 
//Purpose      : This is Data Service js file use to connect with the server side api/controller call. 
//               Whit this ajax call we can achive promise in javascripts. 
//Created By   : Vignesh AshokKumar
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using Heathrow.BPM.Core.Entity;
using System.Data;
using System.Data.SqlClient;
using static System.Convert;
using Heathrow.BPM.DataAccess.Common;
using System.IO;
using System.Text;
using System.Web.UI;
using System.Net;
using System.Net.Mail;
using Heathrow.BPM.Core.Interface;
using System.Threading.Tasks;
using System.Linq;
using System.Configuration;
using Heathrow.BPM.Security;

//using System.Web.Mail;

namespace Heathrow.BPM.DataAccess
{
    public class ShareRepository : GenericRepository<Share>, IShare
    {
        public ShareRepository(BaggageDbContext context) : base(context)
        {

        }

        #region New Code
        public async Task<IList<Share>> FetchAudienceGrp()
        {
            try
            {
                var oFetchAudienceGrp = await Task.Run(() => ((BaggageDbContext)Context).usp_FetchAudienceGroup());
                return oFetchAudienceGrp?.Select(a => new Share
                {
                    GroupId = a.Group_ID,
                    Groupname = a.Group_Name
                }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IList<Share>> FetchRecipients(int AudienceGrpId)
        {
            try
            {
                var oFetchRecipients = await Task.Run(() => ((BaggageDbContext)Context).usp_FetchGroupRecipients(AudienceGrpId));
                return oFetchRecipients?.Select(a => new Share
                {
                    GroupId = ToInt32(a.Group_ID),
                    Groupname = a.Group_Name,
                    RecipientId = a.Recipient_ID,
                    Recipientname = a.Recipient_Name
                }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<string> SendEmail(string selectedrecipients, string Url)
        {
            try
            {
                StringBuilder stringBuilder = new StringBuilder();
                StringWriter writer = new StringWriter(stringBuilder);
                HtmlTextWriter htmlWriter = new HtmlTextWriter(writer);

                return Task.Run(() => SendO365Mail(selectedrecipients, "RE: Test Mail", Url)); // Send Mail using Office365

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private string SendO365Mail(string recipient, string subject, string body)
        {
            try
            {
                string EncryptedUsername = ConfigurationManager.AppSettings["SendMailUsername"];
                string EncryptionKey = ConfigurationManager.AppSettings["EncryptionKey"];
                AesEncryption sec = new AesEncryption();
                string Username = sec.Decrypt(EncryptedUsername, EncryptionKey);
                string EncryptedPassword = ConfigurationManager.AppSettings["SendMailPassword"];
                string Password = sec.Decrypt(EncryptedPassword, EncryptionKey);
                string SmtpServer = "smtp.office365.com";
                string EncryptedFrom = ConfigurationManager.AppSettings["FromMailaddress"];
                string From = sec.Decrypt(EncryptedFrom, EncryptionKey);

                SmtpClient smtpClient = new SmtpClient();
                NetworkCredential basicCredential = new NetworkCredential(Username, Password);
                MailMessage message = new MailMessage();
                MailAddress fromAddress = new MailAddress(From);

                // setup up the host, increase the timeout to 5 minutes
                smtpClient.Host = SmtpServer;
                smtpClient.Port = 587;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.EnableSsl = true;
                smtpClient.Credentials = basicCredential;
                smtpClient.Timeout = (60 * 5 * 1000);

                message.From = fromAddress;
                message.Subject = subject + " - " + DateTime.Now.Date.ToString().Split(' ')[0];
                message.IsBodyHtml = true;
                message.Body = body.Replace("\r\n", "<br>");
                
                //message.To.Add("xxxx");

                // Commented the above line and added below -- This will add all the selected recipients in To addresss in mail
                string[] strRecipientslist = recipient.Split(',');
                for (int i = 0; i < strRecipientslist.Length; i++)
                {
                    message.To.Add(strRecipientslist[i].ToString());
                }

                smtpClient.Send(message);

                return "Success";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion
    }
}
