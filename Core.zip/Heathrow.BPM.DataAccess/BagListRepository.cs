﻿//----------------------------------------------------------------------
//Class Name   : BagListRepository 
//Purpose      : This is Data Service js file use to connect with the server side api/controller call. 
//               Whit this ajax call we can achive promise in javascripts. 
//Created By   : Vignesh AshokKumar
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.DataAccess.Common;
using static System.Convert;

namespace Heathrow.BPM.DataAccess
{
    public class BagListRepository : Core.Interface.IBagList
    {
        public BagListRepository() { }

        public string GetUserExistingBagtags(string userId)
        {
            DbConnection oDAL = null;
            DataSet dsUserExistingBagtag = null;
            string UserExistingBagtags = string.Empty;
            try
            {

                oDAL = new DbConnection();
                dsUserExistingBagtag = new DataSet();
                oDAL.ExecuteDataSet(ProcedureConstants.UserExistingBagtagsCnt, out dsUserExistingBagtag,
                 new List<SqlParameter>()
                 {
                       new SqlParameter() { ParameterName = "@updateduser", DbType = DbType.String, Value = userId },

                 });

                if ((dsUserExistingBagtag != null) && (dsUserExistingBagtag.Tables.Count > 0) && (dsUserExistingBagtag.Tables[0].Rows.Count > 0))
                {
                    if (dsUserExistingBagtag.Tables[0].Rows[0]["Bag_Tag"] != null)
                        return UserExistingBagtags = dsUserExistingBagtag.Tables[0].Rows[0]["Bag_Tag"].ToString();
                    else
                        return UserExistingBagtags;
                }
                else
                    return UserExistingBagtags;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }

        public int GetUserExistingBagtagsCnt(string userId)
        {
            //
            DbConnection oDAL = null;
            DataSet dsUserExistingBagtag = null;
            int UserExistingBagtagCnt = 0;
            try
            {

                oDAL = new DbConnection();
                dsUserExistingBagtag = new DataSet();
                oDAL.ExecuteDataSet(ProcedureConstants.UserExistingBagtagsCnt, out dsUserExistingBagtag,
                 new List<SqlParameter>()
                 {
                       new SqlParameter() { ParameterName = "@updateduser", DbType = DbType.String, Value = userId },

                 });

                if ((dsUserExistingBagtag != null) && (dsUserExistingBagtag.Tables.Count > 0) && (dsUserExistingBagtag.Tables[0].Rows.Count > 0))
                {
                    if (dsUserExistingBagtag.Tables[0].Rows[0]["BagTags_Count"] != null)
                        return UserExistingBagtagCnt = Convert.ToInt32(dsUserExistingBagtag.Tables[0].Rows[0]["BagTags_Count"]);
                    else
                        return UserExistingBagtagCnt;
                }
                else
                    return UserExistingBagtagCnt;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }

        }

        public int RemoveBagTags(string bagtags, string userId)
        {
            DbConnection oDAL = null;
            DataSet dsBagtag = null;
            int BagtagCount = 0;
            try
            {

                oDAL = new DbConnection();
                dsBagtag = new DataSet();
                oDAL.ExecuteDataSet(ProcedureConstants.RemoveBagtags, out dsBagtag,
                 new List<SqlParameter>()
                 {
                       new SqlParameter() { ParameterName = "@Bagtag", DbType = DbType.String, Value = bagtags },
                       new SqlParameter() { ParameterName = "@updateduser", DbType = DbType.String, Value = userId },

                 });

                if ((dsBagtag != null) && (dsBagtag.Tables.Count > 0) && (dsBagtag.Tables[0].Rows.Count > 0))
                {
                    if (dsBagtag.Tables[0].Rows[0]["BagTags_Count"] != null)
                        return BagtagCount = Convert.ToInt32(dsBagtag.Tables[0].Rows[0]["BagTags_Count"]);
                    else
                        return BagtagCount;
                }
                else
                    return BagtagCount;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }

        public int SaveBagTags(string bagtags, string userId)
        {
            DbConnection oDAL = null;
            DataSet dsBagtag = null;
            int BagtagCount = 0;
            try
            {

                oDAL = new DbConnection();
                dsBagtag = new DataSet();
                oDAL.ExecuteDataSet(ProcedureConstants.SaveBagtags, out dsBagtag,
                 new List<SqlParameter>()
                 {
                       new SqlParameter() { ParameterName = "@Bagtag", DbType = DbType.String, Value = bagtags },
                       new SqlParameter() { ParameterName = "@updateduser", DbType = DbType.String, Value = userId },

                 });

                if ((dsBagtag != null) && (dsBagtag.Tables.Count > 0) && (dsBagtag.Tables[0].Rows.Count > 0))
                {
                    if (dsBagtag.Tables[0].Rows[0]["BagTags_Count"] != null)
                        return BagtagCount = Convert.ToInt32(dsBagtag.Tables[0].Rows[0]["BagTags_Count"]);
                    else
                        return BagtagCount;
                }
                else
                    return BagtagCount;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }

        public IList<BagList> GetMybaglistOtherUsers()
        {
            DbConnection oDal = null;
            DataSet dsOtherUsers = null;
            try
            {
                oDal = new DbConnection();
                dsOtherUsers = new DataSet();

                oDal.ExecuteDataSet(ProcedureConstants.FetchMybaglistOtherUsers, out dsOtherUsers);


                if ((dsOtherUsers != null) && (dsOtherUsers.Tables.Count > 0) && (dsOtherUsers.Tables[0].Rows.Count > 0))
                {
                    // Dataset Data to collection
                    return ConvertDatatoCollection(dsOtherUsers);
                }
                else
                    return new List<BagList> { };
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }

        private IList<BagList> ConvertDatatoCollection(DataSet ds)
        {
            IList<BagList> UserList = null;
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                UserList = new List<BagList>();

                if (ds.Tables[0].Columns.Contains("User_ID") && ds.Tables[0].Columns.Contains("Email"))
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        UserList.Add(new BagList
                        {
                            OthersMybaglistUserId = ToInt32(row["User_ID"]),
                            UserFirstname = Convert.ToString(row["First_Name"]),
                            UserLasttname = Convert.ToString(row["Last_Name"]),
                            UserEmail = Convert.ToString(row["Email"]),
                            UserOrg = Convert.ToString(row["Organization"]),
                            UserRole = Convert.ToString(row["Job_Role"]),
                        });
                    }

                }
                
            }
            return UserList;
        }

    }
}
