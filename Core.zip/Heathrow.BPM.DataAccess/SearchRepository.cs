﻿using System;
using System.Collections.Generic;
using Heathrow.BPM.DataAccess.Common;
using Heathrow.BPM.Core;
using System.Data.SqlClient;
using System.Data;
using Heathrow.BPM.Core.Interface;
using System.Threading.Tasks;
using System.Linq;

namespace Heathrow.BPM.DataAccess
{
    public class SearchRepository : GenericRepository<FilterSelection>, ISearch
    {
        private static ReportConfiguration _searchData = null;
        public SearchRepository(BaggageDbContext context) : base(context)
        {

        }
        public async Task<ReportConfiguration> GetSearchData(string searchText, string prefix)
        {
            try
            {
                var objSearch = await Task.Run(() => ((BaggageDbContext)Context).usp_Search(searchText, prefix));

                var result = objSearch?.FirstOrDefault();
                return _searchData = new ReportConfiguration
                {
                    TableName = result.PBITableName,
                    ColumnName = result.PBIColumnName,
                    Operator = result.PBIOpearator,
                    PowerBIURL = result.PBIURL,
                };
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error is occured while retrieving the search", ex);
            }

        }
    }
}
