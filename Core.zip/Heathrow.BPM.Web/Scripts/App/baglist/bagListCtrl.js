﻿//----------------------------------------------------------------------
//Class Name   : Alert Controller
//Purpose      : This is file use to handel all jquery click event related with BagList CRUD method.
//Created By   : Vignesh
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

(function () {
    'use strict';

    $(document).ready(function () {

        var bagList = new BagList();
        var selectedUserID = 1;// Get the Logged-in userID from Session
        //bagList.GetUserExistingBagtags(selectedUserID);
        bagList.LoadBagtagCnt(selectedUserID);


        $("#btnAddBagtags").off('click').on('click', function () {
            if (_.toNumber(sessionStorage.getItem('SelectedbagtagsCnt')) > 0) {
                bagList.AddBagTags();
                //sessionStorage.removeItem("SelectedbagtagsList");
                //sessionStorage.removeItem("SelectedbagtagsCnt");
            }
            else {
                $('#dvAlertMsg').text('Please select atleast one bagtag to add to My Bag List');
                $('.refreshMessage').css("background-color", "#FBC153");
                $('.refreshMessage').css('display', 'block');
                return false;
            }

        });

        $("#btnRemoveBagtags").off('click').on('click', function () {

            if (_.toNumber(sessionStorage.getItem('SelectedbagtagsCnt')) > 0) {
                bagList.RemoveBagTags();
                sessionStorage.removeItem("SelectedbagtagsList");
                sessionStorage.removeItem("SelectedbagtagsCnt");
            }
            else {
                $('#dvAlertMsg').text('Please select atleast one bagtag to remove from My Bag List');
                $('.refreshMessage').css("background-color", "#FBC153");
                $('.refreshMessage').css('display', 'block');
                return false;
            }
        });


        $('#lnkbtnMyBagList').off('click').on('click', function () {
            $("#btnAddBagtags").hide();
            $("#dvDateselection").hide();
            $("#btnRemoveBagtags").show();
            $("#dvOtherUserMyBagList").show();

           // $('#embedContainer').hide();
            //$('#embedContainer2').show();
            //$('#dvOprtnlRpt').show();
            //$('#dvMyBagListEmbedRpt_1').show();
            //$('#dvHistoricRpt').show();
            //$('#dvMyBagListEmbedRpt_2').show();
            bagList.OthersMyBagListUsers();
            var selectedUserID = 1; // Get the Logged-in userID from Session 
            bagList.GetUserExistingBagtags(selectedUserID); //old CR -- To load the MyBaglist screen report in single div
            //bagList.LoadMyBaglistOprtnlHistrcDivs(selectedUserID); // New CR -- To load both Operational and Historic report in separete Divs
            

        });


        $('#btnViewOthersBaglist').off('click').on('click', function () {
            var selectedUserID =$('#ddlOtherUserBaglist').val();
            bagList.GetUserExistingBagtags(selectedUserID);//old CR -- To view the MyBaglist screen report of other selected user  in single div
            //bagList.LoadMyBaglistOprtnlHistrcDivs(selectedUserID);// New CR -- To view both Operational and Historic report in separete Divs of other selected user
            
        });


    });

})();