﻿//----------------------------------------------------------------------
//Class Name   : Alert Controller
//Purpose      : This is file use to handel all jquery click event related with BagList CRUD method.
//Created By   : Vignesh
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

(function () {
    'use strict';

    $(document).ready(function () {
        
        //$("#ddlOtherUserBaglist").combobox({
        //    select: function (event, ui) {
        //        alert("143");
        //        var SelectedUserID = $('option:selected', this).val();
        //        alert(SelectedUserID);
        //    }
        //});


        var bagList = new BagList();
        $("#btnAddBagtags").off('click').on('click', function () {
            if (_.toNumber(sessionStorage.getItem('SelectedbagtagsCnt')) > 0) {
                bagList.AddBagTags();
                //sessionStorage.removeItem("SelectedbagtagsList");
                //sessionStorage.removeItem("SelectedbagtagsCnt");
            }
            else {
                alert("Please select atleast one bagtag to add to My Bag List");
                return false;
            }

        });

        $("#btnRemoveBagtags").off('click').on('click', function () {

            if (_.toNumber(sessionStorage.getItem('SelectedbagtagsCnt')) > 0) {
                bagList.RemoveBagTags();
                sessionStorage.removeItem("SelectedbagtagsList");
                sessionStorage.removeItem("SelectedbagtagsCnt");
            }
            else {
                alert("Please select atleast one bagtag to remove from My Bag List");
                return false;
            }
        });


        $('#lnkbtnMyBagList').off('click').on('click', function () {
            $("#btnAddBagtags").hide();
            $("#dvDateselection").hide();
            $("#btnRemoveBagtags").show();
            $("#dvOtherUserMyBagList").show();
            
            

            bagList.OthersMyBagListUsers();
            var selectedUserID = "1"; // Get the Logged-in userID from Session 
            bagList.GetUserExistingBagtags(selectedUserID);

        });


        $('#btnViewOthersBaglist').off('click').on('click', function () {
            var selectedUserID =$('#ddlOtherUserBaglist').val();
            bagList.GetUserExistingBagtags(selectedUserID);
            
        });


    });

})();