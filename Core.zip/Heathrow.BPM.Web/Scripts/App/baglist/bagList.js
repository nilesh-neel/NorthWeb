﻿//----------------------------------------------------------------------
//Class Name   : Alert
//Purpose      : This is baglist Class js file use for the all bind configuration available in baglist module.. 
//Created By   : Vignesh AshokKumar
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

var BagList = (function () {

    'use strict';

    var service;
    /****
     * Creates a new BagList object.
     * @constructor
     *
     */
    BagList = function () {

    };

    BagList.prototype.AddBagTags = function () {

        var bagtags = sessionStorage.getItem('SelectedbagtagsList');
        var SelectedbagtagsCnt = _.toNumber(sessionStorage.getItem('SelectedbagtagsCnt'));
        var ExistingbagtagCnt = _.toNumber($("#lblMybagListcount").text());
        var Existingbagtags = sessionStorage.getItem('ExistingBagtags').replace("'", "");
        var totalbagtagCnt = ExistingbagtagCnt + SelectedbagtagsCnt;
        var selectedBagtagsArr = bagtags.split(",");
        var ExistingbagtagsArr = Existingbagtags.split(",");

        for (var i = 0; i < selectedBagtagsArr.length; i++) {
            if (ExistingbagtagsArr.includes(selectedBagtagsArr[i])) {
                alert("You are trying to add bag tags that are already present in your My Bag List");
                return false;
                break;
            }
        }

        if (totalbagtagCnt > 100) {
            alert("My Bag List has exceeded its capacity (100 Bag Tags). Remove Bag Tag’s and try again");
            return false;
        }
        else {
            var bagData = { bagtaglist: bagtags, selectedBagtagCnt: SelectedbagtagsCnt, UserId: 'Admin' };

            service = new Service('/BagList/AddtoMyBaglist', 'application/json; charset=utf-8', 'json', bagData);
            service.save()
                .then(function (resp) {
                    var res = JSON.parse(resp);
                    $("#lblMybagListcount").text(res);
                    alert("Bagtags added successfully.");
                }).fail(function (jqXHR, textStatus, errorThrown) {
                    alert("Error while adding bagTags");
                });

            service = new Service('/BagList/GetUserExistingBagtags');
            service.get()
                .then(function (resp) {
                    //var res = JSON.parse(resp);
                    sessionStorage.setItem('ExistingBagtags', resp);
                }).fail(function (jqXHR, textStatus, errorThrown) {
                    alert("Error occured while fetching Existing Bagtags");
                });
        }


    }

    BagList.prototype.RemoveBagTags = function () {

        var bagtags = sessionStorage.getItem('SelectedbagtagsList');
        var RemoveSelectedbagtagsCnt = sessionStorage.getItem('SelectedbagtagsCnt');
        if (RemoveSelectedbagtagsCnt < 1) {
            alert("Select atleast one BagTag to remove.");
            return false;
        }
        else {
            var bagData = { bagtaglist: bagtags, selectedBagtagCnt: RemoveSelectedbagtagsCnt, UserId: 'Admin' };

            service = new Service('/BagList/RemoveFrmMyBaglist', 'application/json; charset=utf-8', 'json', bagData);
            service.save()
                .then(function (resp) {
                    var res = JSON.parse(resp);
                    $("#lblMybagListcount").text(res);
                    alert("Bagtags removed successfully.");
                }).fail(function (jqXHR, textStatus, errorThrown) {
                    alert("Error while adding bagTags");
                });
            BagList.prototype.GetUserExistingBagtags.call(this);
        }
    }

    BagList.prototype.OthersMyBagListUsers = function () {
        service = new Service('/BagList/GetMybaglistOtherUsers', 'application/json; charset=utf-8', 'json');
        service.get()
            .then(function (resp) {
                BagList.prototype.LoadMybaglistOtherusers.call(this, resp);
            }).fail(function (jqXHR, textStatus, errorThrown) {
                alert("Error while adding other MyBagList Users");
            });
    }


    BagList.prototype.LoadMybaglistOtherusers = function (response) {
        var option = '';
        for (var i = 0; i < response.length; i++) {
            option += '<option value="' + response[i].OthersMybaglistUserId + '">' + response[i].UserEmail + '</option>';
        }
        $('#ddlOtherUserBaglist').empty();
        $('#ddlOtherUserBaglist').append(option);
    }

    // This method is to load the MyBaglist both for logged in user and to view other selected user's MyBaglist
    BagList.prototype.GetUserExistingBagtags = function (selectedUserID) {
        var selectedUserID = { otherUserId: selectedUserID };
        service = new Service('/BagList/GetUserExistingBagtags', 'application/json; charset=utf-8', 'json', selectedUserID);
        service.get()
            .then(function (resp) {
                //var res = JSON.parse(resp);
                var dashboardPowerBiApi = new PowerBIAPP("https://app.powerbi.com/reportEmbed?reportId=7ab8bebb-143c-4e25-9496-a234cfa64f1e&groupId=0fc4287c-461d-46bc-a2da-ec29f0962ab3", 'true');
                dashboardPowerBiApi.embedPowerBIFilterApi(resp);
            }).fail(function (jqXHR, textStatus, errorThrown) {
                alert("Error occured while fetching BagTags");
            });
    }


    return BagList;
})();