﻿(function ($)
{
    'use strict';

    $('#dvNotesIcon').off('click').on('click', function () {
        var noteData = { bagtag: 'Bt1', flightnumber: 'Fl1', organisation: 'org1' };
        var updatedNotes = [];

        $.ajax({
            type: 'POST',
            url: '/Notes/Notes',
            data: JSON.stringify(noteData),
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            success: function (response) {
                if (response != null) {
                    CreateDynamicNotes(response);
                }
            },
            failure: function (response) {
                alert('Error while data fetch.');
            },
            error: function (response) {
                alert('Error while data fetch.');
            }
        });




        var CreateDynamicNotes = function (result) {
            var tempHtml = undefined;
            if (result !== null && result.length > 0) {
                for (var i = 0; i < result.length; i++) {
                    //$('#dvMainNotes').append('<div id="updatedet"' + i + '" class = "updatedNotesDetails">    </div > ');
                    //$('#dvMainNotes').append('<div id="updatedet"' + i + '" class = "updatedNotesDetails" +    </div > ');
                    var showChar = 100;
                    //if (result[i].Notedesc.length > showChar) {
                    if (result[i].Notedesc.length > 0) {
                        var ispublic = '';
                        if (result[i].Ispublic == true)
                            ispublic = 'Public';
                        else
                            ispublic = 'Private'


                        var c = result[i].Notedesc.substr(0, showChar);
                        var h = result[i].Notedesc.substr(showChar - 1, result[i].Notedesc.length - showChar);
                        // var des=  C + h


                        tempHtml = $('#dvMainNotes').append('<div class="updatedNotesDetails"> <div class="details">  <div class= " pull-left userName" > <span>' + result[i].UserId + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span></div > <div class="dateAndTime"><span>' + result[i].CreatedDatetime + '&nbsp;' + ispublic + ' </span></div> </div>  <div class="row pull-left">  <div> <label class="text more"> ' + result[i].Notedesc + '</label></div> </div><br/><div id=' + result[i].NotesId + ' class="defaultIcons delete row pull-left"></div></div> </div></div>');

                        //showMore(h);
                    }
                }

            }
        }.bind(this);


        // Get the NotesId of the Deleted Notes
        $('body').on('click', '.delete', function () {
            $('.delete').off('click').on('click', function () {
                var data = { noteId: this.id, bagtag: 'bt1', flightnumber: 'fl1', organisation: 'org1' };
                $.ajax({
                    type: 'POST',
                    url: '/Notes/DeleteNote',
                    data: JSON.stringify(data),
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json',
                    success: function (response) {
                        $('.updatedNotesDetails').empty();
                        CreateDynamicNotes(response);
                        alert('Notes deletd successfully!!');
                    },
                    failure: function (response) {
                        alert('Error while delete.');
                    },
                    error: function (response) {
                        alert('Error while delete.');
                    }
                });
            });
        });


        $('#notesSave').on('click', function SettingsController() {
            var notesDesc = $('#Notedesc').val();
            if (notesDesc != null && notesDesc != '') {
                var noteUserAccess = $('#Ispublic').is(':checked') ? 1 : 0;
                var data = { Notedesc: notesDesc, Ispublic: noteUserAccess, UserId: 'Admin', bagtag: 'bt1', flightnumber: 'fl1', organisation: 'org1' };
                $('#Notedesc').val('');
                $.ajax({
                    type: 'POST',
                    url: '/Notes/Create',
                    data: JSON.stringify(data),
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json',
                    success: function (response) {
                        $('.updatedNotesDetails').empty();
                        CreateDynamicNotes(response);
                        alert('Notes saved successfully!!');
                    },
                    failure: function (response) {
                        alert('Error while save.');
                    },
                    error: function (response) {
                        alert('Error while save.');
                    }
                });
            }
            else
            {
                alert('Please enter the Notes Description to Save');
                return false;
            }
        });



        var showMore = function (txt) {
            var showChar = 140;
            var ellipsestext = '...';
            var moretext = 'more';
            var lesstext = 'less';
            $('.more').each(function () {
                var content = $(this).html();

                if (content.length > showChar) {

                    var c = content.substr(0, showChar);
                    var h = content.substr(showChar - 1, content.length - showChar);

                    var html = c + '<span>' + ellipsestext + '&nbsp;</span><span class="text more"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';

                    $(this).html(html);
                }

            });

            $('.morelink').click(function () {
                if ($(this).hasClass('less')) {
                    $(this).removeClass('less');
                    $(this).html(moretext);
                } else {
                    $(this).addClass('less');
                    $(this).html(lesstext);
                }
                $(this).parent().prev().toggle();
                $(this).prev().toggle();
                return false;
            });
        };
    });

    
    

    $('#Ispublic').change(function () {
        var noteUserAccess = $('#Ispublic').is(':checked');
    });

    /**note script**/
    $('.notes,#notesCancel').click(function (event) {
        event.stopPropagation();
        $(this).children(".spanNotification").css("display", "none");
        $("#notesDiv").toggle();

        $(".notes").toggleClass("clickedIcons");
        $(".notes").toggleClass("customBorderSmall");
    });
    $(".cancel").click(function () {

        if ($(this).parents(".sideNavBar")) {
            $(this).parents(".sideNavBar").css("display", "none");
            $(".updatedNotesDetails").empty();
        }

    });
    /**note script Ends**/

})(jQuery);