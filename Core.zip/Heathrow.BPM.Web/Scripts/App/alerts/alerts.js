﻿//----------------------------------------------------------------------
//Class Name   : Service 
//Purpose      : This is Alert Class js file use for the all bind configuration available in alert module.. 
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

var Alert = (function () {

    'use strict';

    var service;
    /****
     * Creates a new Alert object.
     * @constructor
     *
     */
    Alert = function () {

    };
    /****
     * This  method use to load default Landing page for the alert, notification, report and assign home page module
     */
    Alert.prototype.LoadAlertsLandingPage = function () {
        $('#dvPowerBiEmbed').hide();
        $('#viewContainer').show();
        this.bindTodayAlerts();
    }

    /****
     *  This  method use to bind the Todays Alert Tab
     *  */
    Alert.prototype.bindTodayAlerts = function () {
        
        service = new Service('/Alerts/GetTodaysAlerts', 'application/html; charset=utf-8', 'html', null);
        service.get()
            .then(function (resp) {
                var todayAlertData = _.map(resp, function (x) {
                    return {
                        AlertId: x.alertId,
                        SelectedAudienceGroup: x.selectAudience,
                        SelectedRecipients: x.selectRecipient,
                        Description: x.description,
                        SelectedLocation: x.selectLocation,
                        SelectedThreshold: x.selectThreshold,
                        SelectedMeasure: x.selectMeasure,
                        SelectedTopic: x.selectTopic,
                        CreatedBy:x.createdBy,
                        CreatedDate:x.createdDate,
                        ModifiedBy:x.modifiedBy,
                        ModifiedDate: x.modifiedDate,
                        StartDate:x.startDate,
                        EndDate:x.endDate,
                        Title: x.title,
                        Time: x.time,
                        Response: '<p class="IconsStyles"><span class="' + (x.isAcknowledge ? 'Tick_mark_Fill' : 'Tick_mark_Fill_white') + '"></span> <span class="' + (x.isIgnore ? 'ignore_red_fill' : 'ignore_white_fill') + '"></span> <span class="' + (x.isBlank ? 'blank_out_yellow_fill' : 'blank_out_white_fill') + '"></span> </p>',
                        Topic: x.topics,
                        Location: x.locations,
                        IsSubscribe: x.isSubscribe,
                        IsScreen: x.isOnScreen,
                        IsEmail: x.isEmail,
                        IsMobile: x.isMobile,
                        //Topic: CustomGrid.prototype.CommaSeperatedString.call(this, x.topic),
                        //Location: CustomGrid.prototype.CommaSeperatedString.call(this, x.location),

                        // Time: moment(x.time).format('hh:mm'),
                        //Response
                        IsAcknowledge: x.isAcknowledge,
                        IsIgnore: x.isIgnore,
                        IsBlank: x.isBlank,
                     /*   IsSubscribe: x.isSubscribe,
                        IsScreen: x.isOnScreen,
                        IsEmail: x.isEmail,
                        IsMobile: x.isMobile, */      
                        View: '<span class="Show_details  defaultIcons"></span>'
                    };
                });

                var column = [
                    { "data": 'Title', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'Time'},
                    { "data": 'Response'},
                    { "data": 'Topic', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'Location', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'View' }
                ];
                var grid = new CustomGrid('#todaysAlertTable', todayAlertData, column, true);
                grid.CreateGrid(true);
                var alertIconObj = new AlertIcon();
                alertIconObj.Response();

            })
            .catch(function (jqXHR, textStatus, err) {
                alert('Error : ' + err + ' ' + textStatus);
            });
    }
    /****
     *  This  method use to bind the My Alerts Settings Tab
     *  */
    Alert.prototype.bindMyAlertsSettings = function () {
        service = new Service('/Alerts/GetTodaysAlerts', 'application/html; charset=utf-8', 'html', null);
        service.get()
            .then(function (resp) {
                var myAlertData = _.map(resp, function (x) {
                    return {
                        AlertId: x.alertId,
                        Title: x.title,
                        Topic: x.topics,
                        Location: x.locations,
                        Description: x.description,
                        Threshold:x.thresholds,
                        ThresholdValue: x.thresholdValue,
                        MandatoryOptional: x.mandatoryOptional,
                        Measure:x.measure,
                        //Response
                        IsAcknowledge: x.isAcknowledge,
                        IsIgnore: x.isIgnore,
                        IsBlank: x.isBlank,
                        IsSubscribe: x.isSubscribe,
                        IsScreen: x.isOnScreen,
                        IsEmail: x.isEmail,
                        IsMobile: x.isMobile,
                       
                        //Topic: CustomGrid.prototype.CommaSeperatedString.call(this, x.topic),
                        //Location: CustomGrid.prototype.CommaSeperatedString.call(this, x.location),
                        Subscribe: x.isSubscribe ? '<label class="container"  class="textLabel"><input type="checkbox" id="sub" checked="checked" data-error="*Mandatory Field" required><span class="checkmark" id="sub"></span></label>' : '<label class="container"  class="textLabel"><input type="checkbox" id="sub" data-error="*Mandatory Field" required><span class="checkmark" id="sub"></span></label>',
                        //Blank: '<label class="container"  class="textLabel"><input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label>',
                        Snooze:x.isBlank?'Yes':'No',
                        Email: x.isEmail ? '<label class="container"  class="textLabel"><input type="checkbox" checked="checked"  data-error="*Mandatory Field" required><span class="checkmark" id="gridEmail" ></span></label>' : '<label class="container"  class="textLabel"><input type="checkbox" data-error="*Mandatory Field" required><span class="checkmark" id="gridEmail" ></span></label>',
                        Mobile: x.isMobile ? '<label class="container"  class="textLabel"><input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"  id="gridMobile" ></span></label>' : '<label class="container"  class="textLabel"><input type="checkbox"   data-error="*Mandatory Field" required><span class="checkmark" id="gridMobile"></span></label>',

                        View: ' <span class="Show_details defaultIcons"></span> ',
                        Edit: ' <span class="Edit  defaultIcons"></span>'
                    };
                });

                var column = [
                    { "data": 'AlertId', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'Title' },
                    { "data": 'Topic', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'Location', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'Subscribe' },
                    { "data": 'Snooze' },
                    { "data": 'Email' },
                    { "data": 'Mobile' },
                    { "data": 'View' },
                    { "data": 'Edit' }
                ];

                var grid = new CustomGrid('#alertSettingTable', myAlertData, column, false, true);
                grid.CreateGrid(true);
                if (myAlertData['MandatoryOptional'] != 'Optional')                 
                    $('#sub').attr('disabled', true);

            })
            .catch(function (jqXHR, textStatus, err) {
                console.log(jqXHR.stack);
                alert('Error : ' + jqXHR.message + ' ' + textStatus);
            });
    }
    /****
     *  This  method use to bind the Configure Alert Tab
     *  */
    Alert.prototype.bindConfigureAlerts = function () {
        service = new Service('/Alerts/GetTodaysAlerts', 'application/html; charset=utf-8', 'html', null);
        service.get()
            .then(function (resp) {
                var configureAlertsData = _.map(resp, function (x) {
                    return {
                        AlertId: x.alertId,
                        Measure: x.measure,
                        Title: x.title,
                        Audience: x.audience,
                        Recipients: x.recipient,

                        Description: x.description,
                        Topic: x.topics,
                        Location: x.locations,
                        Threshold: x.thresholds,
                        ThresholdValue: x.thresholdValue,

                        Frequency:x.timeWindow,
                        TimeWindow:x.frequency,
                        MandatoryOptional: x.mandatoryOptional,                      
                        IsScreen: x.isOnScreen,
                        IsEmail: x.isEmail,

                        IsMobile: x.isMobile,
                        Disable: x.disableAlert,

                        StartDate:x.startDate,
                        EndDate: x.endDate,
                        CreatedBy: x.createdBy,
                        Created: x.createdDate,
                        ModifiedBy: x.modifiedBy,
                        ModifiedDate: x.modifiedDate,
                      


                       // Topic: _.chain(x.topic).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                       // Locations: _.chain(x.location).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                      //  CreatedBy: x.createdBy,
                      //  Created: moment(x.createdDate).format(' DD/MM/YYYY'),
                      //  Modified: moment(x.modifiedDate).format(' DD/MM/YYYY, hh:mm'),
                      //  ModifiedBy: x.modifiedBy,
                        View: ' <span class="Show_details defaultIcons"></span> ',
                        Edit: ' <span class="Edit  defaultIcons"></span>'
                    };
                });

                var column = [
                    { "data": 'AlertId'},
                    { "data": 'Title', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'Topic', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'Location', "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'StartDate' },
                    { "data": 'EndDate' },
                    { "data": 'ModifiedDate' },
                    { "data": 'ModifiedBy' },
                    { "data": 'View' },
                    { "data": 'Edit' }
                ];
                var grid = new CustomGrid('#configureAlertsTable', configureAlertsData, column, true, true);
                grid.CreateGrid(true);
            })
            .catch(function (jqXHR, textStatus, err) {
                alert('Error : ' + err + ' ' + textStatus);
            });
    }
    /****
     *  This  method use to rebind the multiselect dropdown in module.
     *  */
    Alert.prototype.bindMultiSelectDroupDown = function () {

        $('select[multiple]').multiselect({
            columns: 1,
            placeholder: 'Select',
            search: true,

            texts: {
                placeholder: 'Select options', // text to use in dummy input
                search: 'Type here', // search input placeholder text
                selectedOptions: ' selected', // selected suffix text
                selectAll: 'Select all', // select all text
                unselectAll: 'Unselect all', // unselect all text
                noneSelected: 'None Selected' // None selected text
            },
            minHeight: 150, // minimum height of option overlay
            maxHeight: 150, // maximum height of option overlay
            maxWidth: 245,
            selectAll: false
        });

    }
    Alert.prototype.bindResponse = function (aData) {
        var x = aData;
        var alertVM = {};
        alertVM.alertId = aData['AlertId'];
        alertVM.isAcknowledge = aData['IsAcknowledge'];
        alertVM.isBlank = aData['IsBlank'];
        alertVM.isIgnore = aData['IsIgnore'];
        alertVM.isSubscribe = aData['IsSubscribe'];
        alertVM.isOnScreen = aData['IsScreen'];
        alertVM.isEmail = aData['IsEmail'];
        alertVM.isMobile = aData['IsMobile'];
        alertVM.title = aData['title'];
        var service = new Service('/Alerts/Edit', 'application/json; charset=utf-8', 'json', alertVM);
        service.save().done(function () {
            if (aData['title'] == 'gridResponse')
                $("#tabs a[href='#todaysAlerts']").click();
            else if (aData['title'] == 'IconResponse')
                $(".alertPopup").toggle();
           
          
        }).fail(function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        });
    }     
    return Alert;

})();
