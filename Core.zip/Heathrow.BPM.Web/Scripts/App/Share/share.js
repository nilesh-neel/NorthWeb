﻿(function () {
    'use strict';
    $(document).ready(function () {
        LoadAudienceGrp();
        // loadcombo();

        $("#ddlAudienceGrp").combobox({
            select: function (event, ui) {
                var SelectedGrpID = $('option:selected', this).val();
                LoadGrpRecipients(SelectedGrpID);
            }
        });
    });

    //$(document).ready(function () {
    //    $('.share,#sharePanelCancel').click(function (event) {
    //        $("#sharepanel").toggle();
    //        $(".share").toggleClass("clickedIcons");
    //        $(".share").toggleClass("customBorderSmall");
    //    });
    //});


    var LoadShareUrl = function () {
        var urlId = sessionStorage.getItem('URLId');
        var rptName = sessionStorage.getItem('RptName')
        var noteData = { menuId: urlId, rptname: rptName };

        $.ajax({
            type: "GET",
            url: "/Share/LoadShareUrl",
            data: JSON.stringify(noteData),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                if (response != null && response.length > 0) {
                    $("#lblShareUrl").text(shareUrl);
                }
            },
            failure: function (response) {
                alert("Error while shareUrl formation.");
            },
            error: function (response) {
                alert("Error while shareUrl formation.");
            }
        });

    };

    var LoadAudienceGrp = function () {
        var noteData = {};

        $.ajax({
            type: "GET",
            url: "/Share/Share",
            data: JSON.stringify(noteData),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                if (response != null && response.length > 0) {
                    GetAudienceGrpData(response);
                }
            },
            failure: function (response) {
                alert("Error while data fetch.");
            },
            error: function (response) {
                alert("Error while data fetch.");
            }
        });

    };

    //get the Audience Group dropdown values
    var GetAudienceGrpData = function (response) {
        var option = '';
        for (var i = 0; i < response.length; i++) {
            option += '<option value="' + response[i].GroupId + '">' + response[i].Groupname + '</option>';
        }
        $('#ddlAudienceGrp').append(option);
    };

    var LoadGrpRecipients = function (SelectedGrpID) {
        var noteData = { GroupId: SelectedGrpID };

        $.ajax({
            type: "POST",
            url: "/Share/GetRecipients",
            data: JSON.stringify(noteData),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                if (response != null && response.length > 0) {
                    GetGrpRecipients(response);
                }
            },
            failure: function (response) {
                alert("Error while Recipients fetch.");
            },
            error: function (response) {
                alert("Error while Recipients fetch.");
            }
        });

    };

    var GetGrpRecipients = function (response) {
        var option = '';
        var newOptions = [];
        for (var i = 0; i < response.length; i++) {
            //option += '<option value="' + response[i].RecipientId + '">' + response[i].Recipientname + '</option>';

            newOptions.push(
                {
                    name: response[i].Recipientname,
                    value: response[i].RecipientId,
                    checked: false
                });
        }
        //$('#ddlGrpRecipients').append(option);

        $('#ddlGrpRecipients').multiselect('loadOptions', newOptions);

        $('#ddlGrpRecipients').multiselect('refresh');


    };
    /**Share script Ends**/

    $("#sharePanelCancel").click(function () {
        $("#sharePanel").css("display", "none");
    });


    $("#shareSave").click(function () {

        // To get the selected value
        var selectedUsers = $("#ddlGrpRecipients option:selected").toArray().map(optionSelected).join(',');

        function optionSelected(item) {
            return [item.value];
        }

        if (selectedUsers != "") {
            var ReportUrl = $("#lblShareUrl").text();
            var SelectedRecipients = { selectedrecipients: selectedUsers, Url: ReportUrl };
            var updatedNotes = [];

            $.ajax({
                type: "POST",
                url: "/Share/SendMail",
                data: JSON.stringify(SelectedRecipients),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    if (response != null) {
                        alert("Report Url shared via Email Successfully.");
                    }
                },
                failure: function (response) {
                    alert("Error while sending mail.");
                },
                error: function (response) {
                    alert("Error while sending mail.");
                }
            });
        }
    });

})(jQuery);




