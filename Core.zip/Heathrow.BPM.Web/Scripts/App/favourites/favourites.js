﻿//----------------------------------------------------------------------
//Class Name   : Favourites
//Purpose      : This is file use to call Favourites CRUD method.
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

var Favourites = (function () {

    /****
     * Creates a new Favourites object.
     * @constructor
     *
     */
    Favourites = function () { };
    /**
  // on click of favourite icon call this method to save favourite url/menu
  */
    Favourites.prototype.saveFavourites = function () {

        var favData = {
            url: sessionStorage.getItem('autoRefURL'),
            menuId: sessionStorage.getItem('URLId')
        };

        var service = new Service('api/Favorites', 'application/json; charset=utf-8', 'json', favData);
        service.save().done(function (favMenu) {
            var childhtml = '';
            _.forEach(favMenu, function (child) {
                childhtml += '<a id="' + child.menuId + '"data-isreport="' + child.isReport + '"data-powerbiurl="' + child.url + '" href=#>' + child.description + '</a>';
            });
            var favMenuHtml = '<li class="subDropdown"><span class="defaultIcons favourite "></span><div class="dropdown-content">' + childhtml + '</div></li>';

            $('.menu li').has('span.defaultIcons.favourite').html(favMenuHtml);
            Menu.prototype.autoRefresh.call();

        }).fail(function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        });
    }


    Favourites.prototype.MarkFavouritesCss = function (markFavourite) {
        $('#liFavorite').css({
            background: 'url(../images/Icons/clickedIcons.png) no-repeat', backgroundPosition: markFavourite ? '-246px -211px' : '-81px -15px;'
        });
    }

    Favourites.prototype.GetFavourites = function () {
        var service = new Service('Favorites/SaveData', 'application/json; charset=utf-8', 'json');
        service.get().done(function (favMenu) {
            console.log(favMenu);
            var childhtml = '';
            _.forEach(favMenu, function (child) {
                childhtml += '<a id="' + child.menuId + '"data-isreport="' + child.isReport + '"data-powerbiurl="' + child.url + '" href=#>' + child.description + '</a>';
            });
            var favMenuHtml = '<li class="subDropdown"><span class="defaultIcons favourite "></span><div class="dropdown-content">' + childhtml + '</div></li>';

            $('.menu li').has('span.defaultIcons.favourite').html(favMenuHtml);
            Menu.prototype.autoRefresh.call();

        }).fail(function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        });


    }


    return Favourites;
})();