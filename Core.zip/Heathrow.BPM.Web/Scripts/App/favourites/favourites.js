﻿//----------------------------------------------------------------------
//Class Name   : Favourites
//Purpose      : This is file use to call Favourites CRUD method.
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

var Favourites = (function () {

    /****
     * Creates a new Favourites object.
     * @constructor
     *
     */
    Favourites = function () { };
    /**
  // on click of favourite icon call this method to save favourite url/menu
  */
    Favourites.prototype.saveFavourites = function () {

        var favData = {
            url: sessionStorage.getItem('autoRefURL'),
            menuId: sessionStorage.getItem('URLId')
        };
        //var service = new Service('api/Favorites?menuId=' + sessionStorage.getItem('URLId') + 'url=' + sessionStorage.getItem('autoRefURL'), 'application/json; charset=utf-8', 'json', favData);
        var service = new Service(baseUrl + 'api/Favorites', 'application/json; charset=utf-8', 'json', favData);
        service.save().done(function (favMenu) {
            var childhtml = '';
            _.forEach(favMenu, function (child) {
                childhtml += '<a id="' + child.menuId + '"data-isreport="' + child.isReport + '"data-powerbiurl="' + child.url + '" href=#>' + child.description + '</a>';
            });
            var favMenuHtml = '<li class="subDropdown"><span class="defaultIcons favourite favourites"></span><div class="dropdown-content">' + childhtml + '</div></li>';

            $('.menu li').has('span.defaultIcons.favourite').html(favMenuHtml);
            //bind the click event post html updated 
            $('#myFavorite').on('click', function () {
                Favourites.prototype.saveFavourites.call(this);
            });
            //update the session variable value after post call.
            sessionStorage.setItem('favMenu', JSON.stringify(favMenu));
            Menu.prototype.autoRefresh.call();
            Favourites.prototype.markFavouritesCss.call(this, sessionStorage.getItem('URLId'));
        }).fail(function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        });
    }

    // set the Favourite CSS
    Favourites.prototype.markFavouritesCss = function (menuItemID) {
        var favMenuList = JSON.parse(sessionStorage.getItem('favMenu'));
        if (!_.isNil(favMenuList) && favMenuList.length > 0) {
            var favMenu = _.find(favMenuList, function (k) { return k.menuId === parseInt(menuItemID) })
            if (!_.isNil(favMenu)) {
                $('#myFavorite').addClass('favorites');
            } else {
                $('#myFavorite').removeClass('favorites');
            }
        }
    }

    Favourites.prototype.GetFavourites = function () {
        var service = new Service(baseUrl + 'api/Favorites', 'application/json; charset=utf-8', 'json');
        service.get().done(function (favMenu) {
            sessionStorage.setItem('favMenu', JSON.stringify(favMenu));
            var childhtml = '';
            _.forEach(favMenu, function (child) {
                childhtml += '<a id="' + child.menuId + '"data-isreport="' + child.isReport + '"data-powerbiurl="' + child.url + '" href=#>' + child.description + '</a>';
            });
            var favMenuHtml = '<li class="subDropdown"><span class="defaultIcons favourite favourites"></span><div class="dropdown-content">' + childhtml + '</div></li>';

            $('.menu li').has('span.defaultIcons.favourite').html(favMenuHtml);
            //bind the click event post html updated 
            $('#myFavorite').on('click', function () {
                Favourites.prototype.saveFavourites.call(this);
            });
            Menu.prototype.autoRefresh.call();

        }).fail(function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        });


    }


    return Favourites;
})();