﻿//----------------------------------------------------------------------
//Class Name   : Favourites
//Purpose      : This is file use to handel all jquery click event related with Favourites CRUD method.
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

(function () {
    'use strict';

    $('.favorite').click(function () {
        var fav = new Favourites();
        fav.saveFavourites();
    });


})();