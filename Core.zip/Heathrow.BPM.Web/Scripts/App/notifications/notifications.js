﻿var Notifications = (function () {

    'use strict';

    var service;
    var msg = new StandardMessage("msg");
    Notifications = function () {

    };
    Notifications.prototype.LoadNotificationLandingPage = function () {
      //  $('#dvPowerBiEmbed').hide();
       // $('#viewContainer').show();
        this.bindTodayNotification();
    
    }

    Notifications.prototype.bindTodayNotification = function () {
       
        service = new Service('/Notifications/GetTodaysNotification', 'application/html; charset=utf-8', 'html', null);
        service.get()
            .then(function (resp) {
                var todayNotificationData = _.map(resp, function (x) {
                    return {
                       
                        IsScreen: x.isOnScreen,
                        IsEmail: x.isEmail,
                        IsMobile: x.isMobile,
                        NotificationId: x.notificationId,
                        Description: x.description,
                        Time: moment(x.dateAndTime).format('LLL'),
                        //Topic: _.chain(x.topic).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        Topic: x.topics,
                        Locations:x.locations,
                      //  Locations: _.chain(x.location).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        View: '<span class="Show_details  defaultIcons"></span>'
                    };
                });

                var column = [
                    { "data": "Description", "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": "Topic", "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": "Locations", "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": "Time" },                                
                    { "data": "View" }
                ];
                var grid = new CustomGrid('#todaysNotificationTable', todayNotificationData, column, true);
                grid.CreateGrid(true);

            })
            .catch(function (jqXHR, textStatus, err) {
                alert('Error : ' + err + " " + textStatus);
            });
    }


    /* This  method use to bind the My Notification Settings Tab
            *  */
    Notifications.prototype.bindMyNotificationSettings = function () {
        service = new Service('/Notifications/GetTodaysNotification', 'application/html; charset=utf-8', 'html', null);
        service.get()
            .then(function (resp) {
                var myNotificationData = _.map(resp, function (x) {
                    return {
                       
                        IsScreen: x.isOnScreen,
                        IsEmail: x.isEmail,
                        IsMobile: x.isMobile,
                        NotificationId: x.notificationId,
                        Description: x.description,                       
                        //Topic: _.chain(x.topic).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        Topic: x.topics,
                        Locations: x.locations,
                        //Locations: _.chain(x.location).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        View: ' <span class="Show_details defaultIcons"></span> ',
                        Edit: ' <span class="Edit  defaultIcons"></span>'
                    };
                });

                var column = [
                    { "data": "NotificationId" },
                    { "data": "Description", "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": "Topic", "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": "Locations", "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": 'View' },
                    { "data": 'Edit' }
                ];

                var grid = new CustomGrid('#notificationSettingsTable', myNotificationData, column, true, true);
               
                grid.CreateGrid(false,true);

            })
            .catch(function (jqXHR, textStatus, err) {
                console.log(jqXHR.stack);
                alert('Error : ' + jqXHR.message + " " + textStatus);
            });
    }

    Notifications.prototype.bindConfigureNotifications = function () {
        service = new Service('/Notifications/GetTodaysNotification', 'application/html; charset=utf-8', 'html', null);  
        service.get()
            .then(function (resp) {
                var configureNotificationData = _.map(resp, function (x) {
                    return {
                        NotificationId: x.notificationId,
                        Description: x.description.substring(0, 20),                        
                       // DisableNotification: x.disableNotification,                       
                        //Topic: _.chain(x.topic).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value()
                        Topic: x.topics,
                        Locations: x.locations,
                        //Locations: _.chain(x.location).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        Start:moment(x.startDate).format("DD/MM/YYYY"),                        
                        End: moment(x.endDate).format(" DD/MM/YYYY"),
                        Disable: x.disableNotification ? '<td><label class="container"  class="textLabel"><input type="checkbox" id="disableNotification" checked data-error="*Mandatory Field" required><span class="checkmark" id="disableNotification"></span></label></td>' : '<td><label class="container"  class="textLabel"><input type="checkbox" id="disableNotification"  data-error="*Mandatory Field" required><span class="checkmark" id="disableNotification"></span></label></td>',
                        IsScreen: x.isOnScreen,
                        IsEmail: x.isEmail,
                        IsMobile: x.isMobile,
                        Created: moment(x.startDate).format(" DD/MM/YYYY"),
                        CreatedBy: x.createdBy,
                        Modified: moment(x.modifiedDate).format(" DD/MM/YYYY"),
                        ModifiedBy: x.modifiedBy,
                        View: ' <span class="Show_details defaultIcons"></span> ',
                        Edit: ' <span class="Edit  defaultIcons"></span>',
                        //Audience: _.chain(x.audienceGroup).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        //Recipients: _.chain(x.recipients).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        Audience: x.audience,
                        Recipients: x.recipient,
                        DisableNotification:x.disableNotification,
                   
                        Additional:x.URL                                                               
                    };
                });

                var column = [
                    { "data": "NotificationId"},
                    { "data": "Description", "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": "Topic", "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": "Locations", "render": CustomGrid.prototype.Ellipsis.call(this, 15) },
                    { "data": "Created" },
                    { "data": "End" },
                    { "data": "Disable" },
                    { "data": "Modified" },
                    { "data": "ModifiedBy" },
                    { "data": 'View' },
                    { "data": 'Edit' }
                ];

                var grid = new CustomGrid('#ConfigureNotificationTable', configureNotificationData, column, true, true);

                grid.CreateGrid(false, true);
            })
            .catch(function (jqXHR, textStatus, err) {
                alert('Error : ' + err + " " + textStatus);
            });
    }

   

    Notifications.prototype.updateConfigureNotifications = function (aData) {
      
        var notificationVM = {};
        notificationVM.notificationId = aData['NotificationId'];
        notificationVM.disableNotification = aData['DisableNotification'];
        var service = new Service('/Notifications/Edit', 'application/json; charset=utf-8', 'json', notificationVM);

        service.save().done(function () {
            //  alert('Success');
            $('.refreshMessage').css('display', 'block');
            $('.refreshMessage').css("background-color", "#A5CB68");
            $('.refreshMessage #msg').text("Success");
        }).fail(function (jqXHR, textStatus, errorThrown) {
            alert(errorThrown);
        });
       
       
    }
    return Notifications;

})();

