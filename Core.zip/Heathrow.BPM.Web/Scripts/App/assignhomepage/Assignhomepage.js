﻿(function ($) {
    'use strict';

    $('#aAssignHomePage').on('click', function SettingsController() {
        window.location.href = '/AssignHomePage/Index/';
    });

    
})(jQuery);