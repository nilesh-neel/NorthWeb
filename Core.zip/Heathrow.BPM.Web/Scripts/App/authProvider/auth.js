﻿//----------------------------------------------------------------------
//Class Name   : auth provider
//Purpose      : This is file use to handel authentication logic at client side
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

(function ($) {
    /* 'use strict';
     var applicationConfig = {
         clientID: '854de9ef-285c-43b1-85f6-a405cf75d4bc',
         authority: "https://login.microsoftonline.com/common/v2.0/",
         scope: ["openid email profile offline_access"],
         endpoint: 'https://localhost:44300/',
     };
 
     var myMSALObj = new Msal.UserAgentApplication(applicationConfig.clientID, applicationConfig.authority, acquireTokenRedirectCallBack,
         { storeAuthStateInCookie: true, cacheLocation: "localStorage" });
 
     function signIn() {
         myMSALObj.loginRedirect(applicationConfig.graphScopes).then(function (idToken) {
             //Login Success
             //showWelcomeMessage();
             //acquireTokenPopupAndCallMSGraph();
         }, function (error) {
             console.log(error);
         });
     }
 
     function acquireTokenPopupAndCallMSGraph() {
         //Call acquireTokenSilent (iframe) to obtain a token for Microsoft Graph
         myMSALObj.acquireTokenSilent(applicationConfig.graphScopes).then(function (accessToken) {
             callMSGraph(applicationConfig.graphEndpoint, accessToken, graphAPICallback);
         }, function (error) {
             console.log(error);
             // Call acquireTokenPopup (popup window) in case of acquireTokenSilent failure due to consent or interaction required ONLY
             if (error.indexOf("consent_required") !== -1 || error.indexOf("interaction_required") !== -1 || error.indexOf("login_required") !== -1) {
                 myMSALObj.acquireTokenPopup(applicationConfig.graphScopes).then(function (accessToken) {
                     callMSGraph(applicationConfig.graphEndpoint, accessToken, graphAPICallback);
                 }, function (error) {
                     console.log(error);
                 });
             }
         });
     }
 
     */

})(jQuery);