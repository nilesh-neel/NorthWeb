﻿//----------------------------------------------------------------------
//Class Name   : CustomGrid
//Purpose      : This is Custome Grid Class js file use to create the default JqData Table object with common css and other. 
//               mandantory features like order enable/disable paginate etc... 
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

var CustomGrid = (function () {
    'use strict';
 
    /****
   * Creates a new Alert object.
   * @constructor
   * @param {string} tableDiv pass the div id to configure the table.
   * @param {object} tableData pass the data to bind the table.
   * @param {object} tableColumn pass the number of column to bind the JqData Table
   * @param {bool} showDetails pass boolean value to show view detils button 
   * @param {bool} allowEdit pass boolean value to show edit detils button
   */
    CustomGrid = function (tableDiv, tableData, tableColumn, showDetails, allowEdit) {
        this.GridDivName = tableDiv;
        this.Data = tableData;
        this.Column = tableColumn;
        this.AllowShow = _.isNull(showDetails) || _.isUndefined(showDetails) ? false : true;
        this.AllowEdit = _.isNull(allowEdit) || _.isUndefined(allowEdit) ? false : true;
        this.resp = true;
        //this.TableObject = $(this.GridDivName).dataTable();
    };

    function triggerRowExpansion(nTr, prevClickedIcon, otable, me, tempName) {
        if ($(nTr).find(prevClickedIcon).hasClass('customBorderSmall')) {
            $(nTr).find(prevClickedIcon).closest("tr").find("td").toggleClass("showDetailsActive");
            $(nTr).find(prevClickedIcon).next().toggleClass("clickedIcons");
            $(nTr).find(prevClickedIcon).toggleClass("customBorderSmall");
            $(nTr).find(prevClickedIcon).closest("td").find("span").removeClass("clickedIcons");
            otable.fnClose(nTr);
        }

        if (otable.fnIsOpen(nTr)) {
            /* This row is already open - close it */
            otable.fnClose(nTr);
            $(me).closest("tr").find("td").toggleClass("showDetailsActive");
            $(me).removeClass("clickedIcons");
            $(me).toggleClass("customBorderSmall");
            $(me).next().toggleClass("clickedIcons");
            $(nTr).find(prevClickedIcon).closest("td").find("span").toggleClass("clickedIcons");
            // $("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
        }
        else {
            /* Open this row */
            $(me).closest("tr").find("td").toggleClass("showDetailsActive");
            $(me).addClass("clickedIcons");
            $(me).next().toggleClass("clickedIcons");
            $(me).toggleClass("customBorderSmall");
            $(nTr).find(prevClickedIcon).closest("td").find("span").toggleClass("clickedIcons");
            otable.fnOpen(nTr, tempName(otable, nTr), 'details');
            //$("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
        }
    }

    CustomGrid.prototype.CreateGrid = function (configForAlert, configForNotify) {

        $(this.GridDivName).dataTable({
            "data": this.Data,
            "columns": this.Column,
            "pagingType": 'full_numbers',
            "ordering": false,
            "info": false,
            "bLengthChange": false,
            "bAutoWidth": false,
            "searching": false,
            "responsive": true,
            "oLanguage": {
                "oPaginate": {
                    "sFirst": 'First',
                    "sNext": '<img class="Next" src="" />',
                    "sPrevious": '<img class="Previous" src="" />',
                    "sLast": 'Last'
                }
            },
            "fnDrawCallback": function (oSettings) {
                $('span.Show_details').closest('td').addClass('showdetailsTDstyle');
                $('span.Edit').closest('td').addClass('showdetailsTDstyle');
                $('table tr td label.container').closest('td').addClass('tableCheckmarkStyleOveride');

            },
            "bDestroy": true
        });

        if (this.AllowShow) {
            CustomGrid.prototype.ShowDetails.call(this);
            
        }
     

        if (this.AllowEdit) { this.EditRow(configForAlert, configForNotify); }
        if (this.resp) { CustomGrid.prototype.Response.call(this); }

            }

    CustomGrid.prototype.ShowDetails = function () {
        $(this.GridDivName + ' tbody td').on('click', '.Show_details', function () {
            var me = this;
            var Edit = '.Edit';
            var tableName = $(this).closest('table').attr('id');

            var oTable = $(this).parents('table').dataTable();
            var nTr = $(this).parents('tr')[0];
             var aData = oTable.fnGetData(nTr);
            // var id = aData['NotificationId'];
            
            var oTable = $(this).parents('table').dataTable();
            triggerRowExpansion(nTr, Edit, oTable, me, fnFormatNotification);
            $("#email").prop('checked', aData['IsEmail']);
            $("#mobile").prop('checked', aData['IsMobile']);
            $("#disable").prop('checked', aData['Disable']);
            $("#sub").prop('checked', aData['IsSubscribe']);
            $("#screen").prop('checked',aData['IsScreen']);
         
        
        });
    }

   

    CustomGrid.prototype.Response = function () {
        var notification = new Notifications();
        var alert = new Alert();
        
        $(".checkmark").click(function (e) {           
            var oTable = $(this).parents('table').dataTable();          
            var nTr = $(this).parents('tr')[0];
            var aData = oTable.fnGetData(nTr);
            if (e.target.id == "disableNotification") {
            aData['DisableNotification'] ? aData['DisableNotification'] = false : aData['DisableNotification'] = true;           
            notification.updateConfigureNotifications(aData);
        }            
      else {
                if (aData['MandatoryOptional'] == 'Optional'){
                 if (e.target.id == "sub") {
                   aData['IsSubscribe'] ? aData['IsSubscribe'] = false : aData['IsSubscribe'] = true;
                 }}
                if(e.target.id=="gridEmail") {
                    aData['IsEmail'] ? aData['IsEmail'] = false : aData['IsEmail'] = true;
                }
                if (e.target.id=="gridMobile") {
                    aData['IsMobile'] ? aData['IsMobile'] = false : aData['IsMobile'] = true;
                }
                aData['title'] = 'subscription';
                alert.bindResponse(aData);
            }

        });
      
   //     $('.IconsStyles').on('click', function (e) {
             //    var aData = [];
             //    var oTable = $(this).parents('table').dataTable();
             //    var nTr = $(this).parents('tr')[0];
             //    var gridData = oTable.fnGetData(nTr);
      //   var y = e.target.parentElement.parentElement.tagName;      
        /*     switch(e.target.className){
                 case "Tick_mark_Fill": e.target.className = "Tick_mark_Fill_white";
                     aData['IsAcknowledge'] = false;
                     break;
                 case "Tick_mark_Fill_white": e.target.className = "Tick_mark_Fill";
                     aData['IsAcknowledge'] = true;
                     break;
                 case "ignore_red_fill": e.target.className = "ignore_white_fill";
                     aData['IsIgnore'] = false;
                     break;
                 case "ignore_white_fill": e.target.className = "ignore_red_fill";
                     aData['IsIgnore'] = true;
                     break;
                 case "blank_out_yellow_fill": e.target.className = "blank_out_white_fill";
                     aData['IsBlank'] = false;
                     break;
                 case "blank_out_white_fill": e.target.className = "blank_out_yellow_fill";
                     aData['IsBlank'] = true;
                     break;
             }
             if (e.target.parentElement.parentElement.tagName == 'TD') {
            
             aData['AlertId'] = gridData['AlertId'];
             aData['title'] = 'response';
             
            }
       else
        {      
        aData['AlertId'] = e.target.parentElement.parentElement.childNodes[1].innerText;
        aData['title'] = 'response';
        }

    alert.bindResponse(aData);    */
//});
   
}

    CustomGrid.prototype.EditRow = function (configAlertTab, configNotifyTab) {
    
      //Row expansion
        $(this.GridDivName + ' .Edit').click(function () {                       
            var me = this;
            var Show_details = '.Show_details';
            var tableName = $(this).closest('table').attr('id');
                
            var nTr = $(this).parents('tr')[0];
            var oTable = $(this).parents('table').dataTable();
            var aData = oTable.fnGetData(nTr);
           
            if(configAlertTab)
            {
               
                if (oTable['0'].id == 'alertSettingTable') {                   
                    triggerRowExpansion(nTr, Show_details, oTable, me, fnFormatEdit);
                    var id = aData['AlertId'];
                    $('#load').load('Alerts/AlertSetting/' + id);
                  /*  $.ajax({
                        url: 'Alerts/AlertSetting/' + id,
                        contentType:'application/html; charset=utf-8',
                        type: 'GET',
                        datatype: 'html'
                    }).success(function (result) {
                        $('#load').load(result);
                    }).error(function (xhr, status) {
                        console.log(status);
                    })*/
                }
                else {
                    triggerRowExpansion(nTr, Show_details, oTable, me, fnFormatEdit);
                    var id = aData['AlertId'];
                    $('#load').load('Alerts/Edit/' + id);
                }
            }
            if(configNotifyTab)
            {
                
                if (oTable['0'].id == 'notificationSettingsTable') {
                    //  triggerRowExpansion(nTr, Show_details, oTable, me, fnFormatNotification);
                    triggerRowExpansion(nTr, Show_details, oTable, me, fnFormatEdit);
                    var id = aData['NotificationId'];
                    $('#load').load('Notifications/NotificationSetting/' + id);

                }
                else {
                    triggerRowExpansion(nTr, Show_details, oTable, me, fnFormatEdit);
                    var id = aData['NotificationId'];
                    $('#load').load('Notifications/Edit/' + id);
                }
           
            }
           

            $('#sub').attr('checked', aData['IsSubscribe']);
            $('#sub').attr('disabled', (aData['MandatoryOptional']=='Optional')?true:false);
            $("#disable").attr('checked', aData['Disable']);
            $("#screen").attr('checked', aData['IsScreen']);
            $("#email").attr('checked', aData['IsEmail']);
            $("#mobile").attr('checked', aData['IsMobile']);
            });
     
        
        //End of Row Expansion

            $('#cancel').click(function () {
                alert('cancel click');
                var me = this;
                var Show_details = '.Show_details';
                var tableName = $(this).closest('table').attr('id');

                var nTr = $(this).parents('tr')[0];
                var oTable = $(this).parents('table').dataTable();
                triggerRowExpansion(nTr, Show_details, oTable, me, fnFormatEdit);
            });
   

    }

    CustomGrid.prototype.Ellipsis = function (cutoff) {
        return function (data, type, row) {
            return data.length > cutoff ? data.substr(0, cutoff) + '…' : data;
        }
    }

    CustomGrid.prototype.CommaSeperatedString = function (listToSplit) {
        return _.chain(listToSplit).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value();
    }


    return CustomGrid;
})();