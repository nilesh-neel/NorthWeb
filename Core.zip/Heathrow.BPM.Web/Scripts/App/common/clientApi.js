﻿////----------------------------------------------------------------------
////Class Name   : Client Api 
////Purpose      : In this file we user axiosjs for teh get CRUD operation from Web Api call.
////               Whit this ajax call we can achive promise in javascripts. 
////Created By   : Nilesh More
////Created Date : 18/Sep/2018
////Version      : 1.0
////History      :
////Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
////<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
////----------------------------------------------------------------------


//var ClientApi = (function (axios) {
//    'use strict';

//    var baseUrl = "https://localhost:44318/";


//    /**
//     * Creates a new Service object.
//     * @constructor
//     * @param {string} url the controller or api url
//     * @param {object} data the data to send to serve for the post call
//     * @param {string} contentType the ajax call content Type like(application/json Or application/html) or api url
//     */
//    ClientApi = function (url, data, contentType) {
//        // this.requestURL = baseUrl + url;
//        //this.requestContentType = _.isNull(contentType) || _.isUndefined(contentType)
//        //    ? 'application/json; charset=utf-8'
//        //    : contentType;
//        //this.requestDataType = _.isNull(dataType) || _.isUndefined(dataType) ? 'json' : dataType;
//        this.requestData = _.isNull(data) || _.isUndefined(data) ? null : data;
//        //this.requestMultipleCall = callArray;


//        axios.defaults.baseURL = baseUrl + url;
//        axios.defaults.headers.common['Authorization'] = 'AUTH_TOKEN';
//        axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
//        axios.defaults.headers.get['Content-Type'] = _.isNull(contentType) || _.isUndefined(contentType)
//            ? 'application/json; charset=utf-8';

//    };


//    /**
//    // ajax authentication call only.
//* @param {string} authToken
//                                  */


//    axios.interceptors.request.use(function (config) {
//        var originalRequest = config;
//        if (config.baseURL !== baseUrl + 'api/token') {
//            return ax.get(baseUrl + 'api/token').then(function (token) {
//                originalRequest['Authorization'] = 'Bearer ' + token;
//                return Promise.resolve(originalRequest);
//            });
//        }
//        return config;
//    }, function (err) {
//        return Promise.reject(err);
//    });



//    ClientApi.prototype.get = function () {
//        try {
//            return ax.get({ type: 'get' });
//        } catch (error) {
//            console.error(error)
//        }
//    };


//    return ClientApi;
//})(axios);