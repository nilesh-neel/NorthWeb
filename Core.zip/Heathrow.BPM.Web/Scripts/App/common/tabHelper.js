﻿//----------------------------------------------------------------------
//Class Name   : TabConfig
//Purpose      : Purpose of this file to configure the default tab behaviour in Alert/Notifications Module's.
//               mandantory features like order enable/disable paginate etc... 
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

var TabConfig = (function () {
    'use strict';

    /****
   * Creates a new Alert object.
   * @constructor
   * @param {string} configForAlert pass the div id to configure the alert tab.
   * @param {string} configForNotify pass the div id to configure the notification tab
   * @param {string} configForReport pass the div id to configure the report tab
   * @param {string} configForAssignHome pass the div id to configure the assign home page tab
   *
   */
    TabConfig = function (configForAlert, configForNotify, configForReport, configForAssignHome) {
        this.AlertTab = _.isNull(configForAlert) || _.isUndefined(configForAlert) ? false : true;
        this.NotificationTab = _.isNull(configForNotify) || _.isUndefined(configForNotify) ? false : true;
        this.ReportTab = _.isNull(configForReport) || _.isUndefined(configForReport) ? false : true;
        this.AssignHomeTab = _.isNull(configForAssignHome) || _.isUndefined(configForAssignHome) ? false : true;
    };

    TabConfig.prototype.AlertTab = function () {
        $(this.GridDivName + ' .Edit').click(function () {
            $("#alertSettingTable_wrapper,#configureAlertsTable_wrapper,#tabs a[href='#alertSettings'],#tabs a[href='#todaysAlerts']").css('display', 'none');
            $('#congigureNewAlertBtn').css('display', 'none');
            $('#configureBackBtn').css('display', 'block');
            $('.configureAlertForm').css('display', 'block');
            $('.configureAlertForm').load('Alerts/Edit');
            $('#congigureNewAlertBtn').text('Configure New Alert');
        });
    }

    TabConfig.prototype.NotificationTab = function () {
       
        $(this.GridDivName + ' tbody td').on('click', '.Show_details', function () {
            var nTr = $(this).parents('tr')[0];
            var oTable = $(this).parents('table').dataTable();
            if (oTable.fnIsOpen(nTr)) {
                /* This row is already open - close it */
                //this.src = "./images/Icons/DefaultIcons.png";
                $(this).closest('tr').find('td').toggleClass('showDetailsActive');
                $(this).toggleClass('clickedIcons');
                $(this).next().toggleClass('clickedIcons');
                oTable.fnClose(nTr);
                $('#verticalTabs').height($('.zeroStyling:nth-child(2)').height());
            }
            else {
                /* Open this row */
                //this.src = "./images/Icons/DefaultIcons.png";
                $(this).closest('tr').find('td').toggleClass('showDetailsActive');
                $(this).toggleClass('clickedIcons');
                $(this).next().toggleClass('clickedIcons');
                oTable.fnOpen(nTr, fnFormatDetails(oTable, nTr), 'details');
                $('#verticalTabs').height($('.zeroStyling:nth-child(2)').height());
            }
        });
    }


    TabConfig.prototype.NewConfigurationButtonClick = function () {

        var configDiv = _.lowerCase($('.tab-content .active').attr('id'));

        if (_.includes(configDiv, 'alert')) {
            $("#alertSettingTable_wrapper,#configureAlertsTable_wrapper,#tabs a[href='#alertSettings'],#tabs a[href='#todaysAlerts']").css('display', 'none');
            $('#congigureNewAlertBtn').css('display', 'none');
            $('#configureBackBtn').css('display', 'block');
            $('.configureAlertForm').css('display', 'block');
            $('.configureAlertForm').load('Alerts/Edit');
            $('#congigureNewAlertBtn').text('Configure New Alert');

        } else if (_.includes(configDiv, 'notification')) {
            $("#notificationSettingsTable_wrapper,#ConfigureNotificationTable_wrapper,#tabs a[href='#notificationSettings'],#tabs a[href='#configureNotifications'],#tabs a[href='#todaysNotifications']").css('display', 'none');
            $('.editNotificationTab').css('display', 'block');
            $('#configureBackBtn').css('display', 'block');
            $('.configureAlertForm').css('display', 'block');
            $('.configureAlertForm').load('Notifications/NewNotification');
          //  $('#congigureNewAlertBtn').text('New Notification');
        }
    }


    TabConfig.prototype.BackButtonClick = function () {

        var configDiv = _.lowerCase($('.tab-content .active').attr('id'));

        if (_.includes(configDiv, 'alert')) {
            $('#configureAlertsTable_wrapper').show();
            $('#alertSettingTable_wrapper').show();
            $('#configureBackBtn').css('display', 'none');
            $('.configureAlertForm').css('display', 'none');
            $('#congigureNewAlertBtn').css('display', 'block');
            $("#tabs a[href='#alertSettings'],#tabs a[href='#todaysAlerts']").css('display', 'block');
            $('#congigureNewAlertBtn').text('Configure New Alert');

        } else if (_.includes(configDiv, 'notification')) {
            $('#notificationSettingsTable_wrapper').show();
            $('#ConfigureNotificationTable_wrapper').show();
            $('#configureBackBtn').css('display', 'none');
            $('.configureAlertForm').css('display', 'none');
            $('.editNotificationTab').css('display', 'none');
            $('#congigureNewAlertBtn').css('display', 'block');
            $('#congigureNewAlertBtn').text('Configure New Notification');
            $("#tabs a[href='#notificationSettings'],#tabs a[href='#todaysNotifications'],#tabs a[href='#configureNotifications']").css('display', 'block');
            
        }
    }
  

    return TabConfig;

})();