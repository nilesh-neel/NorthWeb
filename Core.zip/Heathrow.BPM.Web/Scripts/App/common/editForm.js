﻿$(function () {

    $('#drpLocation').multiselect({
        includeSelectAllOption: true,

        columns: 1,
        placeholder: 'Select',
        search: true,

        texts: {
            placeholder: 'Select options', // text to use in dummy input
            search: 'Type here',         // search input placeholder text
            selectedOptions: ' selected',      // selected suffix text
            selectAll: 'Select all',     // select all text
            unselectAll: 'Unselect all',   // unselect all text
            noneSelected: 'None Selected'   // None selected text
        },
        minHeight: 150,   // minimum height of option overlay
        maxHeight: 150,   // maximum height of option overlay
        maxWidth: 245,
        selectAll: false
    });

   /* $("#datepicker").datepicker({
        changeMonth: true,
        changeYear: true,
       singleDatePicker: true,
      showDropdowns: true
    });*/


   
   // $("#datepicker").addClass("formCalendarIcon");
    
});
function OnSuccess(response) {

    $('.refreshMessage').css('display', 'block');
    $('.refreshMessage').css("background-color", "#A5CB68");
    $('.refreshMessage #msg').text("Success");
    switch(response)
    {
        case 'editAlertForm':$("#tabs a[href='#alertSettings']").click();
        break;
        case 'configureAlertForm':$("#tabs a[href='#configureAlerts']").click();
        break;
        case 'editNotificationForm': $("#tabs a[href='#notificationSettings']").click();
        break;
        case 'configureNotificationForm': $("#tabs a[href='#configureNotifications']").click();
        break;
    }

}

function OnFailure(response) {
    alert("Error occured.");
}

$('.datepicker').on('click', (function () {
    $(this).datepicker({
        changeMonth: true,
        changeYear: true,
        singleDatePicker: true,
        showDropdowns: true
    });
    $(this).addClass("formCalendarIcon");
}));


/*Row expansion Template Show Details */
function fnFormatNotification(oTable, nTr) {
    var aData;
    var sOut;
    //Row expansion  for notification Table
    if (oTable['0'].id == 'todaysNotificationTable')
    {
        aData = oTable.fnGetData(nTr);
        sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
        sOut += '<tr><td>Notification:</td><td>' + aData['Description'] + '</td></tr>';
        sOut += '<tr><td>Topic:</td><td>' + aData['Topic'] + '</td></tr>';
        sOut += '<tr><td>Location:</td><td>' + aData['Locations'] + '</td></tr>';      
        sOut += '<tr><td>&nbsp;</td><td><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" id="screen" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" id="email" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" id="mobile" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
        sOut += '</table>';
    }

    if (oTable['0'].id == 'notificationSettingsTable') {
         aData = oTable.fnGetData(nTr);
         sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
         sOut += '<tr><td>Notification Id:</td><td>' + aData['NotificationId'] + '</td></tr>';
         sOut += '<tr><td>Notification:</td><td>' + aData['Description'] + '</td></tr>';
         sOut += '<tr><td>Topic:</td><td>' + aData['Topic'] + '</td></tr>';
         sOut += '<tr><td>Location:</td><td>' + aData['Locations'] + '</td></tr>';       
     //    sOut += '<tr><td>&nbsp;</td><td>'+ aData['IsSubscribe'] ? '<label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" id="screen" data-error="*Mandatory Field" required><span class="checkmark"></span></label>' : '<label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" id="screen" data-error="*Mandatory Field" required><span class="checkmark"></span></label>'+ aData['IsEmail'] ? '<label class="container"  class="textLabel"><input type="checkbox" checked="checked" id="email" data-error="*Mandatory Field" required><span class="checkmark" id="email"></span></label>' : '<label class="container"  class="textLabel"><input type="checkbox" id="email" data-error="*Mandatory Field" required><span class="checkmark" id="email"></span></label>'+aData['IsMobile'] ? '<label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" id="mobile" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>' : '<label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" id="mobile" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
          sOut += '<tr><td>&nbsp;</td><td><label  for"On Screen" class="textLabel panelCheckBox">Application<input type="checkbox" id="screen" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" id="email" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" id="mobile" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td></tr>';
         sOut += '</table>';
    }
    else if (oTable['0'].id == 'ConfigureNotificationTable') {
       // sOut = fnFormatDetails(oTable, nTr);
        aData = oTable.fnGetData(nTr);
        var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
        sOut += '<tr><td>Notification Id:</td><td>' + aData['NotificationId'] + '</td></tr>';
        sOut += '<tr><td>Notification:</td><td>' + aData['Description'] + '</td></tr>';
        sOut += '<tr><td>Audience Group:</td><td>' + aData['Audience'] + '</td></tr>';
        sOut += '<tr><td>Recipients:</td><td>' + aData['Recipients'] + '</td></tr>';
        sOut += '<tr><td>Additional Information URL:</td><td>' + aData['Additional'] + '</td></tr>';

        sOut += '<tr><td>Topic:</td><td>' + aData['Topic'] + '</td></tr>';
        sOut += '<tr><td>Location:</td><td>' + aData['Locations'] + '</td></tr>';
        sOut += '<tr><td>Start Date:</td><td>' + aData['Start'] + '</td></tr>';
        sOut += '<tr><td>End Date:</td><td>' + aData['End'] + '</td></tr>';
        sOut += '<tr><td>Disable Notification</td><td><label for"Disable" class="textLabel panelCheckBox"><input type="checkbox" id="disable" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td></tr>';
       
        sOut += '<tr><td>&nbsp;</td><td><label  for"On Screen" class="textLabel panelCheckBox">Application<input type="checkbox" id="screen" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" id="email" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" id="mobile" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td></tr>';
        sOut += '<tr><td>Created By:</td><td>' + aData['CreatedBy'] + '</td></tr>';
        sOut += '<tr><td>Created:</td><td>' + aData['Created'] + '</td></tr>';
        sOut += '<tr><td>Modified By:</td><td>' + aData['ModifiedBy'] + '</td></tr>';
        sOut += '<tr><td>Modified:</td><td>' + aData['Modified'] + '</td></tr>';
        sOut += '</table>';
    }
        //Row expansion for alert Table
    else if (oTable['0'].id == 'todaysAlertTable') {
        aData = oTable.fnGetData(nTr);
        var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
        sOut += '<tr><td>Title:</td><td>' + aData['Title'] + '</td></tr>';
        sOut += '<tr><td>Time:</td><td>' + aData['Time'] + '</td></tr>';
        sOut += '<tr><td>Response:</td><td><p class="IconsStyles"><span class="' + (aData['IsAcknowledge'] ? 'Tick_mark_Fill' : 'Tick_mark_Fill_white') + '"></span> <span class="' + (aData['IsIgnore'] ? 'ignore_red_fill' : 'ignore_white_fill') + '"></span> <span class="' + (aData['IsBlank'] ? 'blank_out_yellow_fill' : 'blank_out_white_fill') + '"></span> </p></td></tr>';
        sOut += '<tr><td>Topic:</td><td>' + aData['Topic'] + '</td></tr>';
        sOut += '<tr><td>Location:</td><td>' + aData['Location'] + '</td></tr>';
        sOut += '</table>';
    }
    else if (oTable['0'].id == 'alertSettingTable')
    {
        aData = oTable.fnGetData(nTr);

        var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
        sOut += '<tr><td>Alert ID:</td><td>' + aData['AlertId'] + '</td></tr>';
        sOut += '<tr><td>Measure Name:</td><td>' + aData['Measure'] + '</td></tr>';
        sOut += '<tr><td>Title:</td><td>' + aData['Title'] + '</td></tr>';
        sOut += '<tr><td>Description:</td><td>' + aData['Description'] + '</td></tr>';
        sOut += '<tr><td>Topic:</td><td>' + aData['Topic'] + '</td></tr>';
        sOut += '<tr><td>Location:</td><td>' + aData['Location'] + '</td></tr>';
        sOut += '<tr><td>Threshold:</td><td>' + aData['Threshold'] + '</td></tr>';
        sOut += '<tr><td>Threshold Value:</td><td>' + aData['ThresholdValue'] + '</td></tr>';
        sOut += '<tr><td>Mandatory/Optional:</td><td>' + aData['MandatoryOptional'] + '</td></tr>';
        sOut += '<tr><td>Subscribe</td><td><label for"Disable" class="textLabel panelCheckBox"><input type="checkbox" id="sub" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td></tr>';
        sOut += '<tr><td>Snooze:</td><td>' + aData['Snooze'] + '</td></tr>';
       // sOut += '<tr><td>&nbsp;</td><td>' + aData['IsSubscribe'] ? '<label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" id="screen" data-error="*Mandatory Field" required><span class="checkmark"></span></label>' : '<label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" id="screen" data-error="*Mandatory Field" required><span class="checkmark"></span></label>' + aData['IsEmail'] ? '<label class="container"  class="textLabel"><input type="checkbox" checked="checked" id="email" data-error="*Mandatory Field" required><span class="checkmark" id="email"></span></label>' : '<label class="container"  class="textLabel"><input type="checkbox" id="email" data-error="*Mandatory Field" required><span class="checkmark" id="email"></span></label>' + aData['IsMobile'] ? '<label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" id="mobile" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>' : '<label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" id="mobile" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
        sOut += '<tr><td>&nbsp;</td><td><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" id="screen" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" id="email" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" id="mobile" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td></tr>';

        sOut += '</table>';
    }
    else if (oTable['0'].id == 'configureAlertsTable')
    {
        aData = oTable.fnGetData(nTr);

        var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
        sOut += '<tr><td>Alert ID:</td><td>' + aData['AlertId'] + '</td></tr>';
        sOut += '<tr><td>Measure Name:</td><td>' + aData['Measure'] + '</td></tr>';
        sOut += '<tr><td>Title:</td><td>' + aData['Title'] + '</td></tr>';
        sOut += '<tr><td>Audience:</td><td>' + aData['Audience'] + '</td></tr>';
        sOut += '<tr><td>Recipient:</td><td>' + aData['Recipients'] + '</td></tr>';


        sOut += '<tr><td>Description:</td><td>' + aData['Description'] + '</td></tr>';
        sOut += '<tr><td>Topic:</td><td>' + aData['Topic'] + '</td></tr>';
        sOut += '<tr><td>Location:</td><td>' + aData['Location'] + '</td></tr>';
        sOut += '<tr><td>Threshold:</td><td>' + aData['Threshold'] + '</td></tr>';
        sOut += '<tr><td>Threshold Value:</td><td>' + aData['ThresholdValue'] + '</td></tr>';

        sOut += '<tr><td>Frequency:</td><td>' + aData['Frequency'] + '</td></tr>';
        sOut += '<tr><td>Time Window:</td><td>' + aData['TimeWindow'] + '</td></tr>';
        sOut += '<tr><td>Mandatory/Optional:</td><td>' + aData['MandatoryOptional'] + '</td></tr>';
        sOut += '<tr><td>Start Date</td><td>' + aData['StartDate'] + '</td></tr>';
        sOut += '<tr><td>End Date</td><td>' + aData['EndDate'] + '</td></tr>';

        sOut += '<tr><td>Disable Alert</td><td><label for"Disable" class="textLabel panelCheckBox"><input type="checkbox" id="disable" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td></tr>';
        
        sOut += '<tr><td>&nbsp;</td><td><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" id="screen" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" id="email" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" id="mobile" data-error="*Mandatory Field" required disabled><span class="checkmark"></span></label></td></tr>';
        sOut += '<tr><td>Created By</td><td>' + aData['CreatedBy'] + '</td></tr>';
        sOut += '<tr><td>Created</td><td>' + aData['Created'] + '</td></tr>';
        sOut += '<tr><td>Modified By</td><td>' + aData['ModifiedBy'] + '</td></tr>';
        sOut += '<tr><td>Modified</td><td>' + aData['ModifiedDate'] + '</td></tr>';
        sOut += '</table>';
    }

    return sOut;
}

/*Row expansion Template Edit Details*/
function fnFormatEdit() {
    return '<div id=load></div>';
}