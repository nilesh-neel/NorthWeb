﻿/****************************************************************************************************************
Class Name   : Startup.cs 
Purpose      : Used as Owin Startup class to implements authentication and authorization in Application. 
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using Microsoft.Owin;
using Owin;
using Heathrow.BPM.Web.Configuration;
using System.Web.Routing;
using System.Web.Optimization;

[assembly: OwinStartup(typeof(Heathrow.BPM.Web.Startup))]
namespace Heathrow.BPM.Web
{

    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {

            Bootstrap.Initialise();
            //app.UseCors(CorsOptions.AllowAll);
            BuildConfiguration();
            ConfigureAuth(app);
           
        }


        private void BuildConfiguration()
        {
            // FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
    }
}