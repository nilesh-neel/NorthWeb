﻿using Heathrow.BPM.Web.Filters;
using System.Web.Mvc;

namespace Heathrow.BPM.Web.App_Start
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new BPMErrorHandler());
        }
    }
}