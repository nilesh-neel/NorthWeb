﻿/****************************************************************************************************************
Class Name   : DashboardController.cs 
Purpose      : Dashboard file use to set the user pic and get the token for the power bi reports.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Mvc;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Web.Controllers
{
    public class DashboardController : BaseController
    {
        private readonly IBpmPowerBi _bpmPowerBi;
        private readonly IUserModule _userModule;
        public DashboardController(IAuthProvider authProvider, IBpmPowerBi bpmPowerBi, IUserModule userModule)
        {
            _bpmPowerBi = bpmPowerBi;
            _userModule = userModule;
        }

        // GET: Dashboard
        public async Task<ActionResult> Index()
        {
            // Signal OWIN to send an authorization request to Azure.
            if (!Request.IsAuthenticated)
                RedirectToAction("SignIn", "Account");
            try
            {
                //ViewBag.Locations = new SelectList(await _userModule.GetUserLocation(), "Id", "Description");
                //ViewBag.JobRole = new SelectList(await _userModule.GetUserJobRole(), "Id", "Description");
                //byte[] byteArr = ((MemoryStream)await _userModule.GetUserProfilePhoto()).ToArray();
                //ViewBag.userPic = byteArr;
                return View();
            }
            catch (Exception)
            {
                RedirectToAction("SignIn", "Account");
            }

            return View();
        }

        [HttpGet]
        public async Task<ActionResult> GetData()
        {
            try
            {
                // _bpmPowerBi.GetEmbeddedTokenNativeApp();
                var token = await _bpmPowerBi.EmbedToken();

                if (string.IsNullOrEmpty(token))
                    RedirectToAction("SignIn", "Account");

                return Json(token, JsonRequestBehavior.AllowGet);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }
    }
}