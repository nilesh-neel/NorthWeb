﻿/****************************************************************************************************************
Class Name   : BagListController.cs 
Purpose      : This file is used to save the User's BagList data....
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System.Web.Mvc;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Web.Controllers
{
    public class BagListController : BaseController
    {
        private readonly IBagListModule _bagListModule;
        public string UserId = "1";// Get the logged-in userID from Session

        public BagListController(IBagListModule baglist)
        {
            _bagListModule = baglist;
        }
        // GET: BagList
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public JsonResult GetUserExistingBagtagsCount()
        {
            //string UserId = "Admin";
            int UserExistingBagtagsCnt = _bagListModule.GetUserExistingbagtagsCnt(UserId);
            return Json(UserExistingBagtagsCnt.ToString(), JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetUserExistingBagtags(string otherUserId)
        {
            string strUserExistingBagtags = _bagListModule.GetUserExistingbagtags(otherUserId);
            return Json(strUserExistingBagtags.ToString(), JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetMybaglistOtherUsers()
        {

            var UserListResponse = _bagListModule.LoadMybaglistOtherUsers();
            return Json(UserListResponse, JsonRequestBehavior.AllowGet);
        }

        [OutputCache(NoStore = true, Duration = 0)]
        [HttpPost]
        public ActionResult AddtoMyBaglist(string bagtaglist, int selectedBagtagCnt, string UserId)
        {
            int BagtagsCount = _bagListModule.SaveBagTags(bagtaglist, UserId);
            return Json(BagtagsCount, JsonRequestBehavior.AllowGet);
        }

        public ActionResult RemoveFrmMyBaglist(string bagtaglist, int selectedBagtagCnt, string UserId)
        {
            int BagtagsCount = _bagListModule.RemoveBagTags(bagtaglist, UserId);
            return Json(BagtagsCount, JsonRequestBehavior.AllowGet);
        }

    }
}