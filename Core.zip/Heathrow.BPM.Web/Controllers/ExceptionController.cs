﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Heathrow.BPM.Web.Controllers
{
    [AllowAnonymous]
    public class ExceptionController : Controller
    {
        public ActionResult Error(string message, string debug)
        {
            ViewBag.DebugMessage = message;
            ViewBag.DebugError = debug;
            return View("Error");
        }
    }
}