﻿/****************************************************************************************************************
Class Name   : Global.cs 
Purpose      : This is the mail startup file in the application. To handle all startup even in web app like
               Dependency injection, Route config / web api registrations etc...
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using Heathrow.BPM.Core;
using Heathrow.BPM.Core.Interface;
using Newtonsoft.Json;
using System.Web.Mvc;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Web.Controllers
{
    [Authorize]
    public class FilterController : BaseController
    {
        private readonly IFilterModule _filterModule;
        private readonly IMapper<FilterVM, FilterCollection> _filterMapper;
        // GET: Filter

        /// <inheritdoc />
        /// <summary>
        /// Initialize filter object and implemented constructor injection 
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="dataMapper"></param>
        public FilterController(IFilterModule filter, IMapper<FilterVM, FilterCollection> dataMapper)
        {
            _filterModule = filter;
            _filterMapper = dataMapper;
        }

        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public JsonResult GetFilterData()
        {
            var filterResult = _filterMapper.MapFrom(_filterModule.GetAllFilter());

            var actionResult = JsonConvert.SerializeObject(filterResult);

            return Json(actionResult, JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public JsonResult SaveFilters(FilterVM data)
        {
            int actionResult = _filterModule.SaveFilter(_filterMapper.MapTo(data));

            return Json(actionResult, JsonRequestBehavior.AllowGet);
        }

        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public JsonResult GetFilterByMenuID(int menuID)
        {
            string actionResult = JsonConvert.SerializeObject(_filterMapper.MapFrom(_filterModule.GetFilterByMenuID(menuID)));

            return Json(new { result = actionResult }, JsonRequestBehavior.AllowGet);
        }


        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public JsonResult GetFilterConfigurationDetails(int menuId)
        {
            string configResult = JsonConvert.SerializeObject(_filterMapper.MapFrom(_filterModule.GetFilterConfiguration(menuId)));
            return Json(new { result = configResult }, JsonRequestBehavior.AllowGet);
        }
    }
}