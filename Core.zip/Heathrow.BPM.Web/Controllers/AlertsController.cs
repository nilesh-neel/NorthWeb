﻿/****************************************************************************************************************
Class Name   : Alerts.cs 
Purpose      : Used as Owin Startup class to implements authentication and authorization in Application. 
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Interface;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Web.ViewModel;
using Newtonsoft.Json;
using System.IO;
using Heathrow.BPM.Business.Interface;
using System.Threading.Tasks;

namespace Heathrow.BPM.Web.Controllers
{
    
    public class AlertsController : BaseController
    {

        private readonly IMapper<AlertVM, Alerts> _map;
        // private readonly IAlertsModule _alertModule;
        private readonly IAlertsModule _alertModule;
        private readonly IMapper<LookUpVM, LookupEnt> LookUpMap;

        public AlertsController(IAlerts alerts, IMapper<AlertVM, Alerts> map,  ILookup _lookup, IMapper<LookUpVM, LookupEnt> _mapLookup)
        {
          //  _alertModule = alerts;
            _alertModule = new AlertsModule(alerts, _lookup);
            _map = map; 
            LookUpMap = _mapLookup;
        }

        // GET: Alerts
        public ActionResult Index()
        {           
            return PartialView("_LandingPage");
        }

        [HttpGet]
        //[Route("TodayAlerts")]
        public async Task<JsonResult> GetTodaysAlerts()
        {                     
            return Json(_map.MapFrom(await _alertModule.GetAlerts()), JsonRequestBehavior.AllowGet);
           
        }
        public async Task<ActionResult> NewAlert()
        {           
            AlertVM alertVm = new AlertVM()
            {  // alertId = "",
               // createdBy = "",
               // modifiedDate = "",
               // createdDate = "",
               // startDate = System.DateTime.Now,
               // endDate = System.DateTime.Now,
               // description = "",
                
                location = LookUpMap.MapFrom(await _alertModule.Bag_LocationList()),
                freq=LookUpMap.MapFrom(await _alertModule.Bag_FrequencyList()),
                timeWin=LookUpMap.MapFrom(await _alertModule.Bag_TimeWindowList()),
                measureName = LookUpMap.MapFrom(await _alertModule.Bag_MeasureList()),
                recipients = LookUpMap.MapFrom(_alertModule.RecipientList()),
                topic = LookUpMap.MapFrom(await _alertModule.Bag_TopicList()),
                threshold = LookUpMap.MapFrom(await _alertModule.Bag_ThresholdList()),
                audienceGroup=LookUpMap.MapFrom(_alertModule.AudienceList())
               
            };

            return PartialView("_NewAlert", alertVm);
        }
        [HttpPost]
        public async Task<ActionResult> NewAlert(AlertVM data)
        {
            var objNotifCore = _map.MapTo(data);
            int i = await _alertModule.Save(objNotifCore);
            return new EmptyResult();
        } 
        public async Task<ActionResult> Edit(string id)
        {
          
            AlertVM alertItem;
          

             alertItem =_map.MapFrom(await _alertModule.GetAlertsById(id));    
            alertItem.audienceGroup = LookUpMap.MapFrom(_alertModule.AudienceList());
            alertItem.recipients = LookUpMap.MapFrom(_alertModule.RecipientList());      
           // alertItem.timeWin = LookUpMap.MapFrom(_alertModule.TimeWindowList().OrderBy(x=>x.LookupTypeName));
            alertItem.location = LookUpMap.MapFrom(await _alertModule.Bag_LocationList());
            alertItem.freq = LookUpMap.MapFrom(await _alertModule.Bag_FrequencyList());
            alertItem.timeWin = LookUpMap.MapFrom(await _alertModule.Bag_TimeWindowList());
            alertItem.measureName = LookUpMap.MapFrom(await _alertModule.Bag_MeasureList());
            alertItem.topic = LookUpMap.MapFrom(await _alertModule.Bag_TopicList());
            alertItem.threshold = LookUpMap.MapFrom(await _alertModule.Bag_ThresholdList());
               
            //notificationItem = notList.Find(x => x.notificationId == id);

            return PartialView("_ConfigurNewAlert", alertItem);
        }

        public async Task<ActionResult> AlertSetting(string id)
        {

            AlertVM alertItem;


            alertItem = _map.MapFrom(await _alertModule.GetAlertsById(id));
            // notificationItem.topicEnt = LookUpMap.MapFrom(_lookupModule.GetLookupById(3));                
            alertItem.topic = LookUpMap.MapFrom(await _alertModule.Bag_TopicList());
            alertItem.threshold = LookUpMap.MapFrom(await _alertModule.Bag_ThresholdList());
            alertItem.measureName = LookUpMap.MapFrom(await _alertModule.Bag_MeasureList());
            alertItem.location = LookUpMap.MapFrom(await _alertModule.Bag_LocationList());
            //notificationItem = notList.Find(x => x.notificationId == id);

            return PartialView("_EditAlertSetting", alertItem);
        }
        [HttpPost]
        public async Task<ActionResult> Edit(AlertVM data)
        {
            var objAlertCore = _map.MapTo(data);
            int i = await _alertModule.Update(objAlertCore);
            return new EmptyResult();
        }

       /* [HttpGet]
        [Route("Get")]
      public ActionResult GetAll() => Json(_map.MapFrom(_alertModule.GetAlerts()), JsonRequestBehavior.AllowGet);*/


    }
}