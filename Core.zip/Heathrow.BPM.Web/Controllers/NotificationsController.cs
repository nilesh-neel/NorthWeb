﻿using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Web.ViewModel;
using System.IO;
using Newtonsoft.Json;
using System.Web.UI;

namespace Heathrow.BPM.Web.Controllers
{
    public class NotificationsController : Controller
    {
        private readonly IMapper<NotificationVM, Notification> Map;
        private static NotificationModule _notifyModule;

        public NotificationsController(INotification notify, ILookup _lookup, IMapper<NotificationVM, Notification> _map)
        {
            _notifyModule = new NotificationModule(notify, _lookup);
            Map = _map;
        }
        // GET: Notifications
 

        //Returns data to javascript to load in grid
        [HttpGet]
        //[Route("TodayNotification")]
        public JsonResult GetTodaysNotification()
        {
            List<NotificationVM> notificationVm;

            using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/notification.json")))
            {
                notificationVm = JsonConvert.DeserializeObject<List<NotificationVM>>(readFile.ReadToEnd());
            }

            return Json(notificationVm, JsonRequestBehavior.AllowGet);
        }

        public ActionResult NewNotification()
        {
            List<NotificationVM> notificationVm;
           
            using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/notification.json")))
            {
                notificationVm = JsonConvert.DeserializeObject<List<NotificationVM>>(readFile.ReadToEnd());

            }

           
            return PartialView("_NewNotification", notificationVm.FirstOrDefault());
        }

        //on click of edit icon, notification corresponding to the id is loaded in form
        public ActionResult Edit(string id)
        {          
            List<NotificationVM> notificationVm;
            NotificationVM notificationItem;
            using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/notification.json")))
            {
                notificationVm = JsonConvert.DeserializeObject<List<NotificationVM>>(readFile.ReadToEnd());

            }

            notificationItem = notificationVm.Find(x => x.notificationId == id);
            
            return PartialView("_ConfigurNotifications", notificationItem);
        }

        [HttpPost]
        public void Edit(NotificationVM data)
        {           
           var objNotifCore = Map.MapTo(data);
            List<NotificationVM> notificationVm;
            int i = _notifyModule.Save(objNotifCore);
       
            /*   if (_notifyModule.Save(objNotifCore).Equals(1))
                Response.Write(@"<script language='javascript'>alert('Data  success entered.');</script>");
            else
                Response.Write(@"<script language='javascript'>alert('Data failed entered.');</script>");
*/

            using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/notification.json")))
            {
                notificationVm = JsonConvert.DeserializeObject<List<NotificationVM>>(readFile.ReadToEnd());

            }
        }
    }
}