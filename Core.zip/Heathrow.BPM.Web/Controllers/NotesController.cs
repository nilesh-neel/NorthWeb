﻿/****************************************************************************************************************
Class Name   : NotesController.cs 
Purpose      : This file is used to save the User's newly added Notes data and also to display the existing Notes data.......
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using Heathrow.BPM.Core.Interface;
using System;
using System.Linq;
using System.Web.Mvc;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Web.ViewModel;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Web.Controllers
{
    //[CompressFilter]
    [Authorize]
    public class NotesController : BaseController
    {
        private readonly INotesModule _notesModule;
        private readonly IMapper<NotesVM, Notes> Map;

        public NotesController(INotesModule notes, IMapper<NotesVM, Notes> map)
        {
            _notesModule = notes;
            Map = map;
        }
        // GET: Notes
        [OutputCache(NoStore = true, Duration = 0)]
        [HttpPost]
        public ActionResult Notes(string bagtag, string flightnumber, string organisation)
        {
            var res = new JsonResult { };
            if (!string.IsNullOrEmpty(bagtag) || (!string.IsNullOrEmpty(organisation)))
            {
                var obj = Map.MapFrom(_notesModule.Fetch(bagtag, flightnumber, organisation));
                res = Json(obj, JsonRequestBehavior.AllowGet);
                ViewBag.NotesCount = obj.AsEnumerable().Count();
            }
            return res;
        }

        [HttpPost]
        public ActionResult DeleteNote(int noteId, string bagtag, string flightnumber, string organisation)
        {
            //notesModule.DeleteNotes(noteId, bagtag, flightnumber, organisation);
            //return null;

            var obj = Map.MapFrom(_notesModule.DeleteNotes(noteId, bagtag, flightnumber, organisation));
            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        // GET: Notes/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Notes/Create
        //public ActionResult Create()
        //{
        //    return View();
        //}

        // POST: Notes/Create


        [HttpPost]
        public ActionResult Create(NotesVM _notesVM)
        {
            try
            {
                // TODO: Add insert logic here
                if (!ModelState.IsValid && string.IsNullOrEmpty(_notesVM.Notedesc))
                    return null;

                var objNoteCore = Map.MapTo(_notesVM);
                var obj = Map.MapFrom(_notesModule.Save(objNoteCore));
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                return View();
            }

        }

    }
}
