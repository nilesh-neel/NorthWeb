﻿/****************************************************************************************************************
Class Name   : Global.cs 
Purpose      : This is the mail startup file in the application. To handle all startup even in web app like
               Dependency injection, Route config / web api registrations etc...
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using Heathrow.BPM.Core.Entity;
using System.Web.Mvc;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Web.ViewModel;
using System.Linq;
using System.Diagnostics;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Web.Controllers
{
    [AllowAnonymous]
    public class RegistrationController : Controller
    {

        private readonly IRegistrationModule _registrationModule;
        private readonly ILocationModule _locationModule;

        private readonly IMapper<RegistrationVM, Registration> _map;
        private readonly IMapper<LocationVM, LocationEnt> _mapLocation;

        public RegistrationController(IRegistrationModule registration, IMapper<RegistrationVM, Registration> map,
            IMapper<LocationVM, LocationEnt> mapLocation, ILocationModule location, ILookup lookup)
        {
            _registrationModule = registration;
            _locationModule = location;

            this._map = map;
            this._mapLocation = mapLocation;
        }

        // GET: Registration/Create
        public ActionResult RegistrationPage()
        {
            //     List < string > loc= _registrationModule.locationlist().Select(LookupEnt => LookupEnt.LookupName).ToList();
            var obj = new RegistrationVM()
            {
                myloc = _registrationModule.LocationList().Select(d => d.Description).ToList(),
                myrole = _registrationModule.RoleList().Select(LookupEnt => LookupEnt.Description).ToList(),
                AccessReason = "",
                Email = "",
                FirstName = "",
                LastName = "",
                Organization = "",
                SelectedJobRole = "",
                SelectedLocation = ""
            };


            Debug.Assert(obj != null);
            return View(obj);
        }

        // POST: Registration/Create
        [HttpPost]
        public ActionResult RegistrationPage(RegistrationVM data)
        {
            if (!ModelState.IsValid)
                return null;

            var objRegCore = _map.MapTo(data);

            /*     if (_registrationModule.Save(objRegCore).Equals(1))
                    Response.Write(@"<script language='javascript'>alert('Data  success entered.');</script>");
                else
                    Response.Write(@"<script language='javascript'>alert('Data failed entered.');</script>");
            */
            return View();

        }
        [HttpGet]
        [Route("Get")]
        public ActionResult GetAll()
        {

            return Json(
                _mapLocation.MapFrom(_locationModule.GetAllLocation()),
                JsonRequestBehavior.AllowGet);
        }

    }
}