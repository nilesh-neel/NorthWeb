﻿/****************************************************************************************************************
Class Name   : MenuController.cs 
Purpose      : In this controller we are loading the menu for the weg application.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Web.Http;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Web.ViewModel;
using Newtonsoft.Json;

namespace Heathrow.BPM.Web.Controllers.Api
{
    public class MenuController : BaseApiController
    {
        private readonly IMapper<MenuVM, Menu> _map;
        private readonly IMenuModule _menuModule;
        public MenuController(IMenuModule menuModule, IMapper<MenuVM, Menu> map, IUserModule userModule) : base(userModule)
        {
            _map = map;
            _menuModule = menuModule;
        }

        public async Task<IHttpActionResult> Get()
        {
            //List<MenuVM> menuVm;
            //using (StreamReader readFile = new StreamReader(System.Web.Hosting.HostingEnvironment.MapPath("~/Helper/DummyData/menu.json")))
            //{
            //    menuVm = JsonConvert.DeserializeObject<List<MenuVM>>(readFile.ReadToEnd());
            //}

            //return Json(menuVm);
            var data = await _menuModule.GetAllMenu();
            return Json(_map.MapFrom(await _menuModule.GetAllMenu()));
        }
    }
}
