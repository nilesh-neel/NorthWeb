﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Web.Controllers.Api
{
    public class UserProfileController : BaseApiController
    {
        private IRepository<Locations> _locationRepository;
        private IRepository<JobRoles> _jobRoleRepository;
        public UserProfileController(IUserModule userModule, IRepository<Locations> locationRepo, IRepository<JobRoles> jobRole) : base(userModule)
        {
        }



    }
}
