﻿using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Web.ViewModel;
using System;
using System.Threading.Tasks;
using System.Web.Http;
using Microsoft.Graph;

namespace Heathrow.BPM.Web.Controllers.Api
{
    public class FavoritesController : BaseApiController
    {
        private readonly IFavouriteModule _favoritesModule;
        private readonly IMapper<FavouritesVM, Favourites> _mapFav;
        public FavoritesController(IFavouriteModule fav, IMapper<FavouritesVM, Favourites> mapFav, IUserModule userModule) : base(userModule)
        {
            _favoritesModule = fav;
            _mapFav = mapFav;
        }
        [System.Web.Http.HttpGet]
        public async Task<IHttpActionResult> Get()
        {
            return Json(
                _mapFav.MapFrom(await _favoritesModule.GetUserFavourites("ASDASF234AS")));
        }
        //[System.Web.Http.HttpPost]
        [AcceptVerbs("POST", "PUT")]
        public async Task<IHttpActionResult> Post(string menuId, string url)
        {
            try
            {
                //if (!ModelState.IsValid)
                //    throw new ModelStateException(ModelState);
                var data = new FavouritesVM { menuId = Convert.ToInt32(menuId), url = url };

                var objFavCore = _mapFav.MapTo(data);
                objFavCore.UserId = "ASDASF234AS";
                var result = await _favoritesModule.Save(objFavCore);
                if (result != null)
                    return Json(_mapFav.MapFrom(result));

                return Json("Data save fail.");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }

        }
    }
}
