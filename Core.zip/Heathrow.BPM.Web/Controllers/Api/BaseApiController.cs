﻿using System.Linq;
using System.Web.Http;
using System.Web.Http.Cors;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Web.Controllers.Api
{
    //[EnableCors(origins: "*", headers: "*", methods: "*")]
    //  [Authorize(Roles = "*")]
    [HostAuthentication("OAuth2Bearer")]
    [Authorize]
    public class BaseApiController : ApiController
    {
        private readonly IUserModule _userModule;

        public BaseApiController(IUserModule userModule)
        {
            _userModule = userModule;
        }

        internal AzureAdUser LoginInUser
        {
            get
            {
                var userDetails = _userModule.GetUserDetailsAsync().Result;
                return userDetails != null
                    ? new AzureAdUser
                    {
                        Id = userDetails.Id,
                        Name = userDetails.DisplayName.Length <= 8 ? userDetails.DisplayName : userDetails.DisplayName.Substring(0, 8) + "...",
                        // LastName = userDetails.surname,
                        DisplayName = userDetails.DisplayName,
                        Email = string.IsNullOrEmpty(userDetails.Mail)
                            ? userDetails.UserPrincipalName
                            : userDetails.Mail,
                        Locations = userDetails.UsageLocation,
                        JobRoles = userDetails.JobTitle,
                        Phone = userDetails.BusinessPhones.FirstOrDefault(),
                        Organization = userDetails.CompanyName,
                        Avatar = null
                    }
                    : new AzureAdUser
                    {
                        DisplayName = "Dummy Name",
                        Email = "dummyname@xyzairway.com",
                        JobRoles = "xyzRole",
                        Organization = "xyzOrganization",
                        Locations = "xyzLocation",
                        Name = "Dummy",
                        Phone = "xxxxxxxxxx"
                    };
            }
        }
    }
}
