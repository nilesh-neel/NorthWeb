﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.Linq;


namespace Heathrow.BPM.Web.ViewModel
{
    public class NotificationVM
    {
       
        public int[] selectLocation { get; set; }
        public int selectedTopic { get; set; }
        public int selectedAudience { get; set; }
        public int selectedRecipient { get; set; }

        public string audience { get; set; }
        public string recipient { get; set; }
        public string locations { get; set; }
        public string notificationId { get; set; }
        public bool disableNotification { get; set; }
        public string description { get; set; }
        public string topics { get; set; }
        public string createdBy { get; set; }
        // [DataType(DataType.Date)]
        // [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public string modifiedBy { get; set; }
        public string dateAndTime { get; set; }
        public string startDate { get; set; }
        public string endDate { get; set; }
        public string modifiedDate { get; set; }
        public string createdDate { get; set; }      
        public string URL { get; set; }             
       

        //Response
      
        public bool isOnScreen { get; set; }
        public bool isEmail { get; set; }
        public bool isMobile { get; set; }

        //DropDown
        public IEnumerable<LookUpVM> topicEnt { get; set; }
        public IEnumerable<LookUpVM> audienceGroupEnt { get; set; }
        public IEnumerable<LookUpVM> recipientsEnt { get; set; }
        public IEnumerable<LookUpVM> locationEnt { get; set; }

  /*      public List<DemoLookUpVm> location { get; set; }
        public List<DemoLookUpVm> audienceGroup { get; set; }
        public List<DemoLookUpVm> recipients { get; set; }
        public List<DemoLookUpVm> topic { get; set; }
      
        public List<DemoLookUpVm> mandatoryOptionals { get; set; }
        public List<string> locationList { get; set; }

        public List<string> topicList { get; set; }
        public List<string> audienceGroupList { get; set; }
        public List<string> recipientList { get; set; }*/
    }
    public class NotificationMapping : IMapper<NotificationVM, Notification>
    {
        public NotificationVM MapFrom(Notification _input)
        {
            return BindCoreToViewModel(_input);
        }
        public IEnumerable<NotificationVM> MapFrom(IEnumerable<Notification> _input)
        {
            return _input.Select(x => BindCoreToViewModel(x));
        }

        public Notification MapTo(NotificationVM _input)
        {
            return BindViewModelToCore(_input);
        }

        public IEnumerable<Notification> MapTo(IEnumerable<NotificationVM> _input)
        {
            return _input.Select(x => BindViewModelToCore(x));
        }

        private static NotificationVM BindCoreToViewModel(Notification _input)
        {
            return new NotificationVM()
            {
                /*    Location = string.Join(",", _input.Locations.ToArray()),*/
                notificationId = _input.NotificationID,
                description = _input.Description,
                 topics = _input.Topic,
                createdBy = _input.CreatedBy,              
                disableNotification=_input.DisableNotification,              
                modifiedBy = _input.ModifiedBy,
                audience=_input.Audience,
                recipient=_input.Recipient,
                
                isOnScreen = _input.IsOnScreen,
                isEmail = _input.IsEmail,
                isMobile = _input.IsMobile,
                selectLocation = _input.SelectLocationId,
                locations=_input.Locations,
                startDate = _input.StartDate,
                modifiedDate = _input.ModifiedDate,
                endDate = _input.EndDate,
                dateAndTime=_input.DateAndTime,
                createdDate=_input.CreatedDate,
                selectedTopic = _input.SelectedTopic,
                selectedRecipient = _input.SelectedRecipients,
                selectedAudience = _input.SelectedAudienceGroup,
                URL = _input.HelpUrl
        };
        }

        private static Notification BindViewModelToCore(NotificationVM _input)
        {
            return new Notification()
            {
                NotificationID = _input.notificationId,
                Description = _input.description,
                Topic = _input.topics,
                CreatedBy = _input.createdBy,
                DisableNotification=_input.disableNotification,              
                ModifiedBy = _input.modifiedBy,
                Locations=_input.locations,
                Audience=_input.audience,
                Recipient=_input.recipient,

                StartDate = _input.startDate,
                EndDate = _input.endDate,
                ModifiedDate = _input.modifiedDate,
                DateAndTime=_input.dateAndTime,
                CreatedDate=_input.createdDate,

               
                IsOnScreen = _input.isOnScreen,
                IsEmail = _input.isEmail,
                IsMobile = _input.isMobile,
                SelectLocationId = _input.selectLocation,
              
                SelectedRecipients = _input.selectedRecipient,
                SelectedAudienceGroup = _input.selectedAudience,
                SelectedTopic = _input.selectedTopic,
                HelpUrl = _input.URL
            };
        }
    }

}