﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Web.ViewModel
{
    public class AlertVM
    {


        public int[] selectLocation { get; set; }
        public int selectMeasure { get; set; }
        public int selectAudience { get; set; }
        public int selectRecipient { get; set; }
        public int selectThreshold { get; set; }
        public int selectTopic { get; set; }
        public int selectTimeWindow { get; set; }
        public int selectFrequency { get; set; }

        
        public string alertId { get; set; }
        public string description { get; set; }
        public string title { get; set; }
        public string time { get; set; }
        public string createdBy { get; set; }
        public string createdDate { get; set; }
        public string modifiedBy { get; set; }
        public string modifiedDate { get; set; }
        public string topics { get; set; }
        public string locations { get; set; }
        public string measure { get; set; }
        public string thresholds { get; set; }
        public string audience { get; set; }
        public string recipient { get; set; }
        public string frequency { get; set; }
        public int timeWindow { get; set; }
      
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }

        public string thresholdValue { get; set; }
        public string mandatoryOptional { get; set; }
        //response
        public bool isAcknowledge { get; set; }
        public bool isBlank { get; set; }
        public bool isIgnore { get; set; }


        public bool isSubscribe { get; set; }
        public bool isOnScreen { get; set; }
        public bool isEmail { get; set; }
        public bool isMobile { get; set; }
        public bool disableAlert { get; set; }
        public IEnumerable<LookUpVM> location { get; set; }
        public IEnumerable<LookUpVM> measureName { get; set; }
        public IEnumerable<LookUpVM> audienceGroup { get; set; }
        public IEnumerable<LookUpVM> recipients { get; set; }
        public IEnumerable<LookUpVM> topic { get; set; }
        public IEnumerable<LookUpVM> threshold { get; set; }
        public IEnumerable<LookUpVM> freq { get; set; }
        public IEnumerable<LookUpVM> timeWin { get; set; }

        


        /*    public List<DemoLookUpVm> location { get; set; }
            public List<DemoLookUpVm> measureName { get; set; }
            public List<DemoLookUpVm> audienceGroup { get; set; }
            public List<DemoLookUpVm> recipients { get; set; }
            public List<DemoLookUpVm> topic { get; set; }
            public List<DemoLookUpVm> threshold { get; set; }
            public List<DemoLookUpVm> mandatoryOptionals { get; set; }

        */
    }

    public class DemoLookUpVm
    {
        public string id { get; set; }
        public string name { get; set; }
        public bool isSelected { get; set; }
    }

    public class AlertMapping : IMapper<AlertVM, Alerts>
    {
        public AlertVM MapFrom(Alerts _input)
        {
            return BindCoreToViewModel(_input);
        }
        public IEnumerable<AlertVM> MapFrom(IEnumerable<Alerts> _input)
        {
            return _input.Select(x => BindCoreToViewModel(x));
        }

        public Alerts MapTo(AlertVM _input)
        {
            return BindViewModelToCore(_input);
        }

        public IEnumerable<Alerts> MapTo(IEnumerable<AlertVM> _input)
        {
            return _input.Select(x => BindViewModelToCore(x));
        }

        private static AlertVM BindCoreToViewModel(Alerts _input)
        {
            return new AlertVM()
            {

                alertId = _input.AlertId,              
                title = _input.Title,
                time=_input.Time,
                topics=_input.Topic,
                locations = _input.Location,
                measure=_input.Measure,
                thresholds=_input.Threshold,
                timeWindow=_input.TimeWindow,
                frequency=_input.Frequency,
               audience=_input.Audience,
               recipient=_input.Recipient,
               disableAlert=_input.DisableAlert,
                description=_input.Description,
                createdBy = _input.CreatedBy,
                createdDate = _input.CreatedDate,
                thresholdValue=_input.ThresholdValue,
                modifiedBy = _input.ModifiedBy,
                modifiedDate = _input.ModifiedDate,
                startDate=_input.StartDate,
                endDate=_input.EndDate,
                mandatoryOptional=_input.MandatoryOptional,
                isAcknowledge = _input.IsAcknowledge,
                isBlank = _input.IsBlank,
                isIgnore = _input.IsIgnore,
                isSubscribe=_input.IsSubscribe,
                isEmail=_input.IsEmail,
                isMobile=_input.IsMobile,
                isOnScreen=_input.IsOnScreen,

                selectAudience=_input.SelectedAudienceGroup,
                selectLocation=_input.SelectedLocation,
                selectMeasure=_input.SelectedMeasure,
                selectRecipient=_input.SelectedRecipients,
                selectThreshold=_input.SelectedThreshold,
                selectTopic=_input.SelectedTopic,
                selectFrequency=_input.SelectedFrequency,
                selectTimeWindow=_input.SelectedTimeWindow

            };
        }

        private static Alerts BindViewModelToCore(AlertVM _input)
        {
            return new Alerts()
            {

                AlertId = _input.alertId,
                Title = _input.title,
                Time = _input.time,
                Topic = _input.topics,
                Location = _input.locations,
                
                Description=_input.description,
                CreatedBy = _input.createdBy,
                CreatedDate = _input.createdDate,
                ThresholdValue=_input.thresholdValue,
                MandatoryOptional=_input.mandatoryOptional,
                ModifiedBy = _input.modifiedBy,
                ModifiedDate = _input.modifiedDate,
                StartDate = _input.startDate,
                EndDate = _input.endDate,
               
                IsAcknowledge = _input.isAcknowledge,
                IsBlank = _input.isBlank,
                IsIgnore = _input.isIgnore,
                IsSubscribe = _input.isSubscribe,
                IsEmail = _input.isEmail,
                IsMobile = _input.isMobile,
                IsOnScreen = _input.isOnScreen,

               SelectedAudienceGroup=_input.selectAudience,
               SelectedLocation=_input.selectLocation,
               SelectedMeasure=_input.selectMeasure,
               SelectedRecipients=_input.selectRecipient,
               SelectedThreshold=_input.selectThreshold,
               SelectedTopic=_input.selectTopic,
               SelectedFrequency=_input.selectFrequency,
               SelectedTimeWindow=_input.selectTimeWindow
               
             
            };
        }


    }
}