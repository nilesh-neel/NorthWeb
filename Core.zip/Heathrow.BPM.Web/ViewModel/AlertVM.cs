﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Web.ViewModel
{
    public class AlertVM
    {
        public string alertId { get; set; }
        public string description { get; set; }
        public string title { get; set; }

        public string createdBy { get; set; }
        public DateTime createdDate { get; set; }
        public string modifiedBy { get; set; }
        public DateTime modifiedDate { get; set; }

        //response
        public bool isAcknowledge { get; set; }
        public bool isBlank { get; set; }
        public bool isIgnore { get; set; }


        public bool isSubscribe { get; set; }
        public bool isOnScreen { get; set; }
        public bool isEmail { get; set; }
        public bool isMobile { get; set; }

        public List<DemoLookUpVm> location { get; set; }
        public List<DemoLookUpVm> measureName { get; set; }
        public List<DemoLookUpVm> audienceGroup { get; set; }
        public List<DemoLookUpVm> recipients { get; set; }
        public List<DemoLookUpVm> topic { get; set; }

        public List<DemoLookUpVm> threshold { get; set; }

        public List<DemoLookUpVm> mandatoryOptionals { get; set; }


    }

    public class DemoLookUpVm
    {
        public string id { get; set; }
        public string name { get; set; }
        public bool isSelected { get; set; }
    }


    public class AlertMapping : IMapper<AlertVM, Alerts>
    {
        public AlertVM MapFrom(Alerts _input)
        {
            return BindCoreToViewModel(_input);
        }
        public IEnumerable<AlertVM> MapFrom(IEnumerable<Alerts> _input)
        {
            return _input.Select(x => BindCoreToViewModel(x));
        }

        public Alerts MapTo(AlertVM _input)
        {
            return BindViewModelToCore(_input);
        }

        public IEnumerable<Alerts> MapTo(IEnumerable<AlertVM> _input)
        {
            return _input.Select(x => BindViewModelToCore(x));
        }

        private static AlertVM BindCoreToViewModel(Alerts _input)
        {
            return new AlertVM()
            {

                alertId = _input.AlertId,
                description = _input.Description,
                title = _input.Title,
               // topic = _input.Topic,
                createdBy = _input.CreatedBy,
                createdDate = _input.CreatedDate,
                // location = _input.Location,
                modifiedBy = _input.ModifiedBy,
                modifiedDate = _input.ModifiedDate,
                isAcknowledge = _input.isAcknowledge,
                isBlank = _input.isBlank,
                isIgnore = _input.isIgnore,
                isSubscribe=_input.IsSubscribe,
                isEmail=_input.IsEmail,
                isMobile=_input.IsMobile,
                isOnScreen=_input.IsOnScreen

            };
        }

        private static Alerts BindViewModelToCore(AlertVM _input)
        {
            return new Alerts()
            {

                AlertId = _input.alertId,
                Description = _input.description,
                Title = _input.title,
               // Topic = _input.topic,
                CreatedBy = _input.createdBy,
                CreatedDate = _input.createdDate,
                //Location = _input.location,
                ModifiedBy = _input.modifiedBy,
                ModifiedDate = _input.modifiedDate,
                isAcknowledge = _input.isAcknowledge,
                isBlank = _input.isBlank,
                isIgnore = _input.isIgnore,
                IsEmail = _input.isEmail,
                IsMobile = _input.isMobile,
                IsOnScreen = _input.isOnScreen
            };
        }


    }
}