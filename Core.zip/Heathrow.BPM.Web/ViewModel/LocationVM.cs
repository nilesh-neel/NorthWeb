﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Web.ViewModel
{
    public class LocationVM
    {
        public int LocationsID { get; set; }
        public string LocationsDesc { get; set; }
        // public List<LocationVM> Locationss { get; set; }
    }
    /* public class LocationsMapping : IMapper<LocationVM, Locations>
     {
         public LocationVM MapFrom(Locations _input)
         {
             return BindCoreToViewModel(_input);
         }


         public IEnumerable<LocationVM> MapFrom(IEnumerable<Locations> _input)
         {
             return _input.Select(x => BindCoreToViewModel(x));
         }

         public Locations MapTo(LocationVM _input)
         {
             return BindViewModelToCore(_input);
         }

         public IEnumerable<Locations> MapTo(IEnumerable<LocationVM> _input)
         {
             return _input.Select(x => BindViewModelToCore(x));
         }

         private static List<LocationVM> BindCoreToViewModel(List<Locations> _input)
         {
             return (from loc in _input
                     select (new LocationVM()
                     {
                         LocationsID = loc.LocationsID,
                         LocationsDesc = loc.LocationsDescription
                     })).ToList();
         }
         private static List<Locations> BindViewModelToCore(List<LocationVM> _input)
         {
             return (from loc in _input
                     select (new Locations()
                     {
                         LocationsID = loc.LocationsID,
                         LocationsDescription = loc.LocationsDesc
                     })).ToList();
         }
     }
     */
    public class LocationsMapping : IMapper<LocationVM, Locations>
    {
        public LocationVM MapFrom(Locations _input)
        {
            return BindCoreToViewModel(_input);
        }

        public IEnumerable<LocationVM> MapFrom(IEnumerable<Locations> _input)
        {
            return _input.Select(x => BindCoreToViewModel(x));
        }

        public Locations MapTo(LocationVM _input)
        {
            return BindViewModelToCore(_input);
        }

        public IEnumerable<Locations> MapTo(IEnumerable<LocationVM> _input)
        {
            return _input.Select(x => BindViewModelToCore(x));
        }

        private static LocationVM BindCoreToViewModel(Locations _input)
        {
            return new LocationVM()
            {
                LocationsID = _input.Id,
                LocationsDesc = _input.Description,

            };
        }

        private static Locations BindViewModelToCore(LocationVM _input)
        {
            return new Locations()
            {
                Id = _input.LocationsID,
                Description = _input.LocationsDesc,

            };
        }
    }

}