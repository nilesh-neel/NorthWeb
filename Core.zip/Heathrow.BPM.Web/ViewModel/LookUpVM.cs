﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace Heathrow.BPM.Web.ViewModel
{
    public class LookUpVM
    {
        public int rowId { get; set; }
        public int lookupTypeID { get; set; }
        public string lookupTypeName { get; set; }
        public string lookupName { get; set; }
        public int lookupID { get; set; }
        public bool isActive { get; set; }
    }

    public class LookUpMapping : IMapper<LookUpVM, LookupEnt>
    {
        public LookUpVM MapFrom(LookupEnt _input)
        {
            return BindCoreToViewModel(_input);
        }
        public IEnumerable<LookUpVM> MapFrom(IEnumerable<LookupEnt> _input)
        {
            return _input.Select(x => BindCoreToViewModel(x));
        }

        public LookupEnt MapTo(LookUpVM _input)
        {
            return BindViewModelToCore(_input);
        }

        public IEnumerable<LookupEnt> MapTo(IEnumerable<LookUpVM> _input)
        {
            return _input.Select(x => BindViewModelToCore(x));
        }

        private static LookUpVM BindCoreToViewModel(LookupEnt _input)
        {
            return new LookUpVM()
            {

                isActive = _input.IsActive,
                lookupID=_input.LookupID,
                lookupName=_input.LookupName,
                lookupTypeID=_input.LookupTypeID,
                lookupTypeName=_input.LookupTypeName,
                rowId=_input.RowID

            };
        }

        private static LookupEnt BindViewModelToCore(LookUpVM _input)
        {
            return new LookupEnt()
            {
                IsActive = _input.isActive,
                LookupID = _input.lookupID,
                LookupName=_input.lookupName,
                RowID=_input.rowId,
                LookupTypeID=_input.lookupTypeID,
                LookupTypeName=_input.lookupTypeName
            };
        }
    }
}