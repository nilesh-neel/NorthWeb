﻿using Heathrow.BPM.Core;
using Heathrow.BPM.Core.Interface;
using System.Collections.Generic;
using System.Linq;
namespace Heathrow.BPM.Web
{
    public class FilterVM
    {
        /// <summary>
        /// Filter ID
        /// </summary>
        public long FilterID { get; set; }

        /// <summary>
        /// UserID
        /// </summary>
        public string UserID { get; set; }

        /// <summary>
        /// Menu ID
        /// </summary>
        public int MenuID { get; set; }


        /// <summary>
        /// Filter Text
        /// </summary>
        public string FilterText { get; set; }

        public string ReportName { get; set; }

        /// <summary>
        /// Report ID
        /// </summary>
        public int ReportID { get; set; }


        /// <summary>
        /// Filter Selection
        /// </summary>
        public short FilterSelection { get; set; }

         public IList<FilterSelection> FilterItemSelection { get; set; }


        public IList<DropDownFilter> BagTypeList { get; set; }
        public IList<DropDownFilter> BagSystemList { get; set; }
        public IList<DropDownFilter> ShortConnectList { get; set; }
        public IList<DropDownFilter> OOGBagsList { get; set; }
        public IList<DropDownFilter> AfterChoxList { get; set; }
        public IList<DropDownFilter> DeletedBagsList { get; set; }
        public IList<DropDownFilter> MissedBRSList { get; set; }
        public IList<DropDownFilter> DeletedBSMList { get; set; }
        public IList<DropDownFilter> MyBagList { get; set; }
        public IList<DropDownFilter> InboundITOList { get; set; }

        public IList<DropDownFilter> InTargetList { get; set; }

        public IList<DropDownFilter> FailedMissedList { get; set; }
        public IList<DropDownFilter> FailedInSystemList { get; set; }

        public IList<FilterConfiguration> FilterConfigList { get; set; }
        public IList<FilterSelection> PBIMappingList { get; set; }
    }
    /// <summary>
    ///  Filter mapping 
    /// </summary>

    public class FilterMapping : IMapper<FilterVM, FilterCollection>
    {
        public FilterVM MapFrom(FilterCollection filterData)
        {
            return TransformEntityToViewModel(filterData);
        }
        public FilterCollection MapTo(FilterVM viewModelData)
        {
            return TransformViewModelToEntity(viewModelData);
        }

        public IEnumerable<FilterCollection> MapTo(IEnumerable<FilterVM> viewModelData)
        {
            return viewModelData.Select(m => TransformViewModelToEntity(m));
        }

        public IEnumerable<FilterVM> MapFrom(IEnumerable<FilterCollection> collParam)
        {
            return collParam.Select(y => TransformEntityToViewModel(y));
        }

        private static FilterVM TransformEntityToViewModel(FilterCollection filterColl)
        {
            if (filterColl == null)
            {
                return null;
            }

            var filterData = (filterColl.FilterText != null) ? Newtonsoft.Json.JsonConvert.DeserializeObject<IList<FilterSelection>>(filterColl.FilterText) : null;

            return new FilterVM()
            {
                BagSystemList = filterColl.BagSystemList,
                BagTypeList = filterColl.BagTypeList,
                AfterChoxList = filterColl.AfterChoxList,
                DeletedBagsList = filterColl.DeletedBagsList,
                DeletedBSMList = filterColl.DeletedBSMList,
                FailedInSystemList = filterColl.FailedInSystemList,
                MissedBRSList = filterColl.MissedBRSList,
                FailedMissedList = filterColl.FailedMissedList,
                InboundITOList = filterColl.InboundITOList,
                InTargetList = filterColl.InTargetList,
                MyBagList = filterColl.MyBagList,
                OOGBagsList = filterColl.OOGBagsList,
                ShortConnectList = filterColl.ShortConnectList,
                FilterID = filterColl.FilterID,
                MenuID = filterColl.MenuID,
                UserID = filterColl.UserID,
                FilterItemSelection = filterData,
                FilterConfigList = filterColl.FilterConfigurationList,
                PBIMappingList = filterColl.PBIMappingList,
                ReportID = filterColl.ReportID,
                ReportName = filterColl.ReportName
            };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        private static FilterCollection TransformViewModelToEntity(FilterVM viewModel)
        {
            if (viewModel == null) return null;

            var filterSelection = (viewModel.FilterItemSelection != null) ? Newtonsoft.Json.JsonConvert.SerializeObject(viewModel.FilterItemSelection) : string.Empty;

            return new FilterCollection()
            {
                FilterSelection = viewModel.FilterSelection,
                MenuID = viewModel.MenuID,
                UserID = viewModel.UserID,
                FilterText = filterSelection,
                FilterID = viewModel.FilterID
            };
        }

    }


}