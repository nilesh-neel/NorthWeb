﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System.ComponentModel.DataAnnotations;

namespace Heathrow.BPM.Web.ViewModel
{
    public class ShareVM
    {
        public int GroupId { get; set; }
        public string Groupname { get; set; }
        public int RecipientId { get; set; }
        public string Recipientname { get; set; }

        public List<Share> NotesList { get; set; }
    }

    public class ShareMapping : IMapper<ShareVM, Share>
    {
        public ShareVM MapFrom(Share _input)
        {
            return new ShareVM()
            {
                GroupId = _input.GroupId,
                Groupname = _input.Groupname,
                RecipientId = _input.RecipientId,
                Recipientname = _input.Recipientname

            };
        }


        public IEnumerable<ShareVM> MapFrom(IEnumerable<Share> _input)
        {
            return _input.Select(x => new ShareVM()
            {
                GroupId = x.GroupId,
                Groupname = x.Groupname,
                RecipientId = x.RecipientId,
                Recipientname = x.Recipientname
            });
        }

        public Share MapTo(ShareVM _input)
        {
            return new Share()
            {
                GroupId=_input.GroupId,
                Groupname=_input.Groupname,
                RecipientId=_input.RecipientId,
                Recipientname=_input.Recipientname

            };
        }

        public IEnumerable<Share> MapTo(IEnumerable<ShareVM> _input)
        {
            return _input.Select(x => new Share()
            {
                GroupId=x.GroupId,
                Groupname=x.Groupname,
                RecipientId=x.RecipientId,
                Recipientname=x.Recipientname
            });
        }

    }
}