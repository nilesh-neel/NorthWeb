﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Heathrow.BPM.Web.ViewModel
{
    public class NotesVM
    {
        public int NotesId { get; set; }
        public string Notedesc { get; set; }
        public string Bagtag { get; set; }
        public string Flightnumber { get; set; }
        public string Organization { get; set; }
        public int Ispublic { get; set; }
        public int Isdeleted { get; set; }
        public string UserId { get; set; }

        public string CreatedDatetime { get; set; }


        public List<Notes> NotesList { get; set; }
    }

    public class NotesMapping : IMapper<NotesVM, Notes>
    {
        public NotesVM MapFrom(Notes _input)
        {
            return new NotesVM()
            {
                NotesId = _input.NotesId,
                Notedesc = _input.Notedesc,
                Bagtag = _input.Bagtag,
                Flightnumber = _input.Flightnumber,
                Organization = _input.Organization,
                Ispublic = _input.Ispublic,
                Isdeleted = _input.Isdeleted,
                UserId = _input.UserId,
                CreatedDatetime = Convert.ToString(_input.CreatedDate)

            };
        }


        public IEnumerable<NotesVM> MapFrom(IEnumerable<Notes> _input)
        {
                return _input.Select(x => new NotesVM()
                {

                    NotesId = x.NotesId,
                    Notedesc = x.Notedesc,
                    Bagtag = x.Bagtag,
                    Flightnumber = x.Flightnumber,
                    Organization = x.Organization,
                    Ispublic = x.Ispublic,
                    Isdeleted = x.Isdeleted,
                    UserId = x.UserId,
                    CreatedDatetime = Convert.ToString(x.CreatedDate)
                    //NotesList = x.NotesListVal
                });
        }

        public Notes MapTo(NotesVM _input)
        {
            return new Notes()
            {
                NotesId = _input.NotesId,
                Notedesc = _input.Notedesc,
                Bagtag = _input.Bagtag,
                Flightnumber = _input.Flightnumber,
                Organization = _input.Organization,
                Ispublic = _input.Ispublic,
                Isdeleted = _input.Isdeleted,
                UserId = _input.UserId,
                CreatedDate = DateTime.Now

            };
        }

        public IEnumerable<Notes> MapTo(IEnumerable<NotesVM> _input)
        {
            return _input.Select(x => new Notes()
            {

                NotesId = x.NotesId,
                Notedesc = x.Notedesc,
                Bagtag = x.Bagtag,
                Flightnumber = x.Flightnumber,
                Organization = x.Organization,
                Ispublic = x.Ispublic,
                Isdeleted = x.Isdeleted,
                UserId = x.UserId,
                CreatedDate = DateTime.Now
            });
        }
    }
}