﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;


namespace Heathrow.BPM.Web.ViewModel
{
    public class RegistrationVM
    {
        [Required(ErrorMessage = "*Mandatory Field")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "*Mandatory Field")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "*Mandatory Field")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "*Mandatory Field")]
        public string Organization { get; set; }

        [Required(ErrorMessage = "*Mandatory Field")]
        public string SelectedJobRole { get; set; }
      //  public List<LookupEnt> JobRoles { get; set; }
        [Required(ErrorMessage = "*Mandatory Field")]
        public string SelectedLocation { get; set; }
        
      //  public List<LookupEnt> Locations { get; set; }
        public List<string> myloc { get;set; }
        public List<string> myrole { get; set; }
        [Required(ErrorMessage = "*Mandatory Field")]
        [StringLength(140)]
        public string AccessReason { get; set; }

    }
   
    public class RegistrationMapping : IMapper<RegistrationVM, Registration>
    {
        public RegistrationVM MapFrom(Registration _input)
        {
            return BindCoreToViewModel(_input);
        }


        public IEnumerable<RegistrationVM> MapFrom(IEnumerable<Registration> _input)
        {
            return _input.Select(x => BindCoreToViewModel(x));
        }

        public Registration MapTo(RegistrationVM _input)
        {
            return BindViewModelToCore(_input);
        }

        public IEnumerable<Registration> MapTo(IEnumerable<RegistrationVM> _input)
        {
            return _input.Select(x => BindViewModelToCore(x));
        }


        private static RegistrationVM BindCoreToViewModel(Registration _input)
        {
            return new RegistrationVM()
            {

                FirstName = _input.FirstName,
                LastName = _input.LastName,
                Email = _input.Email,
                Organization = _input.Organization,
                SelectedJobRole=_input.JobRole,
                SelectedLocation=_input.Location,
             /*   JobRoles = new List<LookupEnt> (){
                    new LookupEnt
                    {
                        LookupName="role",
                        LookupID=1,
                        IsActive= true
                    }
                },
                Locations = new List<LookupEnt>()
                {
                     new LookupEnt
                    {
                        LookupName="loc1",
                        LookupID=1,
                        IsActive= true
                    }
                },
                //Locations = BindLocaltionVM(_input.Locations),*/
                
                AccessReason = _input.AccessReason
            };

        }
      
       


        private static Registration BindViewModelToCore(RegistrationVM _input)
        {
            return new Registration()
            {

                FirstName = _input.FirstName,
                LastName = _input.LastName,
                Email = _input.Email,
                Organization = _input.Organization,
                 Location=_input.SelectedLocation,
                 JobRole=_input.SelectedJobRole,
               // Locations = BindLocaltionCore(_input.Locations),
                 AccessReason = _input.AccessReason
            };
        }
       

    }

   
 }