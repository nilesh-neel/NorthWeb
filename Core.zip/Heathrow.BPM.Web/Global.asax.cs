﻿/****************************************************************************************************************
Class Name   : Global.cs 
Purpose      : This is the mail startup file in the application. To handle all startup even in web app like
               Dependency injection, Route config / web api registrations etc...
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System;
using System.Web;

namespace Heathrow.BPM.Web
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            // We have Owin Start Up Class Hence, we moved all code in Owin Startup Class Method.
        }
        protected void Application_Error(object sender, EventArgs e)
        {
            //var ex = Server.GetLastError();
            //var httpContext = ((HttpApplication)sender).Context;
            //httpContext.Response.Clear();
            //httpContext.ClearError();
            //httpContext.Response.TrySkipIisCustomErrors = true;
            //Response.Redirect($"/Exception/Error?message=Aplication Level ERROR&debug={ex.Message}");
        }

    }
}