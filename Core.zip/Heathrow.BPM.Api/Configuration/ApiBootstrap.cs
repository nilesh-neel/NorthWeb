﻿using Heathrow.BPM.Business.Infrastructure;
using Heathrow.BPM.Core.Interface;
using Unity;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Web.ViewModel;
using Unity.Lifetime;
using Unity.Extension;

namespace Heathrow.BPM.Api.Configuration
{
    public class ApiBootstrap
    {
        public static void Initialise()
        {
            var container = BuildUnityContainer();
            //  GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }

        internal static IUnityContainer BuildUnityContainer()
        {
            var container = new UnityContainer();
            container.AddNewExtension<ChildDependencyExtension>();
            container.BindInRequestScope<IMapper<MenuVM, Menu>, MenuMapping>();
            container.BindInRequestScope<IMapper<FavouritesVM, Favourites>, FavouriteMapping>();


            return container;
        }

    }
    public static class UnityIocExtensions
    {
        public static void BindInRequestScope<T1, T2>(this IUnityContainer container) where T2 : T1
        {
            container.RegisterType<T1, T2>(new HierarchicalLifetimeManager());
        }

        public static void BindInSingletonScope<T1, T2>(this IUnityContainer container) where T2 : T1
        {
            container.RegisterType<T1, T2>(new ContainerControlledLifetimeManager());
        }
        public static void InjectStub<I>(this IUnityContainer container, I instance)
        {
            container.RegisterInstance(instance, new ContainerControlledLifetimeManager());
        }
        public static void AddExtension<T>(this IUnityContainer container) where T : UnityContainerExtension
        {
            container.AddNewExtension<T>();
        }
    }

}