﻿using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System.Web.Http;

namespace Heathrow.BPM.Api
{
    [RoutePrefix("api")]
    public class UserProfileController : BaseApiController
    {
        private IRepository<LocationEnt> _locationRepository;
        private IRepository<JobRoleEnt> _jobRoleRepository;
        public UserProfileController(IUserModule userModule, IRepository<LocationEnt> locationRepo, IRepository<JobRoleEnt> jobRole) : base(userModule)
        {
        }



    }
}
