﻿using System.Collections.Generic;
using Heathrow.BPM.Core.Entity;
using System.Threading.Tasks;

namespace Heathrow.BPM.Core.Interface
{
    public interface INotification
    {
       Task<Notification> GetNotificationByNotificationId(string _notificationId);
       Task<int> Save(Notification _notification);
       Task<IEnumerable<Notification>> GetTodaysNotification();
        Task<int> UpdateNotification(Notification notification);
      
        Task<IEnumerable<LookupEnt>> GetAllTopic();

        Task<IEnumerable<LookupEnt>> GetAllLocation();

      
    }
}
