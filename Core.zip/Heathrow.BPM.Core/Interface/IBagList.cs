﻿/****************************************************************************************************************
Class Name   : IBagList.cs 
Purpose      : This class implements the Core Interfacce for the BagList Module to the web application project.
Created By   : Vignesh AshokKumar 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BPM.Core.Entity;


namespace Heathrow.BPM.Core.Interface
{
    public interface IBagList
    {

        Task<string> SaveBagTags(string bagtags, int userId);
        //Task<int> GetUserExistingBagtagsCnt(int userId);

        Task<string> GetUserExistingBagtags(int userId);

        Task<string> RemoveBagTags(string bagtags, int userId);

        Task<IList<BagList>> GetMybaglistOtherUsers();
    }
}
