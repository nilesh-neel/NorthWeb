﻿namespace Heathrow.BPM.Core.Interface
{
    /// <summary>
    ///  Create Filter interface
    /// </summary>
  public interface IFilter
    {
        FilterCollection GetFilterByMenuID(int menuID);
        FilterCollection GetAllFilter();

        FilterCollection GetFilterConfiguration(int menuID);
        int SaveFilter(FilterCollection filterData);
    }
}
