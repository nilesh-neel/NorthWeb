﻿using System.Threading.Tasks;

namespace Heathrow.BPM.Core.Interface
{
    /// <summary>
    ///  Create Filter interface
    /// </summary>
    public interface IFilter
    {
      Task<FilterCollection> GetFilterByMenuID(int menuID);
        Task<FilterCollection>  GetAllFilter();
        Task<FilterCollection> GetFilterConfiguration(int menuID);
       Task<int> SaveFilter(FilterCollection filterData);
    }
}
