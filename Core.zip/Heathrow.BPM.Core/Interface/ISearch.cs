﻿

namespace Heathrow.BPM.Core.Interface
{
    public interface ISearch
    {
        System.Threading.Tasks.Task<ReportConfiguration> GetSearchData(string searchText,string prefix);
    }
}
