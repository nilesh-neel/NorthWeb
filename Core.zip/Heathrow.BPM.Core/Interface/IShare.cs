﻿/****************************************************************************************************************
Class Name   : IShare.cs 
Purpose      : This class implements the Core Interfacce for the Share Module to the web application project.
Created By   : Vignesh AshokKumar 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System.Collections.Generic;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Core.Interface
{
    public interface IShare
    {
        IList<Share> FetchAudienceGrp();

        IList<Share> FetchRecipients(int AudienceGrpId);

        string SendEmail(string selectedrecipients, string Url);
    }
}
