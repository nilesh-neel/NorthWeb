﻿using Heathrow.BPM.Core.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BPM.Core.Interface
{
    public interface IAlerts
    {
        Task<IEnumerable<Alerts>> GetAllAlerts();
        Task<Alerts> GetAlertsById(string _alertId);
        Task<int> Save(Alerts _alert);

        Task<int> UpdateAlert(Alerts _alert);

         Task<IEnumerable<LookupEnt>> GetAllMeasure();

         Task<IEnumerable<LookupEnt>> GetAllTopic();

        Task<IEnumerable<LookupEnt>> GetAllLocation();

        Task<IEnumerable<LookupEnt>> GetAllThreshold();
        Task<IEnumerable<LookupEnt>> GetAllFrequency();
        Task<IEnumerable<LookupEnt>> GetAllTimeWindow();

    }
}
