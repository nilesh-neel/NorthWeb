﻿/****************************************************************************************************************
Class Name   : BagList.cs 
Purpose      : This is the Entity file for BagList Module in the application...
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System;

namespace Heathrow.BPM.Core.Entity
{
    public class BagList
    {
        public int BagListID { get; set; }

        public string Bagtags { get; set; }

        public string UserId { get; set; }

        public int OthersMybaglistUserId { get; set; }

        public string UserFirstname { get; set; }

        public string UserLasttname { get; set; }

        public string UserEmail { get; set; }
        public string UserOrg { get; set; }
        public string UserRole { get; set; }


        public DateTime UpdatedDate { get; set; }

    }
}
