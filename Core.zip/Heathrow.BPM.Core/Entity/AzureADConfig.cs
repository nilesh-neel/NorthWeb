﻿using System.Configuration;

namespace Heathrow.BPM.Core.Entity
{
    public class AzureAdConfig
    {
        public static string AadAuthorityUri => ConfigurationManager.AppSettings["AADAuthorityUri"];
        public static string AzureAdTenant => ConfigurationManager.AppSettings["AzureADTenant"];
        public static string ClientId => ConfigurationManager.AppSettings["ClientId"];
        public static string ClientSecret => ConfigurationManager.AppSettings["ClientSecret"];
        public static string AzureGraphScopes => ConfigurationManager.AppSettings["AzureGraphScopes"];
        public static string RedirectUrl => ConfigurationManager.AppSettings["RedirectUrl"];
        public static string MsGraphServiceBaseUrl => ConfigurationManager.AppSettings["GraphServiceUrl"];
    }
}
