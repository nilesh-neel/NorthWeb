﻿using System;
using System.Collections.Generic;

namespace Heathrow.BPM.Core.Entity
{
    public class Notification : SubscriptionTypeBase
    {
        //Today's Notification      
        public string Description { get; set; }
        //when the notification or alert should be started
        public DateTime StartDate { get; set; }

        //Lookup items
        public string Topic { get; set; }
        public int TopicID { get; set; }

        //Notification Settings
        public string NotificationID { get; set; }


        //Configure
        public string HelpUrl { get; set; }
        public string Title { get; set; }
        public string EndDate { get; set; }
        public string Time { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public List<String> Locations { get; set; }
        public int[] SelectLocationId { get; set; }
        public int SelectedAudienceGroup { get; set; }
        public int SelectedRecipients { get; set; }
        public int SelectedTopic { get; set; }
        //   public int TipID { get; set; }
        //public List<TipOfTheDay> TipsOfTheDay { get; set; }


    }

}
