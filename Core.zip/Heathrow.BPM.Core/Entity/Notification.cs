﻿
using System;
using System.Collections.Generic;

namespace Heathrow.BPM.Core.Entity
{
    public class Notification : SubscriptionTypeBase
    {   //Today's Notification      
        public string Description { get; set; }
        public string Topic { get; set; }
        public string Locations { get; set; }
        public string DateAndTime { get; set; }

        //Notification Settings
        public string NotificationID { get; set; }
        public string Audience { get; set; }
        public string Recipient { get; set; }
        public bool DisableNotification { get; set; }

        //
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDate { get; set; }
        public string CreatedDate { get; set; }
        public int TopicID { get; set; }



        //Multiselect enabled
        public List<LocationEnt> LocationList { get; set; }
        public int[] SelectLocationId { get; set; }

        //Configure
        public string HelpUrl { get; set; }  
        public string CreatedBy { get; set; }        
       

        public int SelectedAudienceGroup { get; set; }
        public int SelectedRecipients { get; set; }
        public int SelectedTopic { get; set; }
   


    }

}
