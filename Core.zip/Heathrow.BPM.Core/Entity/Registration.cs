﻿namespace Heathrow.BPM.Core.Entity
{
    public class Registration:LookupEnt
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Organization { get; set; }
        public string JobRole { get; set; }               
        public string Location { get; set; }
        public string AccessReason { get; set; }
        
    }

}
