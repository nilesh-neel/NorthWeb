﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.Core.Entity
{
    public class AzureAdUser
    {
        public string Id { get; set; }
        public string DisplayName { get; set; }
        public string Email { get; set; }
        public Stream Avatar { get; set; }
        public string Name { get; set; }
        //public string LastName { get; set; }
        public IEnumerable<JobRoleEnt> JobRoles { get; set; }
        public string Phone { get; set; }
        public IEnumerable<LocationEnt> Locations { get; set; }
        public string Organization { get; set; }
    }

}
