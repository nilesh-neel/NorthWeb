﻿using System;

namespace Heathrow.BPM.Core.Entity
{
    public class Alerts:Response
    {
        public string AlertId { get; set; }

       public string Description { get; set; }
        public string Title { get; set; }
        public string Time { get; set; }
        public string Topic { get; set; }       
        public string Location { get; set; }
        public string Measure { get; set; }
        public string Audience { get; set; }
        public string Recipient { get; set; }
        public string Threshold { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string ModifiedDate { get; set; }
        public string ThresholdValue { get; set; }
        public string Frequency { get; set; }
        public int TimeWindow { get; set; }
        public bool DisableAlert { get; set; }
        public string MandatoryOptional { get; set; }
        public int SelectedAudienceGroup { get; set; }
        public int SelectedRecipients { get; set; }
        public int SelectedTopic { get; set; }
        public int SelectedThreshold { get; set; }
        public int[] SelectedLocation { get; set; }
        public int SelectedFrequency { get; set; }
        public int SelectedTimeWindow { get; set; }
        public int SelectedMeasure { get; set; }
    }
}
