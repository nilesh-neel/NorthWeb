﻿namespace Heathrow.BPM.Core.Entity
{
    public class LocationEnt :BaseLookUpEnt
    {
     

    }
   
}
