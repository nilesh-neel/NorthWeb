﻿/****************************************************************************************************************
Class Name   : Share.cs 
Purpose      : This is the Entity file for Share Module in the application...
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

namespace Heathrow.BPM.Core.Entity
{
    public class Share
    {
        public int GroupId { get; set; }
        public string Groupname { get; set; }
        public int RecipientId { get; set; }
        public string Recipientname { get; set; }

    }
}
