﻿/****************************************************************************************************************
Class Name   : Notes.cs 
Purpose      : This is the Entity file for Notes Module in the application...
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System;

namespace Heathrow.BPM.Core.Entity
{
    /// <summary>
    /// Notes DTO
    /// </summary>
    public class Notes
    {
        /// <summary>
        /// NotesId
        /// </summary>
        public int NotesId { get; set; }
        /// <summary>
        /// Notedesc
        /// </summary>
        public string Notedesc { get; set; }
        public string Bagtag { get; set; }
        public string Flightnumber { get; set; }
        public string Organization { get; set; }
        public int Ispublic { get; set; }
        public int Isdeleted { get; set; }
        public string UserId { get; set; }

        public  DateTime CreatedDate { get; set; }

        //public List<Notes> NotesListVal { get; set; }



    }
}
