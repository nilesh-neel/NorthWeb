﻿namespace Heathrow.BPM.Core.Entity
{
  public class SubscriptionTypeBase
    {
        public bool IsSubscribe { get; set; }
        public bool IsOnScreen { get; set; }
        public bool IsEmail { get; set; }
        public bool IsMobile { get; set; }
    }
}
