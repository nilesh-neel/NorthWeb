﻿using System.Collections.Generic;

namespace Heathrow.BPM.Core
{
    /// <summary>
    /// Filter Data transfer object 
    /// </summary>

    public class FilterCollection
    {
        public string ReportName { get; set; }

        public int ReportID { get; set; }
     
        public long FilterID { get; set; }

         public string UserID { get; set; }

        public int MenuID { get; set; }
        
        public string FilterText { get; set; }

        public short FilterSelection { get; set; }

        public IList<FilterConfiguration> FilterConfigurationList { get; set; }
        public IList<FilterSelection> PBIMappingList { get; set; }
        public IList<DropDownFilter> NotLoadedCategoryList { get; set; }
        public IList<DropDownFilter> NotLoadedSubCategoryList { get; set; }
        public IList<DropDownFilter> BaggageSystemList { get; set; }
        public IList<DropDownFilter> OutboundAircraftList { get; set; }
        public IList<DropDownFilter> DestinationList { get; set; }
        public IList<DropDownFilter> OutboundAirlineList { get; set; }
        public IList<DropDownFilter> OutboundTerminalList { get; set; }
        public IList<DropDownFilter> LastSeenLocationList { get; set; }
        public IList<DropDownFilter> OutboundHandlerList { get; set; }
    }
    public class DropDownFilter
    {
        public string ID { get; set; }
        public string Name { get; set; }
    }
    //public class TextFilter
    //{
    //    public long ID { get; set; }
    //    public string Text { get; set; }
    //}
    public class FilterSelection
    {
        public string TableName { get; set; }
        public string ColumnName { get; set; }
        public IList<string> ColumnValue { get; set; }
        public string Operator { get; set; }
        public int ControlMappingID { get; set; }
    }

    public class FilterConfiguration
    {
        public int FilterControlID { get; set; }
        public string FilterName { get; set; }
    }

    public class ReportConfiguration
    {
        public string TableName { get; set; }
        public string ColumnName { get; set; }
        public IList<string> ColumnValue { get; set; }
        public string Operator { get; set; }
        public string PowerBIURL { get; set; }
    }

}



