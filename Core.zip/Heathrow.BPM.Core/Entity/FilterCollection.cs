﻿using System.Collections.Generic;

namespace Heathrow.BPM.Core
{
    /// <summary>
    /// Filter Data transfer object 
    /// </summary>

    public class FilterCollection
    {
        /// <summary>
        /// Report Name
        /// </summary>

        public string ReportName { get; set; }

        /// <summary>
        /// Report ID
        /// </summary>
        public int ReportID { get; set; }
        /// <summary>
        /// Filter ID
        /// </summary>
        public long FilterID { get; set; }

        /// <summary>
        /// UserID
        /// </summary>
        public string UserID { get; set; }

        /// <summary>
        /// Menu ID
        /// </summary>
        public int MenuID { get; set; }


        /// <summary>
        /// Filter Text
        /// </summary>
        public string FilterText { get; set; }

        /// <summary>
        /// Filter Selection
        /// </summary>
        public short FilterSelection { get; set; }

        public IList<FilterConfiguration> FilterConfigurationList { get; set; }
        public IList<FilterSelection> PBIMappingList { get; set; }

        public IList<DropDownFilter> BagTypeList { get; set; }
        public IList<DropDownFilter> BagSystemList { get; set; }

        public IList<DropDownFilter> ShortConnectList { get; set; }
        public IList<DropDownFilter> OOGBagsList { get; set; }
        public IList<DropDownFilter> AfterChoxList { get; set; }
        public IList<DropDownFilter> DeletedBagsList { get; set; }
        public IList<DropDownFilter> MissedBRSList { get; set; }
        public IList<DropDownFilter> DeletedBSMList { get; set; }
        public IList<DropDownFilter> MyBagList { get; set; }
        public IList<DropDownFilter> InboundITOList { get; set; }
        public IList<DropDownFilter> InTargetList { get; set; }
        public IList<DropDownFilter> FailedMissedList { get; set; }
        public IList<DropDownFilter> FailedInSystemList { get; set; }
    }
    public class DropDownFilter
    {
        public string ID { get; set; }
        public string Name { get; set; }
    }
    public class TextFilter
    {
        public long ID { get; set; }
        public string Text { get; set; }
    }
    public class FilterSelection
    {
        public string TableName { get; set; }
        public string ColumnName { get; set; }
        public IList<string> ColumnValue { get; set; }
        public string Operator { get; set; }

        public int ControlMappingID { get; set; }
    }

    public class FilterConfiguration
    {
        public int FilterControlID { get; set; }
        public string FilterName { get; set; }
    }

}



