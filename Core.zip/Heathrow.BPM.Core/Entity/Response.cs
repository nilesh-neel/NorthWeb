﻿namespace Heathrow.BPM.Core.Entity
{
  public class Response
    {
        public bool IsAcknowledge { get; set; }
        public bool IsBlank { get; set; }
        public bool IsIgnore { get; set; }
        public bool IsSubscribe { get; set; }
        public bool IsOnScreen { get; set; }
        public bool IsEmail { get; set; }
        public bool IsMobile { get; set; }
    }
}
