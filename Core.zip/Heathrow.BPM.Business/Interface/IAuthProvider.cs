﻿using System.Threading.Tasks;
using Microsoft.Graph;

namespace Heathrow.BPM.Business.Interface
{
    public interface IAuthProvider
    {
        Task<string> GetUserAccessTokenAsync();
        GraphServiceClient GetGraphServiceClient();
    }
}
