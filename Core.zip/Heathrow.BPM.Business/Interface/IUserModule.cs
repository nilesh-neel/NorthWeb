﻿using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Business.Interface
{
    public interface IUserModule
    {
        Task<Stream> GetUserProfilePhoto();
        Task<AzureAdUser> GetUserDetailsAsync();
        Task<AzureAdUser> GetUser(string id);
        Task<IEnumerable<LocationEnt>> GetUserLocation();
        Task<IEnumerable<JobRoleEnt>> GetUserJobRole();

    }
}