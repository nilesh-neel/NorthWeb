﻿using System.IO;
using System.Threading.Tasks;
using Microsoft.Graph;

namespace Heathrow.BPM.Business.Interface
{
    public interface IUserModule
    {
        Task<Stream> GetUserProfilePhoto();
        Task<User> GetUserDetailsAsync();
        Task<User> GetUser(string id);

    }
}