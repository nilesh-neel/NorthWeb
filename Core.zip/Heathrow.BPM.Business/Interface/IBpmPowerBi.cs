﻿using System.Collections.Specialized;
using System.IO;
using System.Threading.Tasks;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Business.Interface
{
    public interface IBpmPowerBi
    {
        Task<string> GetEmbeddedTokenWebApp();
        Task<string> GetEmbeddedTokenNativeApp();
        Task<string> GetToken();
        Task<string> EmbedToken();
    }
}
