﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BPM.Core.Entity;
namespace Heathrow.BPM.Business.Interface
{
    public interface ILookUpModule
    {
        IEnumerable<LookupEnt> GetLookupById(int id);   
    }
}
