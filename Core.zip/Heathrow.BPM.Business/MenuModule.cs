﻿/****************************************************************************************************************
Class Name   : MenuModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Business
{
    public class MenuModule : IMenuModule
    {
        IRepository<Menu> Menu { get; set; }
        public MenuModule(IRepository<Menu> menu)
        {
            Menu = menu;
        }

        public async Task<IEnumerable<Menu>> GetAllMenu()
        {
            try
            {
               return await Menu.ExecuteQueryAsync(ProcedureConstants.GetAllMenu);
            }
            catch (Exception ex)
            {

                throw ex;
            }


        }

        //public IEnumerable<Menu> GetAllMenu()
        //{
        //    return _menu.All();
        //}
    }
}
