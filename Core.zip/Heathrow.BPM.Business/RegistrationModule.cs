﻿/****************************************************************************************************************
Class Name   : RegistrationModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Business
{
    public class RegistrationModule : IRegistrationModule
    {
        //   private static LookupRepository lr = new LookupRepository();
        private IRepository<LocationEnt> _locationRepository;
        private IRepository<JobRoleEnt> _jobRoleRepository;
        private static IRegistration Registration { get; set; }
        private static ILookup Lookup { get; set; }
        public RegistrationModule(IRegistration registration, ILookup lookup, IRepository<LocationEnt> locationRepo, IRepository<JobRoleEnt> jobRole)
        {
            Registration = registration;
            Lookup = lookup;
            _locationRepository = locationRepo;
            _jobRoleRepository = jobRole;
        }

        public int Save(Registration registration)
        {
            /*      List<LookupEnt> listobj = new List<LookupEnt>(); 
                 listobj= lr.GetLookupDetailsById(1);
                  foreach (LookupEnt le in listobj)
                      System.Console.WriteLine(le.LookupTypeName);*/

            return Registration.Save(registration);
        }

        public  IEnumerable<LocationEnt> LocationList()
        {
            return  _locationRepository.All();
        }

        public IEnumerable<JobRoleEnt> RoleList()
        {
            return  _jobRoleRepository.All();
        }
    }
}
