﻿using System.Collections.Generic;
using Heathrow.BPM.Core;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Business
{
    
    public class SearchModule : ISearchModule
    {

        private readonly ISearch searchInstance;
        public SearchModule(ISearch searchObj)
        {
            searchInstance = searchObj;
        }

        public IList<TextFilter> GetSearchData(string searchQuery, string searchPrefix)
        {
            return searchInstance.GetSearchData(searchQuery, searchPrefix);
        }

    
    }
}
