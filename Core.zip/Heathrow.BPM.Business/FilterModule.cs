﻿using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core;
using Heathrow.BPM.Core.Interface;
using System.Threading.Tasks;

namespace Heathrow.BPM.Business
{
    /// <summary>
    ///  Baggage filter business 
    /// </summary>
    public class FilterModule : IFilterModule
    {
        private readonly IFilter _filterRepository;

        public FilterModule(IFilter filterData)
        {
            _filterRepository = filterData;
        }

        /// <summary>
        /// Create Filter business 
        /// </summary>
        /// <param name="filterEntity"></param>
        /// <returns></returns>
        public Task<int> SaveFilter(FilterCollection filterEntity)
        {
            return _filterRepository.SaveFilter(filterEntity);
        }

        /// <summary>
        /// Get Filter Business 
        /// </summary>
        /// <param name="menuID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public async Task<FilterCollection> GetFilterByMenuID(int menuID)
        {
           // await GetAllFilter();
            return await _filterRepository.GetFilterByMenuID(menuID);
        }

        public async Task<FilterCollection> GetAllFilter()
        {
            return await _filterRepository.GetAllFilter();
        }
        public async Task<FilterCollection> GetFilterConfiguration(int menuId)
        {
            return await _filterRepository.GetFilterConfiguration(menuId);
        }

    }
}
