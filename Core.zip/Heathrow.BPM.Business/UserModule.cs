﻿/****************************************************************************************************************
Class Name   : UserModule.cs 
Purpose      : This class use to fetch the login in user details for the azure ad with use of azure graph services.
Created By   : Nilesh More 
Created Date : 10/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess;
using Microsoft.Graph;


namespace Heathrow.BPM.Business
{
    public class UserModule : IUserModule
    {
        private readonly IAuthProvider _authProvider;
        //private readonly IRepository<DataAccess.Location> _locationRepository;
        //private readonly IRepository<JobRole> _jobRoleRepository;
        public UserModule(IAuthProvider authProvider)//, IRepository<DataAccess.Location> locationRepo, IRepository<JobRole> jobRole)
        {
            _authProvider = authProvider;
            //_locationRepository = locationRepo;
            //_jobRoleRepository = jobRole;
        }

        public async Task<AzureAdUser> GetUserDetailsAsync()
        {
            var graphUser = await _authProvider.GetGraphServiceClient().Me.Request().GetAsync();

            return new AzureAdUser
            {
                Id = graphUser.Id,
                Name = graphUser.DisplayName.Length <= 8
                    ? graphUser.DisplayName
                    : graphUser.DisplayName.Substring(0, 8) + "...",
                DisplayName = graphUser.DisplayName,
                Email = string.IsNullOrEmpty(graphUser.Mail) ? graphUser.UserPrincipalName : graphUser.Mail,
                Locations = null,//await _locationRepository.AllAsync(),
                JobRoles = null,// await _jobRoleRepository.AllAsync(),
                Phone = graphUser.BusinessPhones.FirstOrDefault(),
                Organization = graphUser.CompanyName,
                Avatar = null

            };
        }

        // Get a specified user.
        public async Task<AzureAdUser> GetUser(string id)
        {
            // Get the specific user.
            var graphUser = await _authProvider.GetGraphServiceClient().Users[id].Request().GetAsync();

            return new AzureAdUser
            {
                Id = graphUser.Id,
                Name = graphUser.DisplayName.Length <= 8
                    ? graphUser.DisplayName
                    : graphUser.DisplayName.Substring(0, 8) + "...",
                DisplayName = graphUser.DisplayName,
                Email = string.IsNullOrEmpty(graphUser.Mail) ? graphUser.UserPrincipalName : graphUser.Mail,
                Locations = null,// await _locationRepository.AllAsync(),
                JobRoles = null,// _jobRoleRepository.AllAsync(),
                Phone = graphUser.BusinessPhones.FirstOrDefault(),
                Organization = graphUser.CompanyName,
                Avatar = null

            };
        }

        // Get the profile photo of the current user (from the user's mailbox on Exchange Online). 
        public async Task<Stream> GetUserProfilePhoto()
        {
            try
            {
                return await _authProvider.GetGraphServiceClient().Me.Photo.Content.Request().GetAsync() ??
                       System.IO.File.OpenRead(System.Web.Hosting.HostingEnvironment.MapPath("/images/Icons/userProfile.png"));
            }
            catch (Exception ex)
            {
                return System.IO.File.OpenRead(System.Web.Hosting.HostingEnvironment.MapPath("/images/Icons/userProfile.png"));
            }

        }

        public static async Task<AzureAdUser> GetUserDetailsAsync(string accessToken)
        {
            var graphClient = new GraphServiceClient(AzureAdConfig.MsGraphServiceBaseUrl,
                new DelegateAuthenticationProvider(async (requestMessage) =>
                {
                    requestMessage.Headers.Authorization =
                        new AuthenticationHeaderValue("Bearer", accessToken);
                }));

            var graphUser = await graphClient.Me.Request().GetAsync();

            return new AzureAdUser
            {
                Id = graphUser.Id,
                Name = graphUser.DisplayName.Length <= 8
                    ? graphUser.DisplayName
                    : graphUser.DisplayName.Substring(0, 8) + "...",
                DisplayName = graphUser.DisplayName,
                Email = string.IsNullOrEmpty(graphUser.Mail) ? graphUser.UserPrincipalName : graphUser.Mail,
                Locations = null, //graphUser.UsageLocation,
                JobRoles = null, // graphUser.JobTitle,
                Phone = graphUser.BusinessPhones.FirstOrDefault(),
                Organization = graphUser.CompanyName,
                Avatar = null

            };
            //return await graphClient.Me.Request().GetAsync();
        }

        public async Task<IEnumerable<LocationEnt>> GetUserLocation()
        {
            return null;// await _locationRepository.AllAsync();
        }

        public async Task<IEnumerable<JobRoleEnt>> GetUserJobRole()
        {
            return null;// await _jobRoleRepository.AllAsync();
        }
    }
}
