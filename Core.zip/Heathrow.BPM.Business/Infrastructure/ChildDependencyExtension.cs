﻿/****************************************************************************************************************
Class Name   : ChildDependencyExtension.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess;
using Unity.Extension;
using Unity;
using Unity.Lifetime;
using System.Data.Entity;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Business.Infrastructure
{
    public class ChildDependencyExtension : UnityContainerExtension
    {
        //Here register the repository with its abstractions for the dependency injection. 
        protected override void Initialize()
        {
            #region "Business  DI"
            Container.RegisterType<IAuthProvider, AuthProviderModule>();
            Container.RegisterType<IAlertsModule, AlertsModule>();
            Container.RegisterType<IAssignHomePageModule, AssignHomePageModule>();
            Container.RegisterType<IBagListModule, BagListModule>();
            Container.RegisterType<IFavouriteModule, FavouriteModule>();
            Container.RegisterType<IFilterModule, FilterModule>();
            Container.RegisterType<ILocationModule, LocationModule>();
            Container.RegisterType<IMenuModule, MenuModule>();
            Container.RegisterType<INotesModule, NotesModule>();
            Container.RegisterType<INotificationModule, NotificationModule>();
            Container.RegisterType<IBpmPowerBi, PowerBiModule>();
            Container.RegisterType<IRegistrationModule, RegistrationModule>();
            Container.RegisterType<ISearchModule, SearchModule>();
            Container.RegisterType<IShareModule, ShareModule>();
            Container.RegisterType<IUserModule, UserModule>();
         //   Container.RegisterType<ILookup, LookupModule>();

            #endregion

            #region "Repository DI"
            Container.RegisterType<IAlerts, AlertsRepository>();
            Container.RegisterType<INotification, NotificationRepository>();
            Container.RegisterType<IRegistration, RegistrationRepository>();
            Container.RegisterType<ILocation, LocationRepository>();
            Container.RegisterType<ILookup, LookupRepository>();
            Container.RegisterType<IFavourites, FavouritesRepository>();
            Container.RegisterType<IFilter, FilterRepository>();
            Container.RegisterType<INotes, NotesRepository>();
            Container.RegisterType<IShare, ShareRepository>();
            Container.RegisterType<IBagList, BagListRepository>();
            Container.RegisterType<ISearch, SearchRepository>();
            Container.RegisterType(typeof(IRepository<>), typeof(GenericRepository<>));
            // Database context, one per request, ensure it is disposed **HierarchicalLifetimeManager**
            Container.RegisterType<DbContext, BaggageDbContext>(new HierarchicalLifetimeManager());
            #endregion



        }
    }
}
