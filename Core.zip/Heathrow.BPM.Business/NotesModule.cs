﻿/****************************************************************************************************************
Class Name   : NotesModule.cs 
Purpose      : This class implements the Business Logic of the Notes Module.
Created By   : Vignesh AshokKumar 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System.Collections.Generic;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Core.Entity;
using System.Threading.Tasks;
using System;

namespace Heathrow.BPM.Business
{
    public class NotesModule : INotesModule
    {
        private static INotes _notes { get; set; }
        public NotesModule(INotes notes)
        {
            _notes = notes;
        }

        public Task<IList<Notes>> DeleteNotes(int notesId, string bagTag, string flightNumber, string organization, string UserId)
        {
            try
            {
                return _notes.DeleteNotes(notesId, bagTag, flightNumber, organization, UserId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<IList<Notes>> Fetch(string bagTag, string flightNumber, string organization,string UserId)
        {
            try
            {
                return Task.Run(()=> _notes.FetchNotes(bagTag, flightNumber, organization, UserId));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<IList<Notes>> Save(Notes notes)
        {
            try
            {
                return _notes.SaveNotes(notes);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
