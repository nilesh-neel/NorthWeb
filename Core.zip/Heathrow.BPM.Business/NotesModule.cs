﻿/****************************************************************************************************************
Class Name   : NotesModule.cs 
Purpose      : This class implements the Business Logic of the Notes Module.
Created By   : Vignesh AshokKumar 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System.Collections.Generic;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Business
{
    public class NotesModule : INotesModule
    {
        private static INotes _notes { get; set; }
        public NotesModule(INotes notes)
        {
            _notes = notes;
        }

        public IList<Notes> Save(Notes notes)
        {
            if (notes == null && string.IsNullOrEmpty(notes.Notedesc)) return null;
            return _notes.SaveNotes(notes);
        }

        public IList<Notes> Fetch(string Bagtag, string Flightnumber, string Organization)
        {
            return _notes.FetchNotes(Bagtag, Flightnumber, Organization);
        }

        public IList<Notes> DeleteNotes(int notesId, string Bagtag, string Flightnumber, string Organization)
        {
            return _notes.DeleteNotes(notesId, Bagtag, Flightnumber, Organization);
        }
    }
}
