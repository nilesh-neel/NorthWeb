﻿/****************************************************************************************************************
Class Name   : NotificationModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System.Collections.Generic;
using System.Linq;
using Heathrow.BPM.Business.Interface;
using System;
using System.Threading.Tasks;

namespace Heathrow.BPM.Business
{
    public class NotificationModule : INotificationModule
    {

        private static ILookup Lookup { get; set; }

        private static INotification NotificationRepository { get; set; }
        public NotificationModule(INotification notification, ILookup lookup)
        {
            NotificationRepository = notification;
            Lookup = lookup;
        }       

        public Task<int> Save(Notification notification)
        {
            return NotificationRepository.Save(notification);
        }
        public Task<int> Update(Notification notification)
        {
            return NotificationRepository.UpdateNotification(notification);
        }

        public Task<Notification> GetNotificationById(string notificationId)
        {
                                       
            return NotificationRepository.GetNotificationByNotificationId(notificationId);
        }

        public Task<IEnumerable<Notification>> GetTodaysNotification()
        {       
            return NotificationRepository.GetTodaysNotification();
        }

        public IEnumerable<LookupEnt> LocationList()
        {
            return Lookup.GetLookupDetailsById(1);
        }
        public IEnumerable<LookupEnt> TopicList()
        {
            return Lookup.GetLookupDetailsById(3);
        }
        public IEnumerable<LookupEnt> AudienceList()
        {
            return Lookup.GetLookupDetailsById(4);
        }
        public IEnumerable<LookupEnt> RecipientList()
        {
            return Lookup.GetLookupDetailsById(2);
        }
        public Task<IEnumerable<LookupEnt>> Bag_TopicList()
        {
            return NotificationRepository.GetAllTopic();
        }
        public Task<IEnumerable<LookupEnt>> Bag_LocationList()
        {
            return NotificationRepository.GetAllLocation();
        }

    }
}
