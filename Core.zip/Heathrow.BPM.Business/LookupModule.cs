﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Business
{
  public  class LookupModule:ILookUpModule
    {
        private static ILookup _lookup { get; set; }
        public LookupModule(ILookup lookup)
        {

            _lookup = lookup;
        }

        public IEnumerable<LookupEnt> GetLookupById(int id)
        {
            return _lookup.GetLookupDetailsById(id);
        }
    }
}
