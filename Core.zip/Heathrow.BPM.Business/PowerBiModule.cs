﻿/****************************************************************************************************************
Class Name   : PowerBiModule.cs 
Purpose      : PowerBiModule use to get Access token for the power bi report embadded.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Text;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security.Claims;
using Heathrow.BPM.Business.Infrastructure;
using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.Rest;

namespace Heathrow.BPM.Business
{
    public class PowerBiModule : IBpmPowerBi
    {
        public async Task<string> GetEmbeddedTokenWebApp()
        {
            var paramsList = new List<KeyValuePair<string, string>>
                {
                    new KeyValuePair<string, string>("grant_type", "password"),
                    new KeyValuePair<string, string>("scope", "openid"),
                    new KeyValuePair<string, string>("resource", PowerBiConfig.PowerBiApiResource),
                    new KeyValuePair<string, string>("client_id", AzureAdConfig.ClientId),
                    new KeyValuePair<string, string>("client_secret", AzureAdConfig.ClientSecret),
                    new KeyValuePair<string, string>("username", PowerBiConfig.PowerBiUserName),
                    new KeyValuePair<string, string>("password", PowerBiConfig.PowerBiUserPassword)
                };
            //string url = $"https://login.windows.net/{tenantId}/oauth2/token";
            string url = string.Format(PowerBiConfig.PowerBiAuthorityUri, AzureAdConfig.AzureAdTenant);
            HttpClient hc = new HttpClient();
            HttpContent content = new FormUrlEncodedContent(paramsList);
            HttpResponseMessage hrm = hc.PostAsync(url, content).Result;
            string responseData = "";
            try
            {
                //if (!hrm.IsSuccessStatusCode)
                //    return JsonConvert.DeserializeObject<AccessToken>(responseData).access_token;
                Stream data = await hrm.Content.ReadAsStreamAsync();
                using (StreamReader reader = new StreamReader(data, Encoding.UTF8))
                {
                    responseData = reader.ReadToEnd();
                }

                //var accessToken = JsonConvert.DeserializeObject<AccessToken>(responseData).access_token;

                //var tokenCredentials = new TokenCredentials(accessToken, "Bearer");
                // string _groupId = "ee94827c-74e3-4922-a353-6ad84244c177";

                //using (var client = new PowerBIClient(new Uri(PowerBiConfig.PowerBiApiUrl), tokenCredentials))
                //{
                //    var grp = client.Groups.GetGroups().Value.ToList();
                //    var reportListd = client.Reports.GetReportsInGroup("0fc4287c-461d-46bc-a2da-ec29f0962ab3");
                //    EmbedToken embedToken = await client.Reports.GenerateTokenInGroupAsync(_groupId, "f7d642f8-6934-4e28-95f3-22efadb9a1fb", new GenerateTokenRequest(accessLevel: "View"));
                //}

                return JsonConvert.DeserializeObject<AccessToken>(responseData).access_token;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

        }

        //To Native app access token withour secret key
        public async Task<string> GetEmbeddedTokenNativeApp()
        {
            try
            {
                var oauthEndpoint = new Uri(string.Format(PowerBiConfig.PowerBiAuthorityUri, AzureAdConfig.AzureAdTenant));
                using (var client = new HttpClient())
                {
                    var result = await client.PostAsync(oauthEndpoint, new FormUrlEncodedContent(new[]
                    {
                    new KeyValuePair<string, string>("resource", PowerBiConfig.PowerBiApiResource),
                    new KeyValuePair<string, string>("client_id","9eecd6a0-0204-4463-a816-9e0d6966e8fa"),
                    //new KeyValuePair<string, string>("client_id",AzureAdConfig.ClientId),
                    new KeyValuePair<string, string>("grant_type", "password"),
                    new KeyValuePair<string, string>("username",  PowerBiConfig.PowerBiUserName),
                    new KeyValuePair<string, string>("password",  PowerBiConfig.PowerBiUserPassword),
                    new KeyValuePair<string, string>("scope", "openid"),
                }));

                    var content = await result.Content.ReadAsStringAsync();
                    var obj = JsonConvert.DeserializeObject<AccessToken>(content);

                    return obj.access_token;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

        }

        public async Task<string> GetToken()
        {
            try
            {
                string signedInUserId = ClaimsPrincipal.Current.FindFirst(ClaimTypes.NameIdentifier).Value;
                HttpContextWrapper httpContext = new HttpContextWrapper(HttpContext.Current);
                Microsoft.Identity.Client.TokenCache userTokenCache = new SessionTokenCache(signedInUserId, httpContext).GetMsalCacheInstance();
                //var cachedItems = tokenCache.ReadItems(appId); // see what's in the cache

                ConfidentialClientApplication idClient = new ConfidentialClientApplication(AzureAdConfig.ClientId, PowerBiConfig.PowerBiApiResource,
                    new Microsoft.Identity.Client.ClientCredential(AzureAdConfig.ClientSecret), userTokenCache, null);
                var accounts = await idClient.GetAccountsAsync();
                var scope = "Capacity.Read.All Capacity.ReadWrite.All Content.Create Dashboard.Read.All Dashboard.ReadWrite.All Data.Alter_Any Datapool.Read.All Datapool.ReadWrite.All Dataset.Read.All Dataset.ReadWrite.All Group.Read Group.Read.All Metadata.View_Any Report.Read.All Report.ReadWrite.All Workspace.Read.All Workspace.ReadWrite.All";
                Microsoft.Identity.Client.AuthenticationResult result = await idClient.AcquireTokenForClientAsync(scope.Split(new char[] { ' ' }));
                return result.AccessToken;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }


        public async Task<string> EmbedToken()
        {
            try
            {
                // Create a user password cradentials.
                var credential = new UserPasswordCredential(PowerBiConfig.PowerBiUserName, PowerBiConfig.PowerBiUserPassword);

                // Authenticate using created credentials
                var authenticationContext = new AuthenticationContext("https://login.microsoftonline.com/2133b7ab-6392-452c-aa20-34afbe98608e/oauth2/authorize");
                var authenticationResult = await authenticationContext.AcquireTokenAsync("https://analysis.windows.net/powerbi/api", "9eecd6a0-0204-4463-a816-9e0d6966e8fa", credential);


                return authenticationResult == null ? "Authentication Failed." : authenticationResult.AccessToken;
            }
            catch (HttpOperationException exc)
            {
                return string.Format("Status: {0} ({1})\r\nResponse: {2}\r\nRequestId: {3}", exc.Response.StatusCode, (int)exc.Response.StatusCode, exc.Response.Content, exc.Response.Headers["RequestId"].FirstOrDefault());
            }
            catch (Exception exc)
            {
                return exc.ToString();
            }
        }

        /*
        public async Task<ActionResult> EmbedReport(string username, string roles)
        {
            var result = new EmbedConfig();
            try
            {
                result = new EmbedConfig { Username = username, Roles = roles };
                var error = GetWebConfigErrors();
                if (error != null)
                {
                    result.ErrorMessage = error;
                    return View(result);
                }

                 // Create a user password cradentials.
                var credential = new UserPasswordCredential(Username, Password);

                // Authenticate using created credentials
                var authenticationContext = new AuthenticationContext(AuthorityUrl);
                var authenticationResult = await authenticationContext.AcquireTokenAsync(ResourceUrl, ApplicationId, credential);

                if (authenticationResult == null)
                {
                    result.ErrorMessage = "Authentication Failed.";
                    return View(result);
                }

                var tokenCredentials = new TokenCredentials(authenticationResult.AccessToken, "Bearer");

                // Create a Power BI Client object. It will be used to call Power BI APIs.
                using (var client = new PowerBIClient(new Uri(ApiUrl), tokenCredentials))
                {
                    // Get a list of reports.
                    var reports = await client.Reports.GetReportsInGroupAsync(WorkspaceId);

                    // No reports retrieved for the given workspace.
                    if (reports.Value.Count() == 0)
                    {
                        result.ErrorMessage = "No reports were found in the workspace";
                        return View(result);
                    }

                    Report report;
                    if (string.IsNullOrWhiteSpace(ReportId))
                    {
                        // Get the first report in the workspace.
                        report = reports.Value.FirstOrDefault();
                    }
                    else
                    {
                        report = reports.Value.FirstOrDefault(r => r.Id == ReportId);
                    }

                    if (report == null)
                    {
                        result.ErrorMessage = "No report with the given ID was found in the workspace. Make sure ReportId is valid.";
                        return View(result);
                    }

                    var datasets = await client.Datasets.GetDatasetByIdInGroupAsync(WorkspaceId, report.DatasetId);
                    result.IsEffectiveIdentityRequired = datasets.IsEffectiveIdentityRequired;
                    result.IsEffectiveIdentityRolesRequired = datasets.IsEffectiveIdentityRolesRequired;
                    GenerateTokenRequest generateTokenRequestParameters;
                    //username = "abdul.asrath@heathrow.com";
                    // This is how you create embed token with effective identities
                    if (!string.IsNullOrWhiteSpace(username))
                    {
                        var rls = new EffectiveIdentity(username, new List<string> { report.DatasetId });
                        if (!string.IsNullOrWhiteSpace(roles))
                        {
                            var rolesList = new List<string>();
                            rolesList.AddRange(roles.Split(','));
                            rls.Roles = rolesList;
                        }
                        // Generate Embed Token with effective identities.
                        generateTokenRequestParameters = new GenerateTokenRequest(accessLevel: "view", identities: new List<EffectiveIdentity> { rls });
                    }
                    else
                    {
                        // Generate Embed Token for reports without effective identities.
                        generateTokenRequestParameters = new GenerateTokenRequest(accessLevel: "view");
                    }

                    var tokenResponse = await client.Reports.GenerateTokenInGroupAsync(WorkspaceId, report.Id, generateTokenRequestParameters);

                    if (tokenResponse == null)
                    {
                        result.ErrorMessage = "Failed to generate embed token.";
                        return View(result);
                    }

                    // Generate Embed Configuration.
                    result.EmbedToken = tokenResponse;
                    result.EmbedUrl = report.EmbedUrl;
                    result.Id = report.Id;

                    return View(result);
                }
            }
            catch (HttpOperationException exc)
            {
                result.ErrorMessage = string.Format("Status: {0} ({1})\r\nResponse: {2}\r\nRequestId: {3}", exc.Response.StatusCode, (int)exc.Response.StatusCode, exc.Response.Content, exc.Response.Headers["RequestId"].FirstOrDefault());
            }
            catch (Exception exc)
            {
                result.ErrorMessage = exc.ToString();
            }

            return View(result);
        }
        */
        /*
        public async Task<Stream> GetMyProfilePhoto(string accessToken)
        {

            // Get the profile photo of the current user (from the user's mailbox on Exchange Online). 
            // This operation in version 1.0 supports only a user's work or school mailboxes and not personal mailboxes. 
            string endpoint = "https://graph.microsoft.com/v1.0/me/photo/$value";

            using (var client = new HttpClient())
            {
                using (var request = new HttpRequestMessage(HttpMethod.Get, endpoint))
                {
                    //request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                    var response = await client.SendAsync(request);

                    // If successful, Microsoft Graph returns a 200 OK status code and the photo's binary data. If no photo exists, returns 404 Not Found.
                    if (response.IsSuccessStatusCode)
                    {
                        return await response.Content.ReadAsStreamAsync();
                    }
                    else
                    {
                        // If no photo exists, the sample uses a local file.
                        return File.OpenRead(System.Web.Hosting.HostingEnvironment.MapPath("/Content/test.jpg"));
                    }
                }
            }
        }
        private async void SetAccessToken()
        {
            //var credential = new UserPasswordCredential(PowerBiConfig.PowerBiUserName, PowerBiConfig.PowerBiUserPassword);

            //// Authenticate using created credentials
            //var authenticationContext = new AuthenticationContext(PowerBiConfig.PowerBiAuthorityUri);
            //var authenticationResult = await authenticationContext.AcquireTokenAsync(PowerBiConfig.PowerBiApiResource, AzureAdConfig.ClientId, credential);

            //if (authenticationResult == null)
            //    new Exception("Authentication Failed.");

            //var tokenCredentials = new TokenCredentials(authenticationResult.AccessToken, "Bearer");

            ////Microsoft.IdentityModel.Clients.ActiveDirectory.TokenCache TC = new Microsoft.IdentityModel.Clients.ActiveDirectory.TokenCache();

            ////AuthenticationContext AC = new AuthenticationContext(PowerBIConfig.PowerBiAuthorityUri, TC);
            ////Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential cc = new Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential(AzureADConfig.ClientId, AzureADConfig.ClientSecret);
            ////var embaedToken = await AC.AcquireTokenByAuthorizationCodeAsync(accessToken, new Uri(PowerBIConfig.DashboardRedirectUrl), cc);





            //using (var client = new PowerBIClient(new Uri(PowerBiConfig.PowerBiApiUrl), tokenCredentials))
            //{
            //    var grp = client.Groups.GetGroups().Value.ToList();
            //    var reportListd = client.Reports.GetReportsInGroup("0fc4287c-461d-46bc-a2da-ec29f0962ab3");
            //    EmbedToken embedToken = await client.Reports.GenerateTokenInGroupAsync(_groupId, "f7d642f8-6934-4e28-95f3-22efadb9a1fb", new GenerateTokenRequest(accessLevel: "View"));
            //}
        }

    */
    }
}
