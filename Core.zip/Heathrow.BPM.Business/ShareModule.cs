﻿/****************************************************************************************************************
Class Name   : ShareModule.cs 
Purpose      : This class implements the Business Logic of the Share Module.
Created By   : Vignesh AshokKumar 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Collections.Generic;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Core.Entity;
using System.Threading.Tasks;
using System;

namespace Heathrow.BPM.Business
{
    public class ShareModule : IShareModule
    {
        private static IShare _share { get; set; }

        public ShareModule(IShare share)
        {
            _share = share;
        }

        public Task<IList<Share>> GetAudienceGrp()
        {
            try
            {
                return _share.FetchAudienceGrp();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<IList<Share>> GetGrpRecipients(int Audiencegrpid)
        {
            try
            {
                return _share.FetchRecipients(Audiencegrpid);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<string> SendEmail(string selectedrecipients, string Url)
        {
            try
            {
                return _share.SendEmail(selectedrecipients, Url);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
