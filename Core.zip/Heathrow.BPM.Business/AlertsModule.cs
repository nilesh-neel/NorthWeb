﻿/****************************************************************************************************************
Class Name   : AlertsModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System.Collections.Generic;
using Heathrow.BPM.Business.Interface;
using System.Threading.Tasks;

namespace Heathrow.BPM.Business
{
    public class AlertsModule : IAlertsModule
    {
        private static IAlerts _alertsRepository;
        private static ILookup Lookup { get; set; }
        public AlertsModule(IAlerts alerts,ILookup lookup)
        {
            //_alertsRepository = alert;
            _alertsRepository = alerts;
            Lookup = lookup;
            // CRUD oDAL = new CRUD();
        }

        public Task<IEnumerable<Alerts>> GetAlerts()
        {
            // return null;//
            return _alertsRepository.GetAllAlerts();
        }
        public Task<Alerts> GetAlertsById(string id)
        {
            //  return null;// _alertsRepository.GetAlertsById(id);
            return _alertsRepository.GetAlertsById(id);
        }
        public Task<int> Save(Alerts alert)
        {
            return _alertsRepository.Save(alert);
        }
        public Task<int> Update(Alerts alert)
        {
            return _alertsRepository.UpdateAlert(alert);
        }

        public Task<IEnumerable<LookupEnt>> Bag_MeasureList()
        {
            // return Lookup.GetLookupDetailsById(1);
            return _alertsRepository.GetAllMeasure();
        }
        public Task<IEnumerable<LookupEnt>> Bag_TopicList()
        {
            return _alertsRepository.GetAllTopic();
        }
        public Task<IEnumerable<LookupEnt>> Bag_LocationList()
        {           
            return _alertsRepository.GetAllLocation();
        }
        public Task<IEnumerable<LookupEnt>> Bag_ThresholdList()
        {
            return _alertsRepository.GetAllThreshold();
        }
        public Task<IEnumerable<LookupEnt>> Bag_FrequencyList()
        {
            return _alertsRepository.GetAllFrequency();
        }

        public Task<IEnumerable<LookupEnt>> Bag_TimeWindowList()
        {
            return _alertsRepository.GetAllTimeWindow();
        }

        public IEnumerable<LookupEnt> LocationList()
        {
            return Lookup.GetLookupDetailsById(1);
        }
        public IEnumerable<LookupEnt> TopicList()
        {
            return Lookup.GetLookupDetailsById(3);
        }
        public IEnumerable<LookupEnt> AudienceList()
        {
            return Lookup.GetLookupDetailsById(4);
        }
        public IEnumerable<LookupEnt> RecipientList()
        {
            return Lookup.GetLookupDetailsById(2);
        }
        public IEnumerable<LookupEnt> ThresholdList()
        {
            return Lookup.GetLookupDetailsById(5);
        }

        public IEnumerable<LookupEnt> MeasureNameList()
        {
            return Lookup.GetLookupDetailsById(6);

        }

        public IEnumerable<LookupEnt> FrequencyList()
        {
            return Lookup.GetLookupDetailsById(7);

        }
        public IEnumerable<LookupEnt> TimeWindowList()
        {
            return Lookup.GetLookupDetailsById(8);

        }
    }
}
