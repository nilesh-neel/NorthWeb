﻿/****************************************************************************************************************
Class Name   : AlertsModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System.Collections.Generic;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Business
{
    public class AlertsModule : IAlertsModule
    {
        private static IAlerts _alertsRepository;

        public AlertsModule(IAlerts alerts)
        {
            //_alertsRepository = alert;
            _alertsRepository = alerts;
            // CRUD oDAL = new CRUD();
        }

        public IEnumerable<Alerts> GetData()
        {
            // return null;//
            return _alertsRepository.GetAll();
        }
        public Alerts GetAlertsById(string id)
        {
            //  return null;// _alertsRepository.GetAlertsById(id);
            return _alertsRepository.GetAlertsById(id);
        }

        public int Save(Alerts alert)
        {
            return _alertsRepository.Save(alert);
        }
    }
}
