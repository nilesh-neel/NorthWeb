﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.Business
{
   public class MenuModule
    {
        private static IMenu _menu { get; set; }
        public MenuModule(IMenu menu)
        {
            _menu = menu;
        }
        public IEnumerable<Menu> GetMenu()
        {
            return _menu.GetAllMenu();
        }
    }
}
