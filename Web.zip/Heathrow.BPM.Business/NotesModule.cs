﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Core.Entity;
using System.Collections.Generic;

namespace Heathrow.BPM.Business
{
    public class NotesModule
    {
        private static INotes _notes { get; set; }
        public NotesModule(INotes notes)
        {
            _notes = notes;
        }

        public IList<Notes> Save(Notes notes)
        {
            if (notes == null && string.IsNullOrEmpty(notes.Notedesc)) return null;
            return _notes.SaveNotes(notes);
        }

        public IList<Notes> Fetch(string Bagtag, string Flightnumber, string Organization)
        {
            return _notes.FetchNotes(Bagtag, Flightnumber, Organization);
        }

        public IList<Notes> DeleteNotes(int notesId, string Bagtag, string Flightnumber, string Organization)
        {
            return _notes.DeleteNotes(notesId, Bagtag, Flightnumber, Organization);
        }
    }
}
