﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace Heathrow.BPM.Business
{
    public class FavouritesModule
    {
        private static IFavourites _favourites { get; set; }
        private static IMenu _menu { get; set; }
        public FavouritesModule(IFavourites favourites, IMenu menu)
        {
            _favourites = favourites;
            _menu = menu;
        }


        public int Save(Favourites fav)
        {
            var _menuList = _menu.GetAllMenu().ToList();

            if (_menuList.Any(a => a.MenuId.Equals(fav.FavouriteLink.MenuId)))
                return _favourites.Save(fav);
            return 999;//999 indicate error on save
        }

        public IEnumerable<Favourites> GetUserFavourites(string _userId)
        {
            return _favourites.GetFavouritesByUserId(_userId);
        }


    }
}
