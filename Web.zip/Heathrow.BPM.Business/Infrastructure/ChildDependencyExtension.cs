﻿using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess;
using Unity.Extension;
using Unity;

namespace Heathrow.BPM.Business.Infrastructure
{
    public class ChildDependencyExtension : UnityContainerExtension
    {
        protected override void Initialize()
        {
            Container.RegisterType<IAlerts, AlertsRepository>();
            Container.RegisterType<INotification, NotificationRepository>();
            Container.RegisterType<IRegistration, RegistrationRepository>();
            Container.RegisterType<ILocation, LocationRepository>();
            Container.RegisterType<ILookup, LookupRepository>();
            Container.RegisterType<IFavourites, FavouritesRepository>();
            Container.RegisterType<IMenu, MenuRepository>();

            Container.RegisterType<INotes, NotesRepository>();
        }
    }
}
