﻿using System.Collections.Specialized;

namespace Heathrow.BPM.Business.Interface
{
    public interface IBpmPowerBi
    {
        string AADAuthorityUri { get; set; }
        NameValueCollection GetAuthorizationCode();
        string RedirectOnAuthentication(string authorizationCode);
        string GetDashboardDetails(string _AccessToken);

    }
}
