﻿using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Heathrow.BPM.Business
{
    public class PowerBIModule : IBpmPowerBi
    {

        public string AADAuthorityUri { get; set; }

        public PowerBIModule()
        {

        }
        public NameValueCollection GetAuthorizationCode()
        {
            AADAuthorityUri = AzureAD.AADAuthorityUri;
            return new NameValueCollection
            {
                //Azure AD will return an authorization code. 
                {"response_type", "code"},

                //Client ID is used by the application to identify themselves to the users that they are requesting permissions from. 
                //You get the client id when you register your Azure app.
                {"client_id",AzureAD.ClinetId},

                //Resource uri to the Power BI resource to be authorized
                //The resource uri is hard-coded for sample purposes
                {"resource", PowerBI.PowerBiAPIResource},

                //After app authenticates, Azure AD will redirect back to the web app. In this sample, Azure AD redirects back
                //to Default page (Default.aspx).
                { "redirect_uri", PowerBI.DashboardRedirectUrl}
            };
        }

        public string RedirectOnAuthentication(string authorizationCode)
        {

            if (authorizationCode != null)
            {
                // Get auth token from auth code       
                TokenCache TC = new TokenCache();

                AuthenticationContext AC = new AuthenticationContext(PowerBI.PowerBiAuthorityUri, TC);
                ClientCredential cc = new ClientCredential(AzureAD.ClinetId, AzureAD.ClientSecret);

                return AC.AcquireTokenByAuthorizationCode(authorizationCode, new Uri(PowerBI.DashboardRedirectUrl), cc).AccessToken;
            }
            else { return ""; }

        }

        public string GetDashboardDetails(string _AccessToken)
        {
            string responseContent = string.Empty;

            //Configure dashboards request
            System.Net.WebRequest request = System.Net.WebRequest.Create(String.Format("{0}dashboards", PowerBI.PowerBiDataset)) as System.Net.HttpWebRequest;
            request.Method = "GET";
            request.ContentLength = 0;
            request.Headers.Add("Authorization", String.Format("Bearer {0}", Convert.ToString(_AccessToken)));

            //Get dashboards response from request.GetResponse()
            using (var response = request.GetResponse() as System.Net.HttpWebResponse)
            {
                //Get reader from response stream
                using (var reader = new System.IO.StreamReader(response.GetResponseStream()))
                {
                    responseContent = reader.ReadToEnd();

                }
            }
            return responseContent ?? "";
        }

        protected void GetReportDetails()
        {
            var WorkspaceId = PowerBI.WorkspaceId;
            var reportId = PowerBI.ReportId;
            var powerBiApiUrl = PowerBI.PowerBiApiUrl;

            //using (var client = new PowerBIClient(new Uri(powerBiApiUrl), new TokenCredentials(Convert.ToString(Session["AccessToken"]), "Bearer")))
            //{
            //    Report report;

            //    //// Settings' workspace ID is not empty
            //    if (!string.IsNullOrEmpty(WorkspaceId))
            //    {
            //        // Gets a report from the workspace.
            //        report = GetReportFromWorkspace(client, WorkspaceId, reportId);
            //    }
            //    // Settings' report and workspace Ids are empty, retrieves the user's first report.
            //    else if (string.IsNullOrEmpty(reportId))
            //    {
            //        var test = client.Reports.GetReports();
            //        report = client.Reports.GetReports().Value.FirstOrDefault();
            //        AppendErrorIfReportNull(report, "No reports found. Please specify the target report ID and workspace in the applications settings.");
            //    }
            //    // Settings contains report ID. (no workspace ID)
            //    else
            //    {
            //        // report = client.Reports.GetReports().Value;
            //        report = client.Reports.GetReports().Value.FirstOrDefault(r => r.Id == reportId);
            //        AppendErrorIfReportNull(report, string.Format("Report with ID: '{0}' not found. Please check the report ID. For reports within a workspace with a workspace ID, add the workspace ID to the application's settings", reportId));
            //    }

            //    if (report != null)
            //    {
            //        List<Report> reports = new List<Report>();
            //        reports.Add(report);

            //        return reports.ToList();
            //    }
            //    return null;
            //}
        }


    }
}
