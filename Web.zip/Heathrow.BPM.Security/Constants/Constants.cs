﻿/*********************************************************************** 
Class Name: Constants.cs 
Purpose :  This class contains constants of the DataAdapter project
Developed By:Vishnupriya E
Start Date: 29/03/2018 End Date: 29/03/2018 
********************************************************************** 
Modification Log 
Author Date Description 
********************************************************************** 
Every time this file is changed add the modification log. 
**********************************************************************/
namespace Heathrow.BPM.Security
{
    public static class Constants
    {
        public static readonly string Success = "TRUE";
        public static readonly string Failure = "FALSE";
    }

}
