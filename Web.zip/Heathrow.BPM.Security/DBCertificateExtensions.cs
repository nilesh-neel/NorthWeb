﻿/********************************************************************* 
Class Name: CertificateExtensions.cs 
Purpose : This class for CertificateExtensions methods
Developed By: Syed
Start Date: 12/06/2017 End Date: 12/06/2017
********************************************************************** 
Modification Log 
Author Date Description 
********************************************************************** 
Every time this file is changed add the modification log. 
**********************************************************************/
using Heathrow.O2P.SharedEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Globalization;
using System.Security.Cryptography.X509Certificates;
using Heathrow.O2P.AzureLogger;
using System.Web;

namespace Heathrow.O2P.Security
{
    public static class CertificateExtensions
    {
        /// <summary>
        /// compare certificate with OriginalCertificate and received certificate from the http request
        /// </summary>
        /// <param name="originalCertificate"></param>
        /// <param name="source"></param>
        /// <param name="certificate"></param>
        /// <param name="validateChain"></param>
        /// <returns></returns>
        public static bool CompareCertificatesWith(this X509Certificate2 originalCertificate, string source, X509Certificate2 certificate, bool validateChain)
        {
            bool ignoreCase = true;
            originalCertificate.ValidateCertificate(source);
            certificate.ValidateCertificate(source);

            //check if certificate subject equals
            if (string.Compare(originalCertificate.Subject, certificate.Subject, ignoreCase) != 0)
                throw new Exception(string.Format(CultureInfo.InvariantCulture,
                    CommonConstants.CertificateSubjectNotMatching,
                    source,
                    originalCertificate.Subject,
                    certificate.Subject
                    ));
            
            //check if certificate Issuer equals
            if (string.Compare(originalCertificate.Issuer, certificate.Issuer, ignoreCase) != 0)
                throw new Exception(string.Format(CultureInfo.InvariantCulture,
                    CommonConstants.CertificateIssuerNotMatching,
                    source,
                    originalCertificate.Issuer,
                    certificate.Issuer
                    ));
           
            //check if certificate Thumbprint equals
            if (string.Compare(originalCertificate.Thumbprint.Trim().ToUpper(), certificate.Thumbprint.Trim().ToUpper(), ignoreCase) != 0)
                throw new Exception(string.Format(CultureInfo.InvariantCulture,
                    CommonConstants.CertificateThumbprintNotMatching,
                    originalCertificate.Thumbprint,
                    source,
                    certificate.Thumbprint
                    ));
            
            //check if certificate SerialNumber equals
            if (string.Compare(originalCertificate.SerialNumber.Trim().ToUpper(), certificate.SerialNumber.Trim().ToUpper(), ignoreCase) != 0)
                throw new Exception(string.Format(CultureInfo.InvariantCulture,
                    CommonConstants.CertificateSerialNotMatching,
                    source,
                    originalCertificate.SerialNumber,
                    certificate.SerialNumber
                    ));

            // If you also want to test if the certificate chains to a Trusted Root Authority you can uncomment the code below
            if (validateChain)
            {
                foreach (var item in new[] { originalCertificate, certificate })
                {
                    X509Chain certChain = new X509Chain();
                    certChain.Build(item);
                    bool isValidCertChain = true;
                    foreach (X509ChainElement chElement in certChain.ChainElements)
                    {
                        //check if chElement valid or not
                        if (!chElement.Certificate.Verify())
                        {
                            isValidCertChain = false;
                            break;
                        }
                    }
                    //check if Valid Cert Chain or not
                    if (!isValidCertChain)
                        throw new Exception(string.Format(CultureInfo.InvariantCulture,
                            CommonConstants.CertificateChainValidationFailed,
                            source,
                            item.Thumbprint
                            ));
                }
            }

            return true;
        }

        /// <summary>
        /// Validate certificate 
        /// </summary>
        /// <param name="certificate"></param>
        /// <param name="source"></param>
        /// <returns></returns>
        public static bool ValidateCertificate(this X509Certificate2 certificate, string source)
        {
            //check if Certificate is null
            if (certificate == null)
                throw new Exception(string.Format(
                    CultureInfo.InvariantCulture, 
                    CommonConstants.CertificateEmpty,
                    source));

            // 1. Check time validity of Certificate
            if (DateTime.Compare(DateTime.Now, certificate.NotBefore) < 0 
                || DateTime.Compare(DateTime.Now, certificate.NotAfter) > 0)
                throw new Exception(string.Format(CultureInfo.InvariantCulture,
                    CommonConstants.CertificateValidFromExpireOn,
                    source,
                    certificate.Thumbprint,
                    certificate.NotBefore,
                    certificate.NotAfter
                    ));

            // 2. Check subject name of Certificate
            if (certificate.Subject.Length == 0)
                throw new Exception(string.Format(CultureInfo.InvariantCulture,
                    CommonConstants.CertificateSubjectNotFound
                    ));

            // 3. Check issuer name of Certificate
            if (certificate.Issuer.Length == 0)
                throw new Exception(string.Format(CultureInfo.InvariantCulture,
                    CommonConstants.CertificateIssuerNotFound
                    ));

            return true;
        }
        /// <summary>
        /// method to Log Certificate Expiry OnPremises
        /// </summary>
        /// <param name="certificate"></param>
        public static void LogCertificateExpiryOnPremises(this X509Certificate2 certificate)
        {
            Logger.LoggerManager logManager = new Logger.LoggerManager();

            //check if Certificate is null
            if (certificate == null)
                throw new Exception(string.Format(
                    CultureInfo.InvariantCulture, 
                    CommonConstants.CertificateEmpty,
                    CommonConstants.AzureServer
                    ));

            int daysLeftToExpiry = (certificate.NotAfter - DateTime.Now).Days;
            List<int> daysToCheck = GetDaysFromConfiguration();
            //check if expiry date for the validation 
            if (daysToCheck.Contains(daysLeftToExpiry) || daysToCheck.Min() >= daysLeftToExpiry)
            {
                logManager.LogException(new Exception(
                    string.Format(
                        CultureInfo.InvariantCulture,
                        CommonConstants.CertificateIsAboutToExpiry,
                        CommonConstants.AzureServer,
                        certificate.Thumbprint,
                        certificate.NotAfter
                    )));
            }
        }
        /// <summary>
        /// method to Log Certificate Expiry OnCloud
        /// </summary>
        /// <param name="certificate"></param>
        public static void LogCertificateExpiryOnCloud(this X509Certificate2 certificate)
        {
            AzureLogger.LoggerManager logManager = new AzureLogger.LoggerManager();

            //check if Certificate is null
            if (certificate == null)
                throw new Exception(string.Format(
                    CultureInfo.InvariantCulture, 
                    CommonConstants.CertificateEmpty,
                    CommonConstants.ClientMachine
                    ));
            int daysLeftToExpiry = (certificate.NotAfter - DateTime.Now).Days;
            List<int> daysToCheck = GetDaysFromConfiguration();
            //check if expiry date for the validation 
            if (daysToCheck.Contains(daysLeftToExpiry) || daysToCheck.Min() >= daysLeftToExpiry)
            {
                logManager.LogException(new WebAppExceptionLog(HttpContext.Current)
                {
                    ErrorMessage = string.Format(
                        CultureInfo.InvariantCulture,
                        CommonConstants.CertificateIsAboutToExpiry,
                        CommonConstants.ClientMachine,
                        certificate.Thumbprint,
                        certificate.NotAfter
                    )
                });
            }
        }
        /// <summary>
        /// method gets Days From Configuration
        /// </summary>
        /// <returns></returns>
        private static List<int> GetDaysFromConfiguration()
        {
            int temp = 0;
            List<int> daysToCheck = new List<int>();

            string[] daysReceivedToCheck = ConfigurationManager
                .AppSettings[CommonConstants.CertificateExpiryValidation]
                .Split(new[] { "," }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string item in daysReceivedToCheck)
            {
                if (int.TryParse(item, out temp))
                {
                    daysToCheck.Add(temp);
                }
            }

            return daysToCheck;
        }
    }
}
