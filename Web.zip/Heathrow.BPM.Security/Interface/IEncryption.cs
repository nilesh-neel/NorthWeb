﻿/*********************************************************************** 
Class Name: IEncryption.cs 
Purpose : IEncryption interface class will contain methods for
          encryption
Developed By:Vishnupriya E
Start Date: 29/03/2018 End Date: 29/03/2018 
********************************************************************** 
Modification Log 
Author Date Description 
********************************************************************** 
Every time this file is changed add the modification log. 
**********************************************************************/
namespace Heathrow.BPM.Security
{
    public interface IEncryption
    {
        /// <summary>
        /// Decrypt method
        /// </summary>
        /// <param name="encryptedText"></param>
        /// <param name="encryptionKey"></param>
        /// <returns></returns>
        string Decrypt(string encryptedText, string encryptionKey);
        /// <summary>
        /// Encrypt method
        /// </summary>
        /// <param name="text"></param>
        /// <param name="encryptionKey"></param>
        /// <returns></returns>
        string Encrypt(string text, string encryptionKey);
    }
}
