﻿/*********************************************************************** 
Class Name: AesEncryption.cs 
Purpose : Class for encryption and decryption
Developed By:Vishnupriya E
Start Date: 29/03/2018 End Date: 29/03/2018 
********************************************************************** 
Modification Log 
Author Date Description 
********************************************************************** 
Every time this file is changed add the modification log. 
**********************************************************************/

using System;
using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
namespace Heathrow.BPM.Security
{
    public class AesEncryption : IEncryption
    {
        private string logExceptionInAzure = string.Empty;
        //private readonly Logging.Logger _logger;
       
        //public AesEncryption(Logger logger)
        //{
        //    _logger = logger;
        //}

        /// <summary>
        /// This method is used to decrypt the encrypted access using the Key
        /// </summary>
        /// <param name="encryptedText"></param>
        /// <param name="encryptionKey"></param>
        /// <returns></returns>
        public string Decrypt(string encryptedText, string encryptionKey)
        {
            byte[] bytesToBeDecrypted = Convert.FromBase64String(encryptedText);
            byte[] accessBytes = Encoding.UTF8.GetBytes(encryptionKey);
            byte[] originalBytes = null;
            try
            {
                // Hash the access with SHA256
                accessBytes = SHA256.Create().ComputeHash(accessBytes);

                byte[] decryptedBytes = AesDecrypt(bytesToBeDecrypted, accessBytes);

                // Getting the size of salt
                int _saltSize = 4;

                // Removing salt bytes, retrieving original bytes
                originalBytes = new byte[decryptedBytes.Length - _saltSize];
                for (int rowCount = _saltSize; rowCount < decryptedBytes.Length; rowCount++)
                {
                    originalBytes[rowCount - _saltSize] = decryptedBytes[rowCount];
                }
            }
            catch (Exception exception)
            {                
                 //_logger.WriteError(exception);
                //check if exception is azure status
                if (logExceptionInAzure.ToUpper(CultureInfo.InvariantCulture) == Constants.Failure)
                {
                    //Code to go
                }
                else if (logExceptionInAzure.ToUpper(CultureInfo.InvariantCulture) == Constants.Success)
                {
                    throw exception;
                }
            }
            finally
            {
                SHA256.Create().Dispose();
            }
            return Encoding.UTF8.GetString(originalBytes);
        }
        /// <summary>
        /// private method for decryption
        /// </summary>
        /// <param name="valueToBeDecrypted"></param>
        /// <param name="accessValue"></param>
        /// <returns></returns>
        private byte[] AesDecrypt(byte[] valueToBeDecrypted, byte[] accessValue)
        {
            byte[] decryptedBytes = null;

            // Set your salt here, change it to meet your flavor:
            // The salt bytes must be at least 8 bytes.
            byte[] saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };

            try
            {
                using (MemoryStream memoryStream = new MemoryStream())
                {
                    using (RijndaelManaged AES = new RijndaelManaged())
                    {
                        AES.KeySize = 256;
                        AES.BlockSize = 128;

                        using (var key = new Rfc2898DeriveBytes(accessValue, saltBytes, 1000))
                        {
                            AES.Key = key.GetBytes(AES.KeySize / 8);
                            AES.IV = key.GetBytes(AES.BlockSize / 8);

                            AES.Mode = CipherMode.CBC;
                            //check is value to be decrypted is null
                            if (valueToBeDecrypted != null && valueToBeDecrypted.Length > 0)
                            {
                                using (var cs = new CryptoStream(memoryStream, AES.CreateDecryptor(),
                                    CryptoStreamMode.Write))
                                {
                                    cs.Write(valueToBeDecrypted, 0, valueToBeDecrypted.Length);
                                    cs.Close();
                                }
                            }
                            decryptedBytes = memoryStream.ToArray();
                        }
                    }
                }
            }
            catch (Exception exception)
            {                
                 //_logger.WriteError(exception);
                //check if exception is azure status
                if (logExceptionInAzure.ToUpper(CultureInfo.InvariantCulture) == Constants.Failure)
                {
                    //Code to go
                }
                else if (logExceptionInAzure.ToUpper(CultureInfo.InvariantCulture) == Constants.Success)
                {
                    throw exception;
                }
            }

            return decryptedBytes;
        }

        /// <summary>
        /// Method to encrypt using AES 
        /// </summary>
        /// <param name="valueToBeEncrypted"></param>
        /// <param name="accessValue"></param>
        /// <returns></returns>
        private byte[] AesEncrypt(byte[] valueToBeEncrypted, byte[] accessValue)
        {
            byte[] encryptedBytes = null;

            byte[] saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };
            MemoryStream memoryStream = new MemoryStream();

            try
            {
                //memoryStream = new MemoryStream();
                RijndaelManaged AES = new RijndaelManaged();
                try
                {
                    AES.KeySize = 256;
                    AES.BlockSize = 128;
                    try
                    {
                        using (var key = new Rfc2898DeriveBytes(accessValue, saltBytes, 1000))
                        {
                            AES.Key = key.GetBytes(AES.KeySize / 8);
                            AES.IV = key.GetBytes(AES.BlockSize / 8);

                            AES.Mode = CipherMode.CBC;
                            //check if value to be encrypted is null
                            if (valueToBeEncrypted != null && valueToBeEncrypted.Length > 0)
                            {
                                using (CryptoStream cs = new CryptoStream(memoryStream, AES.CreateEncryptor(),
                                    CryptoStreamMode.Write))
                                {
                                    cs.Write(valueToBeEncrypted, 0, valueToBeEncrypted.Length);
                                    cs.Close();
                                }
                            }
                        }
                        encryptedBytes = memoryStream.ToArray();
                        AES.Clear();
                        
                    }
                    catch (Exception exception)
                    {                       
                        //_logger.WriteError(exception);
                        //check if exception is azure status
                        if (logExceptionInAzure.ToUpper(CultureInfo.InvariantCulture) == Constants.Failure)
                        {
                            //code to go
                        }
                        else if (logExceptionInAzure.ToUpper(CultureInfo.InvariantCulture) == Constants.Success)
                        {
                            throw exception;
                        }
                    }
                }
                finally
                {
                    if (AES != null)
                        AES.Dispose();
                }
            }
            finally
            {
                if (memoryStream != null)
                    memoryStream.Dispose();
            }

            return encryptedBytes;
        }

        /// <summary>
        /// Method to do encryption - Takes the accessValue and key as Input
        /// </summary>
        /// <param name="text"></param>
        /// <param name="encryptionKey"></param>
        /// <returns></returns>
        public string Encrypt(string text, string encryptionKey)
        {
            byte[] originalBytes = Encoding.UTF8.GetBytes(text);
            byte[] encryptedBytes = null;
            byte[] accessBytes = Encoding.UTF8.GetBytes(encryptionKey);
            byte[] bytesToBeEncrypted = null;
            try
            {
                accessBytes = SHA256.Create().ComputeHash(accessBytes);

                // Generating salt bytes
                byte[] saltBytes = GetRandomBytes();

                // Appending salt bytes to original bytes
                bytesToBeEncrypted = new byte[saltBytes.Length + originalBytes.Length];
                for (int rowCount = 0; rowCount < saltBytes.Length; rowCount++)
                {
                    bytesToBeEncrypted[rowCount] = saltBytes[rowCount];
                }
                for (int rowValue = 0; rowValue < originalBytes.Length; rowValue++)
                {
                    bytesToBeEncrypted[rowValue + saltBytes.Length] = originalBytes[rowValue];
                }

                encryptedBytes = AesEncrypt(bytesToBeEncrypted, accessBytes);

            }
            catch (Exception exception)
            {               
               // _logger.WriteError(exception);
                if (logExceptionInAzure.ToUpper(CultureInfo.InvariantCulture) == Constants.Success)
                {
                    //Code to go
                }
                else if (logExceptionInAzure.ToUpper(CultureInfo.InvariantCulture) == Constants.Failure)
                {
                    throw exception;
                }
            }
            finally
            {
                SHA256.Create().Dispose();
            }
            // Hash the accessValue with SHA256
            return Convert.ToBase64String(encryptedBytes);
        }

        /// <summary>
        /// Method which will generate the Random number in byte array
        /// </summary>
        /// <returns></returns>
        private byte[] GetRandomBytes()
        {
            int _saltSize = 4;
            byte[] ba = new byte[_saltSize];
            RandomNumberGenerator.Create().GetBytes(ba);
            return ba;
        }
    }
}
