﻿using Heathrow.BPM.Core.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Heathrow.BPM.Web.Configuration
{
    public class ConnectionManager
    {

        /// <summary>
        /// Below method will get the access keys from azure keyvalut store
        /// </summary>
        /// <returns></returns>
        public ConnectionKey GetConnection()
        {
            ConnectionKey _accesDetails = new ConnectionKey();


            return _accesDetails;

        }
    }
}