﻿using Heathrow.BPM.Business.Infrastructure;
using Heathrow.BPM.Core.Interface;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Web.Mvc;
using Unity;
using Unity.Mvc5;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Web.ViewModel;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Business;

namespace Heathrow.BPM.Web.Configuration
{
    public class Bootstrap
    {
        public static void Initialise()
        {
            var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            // e.g. container.RegisterType<ITestService, TestService>();

            //container.RegisterType<ICourseService, CourseService>();
            //container.RegisterType<IInstitutionService, InstitutionService>();

            //  container.LoadConfiguration();
            //container.ResolveAll<IMapper>();

            container.RegisterType<IMapper<FavouritesVM, Favourites>, FavouriteMapping>();

            container.RegisterType<IMapper<RegistrationVM, Registration>, RegistrationMapping>();
            container.RegisterType<IMapper<NotificationVM, Notification>, NotificationMapping>();
            container.RegisterType<IMapper<LocationVM, Location>, LocationMapping>();
            container.RegisterType<IMapper<AlertVM,Alerts>,AlertMapping>();
            container.RegisterType<IMapper<MenuVM, Menu>, MenuMapping>();
            container.RegisterType<IBpmPowerBi, PowerBIModule>();
            container.RegisterType<IMapper<NotesVM, Notes>, NotesMapping>();
            container.AddNewExtension<ChildDependencyExtension>();
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));

            
        }

    }

}