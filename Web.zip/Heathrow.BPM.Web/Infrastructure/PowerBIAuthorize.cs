﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Web;

namespace Heathrow.BPM.Web.Infrastructure
{
    public class PowerBIAuthorize
    {
        /* private static readonly string _PowerBiAPIResource = ConfigurationManager.AppSettings["PowerBiAPIResource"];
         private static readonly string _AADAuthorityUri = ConfigurationManager.AppSettings["AADAuthorityUri"];
         private static readonly string _PowerBiDataset = ConfigurationManager.AppSettings["PowerBiDataset"];
         private static readonly string _PowerBiApiUrl = ConfigurationManager.AppSettings["PowerBiApiUrl"];

         private static readonly string _RedirectUrl = ConfigurationManager.AppSettings["DashboardRedirectUrl"];
         private static readonly string _ClinetId = ConfigurationManager.AppSettings["ClinetId"];
         private static readonly string _ClientSecret = ConfigurationManager.AppSettings["ClientSecret"];


         private string GetAuthorizationCode()
         {
             var @params = new NameValueCollection
             {
                 //Azure AD will return an authorization code. 
                 {"response_type", "code"},

                 //Client ID is used by the application to identify themselves to the users that they are requesting permissions from. 
                 //You get the client id when you register your Azure app.
                 {"client_id",_ClinetId},

                 //Resource uri to the Power BI resource to be authorized
                 //The resource uri is hard-coded for sample purposes
                 {"resource", _PowerBiAPIResource},

                 //After app authenticates, Azure AD will redirect back to the web app. In this sample, Azure AD redirects back
                 //to Default page (Default.aspx).
                 { "redirect_uri", _RedirectUrl}
             };

             //Create sign-in query string
             var queryString = HttpUtility.ParseQueryString(string.Empty);
             queryString.Add(@params);


             return String.Format(_AADAuthorityUri + "?{0}", queryString);
         }

         public void GetDashboard()
         {
             try
             {
                 if (Session["AccessToken"] != null)
                 {
                     //Get the authentication result from the session
                     //authResult = (AuthenticationResult)Session[authResultString];

                     //objAut.authResult = authResult;
                     var data = (IEnumerable<PBIDashboard>)GetDashboardDetails();
                     TempData["data"] = data;
                     return RedirectToAction("Index");
                 }
                 return RedirectToAction("Index");


             }
             catch
             {
                 return RedirectToAction("Index");
             }
         }

     }

     public class PBIDashboards
     {
         public PBIDashboard[] value { get; set; }
     }

     public class PBIDashboard
     {
         public string id { get; set; }
         public string displayName { get; set; }
         public string embedUrl { get; set; }
         public bool isReadOnly { get; set; }
     }*/
    }
}