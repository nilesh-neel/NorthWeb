﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Heathrow.BPM.Web
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            SetCutomeViewPath();
            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Dashboard", action = "Index", id = UrlParameter.Optional }
            );
        }

        private static void SetCutomeViewPath()
        {

            var razorEngine = ViewEngines.Engines.OfType<RazorViewEngine>().FirstOrDefault();
            razorEngine.ViewLocationFormats = razorEngine.ViewLocationFormats.Concat(
                    new string[] {
                        "~/Views/Desktop/{1}/{0}.cshtml",
                        "~/Views/Desktop/{0}.cshtml"
                        // add other folders here (if any)
                    }).ToArray();

            // Add  folder to the default location scheme for PARTIAL Views
            razorEngine.PartialViewLocationFormats =
                razorEngine.PartialViewLocationFormats.Concat(
                    new string[] {
                        //"~/Views/Desktop/Shared/{0}.cshtml",
                     "~/Views/Desktop/Alerts/{0}.cshtml",
                     "~/Views/Desktop/Notes/{0}.cshtml",
                      "~/Views/Desktop/Shared/{0}.cshtml",
                      "~/Views/Desktop/{0}.cshtml",
                       "~/Views/Desktop/AssignHomePage/{0}.cshtml",
                       "~/Views/Desktop/Notifications/{0}.cshtml"
                    //"~/Views/Desktop/{1}/{0}.cshtml"
                   

                    // add other folders here (if any)
                }).ToArray();
        }
    }
}
