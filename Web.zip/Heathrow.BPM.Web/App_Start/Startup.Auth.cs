﻿using Microsoft.IdentityModel.Tokens;
using Microsoft.Owin.Security.ActiveDirectory;
using Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Web
{
    public partial class Startup
    {
        public void ConfigureAuth(IAppBuilder app)
        {
            app.UseWindowsAzureActiveDirectoryBearerAuthentication(
                new WindowsAzureActiveDirectoryBearerAuthenticationOptions
                {
                    Tenant = AzureAD.AzureADTenant,
                    TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidAudience = AzureAD.ClinetId
                    }
                });
        }
    }
}