﻿using System.Web;
using System.Web.Optimization;

namespace Heathrow.BPM.Web
{
    public class BundleConfig
    {
        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at https://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        //"~/Scripts/modernizr-*",
                        "~/Scripts/polyfill.min"

                        ));

            bundles.Add(new ScriptBundle("~/bundles/vendor").Include(
                 "~/Scripts/jquery-3.3.1.js",
                 "~/Scripts/jquery-ui.min.js",
                 "~/Scripts/jquery.validate.unobtrusive.min",
                 "~/Scripts/powerbi/adal.js",
                 "~/Scripts/powerbi/powerbi.js",
                 "~/Scripts/powerbi/powerBIApp.js",
                 "~/Scripts/validator.js",
                 "~/Scripts/lodash.min.js",
                 "~/Scripts/bootstrap.min.js",
                 "~/Scripts/jquery.dataTables.min.js",
                 "~/Scripts/moment.min.js",
                 "~/Scripts/daterangepicker.js",
                 "~/Scripts/ion.rangeSlider.js",
                 "~/Scripts/jquery.multiselect.js",
                  "~/Scripts/comboBox.js",

                 "~/Scripts/script.js"));

            bundles.Add(new ScriptBundle("~/bundles/appJS").IncludeDirectory(
                   "~/Scripts/App/", "*.js", true));


            bundles.Add(new StyleBundle("~/bundles/Content").Include(
                      "~/Content/jquery-ui.min.css",
                      "~/Content/bootstrap.min.css",
                      "~/Content/jquery.dataTables.min.css",
                      "~/Content/daterangepicker.css",
                      "~/Content/ion.rangeSlider.css",
                      "~/Content/jquery.multiselect.css",
                       "~/Content/skin2.css",
                      "~/Content/style.css"));
#if DEBUG
            BundleTable.EnableOptimizations = false;
#else
            BundleTable.EnableOptimizations = true;
#endif

        }
    }
}
