﻿using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Web.ViewModel;
using System.Web.Mvc;

namespace Heathrow.BPM.Web.Controllers
{
    public class MenuController : Controller
    {
        private static MenuModule _menuModule;
        private readonly IMapper<MenuVM, Menu> Map;
        private static IMenu _menu { get; set; }

        public MenuController(IMenu menu, IMapper<MenuVM, Menu> _map)
        {
            _menuModule = new MenuModule(menu);
            Map = _map;
        }

        [HttpGet]
        [Route("MenuList")]
        public JsonResult GetAllMenu()
        {
            return Json(
                Map.MapFrom(_menuModule.GetMenu()),
                JsonRequestBehavior.AllowGet);
        }

    }
}