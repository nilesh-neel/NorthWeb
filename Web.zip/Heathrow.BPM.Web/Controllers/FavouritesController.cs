﻿using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Web.Filters;
using Heathrow.BPM.Web.ViewModel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Linq;
namespace Heathrow.BPM.Web.Controllers
{
    [ModelStateException]
    [BPMErrorHandler]
    public class FavouritesController : Controller
    {
        private static FavouritesModule _favouritesModule;
        private readonly IMapper<FavouritesVM, Favourites> Map;
        private static IMenu _menu { get; set; }

        public FavouritesController(IFavourites fav, IMenu menu, IMapper<FavouritesVM, Favourites> _map)
        {
            _favouritesModule = new FavouritesModule(fav, menu);
            Map = _map;
        }

        [HttpGet]
        [Route("Get")]
        public ActionResult GetAll(string _userId)
        {
            return Json(
                Map.MapFrom(_favouritesModule.GetUserFavourites(_userId)),
                JsonRequestBehavior.AllowGet);
        }

        [HttpPost]

        public JsonResult Save(FavouritesVM data)
        {
            try
            {
                if (!ModelState.IsValid)
                    throw new ModelStateException(ModelState);

                var objFavCore = Map.MapTo(data);
                if (_favouritesModule.Save(objFavCore).Equals(0))
                    return Json("Data save succes.", JsonRequestBehavior.AllowGet);
                return Json("Data save fail.", JsonRequestBehavior.AllowGet);
            }
           
            catch (Exception ex)
            {

                throw ex;
            }

        }

        [HttpGet]
        public JsonResult xmltoJson(string xml)
        {
            string jsonText = string.Empty;
            try
            {
                XmlDocument doc = new XmlDocument();
                XmlReaderSettings settings = new XmlReaderSettings();
                settings.ConformanceLevel = ConformanceLevel.Fragment;
                settings.IgnoreWhitespace = true;

                using (XmlReader reader = XmlReader.Create(xml, settings))
                {
                    while (reader.Read())
                    {
                        if (reader.NodeType == XmlNodeType.Element)
                        {
                            var node = doc.ReadNode(reader);
                            jsonText = JsonConvert.SerializeXmlNode(node);
                        }
                    }
                }

                // var result = JsonConvert.DeserializeObject(jsonText);
                return Json(jsonText, JsonRequestBehavior.AllowGet);

            }
            catch (Exception ex)
            {
                //return Json(ex.Message, JsonRequestBehavior.AllowGet);
                throw ex;
            }

        }


    }
}