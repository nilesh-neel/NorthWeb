﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Heathrow.BPM.Web.Controllers
{
    public class AssignHomePageController : Controller
    {
       // private static NotificationModule _notifyModule;
      //  public NotificationsController(INotification notify)
      //  {
      //      _notifyModule = new NotificationModule(notify);
      //  }
        // GET: Notifications
        public ActionResult Index()
        {
            return View("AssignHomePage");
        }

        public ActionResult AssignHomePageView()
        {

            return PartialView("_AssignHomePage");
        }
    }
}