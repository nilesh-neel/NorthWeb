﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using Heathrow.BPM.Business.Interface;
using System.Collections.Specialized;

namespace Heathrow.BPM.Web.Controllers
{
    public class DashboardController : Controller
    {
        private readonly IBpmPowerBi _bpmPowerBi;
        public DashboardController(IBpmPowerBi bpmPowerBi)
        {
            _bpmPowerBi = bpmPowerBi;

        }
        // GET: Dashboard
        public ActionResult Index()
        {
            if (Request.Params.Get("code") != null)
            {
                Session["AccessToken"] = _bpmPowerBi.RedirectOnAuthentication(Request.Params.GetValues("code")[0]);
                ViewBag.DashboardAccessToken = Session["AccessToken"];
            }
            else if (string.IsNullOrEmpty(Convert.ToString(Session["AccessToken"])))
            {
                var queryString = HttpUtility.ParseQueryString(string.Empty);
                queryString.Add(_bpmPowerBi.GetAuthorizationCode());

                return Redirect(String.Format(_bpmPowerBi.AADAuthorityUri + "?{0}", queryString));
            }

            return View();
        }

        [HttpGet]
        public ActionResult GetData()
        {

            if (string.IsNullOrEmpty(Convert.ToString(Session["AccessToken"])))
            {
                var queryString = HttpUtility.ParseQueryString(string.Empty);
                queryString.Add(_bpmPowerBi.GetAuthorizationCode());

                return Redirect(String.Format(_bpmPowerBi.AADAuthorityUri + "?{0}", queryString));
            }
            else
            {

                return Json(Convert.ToString(Session["AccessToken"]), JsonRequestBehavior.AllowGet);
            }
        }


        public ActionResult SignIn()
        {
            var queryString = HttpUtility.ParseQueryString(string.Empty);
            queryString.Add(_bpmPowerBi.GetAuthorizationCode());

            return Redirect(String.Format(_bpmPowerBi.AADAuthorityUri + "?{0}", queryString));
        }

    }
}