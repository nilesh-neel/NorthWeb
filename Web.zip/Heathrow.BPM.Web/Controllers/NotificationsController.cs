﻿using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Web.ViewModel;



namespace Heathrow.BPM.Web.Controllers
{
    public class NotificationsController : Controller
    {
        private readonly IMapper<NotificationVM, Notification> Map;
        private static NotificationModule _notifyModule;
        
        public NotificationsController(INotification notify,ILookup _lookup, IMapper<NotificationVM, Notification> _map)
        {
            _notifyModule = new NotificationModule(notify,_lookup);
            Map = _map;
        }
        // GET: Notifications
        public ActionResult Index()
        {
          
            return View("NotificationsSettings");
        }

        public ActionResult TodaysNotification()
        {

            return PartialView("_TodaysNotification");
        }

        [HttpGet]
        [Route("Get")]
        public ActionResult GetAll()
        {

            return Json(
               Map.MapFrom(_notifyModule.GetTodaysNotification()),
                JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        [Route("Get")]
        public ActionResult GetNotificationById()
        {
            return Json(
                Map.MapFrom(_notifyModule.GetNotificationById("NOT01")),
                JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult Update(NotificationVM data)
        {

            if (!ModelState.IsValid)
                return null;

            var objNotifCore = Map.MapTo(data);
            
            if (_notifyModule.Save(objNotifCore).Equals(0))
                return Json("Data save succes.", JsonRequestBehavior.AllowGet);
            return Json("Data save fail.", JsonRequestBehavior.AllowGet);

        }
    }
}