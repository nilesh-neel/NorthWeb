﻿using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Web.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Web.ViewModel;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.IO;

namespace Heathrow.BPM.Web.Controllers
{
    [CompressFilter]
    public class AlertsController : Controller
    {

        private readonly IMapper<AlertVM, Alerts> Map;
        private static AlertsModule _alertModule;

        public AlertsController(IAlerts alerts, IMapper<AlertVM, Alerts> _map)
        {
            _alertModule = new AlertsModule(alerts);
            Map = _map;
        }

        // GET: Alerts
        public ActionResult Index()
        {
            //_alertModule.GetAlertsById("123");
            //List<AlertVM> alertVm;

            //using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/alerts.json")))
            //{
            //    alertVm = JsonConvert.DeserializeObject<List<AlertVM>>(readFile.ReadToEnd());
            //}


            return PartialView("_LandingPage");
        }

        [HttpGet]
        //[Route("TodayAlerts")]
        public JsonResult GetTodaysAlers()
        {
            List<AlertVM> alertVm;

            using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/alerts.json")))
            {
                alertVm = JsonConvert.DeserializeObject<List<AlertVM>>(readFile.ReadToEnd());
            }

            return Json(alertVm, JsonRequestBehavior.AllowGet);
        }


        public ActionResult Edit(string id)
        {
            List<AlertVM> alertVm;

            using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/alerts.json")))
            {
                alertVm = JsonConvert.DeserializeObject<List<AlertVM>>(readFile.ReadToEnd());
            }

            return PartialView("_ConfigurNewAlert", alertVm.FirstOrDefault());
        }

        public ActionResult TodaysAlert()
        {
            return PartialView("_TodayAlerts");
        }

        public PartialViewResult MyAlerts()
        {
            return PartialView("_TodayAlerts");
        }


        [HttpGet]
        [Route("Get")]
        public ActionResult GetAll()
        {

            return Json(
               Map.MapFrom(_alertModule.GetData()),
                JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        [Route("Get")]
        public ActionResult GetAlertById()
        {
            return Json(
                Map.MapFrom(_alertModule.GetAlertsById("ALT01")),
                JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult Update(AlertVM data)
        {

            if (!ModelState.IsValid)
                return null;

            var objNotifCore = Map.MapTo(data);

            if (_alertModule.Save(objNotifCore).Equals(0))
                return Json("Data save succes.", JsonRequestBehavior.AllowGet);
            return Json("Data save fail.", JsonRequestBehavior.AllowGet);

        }

    }
}