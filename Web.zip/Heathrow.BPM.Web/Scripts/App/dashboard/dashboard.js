﻿(function () {
    'use strict';
    $(document).ready(function () {
        var intervalID;
        var dashboardPowerBiApi = new PowerBIAPP(null, 'true');
        dashboardPowerBiApi.embedPowerBIApi();

        $('#spnAutoUpdate').on('click', function () {
            var self = $(this)[0];
            if ($(this).data('update') === true) {
                intervalID = setInterval(function () {
                    console.log('Interval 15 seconds call..');
                    if (!_.isNull(self.dataset.powerbiurl)) {
                        dashboardPowerBiApi = new PowerBIAPP(self.dataset.powerbiurl, self.dataset.isreport);
                        dashboardPowerBiApi.embedPowerBIApi();

                    } else {
                        dashboardPowerBiApi.refreshReport();
                    }
                    $('#divDate').html(moment().format(" DD/MM/YYYY, hh:mm:ss"));
                }, 15000);
                $(this).data('update', false);
            } else {
                console.log('Interval 15 seconds call clear..'); clearInterval(intervalID);
                $(this).data('update', true);
            }
        });

        $('.print').on('click', function () {

            dashboardPowerBiApi.printReport();

            //html2canvas($('#embedContainer')[0], {
            //    onrendered: function (canvas) {
            //        document.body.appendChild(canvas);
            //        //var imgData = canvas.toDataURL("image/jpeg");
            //        //var pdf = new jsPDF();
            //        //pdf.addImage(imgData, 'JPEG', 0, 0, -180, -180);
            //        //pdf.save("download.pdf");
            //    }
            //});

        });




    });

})();
