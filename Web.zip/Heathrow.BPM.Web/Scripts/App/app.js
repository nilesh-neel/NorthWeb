﻿var favObject = '';

(function ($) {
    'use strict';

    $('.homeLinkIcon').on('click', function () {
        window.location.href = '/Dashboard/Index';
    });


    $('#spnScan').on('click', function () {
        $("#livestream_scanner").modal('show');
    });

    //Code Start to bind the menu
    $(document).ready(function () {

        //first bind the menu then call powerbi API.
        var service = new Service('/Menu/GetAllMenu');

        $.when(service.get()
                .then(function (resp) {
                    bindMenu(resp);
                    var dashboardPowerBiApi = new PowerBIAPP(null, 'true');
                    dashboardPowerBiApi.embedPowerBIApi();
                }).catch(function (jqXHR, textStatus, err) {
                    alert('Unable to fetch data for menu: ' + textStatus);
                })
              );

        $('#divDate').html(moment().format(" DD/MM/YYYY, hh:mm:ss"));

        var bindMenu = function (menuData) {
            var menuHtml = '';
            var parentMenu = _.takeWhile(menuData, function (o) { return o.parentId === 0; });

            for (var i = 0; i < parentMenu.length; i++) {

                var childList = _.filter(menuData, { parentId: parentMenu[i].menuId });
                if (_.isEmpty(childList)) {
                    menuHtml += '<li><span class="' + parentMenu[i].cssIcon + '"></span></li>';
                }
                else {
                    var childhtml = '';
                    _.forEach(childList, function (child) {
                        childhtml += '<a id="' + child.menuId + '"data-isreport="' + child.isReport + '"data-powerbiurl="' + child.url + '" href=#>' + child.description + '</a>';
                    }) + '</li>';
                    menuHtml += '<li class="subDropdown"><span class="' + parentMenu[i].cssIcon + '"></span><div class="dropdown-content">' + childhtml + '</div></li>';
                }
            }

            menuHtml += '<li><span class="defaultIcons .mSetting"></span></li>';
            $('.menu').html(menuHtml)

            $('.dropdown-content a').on('click', function () {
                var self = $(this)[0];
                //$('#spnAutoUpdate').attr("data-powerbiurl", self.dataset.powerbiurl);
                //$('#spnAutoUpdate').attr("data-isreport", self.dataset.isreport);
                //var oPowerBiApi = new PowerBIAPP(self.dataset.powerbiurl, self.dataset.isreport);

                $('#spnAutoUpdate').attr("data-powerbiurl", self.getAttribute('powerbiurl'));
                $('#spnAutoUpdate').attr("data-isreport", self.getAttribute('isreport'));
                var oPowerBiApi = new PowerBIAPP(self.getAttribute('powerbiurl'), self.getAttribute('isreport'));

                oPowerBiApi.embedPowerBIApi();
            })
        }

        //Code End to bind the menu
    });

    var dangerAlter = function () {
        $(".danger-alert").css('display', 'block');

        $("#danger-alert").fadeTo(2000, 500).slideUp(500, function () {
            $("#danger-alert").slideUp(500);
        });

        if (XMLHttpRequest.status === 400) {
            $('#messageToClient').text(XMLHttpRequest.responseText);
        }
        else { $('#messageToClient').text('Error in application..'); }
    };

})(jQuery);