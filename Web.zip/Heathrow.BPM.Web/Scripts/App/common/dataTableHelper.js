﻿var CustomGrid = (function () {
    'use strict';

    CustomGrid = function (tableDiv, tableData, tableColumn, showDetails, allowEdit) {
        this.GridDivName = tableDiv;
        this.Data = tableData;
        this.Column = tableColumn;
        this.AllowShow = _.isNull(showDetails) || _.isUndefined(showDetails) ? false : true;
        this.AllowEdit = _.isNull(allowEdit) || _.isUndefined(allowEdit) ? false : true;
        //this.TableObject = $(this.GridDivName).dataTable();
    };

    CustomGrid.prototype.CreateGrid = function (configForAlert) {

        $(this.GridDivName).dataTable({
            "data": this.Data,
            "columns": this.Column,
            "pagingType": "full_numbers",
            "ordering": false,
            "info": false,
            "bLengthChange": false,
            "bAutoWidth": false,
            "searching": false,
            "responsive": true,
            "oLanguage": {
                "oPaginate": {
                    "sFirst": "First",
                    "sNext": '<img class="Next" src="" />',
                    "sPrevious": '<img class="Previous" src="" />',
                    "sLast": "Last"
                }
            },
            "bDestroy": true
        });


        if (this.AllowShow) { this.ShowDetails(); }
        if (this.AllowEdit) { this.EditRow(configForAlert); }
    }

    CustomGrid.prototype.ShowDetails = function () {
        $(this.GridDivName + ' tbody td').on('click', '.Show_details', function () {
            var nTr = $(this).parents('tr')[0];
            var oTable = $(this).parents('table').dataTable();
            if (oTable.fnIsOpen(nTr)) {
                /* This row is already open - close it */
                //this.src = "./images/Icons/DefaultIcons.png";
                $(this).closest("tr").find("td").toggleClass("showDetailsActive");
                $(this).toggleClass("clickedIcons");
                $(this).next().toggleClass("clickedIcons");
                oTable.fnClose(nTr);
                $("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
            }
            else {
                /* Open this row */
                //this.src = "./images/Icons/DefaultIcons.png";
                $(this).closest("tr").find("td").toggleClass("showDetailsActive");
                $(this).toggleClass("clickedIcons");
                $(this).next().toggleClass("clickedIcons");
                oTable.fnOpen(nTr, fnFormatDetails(oTable, nTr), 'details');
                $("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
            }
        });
    }


    CustomGrid.prototype.EditRow = function (configAlertTab) {
        if (configAlertTab) {
            $(this.GridDivName + ' .Edit').click(function () {
                $("#alertSettingTable_wrapper,#configureAlertsTable_wrapper,#tabs a[href='#alertSettings'],#tabs a[href='#todaysAlerts']").css('display', 'none');
                $('#congigureNewAlertBtn').css('display', 'none');
                $('#configureBackBtn').css('display', 'block');
                $('.configureAlertForm').css('display', 'block');
                $('.configureAlertForm').load('Alerts/Edit');

            });
        } else {
            $(this.GridDivName + ' .Edit').click(function () {
                $("#alertSettingTable_wrapper,#configureAlertsTable_wrapper,#tabs a[href='#alertSettings'],#tabs a[href='#todaysAlerts']").css('display', 'none');
                $('#congigureNewAlertBtn').css('display', 'none');
                $('#configureBackBtn').css('display', 'block');
                $('.configureAlertForm').css('display', 'block');
                $('.configureAlertForm').load('Alerts/Edit');

            });
        }

     
    }


    return CustomGrid;

})();