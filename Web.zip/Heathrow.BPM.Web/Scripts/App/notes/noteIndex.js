﻿(function ($)
{
    'use strict';

    //$(document).ready(function () {
    //    $(".delete").click(function () {
    //        alert("333");
    //    });
    //});

    //var noteList;
    //var tempdata = { };

    //if (data)
    //$(document).ready(function () {
    //    $.ajax({
    //        type: "GET",
    //        url: "/Notes/Notes",
    //        data: JSON.stringify(tempdata),
    //        contentType: "application/json; charset=utf-8",
    //        dataType: "json",
    //        success: function (res) {
    //            if (res.data != null)
    //            {
    //                var temp = res.data; 

    //                alert("Notes save successfully!!");
    //            }
    //        },
    //        failure: function (response) {
    //            alert("Error while Notes Fetch.");
    //        },
    //        error: function (response) {
    //            alert("Error while while Notes Fetch.");
    //        }
    //    });
    //});

    //$('#Ispublic').change(function () {
    //    var noteUserAccess = $("#Ispublic").is(':checked');
    //});
   
    

    //$('#notesSave').on('click', function SettingsController() {
    //    //window.location.href = '/Notes/Create/';
    //    var notesDesc = $("#Notedesc").val();
    //    var noteUserAccess = $("#Ispublic").is(':checked') ? 1 : 0;
    //    //var data = { pageUrl: "Notes" };
    //    var data = { Notedesc: notesDesc, Ispublic: noteUserAccess, UserId:'Admin' };
    //    $("#Notedesc").val('');
    //    $.ajax({
    //        type: "POST",
    //        url: "/Notes/Create",
    //        data: JSON.stringify(data),
    //        contentType: "application/json; charset=utf-8",
    //        dataType: "json",
    //        success: function (response) {
    //            alert("Notes save successfully!!");
    //        },
    //        failure: function (response) {
    //            alert("Error while save.");
    //        },
    //        error: function (response) {
    //            alert("Error while save.");
    //        }
    //    });
    //});

    
    

    $('#Ispublic').change(function () {
        var noteUserAccess = $("#Ispublic").is(':checked');
    });

    



    //$('.notes,#notesCancel').click(function (event) {
    //    event.stopPropagation();
    //    $(this).children(".spanNotification").css("display", "none");
    //    $("#notesDiv").toggle();

    //    $(".notes").toggleClass("clickedIcons");
    //    $(".notes").toggleClass("customBorderSmall");
    //});

    //$(".cancel").click(function () {

    //    if ($(this).parents(".sideNavBar")) {
    //        $(this).parents(".sideNavBar").css("display", "none");
    //    }

    //});

    //$("#notesIcon").click(function (event) {
    //    event.stopPropagation();
    //    $("#notesDiv").toggle();
    //});
})(jQuery);