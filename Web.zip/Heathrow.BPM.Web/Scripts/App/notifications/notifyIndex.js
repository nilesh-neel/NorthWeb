﻿(function ($) {
    'use strict';

    $('#aNotification').on('click', function SettingsController() {
        window.location.href = '/Notifications/Index/';
    });

    $(document).ready(function () {
        //var alert = new Alert
        var configTab = new TabConfig(false, true, false, false);


    });



})(jQuery);