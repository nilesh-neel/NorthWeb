﻿(function () {
    'use strict';



    $("#liFavorite").click(function () {

        //$('.menu a').each(function () {
        //    var self = $(this);
        //    console.log(self[0].id);
        //})




        var arrayOfPath = window.location.pathname.split("/");
        var controller = arrayOfPath[1];
        var action = arrayOfPath[2] || "Index";

        var data = {
            favouriteId: 0, url: controller + '/' + action, description: "Dashboard"
            //, menuId: 2020 //, userId: '254ADS33'
        };

        $.ajax({
            type: "POST",
            url: "/Favourites/Save",
            data: JSON.stringify(data),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                alert("Favourites save successfully!!");
            },
            failure: function (response) {
                alert("Error while save.");
            },
            error: function (XMLHttpRequest, textStatus, errorThrown) {
                dangerAlter();
            }
        });
    });

})();