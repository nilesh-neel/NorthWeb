﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Heathrow.BPM.Web.ViewModel
{
    public class NotificationVM
    {
        public string NotificationId { get; set; }
        public string Description { get; set; }
        public string Title { get; set; }
        public string Topic { get; set; }
        public int TipID { get; set; }
        public string Location { get; set; }
        public string HelpUrl { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Time { get; set; }
        public bool IsSubscribe { get; set; }
        public bool IsOnScreen { get; set; }
        public bool IsEmail { get; set; }
        public bool IsMobile { get; set; }
    }
    public class NotificationMapping : IMapper<NotificationVM, Notification>
    {
        public NotificationVM MapFrom(Notification _input)
        {
            return BindCoreToViewModel(_input);
        }
        public IEnumerable<NotificationVM> MapFrom(IEnumerable<Notification> _input)
        {
            return _input.Select(x => BindCoreToViewModel(x));
        }

        public Notification MapTo(NotificationVM _input)
        {
            return BindViewModelToCore(_input);
        }

        public IEnumerable<Notification> MapTo(IEnumerable<NotificationVM> _input)
        {
            return _input.Select(x => BindViewModelToCore(x));
        }

        private static NotificationVM BindCoreToViewModel(Notification _input)
        {
            return new NotificationVM()
            {

                NotificationId = _input.NotificationID,
                Description = _input.Description,
                Title = _input.Title,
                Topic = _input.Topic,
                TipID=_input.TipID,
               // Location = _input.Location,
              //  TipOfTheDay = _input.TipOfTheDay,
                HelpUrl = _input.HelpUrl,
                StartDate = _input.StartDate.Date,
                EndDate = _input.EndDate.Date,
                Time=_input.StartDate.TimeOfDay.ToString(),
                IsSubscribe = _input.IsSubscribe,
                IsOnScreen = _input.IsOnScreen,
                IsEmail = _input.IsEmail,
                IsMobile = _input.IsMobile,
                Location = string.Join(",", _input.Locations.ToArray())

        };
        }

        private static Notification BindViewModelToCore(NotificationVM _input)
        {
            return new Notification()
            {

                NotificationID = _input.NotificationId,
                Description = _input.Description,
                Title = _input.Title,
                Topic = _input.Topic,
                TipID=_input.TipID,
              //  Location = _input.Location,
              //  TipOfTheDay = _input.TipOfTheDay,
                HelpUrl = _input.HelpUrl,
                StartDate = _input.StartDate.Date,
                EndDate = _input.EndDate.Date,
                Time=_input.StartDate.TimeOfDay.ToString(),
                IsSubscribe = _input.IsSubscribe,
                IsOnScreen = _input.IsOnScreen,
                IsEmail = _input.IsEmail,
                IsMobile = _input.IsMobile
            };
        }
    }
        
 }