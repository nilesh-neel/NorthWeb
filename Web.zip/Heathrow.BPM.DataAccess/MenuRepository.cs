﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
namespace Heathrow.BPM.DataAccess
{
    public class MenuRepository : IMenu
    {
        public IEnumerable<Menu> GetAllMenu()
        {
            DbConnection oDAL = new DbConnection();
            try
            {

                DataSet dsMenuList = new DataSet();
                oDAL.ExecuteDataSet(ProcedureConstants.GetAllMenu, out dsMenuList);
                return dsMenuList.Tables != null &&
                        dsMenuList.Tables[0].Rows.Count > 0 ? BindDataToEntity(dsMenuList) : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }


        private List<Menu> BindDataToEntity(DataSet dsMenu)
        {
            try
            {
                return (from drAlert in dsMenu.Tables[0].AsEnumerable()
                        select (new Menu
                        {
                            MenuId = Convert.ToInt32(drAlert["Menu_ID"]),
                            Description = Convert.ToString(drAlert["Menu_Desc"]),
                            MenuUrl = Convert.ToString(drAlert["Menu_Url"]),
                            CssIcon = Convert.ToString(drAlert["Css_Icon"]),
                            ParentId = Convert.ToInt32(drAlert["Parent_ID"]),
                            OrderId = Convert.ToInt32(drAlert["Order_ID"]),
                            IsReport = Convert.ToBoolean(drAlert["IsReport"]),
                        })).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }

}
