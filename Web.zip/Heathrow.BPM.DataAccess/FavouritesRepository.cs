﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System.Linq;

namespace Heathrow.BPM.DataAccess
{
    public class FavouritesRepository : IFavourites
    {
        public FavouritesRepository() { }

        public int Save(Favourites _favourites)
        {
            DbConnection oDAL = new DbConnection();
            try
            {

                DataSet dsFavList = new DataSet();

                oDAL.ExecuteDataSet(ProcedureConstants.GetFavouritesByUser, out dsFavList,
                   new List<SqlParameter>()
                   {
                        new SqlParameter() { ParameterName = "@User_ID", DbType = DbType.String, Value = _favourites.UserId },
                        new SqlParameter() { ParameterName = "@Menu_Id", DbType = DbType.Int32, Value =_favourites.FavouriteLink.MenuId},
                         new SqlParameter() { ParameterName = "@Favourite_0ID", DbType = DbType.Int32, Value = _favourites.FavouriteId}
                   });

                return dsFavList.Tables != null && dsFavList.Tables[0].Rows.Count > 0
                    ? Convert.ToInt32(Convert.ToString(dsFavList.Tables[0].Rows[0][0]).Equals("success") ? 0 : 999)
                    : 999;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }

        public IEnumerable<Favourites> GetFavouritesByUserId(string _userId)
        {
            DbConnection oDAL = new DbConnection();
            try
            {

                DataSet dsFavList = new DataSet();

                oDAL.ExecuteDataSet(ProcedureConstants.GetFavouritesByUser, out dsFavList,
                   new List<SqlParameter>()
                   {
                        new SqlParameter() { ParameterName = "@User_ID", DbType = DbType.String, Value = _userId }
                   });

                return dsFavList.Tables != null &&
                        dsFavList.Tables[0].Rows.Count > 0 ? BindDataToEntity(dsFavList, _userId) : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }


        private List<Favourites> BindDataToEntity(DataSet dsFavourate, string _userId)
        {
            try
            {
                return (from drAlert in dsFavourate.Tables[0].AsEnumerable()
                        select (new Favourites
                        {
                            FavouriteId = Convert.ToInt32(dsFavourate.Tables[0].Rows[0]["Favourite_ID"]),
                            UserId = _userId,
                            FavouriteLink = new Menu()
                            {
                                MenuId = Convert.ToInt32(dsFavourate.Tables[0].Rows[0]["Menu_ID"]),
                                Description = Convert.ToString(dsFavourate.Tables[0].Rows[0]["Menu_Desc"]),
                                MenuUrl = Convert.ToString(dsFavourate.Tables[0].Rows[0]["Menu_Url"]),
                                // CssIcon= Convert.ToString(dsFavourate.Tables[0].Rows[0]["Css_Icon"])
                            }

                        })).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
