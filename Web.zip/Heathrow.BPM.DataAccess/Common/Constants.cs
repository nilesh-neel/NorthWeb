﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.DataAccess.Common
{
   public class ProcedureConstants
    {
        public const string SelectAlertsById = "USP_GetAlertsById";

        public const string GetFavouritesByUser = "sp_GetFavourites";

        public const string GetAllMenu = "sp_GetMenu";
        public const string InsertUser = "sp_InsertUser";
        //Notes
        public const string GetLocation = "sp_GetLookupItems";
        public const string GetLookupItemName = "";
        public const string InsertNotes = "usp_SaveNotes";
        public const string FetchNotes = "usp_FetchNotes";
        public const string DeleteNotes = "usp_DeleteNotes";
        //Notification

        public const string GetNotificationByID = "";
        public const string UpdateNotification = "";
        public const string GetAllNotification = "";

        //Alert
        public const string UpdateAlert= "";
    }
}
