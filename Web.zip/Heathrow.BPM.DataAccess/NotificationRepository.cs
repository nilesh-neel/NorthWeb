﻿using System;
using System.Data.SqlClient;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System.Data;
using System.Collections.Generic;
using System.Linq;

namespace Heathrow.BPM.DataAccess
{
    public class NotificationRepository : INotification
    {
        public NotificationRepository() { }


        public int Save(Notification _notification)
        {
            DbConnection oDAL = new DbConnection();
            try
            {

                DataSet dsNotificationList = new DataSet();

                oDAL.ExecuteDataSet(ProcedureConstants.UpdateNotification, out dsNotificationList,
                   new List<SqlParameter>()
                   {
                        new SqlParameter(){ParameterName ="@notificationId", DbType = DbType.String, Value = _notification.NotificationID },
                        new SqlParameter(){ParameterName="@topic",DbType=DbType.String,Value=_notification.Topic},
                        new SqlParameter(){ParameterName="@tipID",DbType=DbType.Int32,Value=_notification.TipID},
                        new SqlParameter(){ParameterName="@helpURL",DbType=DbType.String,Value=_notification.HelpUrl}

                        //To Do: Save list of locations for this.NotificationID and this.UserID
                        //Subscription for each notification
                   });

                // return dsNotificationList.Tables != null && dsNotificationList.Tables[0].Rows.Count > 0
                //     ? Convert.ToInt32(Convert.ToString(dsNotificationList.Tables[0].Rows[0][0]).Equals("success") ? 0 : 999)
                //     : 999;

                return 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }

        public IEnumerable<Notification> GetNotificationByNotificationId(string _notificationId)
        {
            DbConnection oDAL = new DbConnection();
            try
            {

                DataSet dsNotificationList = new DataSet();

                oDAL.ExecuteDataSet(ProcedureConstants.GetNotificationByID, out dsNotificationList,
                   new List<SqlParameter>()
                   {
                        new SqlParameter() { ParameterName = "@notificationId", DbType = DbType.String, Value =  _notificationId }
                   });

                return dsNotificationList.Tables != null &&
                        dsNotificationList.Tables[0].Rows.Count > 0 ? BindDataToEntity(dsNotificationList, _notificationId) : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }

        public IEnumerable<Notification> GetTodaysNotification()
        {
            DbConnection oDAL = new DbConnection();
            try
            {
                DataSet dsNotificationList = new DataSet();
                oDAL.ExecuteDataSet(ProcedureConstants.GetAllNotification, out dsNotificationList);
                return dsNotificationList.Tables != null &&
                    dsNotificationList.Tables[0].Rows.Count > 0 ? BindAllDataToEntity(dsNotificationList) : null;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }

        private List<Notification> BindDataToEntity(DataSet dsNotification, string _notificationId)
        {
               try
                {
                    return (from drAlert in dsNotification.Tables[0].AsEnumerable()
                            select (new Notification
                            {
                               // FavouriteId = Convert.ToInt32(dsNotification.Tables[0].Rows[0]["Favourite_ID"]),
                                NotificationID = _notificationId,
                                Description= Convert.ToString(dsNotification.Tables[0].Rows[0]["Description"]),
                                Title = Convert.ToString(dsNotification.Tables[0].Rows[0]["Title"]),
                              //  Topic = Convert.ToString(dsNotification.Tables[0].Rows[0]["Topic"]),
                              //  Location = Convert.ToString(dsNotification.Tables[0].Rows[0]["Location"]),
                              //  TipOfTheDay= Convert.ToString(dsNotification.Tables[0].Rows[0]["Tip_Of_The_Day"]),
                                HelpUrl = Convert.ToString(dsNotification.Tables[0].Rows[0]["Help_Url"]),
                                StartDate=Convert.ToDateTime(dsNotification.Tables[0].Rows[0]["Start_Date"]),
                                EndDate = Convert.ToDateTime(dsNotification.Tables[0].Rows[0]["End_Date"]),
                                Time= Convert.ToString(dsNotification.Tables[0].Rows[0]["Time"]),
                                IsSubscribe =Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Subscribe"]),
                                IsOnScreen = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_OnScreen"]),
                                IsEmail = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Email"]),
                                IsMobile = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Mobile"])

                            })).ToList();
                }
                catch (Exception)
                {
                    throw;
                }
            //return null;
        }
        private List<Notification> BindAllDataToEntity(DataSet dsNotification)
        {
            try
            {
                return (from drAlert in dsNotification.Tables[0].AsEnumerable()
                        select (new Notification
                        {
                            Description = Convert.ToString(dsNotification.Tables[0].Rows[0]["Description"]),
                            Topic = Convert.ToString(dsNotification.Tables[0].Rows[0]["Topic"]),
                            StartDate = Convert.ToDateTime(dsNotification.Tables[0].Rows[0]["Start_Date"]),
                            EndDate = Convert.ToDateTime(dsNotification.Tables[0].Rows[0]["End_Date"]),
                            Time = Convert.ToString(dsNotification.Tables[0].Rows[0]["Time"]),

                            // NotificationID = Convert.ToString(dsNotification.Tables[0].Rows[0]["NotificationID"]),
                            //  Topic = Convert.ToString(dsNotification.Tables[0].Rows[0]["Topic"]),
                            //  Location = Convert.ToString(dsNotification.Tables[0].Rows[0]["Location"]),
                            //  TipOfTheDay= Convert.ToString(dsNotification.Tables[0].Rows[0]["Tip_Of_The_Day"]),
                            //   HelpUrl = Convert.ToString(dsNotification.Tables[0].Rows[0]["Help_Url"]),

                            //IsSubscribe = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Subscribe"]),
                            // IsOnScreen = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_OnScreen"]),
                            //  IsEmail = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Email"]),
                            //  IsMobile = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Mobile"])

                        })).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            //return null;
        }
    }
}
