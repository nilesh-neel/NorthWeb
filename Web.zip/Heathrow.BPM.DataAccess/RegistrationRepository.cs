﻿using System;
using System.Data.SqlClient;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System.Data;
using System.Collections.Generic;
using System.Linq;

namespace Heathrow.BPM.DataAccess
{
    public class RegistrationRepository : IRegistration
    {

        public RegistrationRepository() { }

        public int Save(Registration _registration)
        {
            DbConnection oDAL = new DbConnection();
            try
            {

                DataSet dsRegList = new DataSet();

                oDAL.ExecuteDataSet(ProcedureConstants.InsertUser, out dsRegList,
                   new List<SqlParameter>()
                   {
                        new SqlParameter() { ParameterName = "@firstName", DbType = DbType.String, Value = _registration.FirstName },
                        new SqlParameter() { ParameterName = "@lastName", DbType = DbType.String, Value =_registration.LastName},
                        new SqlParameter() { ParameterName = "@location", DbType = DbType.String, Value =_registration.Location},
                        new SqlParameter() { ParameterName = "@jobRole", DbType = DbType.String, Value = _registration.JobRole},
                        new SqlParameter() { ParameterName = "@accessReason", DbType = DbType.String,Value = _registration.AccessReason},
                        new SqlParameter() { ParameterName = "@organization",DbType = DbType.String,Value = _registration.Organization},
                        new SqlParameter() { ParameterName = "@email", DbType = DbType.String,Value = _registration.Email}
                   });

                //return dsRegList.Tables != null && dsRegList.Tables[0].Rows.Count > 0
                //   ? Convert.ToInt32(Convert.ToString(dsRegList.Tables[0].Rows[0][0]).Equals("success") ? 0 : 999)
                // : 999;

                return 1;


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }

    }
}


