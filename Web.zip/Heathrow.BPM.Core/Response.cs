﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.Core
{
  public class Response
    {
        public bool isAcknowledge { get; set; }
        public bool isBlank { get; set; }
        public bool isIgnore { get; set; }
    }
}
