﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Core.Interface
{
    public interface ILocation
    {
        IEnumerable<Location> GetLocation();
    }
}
