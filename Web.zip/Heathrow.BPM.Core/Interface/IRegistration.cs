﻿using System.Collections.Generic;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Core.Interface
{
   public interface IRegistration
    {        
        int Save(Registration _registration);
        
    }
}
