﻿using Heathrow.BPM.Core.Entity;
using System.Collections.Generic;

namespace Heathrow.BPM.Core.Interface
{
    public interface IFavourites
    {
        IEnumerable<Favourites> GetFavouritesByUserId(string _userId);
        int Save(Favourites _favourites);

    }
}
