﻿using Heathrow.BPM.Core.Entity;
using System.Collections.Generic;

namespace Heathrow.BPM.Core.Interface
{
    public interface IAlerts
    {
        IEnumerable<Alerts> GetAll();
        Alerts GetAlertsById(string _alertId);
        int Save(Alerts _alert);
    }
}
