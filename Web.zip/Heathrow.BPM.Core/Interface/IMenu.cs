﻿using Heathrow.BPM.Core.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.Core.Interface
{
    public interface IMenu
    {
        IEnumerable<Menu> GetAllMenu();
    }
}
