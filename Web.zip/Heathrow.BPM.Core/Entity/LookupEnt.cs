﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.Core.Entity
{
  public  class LookupEnt
    {
        public int LookupTypeID { get; set; }
        public string LookupTypeName { get; set; }
        public string LookupName { get; set; }
        public int LookupID { get; set; }
        public bool IsActive { get; set; }
    }
}
