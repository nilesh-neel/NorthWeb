﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.Core.Entity
{
    public class AzureAD
    {
        public static string AADAuthorityUri { get { return ConfigurationManager.AppSettings["AADAuthorityUri"]; } }
        public static string AzureADTenant { get { return ConfigurationManager.AppSettings["AzureADTenant"]; } }
        public static string ClinetId { get { return ConfigurationManager.AppSettings["ClinetId"]; } }
        public static string ClientSecret { get { return ConfigurationManager.AppSettings["ClientSecret"]; } }
        public static string ApplicationID { get { return ConfigurationManager.AppSettings["ApplicationID"]; } }
        public static string ApplicationSecret { get { return ConfigurationManager.AppSettings["ApplicationSecret"]; } }

    }
}
