﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.Core.Entity
{
    public class PowerBI : AzureAD
    {
        public static string PowerBiAPIResource { get { return ConfigurationManager.AppSettings["PowerBiAPIResource"]; } }
        public static string PowerBiAuthorityUri { get { return ConfigurationManager.AppSettings["PowerBiAuthorityUri"]; } }
        public static string PowerBiDataset { get { return ConfigurationManager.AppSettings["PowerBiDataset"]; } }
        public static string PowerBiApiUrl { get { return ConfigurationManager.AppSettings["PowerBiApiUrl"]; } }
        public static string WorkspaceId { get { return ConfigurationManager.AppSettings["PowerBiAPIResource"]; } }
        public static string ReportId { get { return ConfigurationManager.AppSettings["ReportId"]; } }
        public static string ReportRedirectUrl { get { return ConfigurationManager.AppSettings["ReportRedirectUrl"]; } }
        public static string DashboardRedirectUrl { get { return ConfigurationManager.AppSettings["DashboardRedirectUrl"]; } }
    }
}
