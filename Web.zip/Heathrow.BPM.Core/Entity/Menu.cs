﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Heathrow.BPM.Core.Entity
{
    public class Menu
    {
        public int MenuId { get; set; }
        public string Description { get; set; }
        public string MenuUrl { get; set; }
        public int ParentId { get; set; }
        public int OrderId { get; set; }
        public string CssIcon { get; set; }
        public bool IsReport { get; set; }
    }
}
