﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;
using Heathrow.BIPM.Kestrel.DataAccess.Common;

namespace Heathrow.BIPM.Kestrel.DataAccess
{
    public class LookupRepository: GenericRepository<LookupEnt>, ILookup
    {
        public int Status;
        public LookupRepository(BaggageDbContext context) : base(context)
        { }
        /*   public List<LookupEnt> GetLookupType()
           {
               LookupEnt oLookupDetailsEnt = null;
               List<LookupEnt> lstLookup = null;
               try
               {
                   DbConnection oDAL = new DbConnection();
                   DataSet dsType = new DataSet();

                   this.Errorno = oDAL.Select(ProcedureConstants.GetLookupTypes, out dsType);

                   if (this.Errorno == 0)
                   {

                       if (dsType.Tables[0].Rows.Count > 0)
                       {
                           foreach (DataRow dr in dsType.Tables[0].Rows)
                           {
                               if (lstLookup == null)
                                   lstLookup = new List<LookupEnt>();
                               oLookupDetailsEnt = new LookupEnt();
                               oLookupDetailsEnt.LookupTypeID = Convert.ToInt32(dr["LookUpTypeID"]);
                               oLookupDetailsEnt.LookupTypeName = Convert.ToString(dr["LookUpTypeName"]);
                               lstLookup.Add(oLookupDetailsEnt);
                           }
                       }
                   }
               }
               catch (Exception ex)
               {
                   throw;

               }

               return lstLookup;
           }
       /*    public void SetLookupDetails(LookupEnt oLookupDetailsEnt)
           {
               try
               {
                   DbConnection oDAL = new DbConnection();

                   this.Errorno = oDAL.Insert(ProcedureConstants.InsertLookupDetails,
                                   oDAL.CreateParameter("@LookUpName", DbType.String, oLookupDetailsEnt.LookupName),
                                   oDAL.CreateParameter("@LookUpTypeId", DbType.Int32, oLookupDetailsEnt.LookupTypeID),
                                   oDAL.CreateParameter("@IsActive", DbType.Boolean, oLookupDetailsEnt.IsActive),
                                   oDAL.CreateParameter("@CreatedBy", DbType.String, "261866"));
                   if (Errorno == 0)
                   {
                       Status = 0;
                   }

               }
               catch (Exception ex)
               {
                   throw;

               }
           }*/
        public IEnumerable<LookupEnt> GetLookupDetailsById(int iLookupTypeId)
        {
            DbConnection oDal = new DbConnection();
            LookupEnt oLookupDetailsEnt = null;
            List<LookupEnt> lstLookupDetails = null;
            try
            {

                DataSet dsType = new DataSet();

                oDal.ExecuteDataSet(ProcedureConstants.GetLocation, out dsType,
                    new List<SqlParameter>()
                    {
                        new SqlParameter() { ParameterName = "@id", DbType = DbType.String, Value = iLookupTypeId }
                    });

                // if (this.Errorno == 0)
                {

                    if (dsType.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsType.Tables[0].Rows)
                        {
                            if (lstLookupDetails == null)
                                lstLookupDetails = new List<LookupEnt>();
                            oLookupDetailsEnt = new LookupEnt();
                            oLookupDetailsEnt.RowID = Convert.ToInt32(dr["id"]);
                            oLookupDetailsEnt.LookupTypeName = Convert.ToString(dr["LookUpItem_Name"]);

                            lstLookupDetails.Add(oLookupDetailsEnt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                oDal.CloseConnection();
            }
            return lstLookupDetails;
        }

        public List<LookupEnt> GetLookups()
        {

            LookupEnt oLookupsDetailsEnt = null;
            List<LookupEnt> lstLookups = null;
            try
            {

                DbConnection oDal = new DbConnection();
                DataSet dsType = new DataSet();
                oDal.ExecuteDataSet(ProcedureConstants.GetLocation, out dsType,
                    new List<SqlParameter>()
                    {
                        new SqlParameter() { ParameterName = "@id", DbType = DbType.String, Value = 1 }
                    });

                {

                    if (dsType.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsType.Tables[0].Rows)
                        {
                            if (lstLookups == null)
                                lstLookups = new List<LookupEnt>();
                            oLookupsDetailsEnt = new LookupEnt();
                            lstLookups.Add(oLookupsDetailsEnt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }

            return lstLookups;
        }

        public string GetLookupItemName(int itemNameId)
        {

            string itemName = "";
            DbConnection oDal = new DbConnection();
            try
            {

                DataSet dsType = new DataSet();

                oDal.ExecuteDataSet(ProcedureConstants.GetLookupItemName, out dsType,
                    new List<SqlParameter>()
                    {
                        new SqlParameter() { ParameterName = "@id", DbType = DbType.String, Value = itemNameId }
                    });

                // if (this.Errorno == 0)
                {

                    if (dsType.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsType.Tables[0].Rows)
                        {
                            itemName = Convert.ToString(dr["LookUpItem_Name"]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                oDal.CloseConnection();
            }
            return itemName;

        }



        public async Task<IEnumerable<LookupEnt>> GetAllMeasure()
        {
            try
            {
                var objalerts = await Task.Run(() => ((BaggageDbContext)Context).usp_GetMeasure());

                return objalerts?.Select(a => new LookupEnt
                {
                    RowID = a.MeasureID,
                    LookupTypeName = a.Description,


                }).ToList();

            }
            catch (Exception e)
            {
                throw;
            }

        }
        public async Task<IEnumerable<LookupEnt>> GetAllTopic()
        {
            try
            {
                var objalerts = await Task.Run(() => ((BaggageDbContext)Context).usp_GetMeasureCategory());

                return objalerts?.Select(a => new LookupEnt
                {
                    RowID = a.MeasureCategoryID,
                    LookupTypeName = a.Description,

                }).ToList();

            }

            catch (Exception e)
            {
                throw;
            }

        }
        public async Task<IEnumerable<LookupEnt>> GetAllLocation()
        {
            try
            {
                var objalerts = await Task.Run(() => ((BaggageDbContext)Context).usp_GetLocation());

                return objalerts?.Select(a => new LookupEnt
                {
                    RowID = a.TerminalFacilityID,
                    LookupTypeName = a.Name,

                }).ToList();

            }
            catch (Exception e)
            {
                throw;
            }

        }
        public async Task<IEnumerable<LookupEnt>> GetAllThreshold()
        {
            try
            {
                var objalerts = await Task.Run(() => ((BaggageDbContext)Context).usp_GetThresholdType());

                return objalerts?.Select(a => new LookupEnt
                {
                    RowID = a.ThresholdTypeID,
                    LookupTypeName = a.Description,

                }).ToList();

            }
            catch (Exception e)
            {
                throw;
            }

        }
        public async Task<IEnumerable<LookupEnt>> GetAllFrequency()
        {
            try
            {
                var objalerts = await Task.Run(() => ((BaggageDbContext)Context).usp_GetFrequency());

                return objalerts?.Select(a => new LookupEnt
                {
                    RowID = a.FrequencyID,
                    LookupTypeName = a.Description,

                }).ToList();

            }
            catch (Exception e)
            {
                throw;
            }

        }
        public async Task<IEnumerable<LookupEnt>> GetAllTimeWindow()
        {
            try
            {
                var objalerts = await Task.Run(() => ((BaggageDbContext)Context).usp_GetTimeWindow());

                return objalerts?.Select(a => new LookupEnt
                {
                    RowID = a.TimeWindowID,
                    LookupTypeName = a.Description,

                }).ToList();

            }
            catch (Exception e)
            {
                throw;
            }

        }

        public async Task<IEnumerable<LookupEnt>> GetAllOrganisation()
        {
            try
            {
                var objalerts = await Task.Run(() => ((BaggageDbContext)Context).usp_GetTimeWindow());

                return objalerts?.Select(a => new LookupEnt
                {
                    RowID = a.TimeWindowID,
                    LookupTypeName = a.Description,

                }).ToList();


            }
            catch (Exception e)
            {
                throw;
            }

        }

        public async Task<IEnumerable<LookupEnt>> GetAllOperationalArea()
        {
            try
            {
                var objalerts = await Task.Run(() => ((BaggageDbContext)Context).usp_GetTimeWindow());

                return objalerts?.Select(a => new LookupEnt
                {
                    RowID = a.TimeWindowID,
                    LookupTypeName = a.Description,

                }).ToList();

                //   return await Task.Run(() => (GetRec(id)));
            }
            catch (Exception e)
            {
                throw;
            }

        }
    }
}



