﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using Heathrow.BIPM.Kestrel.Core.Interface;
using Heathrow.BIPM.Kestrel.DataAccess.Common;

namespace Heathrow.BIPM.Kestrel.DataAccess
{
    public class LocationRepository : ILocation
    {
        /*   public IEnumerable<Location> GetLocation()
           {
               DbConnection oDAL = new DbConnection();
               try
               {

                   DataSet dsLocList = new DataSet();

                   oDAL.ExecuteDataSet(ProcedureConstants.GetLocation, out dsLocList,
                      new List<SqlParameter>()
                      {
                           new SqlParameter() { ParameterName = "@id", DbType = DbType.String, Value = 1 }
                      });

                   return dsLocList.Tables != null &&
                           dsLocList.Tables[0].Rows.Count > 0 ? BindDataToEntity(dsLocList) : null;
               }
               catch (Exception ex)
               {
                   throw ex;
               }
               finally
               {
                   oDAL.CloseConnection();
               }
           }


           private List<Location> BindDataToEntity(DataSet dsLocation)
           {
               try
               {
                   return (from drAlert in dsLocation.Tables[0].AsEnumerable()
                           select (new Location
                           {
                               LocationID = 1,
                               LocationDescription = Convert.ToString(dsLocation.Tables[0].Rows[0]["LookUpItem_Name"]),

                           })).ToList();
               }
               catch (Exception)
               {
                   throw;
               }
           }
       }*/



        public IEnumerable<Core.Entity.LocationEnt> GetLocation()
        {
            DbConnection oDal = new DbConnection();
            try
            {

                DataSet dsLocList = new DataSet();
                oDal.ExecuteDataSet(ProcedureConstants.GetLocation, out dsLocList,
                    new List<SqlParameter>()
                    {
                        new SqlParameter() { ParameterName = "@id", DbType = DbType.String, Value = 1 }
                    });
                return dsLocList.Tables != null &&
                       dsLocList.Tables[0].Rows.Count > 0 ? BindDataToEntity(dsLocList) : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }


        private List<Core.Entity.LocationEnt> BindDataToEntity(DataSet dsLoc)
        {
            try
            {
                return (from drAlert in dsLoc.Tables[0].AsEnumerable()
                        select (new Core.Entity.LocationEnt
                        {
                            Id = 1,
                            Description = Convert.ToString(drAlert["LookUpItem_Name"]),

                        })).ToList();
            }
            catch (Exception)
            {
                throw;
            }

        }

        IEnumerable<Core.Entity.LocationEnt> ILocation.GetLocation()
        {
            throw new NotImplementedException();
        }
    }
}
