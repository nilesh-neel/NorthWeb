﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Interface;
using Heathrow.BIPM.Kestrel.DataAccess.Common;

namespace Heathrow.BIPM.Kestrel.DataAccess
{
    public class MenuRepository : GenericRepository<Menu>, IMenu
    {
        public MenuRepository(BaggageDbContext context) : base(context)
        {

        }


        public IEnumerable<Core.Entity.Menu> GetAllMenu()
        {
            DbConnection oDal = new DbConnection();
            try
            {

                DataSet dsMenuList = new DataSet();
                oDal.ExecuteDataSet(ProcedureConstants.GetAllMenu, out dsMenuList);
                return dsMenuList.Tables != null &&
                        dsMenuList.Tables[0].Rows.Count > 0 ? BindDataToEntity(dsMenuList) : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }
        public IEnumerable<Core.Entity.Menu> GetAllEntityMenu()
        {
            DbConnection oDal = new DbConnection();
            try
            {

                DataSet dsMenuList = new DataSet();
                oDal.ExecuteDataSet(ProcedureConstants.GetAllMenu, out dsMenuList);
                return dsMenuList.Tables != null &&
                        dsMenuList.Tables[0].Rows.Count > 0 ? BindDataToEntity(dsMenuList) : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }

        private List<Core.Entity.Menu> BindDataToEntity(DataSet dsMenu)
        {
            try
            {
                return (from drAlert in dsMenu.Tables[0].AsEnumerable()
                        select (new Core.Entity.Menu
                        {
                            MenuId = Convert.ToInt32(drAlert["MenuId"]),
                            Description = Convert.ToString(drAlert["Description"]),
                            OperationalUrl = Convert.ToString(drAlert["OperationalUrl"]),
                            BusinessUrl = Convert.ToString(drAlert["BusinessUrl"]),
                            Organization = Convert.ToString(drAlert["Organization"]),
                            CssIcon = Convert.ToString(drAlert["CssIcon"]),
                            ParentId = Convert.ToInt32(drAlert["ParentId"]),
                            OrderId = Convert.ToInt32(drAlert["OrderId"]),
                            IsReport = Convert.ToBoolean(drAlert["IsReport"]),
                            Tooltip = Convert.ToString(drAlert["Tooltip"]),
                            FavouritesDescription = Convert.ToString(drAlert["FavouritesDescription"]),
                        })).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }


        public Task<IEnumerable<Menu>> GetAllMenuAsync()
        {
            throw new NotImplementedException();
        }

        IEnumerable<Core.Entity.Menu> IMenu.GetAllMenu()
        {
            throw new NotImplementedException();
        }

        Task<IEnumerable<Core.Entity.Menu>> IMenu.GetAllMenuAsync()
        {
            throw new NotImplementedException();
        }
    }

}
