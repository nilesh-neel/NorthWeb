﻿namespace Heathrow.BIPM.Kestrel.DataAccess
{
    public class Class1
    {
    }
}
