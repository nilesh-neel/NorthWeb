﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;

namespace Heathrow.BIPM.Kestrel.DataAccess
{
    public class SearchRepository : GenericRepository<FilterSelection>, ISearch
    {
        private static ReportConfiguration _searchData = null;
        public SearchRepository(BaggageDbContext context) : base(context)
        {

        }
        public async Task<ReportConfiguration> GetSearchData(string searchText, string prefix)
        {
            try
            {
                var objSearch = await Task.Run(() => ((BaggageDbContext)Context).usp_Search(searchText, prefix));

                var result = objSearch?.FirstOrDefault();
                return _searchData = new ReportConfiguration
                {
                    TableName = result.PBITableName,
                    ColumnName = result.PBIColumnName,
                    Operator = result.PBIOpearator,
                    PowerBIURL = result.PBIURL,
                };
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error is occured while retrieving the search", ex);
            }

        }
    }
}
