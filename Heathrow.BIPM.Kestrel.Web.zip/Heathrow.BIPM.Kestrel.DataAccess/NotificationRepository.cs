﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;
using Heathrow.BIPM.Kestrel.DataAccess.Common;

namespace Heathrow.BIPM.Kestrel.DataAccess
{
    public class NotificationRepository : GenericRepository<Notification>, INotification
    {
        public NotificationRepository(BaggageDbContext context) : base(context)
        { }
        public async Task<int> Save(Notification _notification)
        {
            var lookupLocation = GetLookupDetailsById(1);
            var lookupAudience = GetLookupDetailsById(4);
            var lookupTopic = GetLookupDetailsById(3);
            var lookupRec = GetLookupDetailsById(2);
            List<string> Locations = new List<string>();
            try
            {
                foreach (var locid in _notification.SelectedLocation)
                {
                    foreach (var id in lookupLocation.Where(obj => obj.RowID == (locid)))
                    {
                        {

                            var x = id.LookupTypeName;
                            Locations.Add(x);
                        }
                    }
                }
                foreach (var id in lookupAudience.Where(obj => obj.RowID == _notification.SelectedOperationalArea))
                {
                    {
                        _notification.Audience = id.LookupTypeName;
                    }
                }

                foreach (var id in lookupTopic.Where(obj => obj.RowID == _notification.SelectedTopic))
                {
                    {
                        _notification.Topic = id.LookupTypeName;
                    }
                }
                var objNotification = await Task.Run(() => ((BaggageDbContext)Context).usp_ConfigureNewNotification
                 (_notification.NotificationID, _notification.Description, 1,
                     string.Join(",", _notification.SelectedLocation), _notification.SelectedOperationalArea, _notification.Topic, _notification.HelpUrl, (_notification.StartDate), (_notification.EndDate), _notification.CreatedBy, _notification.ModifiedBy,
                     _notification.ModifiedDate.ToString(), _notification.IsOnScreen, _notification.IsEmail, _notification.IsMobile, _notification.TopicID, string.Join(",", Locations), _notification.Audience, _notification.Recipient)
                );
                return (objNotification == 1) ? 1 : -1;
                //   //To Do: Save list of notifications for this.NotificationID and this.UserID
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public async Task<int> UpdateNotification(Notification _notification)
        {
            var lookupLocation = GetLookupDetailsById(1);
            var lookupAudience = GetLookupDetailsById(4);
            var lookupTopic = GetLookupDetailsById(3);
            var lookupRec = GetLookupDetailsById(2);


            List<string> Locations = new List<string>();
            try
            {
                if (_notification.SelectedLocation == null)
                {
                    var objNotification = await Task.Run(() => ((BaggageDbContext)Context).usp_UpdateNotification(
                      _notification.NotificationID, "", 0, "", 0, "", "", DateTime.Now, DateTime.Now, "", "", "", false, false, false, 0, _notification.DisableNotification, "",
                    "", ""));
                    return (objNotification == 1) ? 1 : -1;

                }
                else if (_notification.Recipient == null && _notification.SelectedTopic != 0)
                {
                    foreach (var locid in _notification.SelectedLocation)
                    {
                        foreach (var id in lookupLocation.Where(obj => obj.RowID == (locid)))
                        {
                            {
                                var x = id.LookupTypeName;
                                Locations.Add(x);
                            }
                        }
                    }
                    foreach (var id in lookupTopic.Where(obj => obj.RowID == _notification.SelectedTopic))
                    {
                        {

                            _notification.Topic = id.LookupTypeName;
                        }
                    }
                    var objNotification = await Task.Run(() => ((BaggageDbContext)Context).usp_UpdateNotification(
                        _notification.NotificationID, _notification.Description, 0,
                  string.Join(",", _notification.SelectedLocation), 0, _notification.Topic,
                  "", DateTime.Now, DateTime.Now, "", "", "", _notification.IsOnScreen, _notification.IsEmail, _notification.IsMobile,
                  _notification.SelectedTopic, false, string.Join(",", Locations),
                      "", ""));
                    return (objNotification == 1) ? 1 : -1;

                }
                else
                {
                    foreach (var locid in _notification.SelectedLocation)
                    {
                        foreach (var id in lookupLocation.Where(obj => obj.RowID == (locid)))
                        {
                            {
                                var x = id.LookupTypeName;
                                Locations.Add(x);
                            }
                        }
                    }
                    foreach (var id in lookupAudience.Where(obj => obj.RowID == _notification.SelectedOperationalArea))
                    {
                        {
                            _notification.Audience = id.LookupTypeName;
                        }
                    }

                    foreach (var id in lookupTopic.Where(obj => obj.RowID == _notification.SelectedTopic))
                    {
                        {

                            _notification.Topic = id.LookupTypeName;
                        }
                    }

                    var objNotification = await Task.Run(() => ((BaggageDbContext)Context).usp_UpdateNotification(
                        _notification.NotificationID, _notification.Description, 1,
                  string.Join(",", _notification.SelectedLocation), _notification.SelectedOperationalArea, _notification.Topic,
                  _notification.HelpUrl, (_notification.StartDate), (_notification.EndDate),
                  _notification.CreatedBy, _notification.CreatedDate.ToString(), _notification.ModifiedBy,
                  _notification.IsOnScreen, _notification.IsEmail, _notification.IsMobile,
                  _notification.SelectedTopic, false, string.Join(",", Locations),
                      _notification.Audience, _notification.Recipient));

                    return (objNotification == 1) ? 1 : -1;
                }



            }

            catch (Exception ex)
            {
                throw ex;
            }

        }
        public async Task<Notification> GetNotificationByNotificationId(string _notificationId)
        {

            try
            {

                var objnotif = await Task.Run(() => ((BaggageDbContext)Context).usp_GetNotificationById(_notificationId));
                var a = objnotif.FirstOrDefault();
                return new Notification
                {
                    NotificationID = _notificationId,
                    Description = a.Notification_Description,
                    CreatedDate = a.Created_Date,
                    ModifiedBy = a.Modified_By,
                    ModifiedDate = DateTime.Parse(a.Modified_Date),
                    CreatedBy = a.Created_By,
                    HelpUrl = a.Help_URL,
                    StartDate = a.Start_Date,
                    EndDate = a.End_Date,
                    SelectedOperationalArea = a.AudienceGroup_ID,
                    SelectedOrganisation = new int[] { 1, 2, 3 },
                    SelectedTopic = a.Topic_ID,
                    Locations = a.Locations,

                    IsOnScreen = (bool)a.isOnScreen,
                    IsEmail = (bool)a.isEmail,
                    IsMobile = (bool)a.isMobile,
                    SelectedLocation = a.Location_ID.Split(',').Select(int.Parse).ToArray(),
                    DisableNotification = (bool)a.Disable_Notification

                };


            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public async Task<IEnumerable<Notification>> GetTodaysNotification()
        {

            try
            {
                var objnotif = await Task.Run(() => ((BaggageDbContext)Context).usp_GetAllNotifications());
                return objnotif?.Select(a => new Notification
                {
                    NotificationID = a.Notification_ID,
                    Description = a.Notification_Description,
                    Topic = a.Topic,
                    Locations = a.Locations,
                    ModifiedBy = a.Modified_By,
                    DisableNotification = (bool)a.Disable_Notification,
                    CreatedBy = a.Created_By,
                    HelpUrl = a.Help_URL,
                    StartDate = a.Start_Date,
                    EndDate = a.End_Date,
                    ModifiedDate = DateTime.Parse(a.Modified_By),
                    DateAndTime = a.Notification_DateTime.ToString(),
                    SelectedOperationalArea = a.AudienceGroup_ID,
                    SelectedOrganisation = new int[] { 1, 2 },
                    SelectedTopic = a.Topic_ID,
                    Audience = a.Audience,
                    Recipient = a.Recipients,

                    IsOnScreen = (bool)a.isOnScreen,
                    IsEmail = (bool)a.isEmail,
                    IsMobile = (bool)a.isMobile

                }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public IEnumerable<LookupEnt> GetLookupDetailsById(int iLookupTypeId)
        {
            /*  try
              {
                  var objalerts = await Task.Run(() => ((BaggageDbContext)Context).usp_GetLookupItems(iLookupTypeId));

                  return objalerts?.Select(a => new LookupEnt
                  {
                      IsActive = a.isActive,
                      LookupID = a.LookUp_ID,
                      LookupName = a.LookUp_Name,
                      LookupTypeID = a.LookUpItem_ID,
                      LookupTypeName = a.LookUpItem_Name,
                      RowID = (int)a.id

                  }).ToList();

              }
              catch (Exception)
              {
                  throw;
              }*/

            DbConnection oDal = new DbConnection();
            LookupEnt oLookupDetailsEnt = null;
            List<LookupEnt> lstLookupDetails = null;
            try
            {

                DataSet dsType = new DataSet();

                oDal.ExecuteDataSet(ProcedureConstants.GetLocation, out dsType,
                       new List<SqlParameter>()
                       {
                           new SqlParameter() { ParameterName = "@id", DbType = DbType.String, Value = iLookupTypeId }
                       });

                // if (this.Errorno == 0)
                {

                    if (dsType.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsType.Tables[0].Rows)
                        {
                            if (lstLookupDetails == null)
                                lstLookupDetails = new List<LookupEnt>();
                            oLookupDetailsEnt = new LookupEnt();
                            oLookupDetailsEnt.RowID = Convert.ToInt32(dr["id"]);
                            oLookupDetailsEnt.LookupTypeName = Convert.ToString(dr["LookUpItem_Name"]);

                            lstLookupDetails.Add(oLookupDetailsEnt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                oDal.CloseConnection();
            }
            return lstLookupDetails;


        }



        public async Task<IEnumerable<Notification>> GetUserNotification(int userid)
        {

            try
            {
                //var objnotif = await Task.Run(() => ((BaggageDbContext)Context).spGetUserNotification(userid));
                //return objnotif?.Select(a => new Notification
                //{
                //    NotificationID = a.NotificationID.ToString(),
                //    Description =a.NotificationDescription,
                //    Topic = a.Topic,
                //    Locations = "Terminal-1,Terminal-2",
                //    ModifiedBy = a.ModifiedBy,
                //    DisableNotification = false,
                //    CreatedBy = a.CreatedBy,
                //    HelpUrl ="Help URL",
                //    StartDate = DateTime.Now,
                //    EndDate = DateTime.Now,
                //    ModifiedDate = (a.ModifiedDateTime)??DateTime.Now,
                //    DateAndTime = a.NotificationCreatedDateTime.ToString(),
                //    SelectedOperationalArea = 1,
                //    SelectedOrganisation = new int[] { 1, 2 },
                //    SelectedTopic = a.MeasureCategoryID,
                //    IsOnScreen = true,
                //    IsEmail = true,
                //    IsMobile = false

                //}).ToList();
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<int> ConfigureNewNotification(Notification _notification)
        {
            try
            {

                //var objNotification = await Task.Run(() => ((BaggageDbContext)Context).spConfigureNewNotification
                // (
                //    _notification.Description,_notification.SelectedTopic,_notification.CreatedBy,3,3
                //));
                //return (objNotification == 1) ? 1 : -1;
                //   //To Do: Save list of notifications for this.NotificationID and this.UserID
                return -1;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

    }
}
