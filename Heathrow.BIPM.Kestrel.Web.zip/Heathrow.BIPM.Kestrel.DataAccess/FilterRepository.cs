﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;

namespace Heathrow.BIPM.Kestrel.DataAccess
{
    /// <summary>
    ///  Save Filter configuration into  Data souruce 
    /// </summary>
    public class FilterRepository : GenericRepository<FilterCollection>, IFilter
    {
        private static FilterCollection filterDto = null;

        public FilterRepository(BaggageDbContext context) : base(context)
        {

        }

        /// <summary>
        /// Save pinned filter configuration into Database
        /// </summary>
        /// <param name="filterData"></param>
        /// <returns></returns>
        public async Task<int> SaveFilter(FilterCollection filterData)
        {
            try
            {
                var objFilter = await Task.Run(() => ((BaggageDbContext)Context)
                                        .usp_SaveFilterDetail(filterData.UserID, filterData.MenuID, filterData.FilterText,
                                        filterData.FilterID).FirstOrDefault());
                return objFilter != null ? Convert.ToInt32(objFilter) : 0;

            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error is occured while saving filters", ex);
            }
        }

        /// <summary>
        ///  Get all Filter configuration Details from Database
        /// </summary>
        /// <param name="menuID"></param>

        /// <returns></returns>
        public async Task<FilterCollection> GetFilterByMenuID(int menuID)
        {
            try
            {
                var dropdownConfig = await Task.Run(() => FillFilterDatasource());
                var filterConfig = await Task.Run(() => FillConfigurationData(menuID));

                var objFilterCollection = await Task.Run(() => ((BaggageDbContext)Context).usp_GetFilterDataByMenuID(menuID).ToList());

                if (objFilterCollection.Count > 0)
                {
                    filterDto = new FilterCollection
                    {
                        FilterID = objFilterCollection[0].FilterID,
                        UserID = objFilterCollection[0].UserID,
                        MenuID = objFilterCollection[0].MenuID,
                        FilterText = objFilterCollection[0].FilterJSON,
                        PBIMappingList = filterConfig.PBIMappingList,
                        FilterConfigurationList = filterConfig.FilterConfigurationList,
                        BaggageSystemList = dropdownConfig.BaggageSystemList,
                        NotLoadedCategoryList = dropdownConfig.NotLoadedCategoryList,
                        NotLoadedSubCategoryList = dropdownConfig.NotLoadedSubCategoryList,
                        LastSeenLocationList = dropdownConfig.LastSeenLocationList,
                        DestinationList = dropdownConfig.DestinationList,
                        OutboundAircraftList=dropdownConfig.OutboundAircraftList,
                        OutboundAirlineList=dropdownConfig.OutboundAirlineList,
                        OutboundHandlerList=dropdownConfig.OutboundHandlerList,
                        OutboundTerminalList=dropdownConfig.OutboundTerminalList,
                    };
                }
                return filterDto;
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error is occured while retrieving the filters", ex);
            }

        }
        public async Task<FilterCollection> GetAllFilter()
        {
            var context = new BaggageDbContext();
            try
            {
                await Task.Run(() => FillFilterDatasource());

            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error is occured while retrieving the filters", ex);
            }

            return filterDto;
        }


        public async Task<FilterCollection> GetFilterConfiguration(int menuID)
        {
            try
            {
                await Task.Run(() => FillConfigurationData(menuID));
            }
            catch (Exception ex)
            {

                throw new ApplicationException("Error is occured while retrieving the filters configuration", ex);
            }

            return filterDto;
        }

        private FilterCollection FillConfigurationData(int menuId)
        {
            using (var context = new BaggageDbContext())
            {

                var oControlConfig = context.usp_GetFilterCtrlConfiguration(menuId)?.ToList();
                // var oReportConfig = context.usp_GetReportConfiguration(menuId)?.FirstOrDefault();
                var oMappingConfig = context.usp_GetFilterConfiguration(menuId)?.ToList();

                filterDto = new FilterCollection
                {
                    PBIMappingList = new List<FilterSelection>(),
                    FilterConfigurationList = new List<FilterConfiguration>(),
                };

                oMappingConfig.ForEach(map =>
                    {
                        filterDto.PBIMappingList.Add(new FilterSelection
                        {
                            TableName = map.PBITableName,
                            ColumnName = map.PBIColumnName,
                            Operator = map.PBIOpearator,
                            ControlMappingID = map.ControlID,
                        });
                    });

                oControlConfig.ForEach(ctrl =>
                {
                    filterDto.FilterConfigurationList.Add(new FilterConfiguration
                    {
                        FilterControlID = ctrl.CtrlID,
                        FilterName = ctrl.CtrlName,
                    });

                });

                return filterDto;
            }
        }

        private FilterCollection FillFilterDatasource()
        {
            using (var context = new BaggageDbContext())
            {
                filterDto = new FilterCollection
                {
                    NotLoadedCategoryList = new List<DropDownFilter>(),
                    NotLoadedSubCategoryList = new List<DropDownFilter>(),
                    OutboundAircraftList = new List<DropDownFilter>(),
                    DestinationList = new List<DropDownFilter>(),
                    OutboundAirlineList = new List<DropDownFilter>(),
                    OutboundTerminalList = new List<DropDownFilter>(),
                    BaggageSystemList = new List<DropDownFilter>(),
                    LastSeenLocationList = new List<DropDownFilter>(),
                    OutboundHandlerList = new List<DropDownFilter>(),
                };

                context.VWNotLoadedCategories.OrderBy(s => s.CategoryDescription).ToList().ForEach(NotLoaded =>
                {
                    filterDto.NotLoadedCategoryList.Add(new DropDownFilter
                    {
                        ID = NotLoaded.CategoryDescription,
                        Name = NotLoaded.CategoryDescription
                    });
                });
                context.VWNotLoadedSubCategories.OrderBy(s => s.SubCategoryDescription).ToList().ForEach(NotLoadedSub =>
                {
                    filterDto.NotLoadedSubCategoryList.Add(new DropDownFilter
                    {
                        ID = NotLoadedSub.SubCategoryDescription,
                        Name = NotLoadedSub.SubCategoryDescription
                    });
                });
                context.VWInOutboundAircraftCategories.OrderBy(a => a.Description).ToList().ForEach(aircraft =>
                {
                    filterDto.OutboundAircraftList.Add(new DropDownFilter
                    {
                        ID = aircraft.Description,
                        Name = aircraft.Description
                    });
                });
                context.VWDestinations.OrderBy(i => i.IATATypeCode).ToList().ForEach(dest =>
                {
                    filterDto.DestinationList.Add(new DropDownFilter
                    {
                        ID = dest.IATATypeCode,
                        Name = dest.IATATypeCode
                    });
                });
                context.VWInOutboundAirlines.OrderBy(i => i.IATAAirlineName).ToList().ForEach(airline =>
                {
                    filterDto.OutboundAirlineList.Add(new DropDownFilter
                    {
                        ID = airline.IATAAirlineName,
                        Name = airline.IATAAirlineName
                    });
                });
                context.VWInOutboundHandlers.OrderBy(d => d.Description).ToList().ForEach(handler =>
                {
                    filterDto.OutboundHandlerList.Add(new DropDownFilter
                    {
                        ID = handler.Description,
                        Name = handler.Description
                    });
                });
                context.VWInOutboundTerminals.OrderBy(d => d.Identifier).ToList().ForEach(terminal =>
                {
                    filterDto.OutboundTerminalList.Add(new DropDownFilter
                    {
                        ID = terminal.Identifier,
                        Name = terminal.Identifier
                    });
                });
                context.VWLastSeenLocations.OrderBy(e => e.Name).ToList().ForEach(loc =>
                {
                    filterDto.LastSeenLocationList.Add(new DropDownFilter
                    {
                        ID = loc.Name,
                        Name = loc.Name
                    });
                });
                context.VWBaggageSystems.OrderBy(e => e.Name).ToList().ForEach(bag =>
                {
                    filterDto.BaggageSystemList.Add(new DropDownFilter
                    {
                        ID = bag.Name,
                        Name = bag.Name
                    });
                });
            }
            return filterDto;
        }
    }
}
