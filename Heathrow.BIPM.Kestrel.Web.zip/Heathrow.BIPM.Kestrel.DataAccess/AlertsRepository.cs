﻿//----------------------------------------------------------------------
//Class Name   : AlertsRepository 
//Purpose      : This is Data Service js file use to connect with the server side api/controller call. 
//               Whit this ajax call we can achive promise in javascripts. 
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;
using Heathrow.BIPM.Kestrel.DataAccess.Common;

namespace Heathrow.BIPM.Kestrel.DataAccess
{
    public class AlertsRepository : GenericRepository<Alerts>,  IAlerts
    {
        public AlertsRepository(BaggageDbContext context) : base(context)
        { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="alert"></param>
        /// <returns></returns>
        public async Task<int> Save(Alerts alert)
        {
            var lookupLocation = GetLookupDetailsById(1);
            var lookupTopic = GetLookupDetailsById(3);
            var lookupAudience = GetLookupDetailsById(4);
            var lookupRec = GetLookupDetailsById(2);
            var lookupMeasure = GetLookupDetailsById(6);
            var lookupThres = GetLookupDetailsById(5);
            var freq = GetLookupDetailsById(7);
            var timeWin = GetLookupDetailsById(8).OrderBy(x => x.LookupTypeName);
            List<string> Locations = new List<string>();
            DbConnection oDal = new DbConnection();
            try
            {
                foreach (var locid in alert.SelectedLocation)
                {
                    foreach (var id in lookupLocation.Where(obj => obj.RowID == (locid)))
                    {
                        {
                            var x = id.LookupTypeName;
                            Locations.Add(x);
                        }
                    }
                }
                foreach (var id in lookupTopic.Where(obj => obj.RowID == alert.SelectedTopic))
                {
                    {

                        alert.Topic = id.LookupTypeName;
                    }
                }
                foreach (var id in lookupAudience.Where(obj => obj.RowID == alert.SelectedOperationalArea))
                {
                    {
                        alert.Audience= id.LookupTypeName;
                    }
                }
             /*   foreach (var id in lookupRec.Where(obj => obj.RowID == alert.SelectedRecipients))
                {
                    {
                        alert.Recipient = id.LookupTypeName;
                    }
                }*/
                foreach (var id in lookupMeasure.Where(obj => obj.RowID == alert.SelectedMeasure))
                {
                    {
                        alert.Measure = id.LookupTypeName;
                    }
                }
                foreach (var id in lookupThres.Where(obj => obj.RowID == alert.SelectedThreshold))
                {
                    {
                        alert.Threshold = id.LookupTypeName;
                    }
                }
                foreach (var id in freq.Where(obj => obj.RowID == alert.SelectedFrequency))
                {
                    {
                        alert.Frequency = id.LookupTypeName;
                    }
                }

                foreach (var id in timeWin.Where(obj => obj.RowID == alert.SelectedTimeWindow))
                {
                    {
                        alert.TimeWindow = Convert.ToInt32(id.LookupTypeName);
                    }
                }
                var objNotification = await Task.Run(() => ((BaggageDbContext)Context).usp_ConfigureNewAlert(
                   "ALT01",alert.Measure,alert.Title,alert.SelectedOperationalArea,1,alert.Description,alert.Topic,
                    string.Join(",", alert.SelectedLocation), alert.SelectedThreshold,alert.ThresholdValue,alert.SelectedMeasure,alert.CreatedBy,alert.CreatedDate.ToString(),alert.ModifiedBy,alert.ModifiedDate.ToString(),alert.IsOnScreen,alert.IsEmail,alert.IsMobile,
                   string.Join(",", Locations), alert.StartDate.ToString(),alert.EndDate.ToString(),"Mandatory",alert.Audience,alert.Recipient,alert.Threshold,alert.SelectedTopic,alert.SelectedTimeWindow,alert.SelectedFrequency,alert.TimeWindow,alert.Frequency,alert.DisableAlert
                 
                   ));
              
                return (objNotification == 1) ? 1 : -1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
          
        }
        public async Task<int> UpdateAlert(Alerts _alert)
        {
            DbConnection oDAL = new DbConnection();

            //     var lookupLocation =lkUp.GetLookupDetailsById(1);
            var lookupLocation = GetLookupDetailsById(1);
            var lookupTopic = GetLookupDetailsById(3);          
            List<string> Locations = new List<string>();
            try
            {
                if (_alert.Title.Contains("Response"))
                {
                    var objAlert = await Task.Run(() => ((BaggageDbContext)Context).usp_UpdateResponse(
               "ALT01", _alert.IsAcknowledge, _alert.IsBlank, _alert.IsIgnore
                            ));
                    return (objAlert == 1) ? 1 : -1;
                }
              /*  else if (_alert.Title == "subscription")
                {
                    var objAlert = await Task.Run(() => ((BaggageDbContext)Context).usp_UpdateSubscription(
            "ALT01", _alert.IsSubscribe, _alert.IsEmail, _alert.IsMobile));
                    return (objAlert == 1) ? 1 : -1;                
                }*/
              
               
                else
                {
                    foreach (var locid in _alert.SelectedLocation)
                    {
                        foreach (var id in lookupLocation.Where(obj => obj.RowID == (locid)))
                        {
                            {
                                var x = id.LookupTypeName;
                                Locations.Add(x);
                            }
                        }
                    }
                    foreach (var id in lookupTopic.Where(obj => obj.RowID == _alert.SelectedTopic))
                    {
                        {

                            _alert.Topic = id.LookupTypeName;
                        }
                    }

                    if (_alert.Threshold==null &&_alert.Audience==null)
                    {
                        var objAlert = await Task.Run(() => ((BaggageDbContext)Context).usp_UpdateAlerts(
                    "ALT01", _alert.Title, 0, 0, _alert.Description,_alert.Topic,string.Join(",", _alert.SelectedLocation),_alert.SelectedThreshold,
                    _alert.ThresholdValue,0, _alert.SelectedTopic,"", "", "","", _alert.IsSubscribe, _alert.IsOnScreen,_alert.IsEmail, _alert.IsMobile,
                    string.Join(",", Locations), DateTime.Now, DateTime.Now,false, false, false,"Mandatory",0,0,_alert.DisableAlert
                          ));
                        return (objAlert == 1) ? 1 : -1;
                    }

                    else
                    {
                        var objAlert = await Task.Run(() => ((BaggageDbContext)Context).usp_UpdateAlerts(
                      "ALT01", _alert.Title, _alert.SelectedOperationalArea, 1, _alert.Description, _alert.Topic, string.Join(",", _alert.SelectedLocation), _alert.SelectedThreshold,
                      _alert.ThresholdValue, _alert.SelectedMeasure, _alert.SelectedTopic, _alert.CreatedBy, _alert.CreatedDate.ToString(), _alert.ModifiedBy, _alert.ModifiedDate.ToString(), _alert.IsSubscribe, _alert.IsOnScreen,
                      _alert.IsEmail, _alert.IsMobile, string.Join(",", Locations),_alert.StartDate, _alert.EndDate, false, false, false,"Mandatory",_alert.SelectedTimeWindow,_alert.SelectedFrequency,_alert.DisableAlert
                                   ));
                        return (objAlert == 1) ? 1 : -1;
                    }
                }

               
            }

            catch (Exception ex)
            {
                throw ex;
            }
           
        }
        public async Task<Alerts> GetAlertsById(string alertId)
        {
            DbConnection oDal = new DbConnection();
            try
            {

                var objalert = await Task.Run(() => ((BaggageDbContext)Context).usp_GetAlertsById(alertId));
                var a = objalert.FirstOrDefault();
                return new Alerts
                {
                    AlertId = 1,
                    Measure = a.Measure_Name,
                    Title = a.Title,
                    Description=a.Description,
                    StartDate=DateTime.Parse(a.Start_Date),
                    EndDate=DateTime.Parse(a.End_Date),
                    ModifiedDate= DateTime.Parse(a.Modified_Date),
                    ModifiedBy=a.Modified_By,
                    CreatedDate= DateTime.Parse(a.Created_Date),
                    ThresholdValue=a.Threshold_Value,
                 
                    MandatoryOptional = 1,
                    
                    IsOnScreen=a.isOnScreen,
                    IsEmail=a.isEmail,
                    IsMobile=a.isMobile,

                    CreatedBy=a.Created_By,
                    SelectedMeasure=a.Measure_ID,
                    SelectedFrequency=a.Frequency_ID,
                    SelectedTimeWindow=a.Time_Window_ID,
                    SelectedTopic=a.Topic_ID,

                    SelectedOperationalArea=a.AudienceGroup_ID,
                    SelectedOrganisation=new int[] { 1,2},
                    SelectedThreshold=a.Threshold_ID,
                    SelectedLocation = a.Location_ID.Split(',').Select(int.Parse).ToArray()
                };
            }
            catch (Exception ex)
            {
                throw ex;
            }
           // return new Alerts();
        }
        public async Task<IEnumerable<Alerts>> GetAllAlerts()
        {           
            try
            {
                var objalerts = await Task.Run(() => ((BaggageDbContext)Context).usp_GetAllAlerts());

                return objalerts?.Select(a => new Alerts
                {
                    AlertId = 1,
                    Location = a.Location,
                    Description = a.Description,
                    Measure=a.Measure_Name,
                    Threshold=a.Threshold,
                    ThresholdValue = a.Threshold_Value,
                    Frequency=a.Frequency,
                    TimeWindow=a.Time_Window,
                    DisableAlert=(bool)a.Disable_Alert,
                    MandatoryOptional = 1,
                    Title = a.Title,
                    Topic = a.Topic,
                    Time = a.Alert_DateTime.ToString(),
                    CreatedBy = a.Created_By,
                    CreatedDate = DateTime.Parse(a.Created_Date),
                    StartDate = DateTime.Parse(a.Start_Date),
                    EndDate = DateTime.Parse(a.End_Date),
                    ModifiedBy = a.Modified_By,
                    ModifiedDate = DateTime.Parse(a.Modified_Date),
                    Audience=a.Audience,
                    Recipient=a.Recipient,                    
                    SelectedOperationalArea = a.AudienceGroup_ID,
                    SelectedMeasure=a.Measure_ID,
                    SelectedOrganisation =new int[]{ 1,2},
                    SelectedThreshold=a.Threshold_ID,
                    SelectedTopic=a.Topic_ID,
                    SelectedLocation=Array.ConvertAll<string, int>(a.Location_ID.Split(','), Convert.ToInt32),
                    IsSubscribe = a.isSubscribe,
                    IsOnScreen = a.isOnScreen,
                    IsEmail = a.isEmail,
                    IsMobile = a.isMobile,
                    IsAcknowledge =(bool) a.isAcknowledge,
                    IsBlank =(bool) a.isSnooze,
                    IsIgnore =(bool) a.isIgnore

                }).ToList();

            }
            catch (Exception e)
            {
                throw;
            }
           
        }
        public IEnumerable<LookupEnt> GetLookupDetailsById(int iLookupTypeId)
        {
            DbConnection oDal = new DbConnection();
           LookupEnt oLookupDetailsEnt = null;
           List<LookupEnt> lstLookupDetails = null;
          try
            {

                DataSet dsType = new DataSet();

                oDal.ExecuteDataSet(ProcedureConstants.GetLocation, out dsType,
                       new List<SqlParameter>()
                       {
                           new SqlParameter() { ParameterName = "@id", DbType = DbType.String, Value = iLookupTypeId }
                       });

                // if (this.Errorno == 0)
                {

                    if (dsType.Tables[0].Rows.Count > 0)
                    {
                        foreach (DataRow dr in dsType.Tables[0].Rows)
                        {
                            if (lstLookupDetails == null)
                                lstLookupDetails = new List<LookupEnt>();
                            oLookupDetailsEnt = new LookupEnt();
                            oLookupDetailsEnt.RowID = Convert.ToInt32(dr["id"]);
                           
                            lstLookupDetails.Add(oLookupDetailsEnt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;

            }
            finally
            {
                oDal.CloseConnection();
            }
            return lstLookupDetails;
            

            
        }


        public async Task<IEnumerable<Alerts>> GetConfigureAlerts()
        {
            try
            {
                /*
                var objalerts = await Task.Run(() => ((BaggageDbContext)Context).spGetAlerts());

                return objalerts?.Select(a => new Alerts
                {
                   AlertId=a.AlertConfigurationID,
                   Title=a.AlertTitle,
                   Time=a.AlertCreatedDatetime.ToString(),
                   Description=a.AlertDescription,                 
                   ThresholdValue=a.ThresholdValue,
                   StartDate = a.AlertStartDatetime,
                   EndDate = a.AlertEndDatetime,
                   CreatedBy =a.AlertCreatedBy,
                   CreatedDate=a.AlertCreatedDatetime,
                   ModifiedBy=a.AlertModifiedBy,
                   ModifiedDate=a.AlertModifiedDatetime,
                   MandatoryOptional=0,
                   IsMobile= (a.AlertMobileDisplayIndicator==1)? true:false,
                   IsEmail=(a.AlertEmailDisplayIndicator==1)?true:false,
                   IsOnScreen=(a.AlertOnScreenDisplayIndicator==1)?true:false,
                   DisableAlert=(a.AlertActiveIndicator==1)?true:false,
                   SelectedFrequency=a.AlertFrequencyID,
                   SelectedMeasure=a.MeasureID,
                   SelectedThreshold=a.ThresholdTypeID,
                   

                  
                }).ToList();
                */
                return null;
            }
            catch (Exception e)
            {
                throw;
            }

        }




    }
}
