﻿using System.Web.Http;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;

namespace Heathrow.BIPM.Kestrel.Api.Controllers
{
    [RoutePrefix("api")]
    public class UserProfileController : BaseApiController
    {
        private IRepository<LocationEnt> _locationRepository;
        private IRepository<JobRoleEnt> _jobRoleRepository;
        public UserProfileController(IUserModule userModule, IRepository<LocationEnt> locationRepo, IRepository<JobRoleEnt> jobRole) : base(userModule)
        {
        }



    }
}
