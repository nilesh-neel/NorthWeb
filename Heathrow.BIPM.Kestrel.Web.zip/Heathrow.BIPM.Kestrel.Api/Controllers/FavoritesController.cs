﻿using System;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web.Http;
using Heathrow.BIPM.Kestrel.Api.ViewModel;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;

namespace Heathrow.BIPM.Kestrel.Api.Controllers
{
    [RoutePrefix("api")]
    public class FavoritesController : BaseApiController
    {
        private readonly IFavouriteModule _favoritesModule;
        private readonly IMapper<FavouritesVM, Favourites> _mapFav;
        public FavoritesController(IFavouriteModule fav, IMapper<FavouritesVM, Favourites> mapFav, IUserModule userModule) : base(userModule)
        {
            _favoritesModule = fav;
            _mapFav = mapFav;
        }
        [HttpGet]
        public async Task<IHttpActionResult> Get()
        {
            return Json(
                _mapFav.MapFrom(await _favoritesModule.GetUserFavourites(ClaimsPrincipal.Current.FindFirst(ClaimTypes.NameIdentifier).Value)));
        }
        [HttpPost]
        public async Task<IHttpActionResult> Post(FavouritesVM favMenu)
        {
            try
            {
                //if (!ModelState.IsValid)+		m_instanceClaims	Count = 1	System.Collections.Generic.List<System.Security.Claims.Claim>

                //    throw new ModelStateException(ModelState);
                var data = new FavouritesVM
                {
                    menuId = Convert.ToInt32(favMenu.menuId),
                    url = favMenu.url,
                    userId = ClaimsPrincipal.Current.FindFirst(ClaimTypes.NameIdentifier).Value

                };
                //Claim scopeClaim = ClaimsPrincipal.Current.FindFirst("http://schemas.microsoft.com/identity/claims/scope");


                var objFavCore = _mapFav.MapTo(data);
                var result = await _favoritesModule.Save(objFavCore);
                if (result != null)
                    return Json(_mapFav.MapFrom(result));

                return Json("Data save fail.");
            }
            catch (Exception ex)
            {
                return Json(ex.Message);
            }

        }
    }
}
