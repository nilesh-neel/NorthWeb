﻿using System.Web.Http;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Api.Controllers
{
    //[EnableCors(origins: "*", headers: "*", methods: "*")]
    //context.OwinContext.Response.Headers.Add("Access-Control-Allow-Origin", new[] { "*" });
    //  [Authorize(Roles = "*")]
    //[HostAuthentication("OAuth2Bearer")]

   // [Authorize]
   // [BpmWebApiAuth]
    public class BaseApiController : ApiController
    {
        private readonly IUserModule _userModule;

        public BaseApiController(IUserModule userModule)
        {
            _userModule = userModule;
        }

        internal AzureAdUser LoginInUser
        {
            get
            {
                var userDetails = _userModule.GetUserDetailsAsync().Result;
                return userDetails ?? new AzureAdUser
                {
                    DisplayName = "Dummy Name",
                    Email = "dummyname@xyzairway.com",
                    JobRoles = null,
                    Organization = "xyzOrganization",
                    Locations = null,
                    Name = "Dummy",
                    Phone = "xxxxxxxxxx"
                };
            }
        }
    }
}
