﻿using System.Threading.Tasks;
using System.Web.Http;
using Heathrow.BIPM.Kestrel.Business.Interface;

namespace Heathrow.BIPM.Kestrel.Api.Controllers
{
    [RoutePrefix("api")]
    public class AuthApiController : ApiController
    {
        private readonly IAuthProvider _authProvider;
        private readonly IBpmPowerBi _bpmPowerBi;
        public AuthApiController(IAuthProvider authProvider, IBpmPowerBi bpmPowerBi)
        {
            _authProvider = authProvider;
            _bpmPowerBi = bpmPowerBi;
        }

        [Route("AdToken")]
        [System.Web.Http.HttpGet]
        public async Task<string> GetAdToken()
        {
            return await _authProvider.GetUserAccessTokenAsync();
        }

        [Route("PbiToken")]
        [System.Web.Http.HttpGet]
        public async Task<string> GetPbiToken()
        {
            var token = await _bpmPowerBi.EmbedToken();
            return !string.IsNullOrEmpty(token) ? token : "";
        }

    }
}
