﻿using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Core.Interface
{
   public interface IRegistration
    {        
        int Save(Registration _registration);
        
    }
}
