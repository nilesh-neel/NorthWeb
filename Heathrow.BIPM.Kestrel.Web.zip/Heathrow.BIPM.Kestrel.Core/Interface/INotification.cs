﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Core.Interface
{
    public interface INotification
    {
       Task<Notification> GetNotificationByNotificationId(string _notificationId);
       Task<int> Save(Notification _notification);
       Task<IEnumerable<Notification>> GetTodaysNotification();
        Task<int> UpdateNotification(Notification notification);
       Task<IEnumerable<Notification>> GetUserNotification(int userid);
        Task<int> ConfigureNewNotification(Notification _notification);
    }
}
