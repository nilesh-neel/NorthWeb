﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Core.Interface
{
    public interface IFavourites : IRepository<Favourites>
    {
        //  IEnumerable<Favourites> GetUserFavourites(string _userId);
        Task<int> Save(Favourites _favourites);
        Task<List<Favourites>> GetUserFavourites(string _userId);
    }
}
