﻿using System.Collections.Generic;
using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Core.Interface
{
    public interface IAssignHomePage
    {
        int Save(AssignHomePage _assignHomePage);
        IEnumerable<AssignHomePage> Get();
    }
}
