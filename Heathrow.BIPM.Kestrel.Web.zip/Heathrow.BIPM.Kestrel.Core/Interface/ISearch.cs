﻿

using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Core.Interface
{
    public interface ISearch
    {
        System.Threading.Tasks.Task<ReportConfiguration> GetSearchData(string searchText,string prefix);
    }
}
