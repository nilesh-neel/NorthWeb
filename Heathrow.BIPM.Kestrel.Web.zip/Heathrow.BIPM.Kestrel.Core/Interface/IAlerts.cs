﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Core.Interface
{
    public interface IAlerts
    {
        Task<IEnumerable<Alerts>> GetAllAlerts();
        Task<Alerts> GetAlertsById(string _alertId);
        Task<int> Save(Alerts _alert);

        Task<int> UpdateAlert(Alerts _alert);
        Task<IEnumerable<Alerts>> GetConfigureAlerts();

      /*   Task<IEnumerable<LookupEnt>> GetAllMeasure();

         Task<IEnumerable<LookupEnt>> GetAllTopic();

        Task<IEnumerable<LookupEnt>> GetAllLocation();

        Task<IEnumerable<LookupEnt>> GetAllThreshold();
        Task<IEnumerable<LookupEnt>> GetAllFrequency();
        Task<IEnumerable<LookupEnt>> GetAllTimeWindow();
        Task<IEnumerable<LookupEnt>> GetAllAudienceGroup();
        Task<IEnumerable<LookupEnt>> GetAllRecipient(int id);*/

    }
}
