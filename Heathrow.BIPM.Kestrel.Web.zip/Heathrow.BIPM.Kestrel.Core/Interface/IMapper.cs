﻿using System.Collections.Generic;

namespace Heathrow.BIPM.Kestrel.Core.Interface
{
    public interface IMapper<T1, T2>
    {
        T2 MapTo(T1 input);
         T1 MapFrom(T2 input);
        IEnumerable<T2> MapTo(IEnumerable<T1> input);
        IEnumerable<T1> MapFrom(IEnumerable<T2> input);

    }
}
