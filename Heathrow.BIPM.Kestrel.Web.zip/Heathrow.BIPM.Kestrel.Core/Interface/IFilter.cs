﻿using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Core.Interface
{
    /// <summary>
    ///  Create Filter interface
    /// </summary>
    public interface IFilter
    {
      Task<FilterCollection> GetFilterByMenuID(int menuID);
        Task<FilterCollection>  GetAllFilter();
        Task<FilterCollection> GetFilterConfiguration(int menuID);
       Task<int> SaveFilter(FilterCollection filterData);
    }
}
