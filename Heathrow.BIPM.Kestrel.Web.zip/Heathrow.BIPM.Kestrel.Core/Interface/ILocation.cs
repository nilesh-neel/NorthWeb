﻿using System.Collections.Generic;
using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Core.Interface
{
    public interface ILocation
    {
        IEnumerable<LocationEnt> GetLocation();
    }
}
