﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Core.Interface
{
    public interface IMenu
    {
        IEnumerable<Menu> GetAllMenu();
        Task<IEnumerable<Menu>> GetAllMenuAsync();
    }
}
