﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Core.Interface
{
    public interface ILookup
    {
         IEnumerable<LookupEnt> GetLookupDetailsById(int iLookupTypeID);

        Task<IEnumerable<LookupEnt>> GetAllMeasure();

        Task<IEnumerable<LookupEnt>> GetAllTopic();

        Task<IEnumerable<LookupEnt>> GetAllLocation();

        Task<IEnumerable<LookupEnt>> GetAllThreshold();
        Task<IEnumerable<LookupEnt>> GetAllFrequency();
        Task<IEnumerable<LookupEnt>> GetAllTimeWindow();
        Task<IEnumerable<LookupEnt>> GetAllOrganisation();
        Task<IEnumerable<LookupEnt>> GetAllOperationalArea();
    }
}
