﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Heathrow.BIPM.Kestrel.Core.Interface
{
    public interface IRepository<TEntity> : IDisposable where TEntity : class
    {
        IEnumerable<TEntity> All();
        IEnumerable<TEntity> AllInclude(params Expression<Func<TEntity, object>>[] includeProperties);
        IEnumerable<TEntity> FindByInclude(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includeProperties);
        IEnumerable<TEntity> FindBy(Expression<Func<TEntity, bool>> predicate);
        TEntity FindByKey(int id);
        void Insert(TEntity entity);
        void Update(TEntity entity);
        void Delete(int id);
        IEnumerable<TEntity> ExecuteQuery(string query, params object[] parameters);
        TEntity ExecuteQuerySingle(string spQuery, object[] parameters);
        //int ExecuteCommand(string spQuery, object[] parameters);

        /**************************Async Call Start***********************************/
        IQueryable<TEntity> GetAllIncluding(params Expression<Func<TEntity, object>>[] includeProperties);
        Task<IEnumerable<TEntity>> AllAsync();
        Task<ICollection<TEntity>> FindByAsyn(Expression<Func<TEntity, bool>> predicate);
        Task<TEntity> GetByIdAsync(object id);
        Task InsertAsync(TEntity entity);
        Task UpdateAsync(TEntity entity);
        Task DeleteAsync(TEntity entity);
        Task DeleteAllAsync(List<TEntity> entity);
        IQueryable<TEntity> Table { get; }
        Task<IEnumerable<TEntity>> ExecuteQueryAsync(string spQuery);
        Task<IEnumerable<TEntity>> ExecuteQueryAsync(string spQuery, object[] parameters);
        Task<TEntity> ExecuteQuerySingleAsync(string spQuery);

        /*************************Async Call End***********************************/


    }
}
