﻿namespace Heathrow.BIPM.Kestrel.Core.Entity
{
  public class BaseLookUpEnt
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
}
