﻿namespace Heathrow.BIPM.Kestrel.Core.Entity
{
  public  class LookupEnt
    {
        public int RowID { get; set; }
      //  public int LookupTypeID { get; set; }
        public string LookupTypeName { get; set; }
      //  public string LookupName { get; set; }
      //  public int LookupID { get; set; }
      //  public bool IsActive { get; set; }
    }
}
