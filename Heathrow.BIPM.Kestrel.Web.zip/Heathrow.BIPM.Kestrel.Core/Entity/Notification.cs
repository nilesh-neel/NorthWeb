﻿using System.Collections.Generic;

namespace Heathrow.BIPM.Kestrel.Core.Entity
{
    public class Notification : Response
    {   //Today's Notification      
        public string Description { get; set; }
        public string Topic { get; set; }
        public string Locations { get; set; }
        public string DateAndTime { get; set; }

        //Notification Settings
        public string NotificationID { get; set; }
        public string Audience { get; set; }
        public string Recipient { get; set; }
        

        //
       
        public int TopicID { get; set; }



        //Multiselect enabled
        public List<LocationEnt> LocationList { get; set; }
     

        //Configure
        public string HelpUrl { get; set; }  
            
       

       /* public int SelectedAudienceGroup { get; set; }
        public int[] SelectedRecipients { get; set; }*/
       
   


    }

}
