﻿namespace Heathrow.BIPM.Kestrel.Core.Entity
{
    public class LocationEnt :BaseLookUpEnt
    {
     

    }
   
}
