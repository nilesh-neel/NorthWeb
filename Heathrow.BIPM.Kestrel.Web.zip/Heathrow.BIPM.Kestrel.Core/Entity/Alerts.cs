﻿

namespace Heathrow.BIPM.Kestrel.Core.Entity
{
    public class Alerts:Response
    {
        public int AlertId { get; set; }

       public string Description { get; set; }
        public string Title { get; set; }
        public string Time { get; set; }
        public string Topic { get; set; }       
        public string Location { get; set; }
        public string Measure { get; set; }
        public string Audience { get; set; }
        public string Recipient { get; set; }
        public string Threshold { get; set; }
     
        public string ThresholdValue { get; set; }
        public string Frequency { get; set; }
        public int TimeWindow { get; set; }
        
        public int MandatoryOptional { get; set; }
      
    /*    public int SelectedTopic { get; set; }
        public int SelectedThreshold { get; set; }
        public int[] SelectedLocation { get; set; }
        public int SelectedFrequency { get; set; }
        public int SelectedTimeWindow { get; set; }
        public int SelectedMeasure { get; set; }*/
    }
}
