﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Heathrow.BIPM.Kestrel.Core.Entity
{
    [ComplexType]
    public class Favourites
    {
        [Column("Favourite_ID", Order = 0)]
        public int FavouriteId { get; set; }
        [Column("[User_ID]", Order = 1)]
        public string UserId { get; set; }
        public Menu FavouriteLink { get; set; }
    }

}
