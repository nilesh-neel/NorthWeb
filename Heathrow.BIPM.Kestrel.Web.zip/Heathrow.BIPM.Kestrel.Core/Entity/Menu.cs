﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Heathrow.BIPM.Kestrel.Core.Entity
{
    [ComplexType]
    public class Menu
    {
        [Column("Menu_ID", Order = 0)]
        public int MenuId { get; set; }
        [Column("Menu_Desc", Order = 1)]
        public string Description { get; set; }
        [Column("Menu_Url", Order = 2)]
        public string OperationalUrl { get; set; }
        public string BusinessUrl { get; set; }
        public string Organization { get; set; }
        [Column("Parent_ID", Order = 3)]
        public int ParentId { get; set; }
        [Column("Order_ID", Order = 4)]
        public int OrderId { get; set; }
        [Column("Css_Icon", Order = 5)]
        public string CssIcon { get; set; }
        [Column("IsReport", Order = 6)]
        public bool IsReport { get; set; }
        public string  Tooltip { get; set; }
        public string FavouritesDescription { get; set; }
    }
}
