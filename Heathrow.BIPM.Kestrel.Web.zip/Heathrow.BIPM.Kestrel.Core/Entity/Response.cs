﻿using System;

namespace Heathrow.BIPM.Kestrel.Core.Entity
{
  public class Response
    {
        public bool IsAcknowledge { get; set; }
        public bool IsBlank { get; set; }
        public bool IsIgnore { get; set; }
        public bool IsSubscribe { get; set; }
        public bool IsOnScreen { get; set; }
        public bool IsEmail { get; set; }
        public bool IsMobile { get; set; }
        public bool DisableAlert { get; set; }
        public bool DisableNotification { get; set; }



        public int SelectedOperationalArea { get; set; }
        public int[] SelectedOrganisation { get; set; }
        public int SelectedTopic { get; set; }
        public int SelectedThreshold { get; set; }
        public int[] SelectedLocation { get; set; }
        public int SelectedFrequency { get; set; }
        public int SelectedTimeWindow { get; set; }
        public int SelectedMeasure { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }

    }
}
