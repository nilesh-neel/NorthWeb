﻿namespace Heathrow.BIPM.Kestrel.Business
{
    public class Class1
    {
    }
}
