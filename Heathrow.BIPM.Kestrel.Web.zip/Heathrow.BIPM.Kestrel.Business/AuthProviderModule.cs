﻿using System;
using System.Linq;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using Heathrow.BIPM.Kestrel.Business.Infrastructure;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Microsoft.Graph;
using Microsoft.Identity.Client;

namespace Heathrow.BIPM.Kestrel.Business
{
    public class AuthProviderModule : IAuthProvider
    {

        public async Task<string> GetUserAccessTokenAsync()
        {
            try
            {
                string signedInUserId = ClaimsPrincipal.Current.FindFirst(ClaimTypes.NameIdentifier).Value;
                HttpContextWrapper httpContext = new HttpContextWrapper(HttpContext.Current);
                TokenCache userTokenCache = new SessionTokenCache(signedInUserId, httpContext).GetMsalCacheInstance();
                //var cachedItems = tokenCache.ReadItems(appId); // see what's in the cache

                ConfidentialClientApplication idClient = new ConfidentialClientApplication(AzureAdConfig.ClientId, AzureAdConfig.AadAuthorityUri,
                    new ClientCredential(AzureAdConfig.ClientSecret), userTokenCache, null);
                var accounts = await idClient.GetAccountsAsync();

                AuthenticationResult result = await idClient.AcquireTokenSilentAsync(AzureAdConfig.AzureGraphScopes.Split(new char[] { ' ' }), accounts.FirstOrDefault());
                return result.AccessToken;
            }

            // Unable to retrieve the access token silently.
            catch (Exception)
            {
                throw new ServiceException(
                    new Error
                    {
                        Code = GraphErrorCode.AuthenticationFailure.ToString(),
                        Message = "Error message when unable to retrieve the access token silently."
                    });
            }
        }

        public GraphServiceClient GetGraphServiceClient()
        {
            return new GraphServiceClient(new DelegateAuthenticationProvider(
                    async (requestMessage) =>
                    {
                        // Append the access token to the request.
                        requestMessage.Headers.Authorization = new AuthenticationHeaderValue("bearer", await GetUserAccessTokenAsync());

                        // Get event times in the current time zone.
                        requestMessage.Headers.Add("Prefer", "outlook.timezone=\"" + TimeZoneInfo.Local.Id + "\"");
                    }));
        }
    }
}
