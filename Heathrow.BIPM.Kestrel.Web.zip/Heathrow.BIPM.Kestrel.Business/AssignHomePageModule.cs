﻿using System.Collections.Generic;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;

namespace Heathrow.BIPM.Kestrel.Business
{
   public class AssignHomePageModule : IAssignHomePageModule
    {
       

        private static IAssignHomePage _assignHomePageRepository { get; set; }
        public AssignHomePageModule(IAssignHomePage assignhomepage)
        {
            _assignHomePageRepository = assignhomepage;
           
        }

        public int Save(AssignHomePage assignhomepage)
        {
            return _assignHomePageRepository.Save(assignhomepage);
        }

     

        //get Todays Notification
        public IEnumerable<AssignHomePage> Get()
        {
            return _assignHomePageRepository.Get();
        }
    }
}
