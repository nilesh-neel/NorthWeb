﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;

namespace Heathrow.BIPM.Kestrel.Business
{
    public class FavouriteModule : IFavouriteModule
    {
        private static IFavourites FavouriteRepo { get; set; }
        private static IMenuModule MenuModel { get; set; }

        public FavouriteModule(IFavourites fav, IMenuModule menu)
        {
            MenuModel = menu;
            FavouriteRepo = fav;
        }


        public async Task<IEnumerable<Favourites>> Save(Favourites fav)
        {
            try
            {
                var menuDetails = await MenuModel.GetAllMenu();
                if (!menuDetails.Any()) return null;
                var curretnFavMenu = menuDetails.Where(a => a.MenuId.Equals(fav.FavouriteLink.MenuId)).FirstOrDefault();
                //set parent id 1 for the favourite.
                curretnFavMenu.ParentId = 1;
                var favMenuList = await FavouriteRepo.GetUserFavourites(fav.UserId);
                if (await FavouriteRepo.Save(fav) == 0)
                {
                    favMenuList.Append(new Favourites { UserId = fav.UserId, FavouriteLink = curretnFavMenu });
                }

                return favMenuList != null ? favMenuList : null;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }

        }

        public async Task<IEnumerable<Favourites>> GetUserFavourites(string _userId)
        {
            try
            {
                //return await Favourites.ExecuteQueryAsync(ProcedureConstants.GetAllMenu);
                var result = await FavouriteRepo.GetUserFavourites(_userId);
                foreach (var menuFav in result)
                {//set parent id 1 for the favourite.
                    menuFav.FavouriteLink.ParentId = 1;
                }

                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
