﻿using System.Threading;
using System.Web;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Microsoft.Identity.Client;
using Newtonsoft.Json;

namespace Heathrow.BIPM.Kestrel.Business.Infrastructure
{ // Simple class to serialize into the session
    

    public class SessionTokenCache
    {
        public static ReaderWriterLockSlim SessionLock { get; } =
            new ReaderWriterLockSlim(LockRecursionPolicy.NoRecursion);

        private readonly string _cacheId;
        private readonly string _cachedUserId;
        private readonly HttpContextBase _httpContext;
        readonly TokenCache _tokenCache = new TokenCache();

        public SessionTokenCache(string userId, HttpContextBase httpContext)
        {
            // not object, we want the SUB
            _cacheId = $"{userId}_TokenCache";
            _cachedUserId = $"{userId}_UserCache";
            _httpContext = httpContext;
            Load();
        }

        public TokenCache GetMsalCacheInstance()
        {
            _tokenCache.SetBeforeAccess(BeforeAccessNotification);
            _tokenCache.SetAfterAccess(AfterAccessNotification);
            Load();
            return _tokenCache;
        }

        public bool HasData()
        {
            return (_httpContext.Session[_cacheId] != null && ((byte[])_httpContext.Session[_cacheId]).Length > 0);
        }

        public void Clear()
        {
            _httpContext.Session.Remove(_cacheId);
        }

        private void Load()
        {
            SessionLock.EnterReadLock();
            _tokenCache.Deserialize((byte[])_httpContext.Session[_cacheId]);
            SessionLock.ExitReadLock();
        }

        private void Persist()
        {
            SessionLock.EnterReadLock();

            // Optimistically set HasStateChanged to false. 
            // We need to do it early to avoid losing changes made by a concurrent thread.
            _tokenCache.HasStateChanged = false;

            _httpContext.Session[_cacheId] = _tokenCache.Serialize();
            SessionLock.ExitReadLock();
        }

        // Triggered right before MSAL needs to access the cache. 
        private void BeforeAccessNotification(TokenCacheNotificationArgs args)
        {
            // Reload the cache from the persistent store in case it changed since the last access. 
            Load();
        }

        // Triggered right after MSAL accessed the cache.
        private void AfterAccessNotification(TokenCacheNotificationArgs args)
        {
            // if the access operation resulted in a cache update
            if (_tokenCache.HasStateChanged)
            {
                Persist();
            }
        }

        public void SaveUserDetails(AzureAdUser user)
        {
            SessionLock.EnterReadLock();
            _httpContext.Session[_cachedUserId] = JsonConvert.SerializeObject(user);
            SessionLock.ExitReadLock();
        }

        public AzureAdUser GetUserDetails()
        {
            SessionLock.EnterReadLock();
            var cachedUser = JsonConvert.DeserializeObject<AzureAdUser>((string)_httpContext.Session[_cachedUserId]);
            SessionLock.ExitReadLock();
            return cachedUser;
        }

    }
}
