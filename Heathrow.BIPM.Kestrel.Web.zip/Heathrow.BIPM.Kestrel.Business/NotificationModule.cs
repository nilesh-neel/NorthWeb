﻿/****************************************************************************************************************
Class Name   : NotificationModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;

namespace Heathrow.BIPM.Kestrel.Business
{
    public class NotificationModule : INotificationModule
    {

      

        private static INotification NotificationRepository { get; set; }
        public NotificationModule(INotification notification)
        {
            NotificationRepository = notification;
           
        }       

        public Task<int> Save(Notification notification)
        {
            return NotificationRepository.Save(notification);
        }
        public Task<int> Update(Notification notification)
        {
            return NotificationRepository.UpdateNotification(notification);
        }

        public Task<Notification> GetNotificationById(string notificationId)
        {
                                       
            return NotificationRepository.GetNotificationByNotificationId(notificationId);
        }

        public Task<IEnumerable<Notification>> GetTodaysNotification()
        {       
            return NotificationRepository.GetTodaysNotification();
        }

        public Task<IEnumerable<Notification>> GetUsersNotification(int id)
        {
            return NotificationRepository.GetUserNotification(id);
        }
        public Task<int> ConfigureNewNotification(Notification notification)
        {
            return NotificationRepository.ConfigureNewNotification(notification);
        }
    }
}
