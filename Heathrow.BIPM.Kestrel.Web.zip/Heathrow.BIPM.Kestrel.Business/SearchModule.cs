﻿using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;

namespace Heathrow.BIPM.Kestrel.Business
{
    
    public class SearchModule : ISearchModule
    {

        private readonly ISearch searchInstance;
        public SearchModule(ISearch searchObj)
        {
            searchInstance = searchObj;
        }

        public async Task<ReportConfiguration> GetSearchData(string searchQuery, string searchPrefix)
        {
            return await searchInstance.GetSearchData(searchQuery, searchPrefix);
        }

    
    }
}
