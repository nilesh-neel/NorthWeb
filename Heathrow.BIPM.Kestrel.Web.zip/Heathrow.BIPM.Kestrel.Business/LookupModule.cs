﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;

namespace Heathrow.BIPM.Kestrel.Business
{
  public  class LookupModule:ILookUpModule
    {
        private static ILookup _lookup { get; set; }
        public LookupModule(ILookup lookup)
        {

            _lookup = lookup;
        }

        public IEnumerable<LookupEnt> GetLookupById(int id)
        {
            return _lookup.GetLookupDetailsById(id);
        }


        public Task<IEnumerable<LookupEnt>> Bag_MeasureList()
        {
            // return Lookup.GetLookupDetailsById(1);
            return _lookup.GetAllMeasure();
        }
        public Task<IEnumerable<LookupEnt>> Bag_TopicList()
        {
            return _lookup.GetAllTopic();
        }
        public Task<IEnumerable<LookupEnt>> Bag_LocationList()
        {
            return _lookup.GetAllLocation();
        }
        public Task<IEnumerable<LookupEnt>> Bag_ThresholdList()
        {
            return _lookup.GetAllThreshold();
        }
        public Task<IEnumerable<LookupEnt>> Bag_FrequencyList()
        {
            return _lookup.GetAllFrequency();
        }

        public Task<IEnumerable<LookupEnt>> Bag_TimeWindowList()
        {
            return _lookup.GetAllTimeWindow();
        }

        public Task<IEnumerable<LookupEnt>> Bag_OrganisationList()
        {
            return _lookup.GetAllOrganisation();
        }
        public Task<IEnumerable<LookupEnt>> Bag_OperationalAreaList()
        {
            return _lookup.GetAllOperationalArea();
        }
    }
}
