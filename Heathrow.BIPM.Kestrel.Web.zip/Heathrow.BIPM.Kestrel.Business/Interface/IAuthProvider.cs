﻿using System.Threading.Tasks;
using Microsoft.Graph;

namespace Heathrow.BIPM.Kestrel.Business.Interface
{
    public interface IAuthProvider
    {
        Task<string> GetUserAccessTokenAsync();
        GraphServiceClient GetGraphServiceClient();
    }
}
