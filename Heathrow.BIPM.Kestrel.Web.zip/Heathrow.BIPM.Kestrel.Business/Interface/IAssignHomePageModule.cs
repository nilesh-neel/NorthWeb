﻿using System.Collections.Generic;
using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Business.Interface
{
    public interface IAssignHomePageModule
    {
        IEnumerable<AssignHomePage> Get();
        int Save(AssignHomePage assignhomepage);
    }
}