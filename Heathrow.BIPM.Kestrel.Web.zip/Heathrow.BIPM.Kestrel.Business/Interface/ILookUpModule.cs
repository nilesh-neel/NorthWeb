﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Business.Interface
{
    public interface ILookUpModule
    {
        IEnumerable<LookupEnt> GetLookupById(int id);
        Task<IEnumerable<LookupEnt>> Bag_MeasureList();
        Task<IEnumerable<LookupEnt>> Bag_TopicList();
        Task<IEnumerable<LookupEnt>> Bag_LocationList();
        Task<IEnumerable<LookupEnt>> Bag_ThresholdList();
        Task<IEnumerable<LookupEnt>> Bag_FrequencyList();
        Task<IEnumerable<LookupEnt>> Bag_TimeWindowList();
        Task<IEnumerable<LookupEnt>> Bag_OrganisationList();
        Task<IEnumerable<LookupEnt>> Bag_OperationalAreaList();
    
}
}
