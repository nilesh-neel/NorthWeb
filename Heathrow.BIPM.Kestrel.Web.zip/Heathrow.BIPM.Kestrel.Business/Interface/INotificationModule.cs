﻿/****************************************************************************************************************
Class Name   : ChildDependencyExtension.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Business.Interface
{
    public interface INotificationModule
    {
        Task<Notification> GetNotificationById(string _notificationId);
        Task<IEnumerable<Notification>> GetTodaysNotification();
        Task<int> Save(Notification notification);
        Task<int> Update(Notification notification);
        Task<IEnumerable<Notification>> GetUsersNotification(int id);
        Task<int> ConfigureNewNotification(Notification notification);
    }

}