﻿using System.Threading.Tasks;

namespace Heathrow.BIPM.Kestrel.Business.Interface
{
    public interface IBpmPowerBi
    {
        Task<string> GetEmbeddedTokenWebApp();
        Task<string> GetEmbeddedTokenNativeApp();
        Task<string> GetToken();
        Task<string> EmbedToken();
    }
}
