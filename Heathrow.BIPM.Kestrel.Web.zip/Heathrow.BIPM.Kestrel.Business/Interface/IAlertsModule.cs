﻿/****************************************************************************************************************
Class Name   : ChildDependencyExtension.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Core.Entity;

namespace Heathrow.BIPM.Kestrel.Business.Interface
{
    public interface IAlertsModule
    {
        Task<Alerts> GetAlertsById(string id);
        Task<IEnumerable<Alerts>> GetAlerts();

        Task<IEnumerable<Alerts>> GetConfigureAlerts();
        Task<int> Save(Alerts alert);
        Task<int> Update(Alerts alerts);
      


     /*    Task<IEnumerable<LookupEnt>> Bag_MeasureList();
         Task<IEnumerable<LookupEnt>> Bag_TopicList();
         Task<IEnumerable<LookupEnt>> Bag_LocationList();
         Task<IEnumerable<LookupEnt>> Bag_ThresholdList();
         Task<IEnumerable<LookupEnt>> Bag_FrequencyList();

        Task<IEnumerable<LookupEnt>> Bag_TimeWindowList();

         Task<IEnumerable<LookupEnt>> Bag_AudienceGroupList();
        Task<IEnumerable<LookupEnt>> Bag_RecipientList(int id);
        */

    }
}