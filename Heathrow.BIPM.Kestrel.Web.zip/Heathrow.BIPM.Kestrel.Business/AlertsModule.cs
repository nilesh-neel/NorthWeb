﻿/****************************************************************************************************************
Class Name   : AlertsModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;

namespace Heathrow.BIPM.Kestrel.Business
{
    public class AlertsModule : IAlertsModule
    {
        private static IAlerts _alertsRepository;
       
        public AlertsModule(IAlerts alerts)
        {
            //_alertsRepository = alert;
            _alertsRepository = alerts;
           
            // CRUD oDAL = new CRUD();
        }

        public Task<IEnumerable<Alerts>> GetAlerts()
        {
            // return null;//
            return _alertsRepository.GetAllAlerts();
        }
        public Task<Alerts> GetAlertsById(string id)
        {
            //  return null;// _alertsRepository.GetAlertsById(id);
            return _alertsRepository.GetAlertsById(id);
        }
        public Task<int> Save(Alerts alert)
        {
            return _alertsRepository.Save(alert);
        }
        public Task<int> Update(Alerts alert)
        {
            return _alertsRepository.UpdateAlert(alert);
        }
        public Task<IEnumerable<Alerts>> GetConfigureAlerts()
        {
            return _alertsRepository.GetConfigureAlerts();
        }
        /*   public Task<IEnumerable<LookupEnt>> Bag_MeasureList()
           {
               // return Lookup.GetLookupDetailsById(1);
               return _alertsRepository.GetAllMeasure();
           }
           public Task<IEnumerable<LookupEnt>> Bag_TopicList()
           {
               return _alertsRepository.GetAllTopic();
           }
           public Task<IEnumerable<LookupEnt>> Bag_LocationList()
           {           
               return _alertsRepository.GetAllLocation();
           }
           public Task<IEnumerable<LookupEnt>> Bag_ThresholdList()
           {
               return _alertsRepository.GetAllThreshold();
           }
           public Task<IEnumerable<LookupEnt>> Bag_FrequencyList()
           {
               return _alertsRepository.GetAllFrequency();
           }

           public Task<IEnumerable<LookupEnt>> Bag_TimeWindowList()
           {
               return _alertsRepository.GetAllTimeWindow();
           }

           public Task<IEnumerable<LookupEnt>> Bag_AudienceGroupList()
           {
               return _alertsRepository.GetAllAudienceGroup();
           }
           public Task<IEnumerable<LookupEnt>> Bag_RecipientList(int id)
           {
               return _alertsRepository.GetAllRecipient(id);
           }
       */
    }
}
