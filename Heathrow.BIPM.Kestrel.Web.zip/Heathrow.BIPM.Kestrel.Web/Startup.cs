﻿/****************************************************************************************************************
Class Name   : Startup.cs 
Purpose      : Used as Owin Startup class to implements authentication and authorization in Application. 
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using Microsoft.Owin;
using Microsoft.Owin.Cors;
using System.Web.Optimization;
using System.Web.Routing;
using Heathrow.BIPM.Kestrel.Web.Configuration;
using Owin;

//using System.Web.Optimization;

[assembly: OwinStartup(typeof(Heathrow.BIPM.Kestrel.Web.Startup))]
namespace Heathrow.BIPM.Kestrel.Web
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {

            Bootstrap.Initialise();
            BuildConfiguration();
            ConfigureAuth(app);
            app.UseCors(CorsOptions.AllowAll);

        }


        private void BuildConfiguration()
        {
            // Bootstrap.Initialise();
            // FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
    }
}