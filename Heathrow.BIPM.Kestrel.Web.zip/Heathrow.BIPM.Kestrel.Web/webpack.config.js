﻿var path = require('path');
var webpack = require("webpack");
var glob = require('glob');
var UglifyJsPlugin = require('uglifyjs-webpack-plugin');

var filesList =
    module.exports = {
        entry: {
            appJs: glob.sync(path.resolve(__dirname + '/Scripts/APP/**/*.js')),
            // vendorJs: glob.sync(path.resolve(__dirname + '/Scripts/vendor/**/*.js')),
            // pluginJs: glob.sync(path.resolve(__dirname + '/Scripts/plugins/**/*.js'))
        }, //toObject(glob.sync('/Scripts/App/**/*.js*')),
        output: {
            path: __dirname + '/dist',
            filename: '[name].js'
        },
        module: {
            rules: [
                // any other rules
                {
                    // Exposes jQuery for use outside Webpack build
                    test: require.resolve('jquery'),
                    use: [{
                        loader: 'expose-loader',
                        options: 'jQuery'
                    }, {
                        loader: 'expose-loader',
                        options: '$'
                    }]
                },
                {
                    test: /\.m?js$/,
                    exclude: /(node_modules|bower_components)/,
                    use: {
                        loader: 'babel-loader',
                        options: {
                            presets: ['@babel/preset-env'],
                            plugins: ['@babel/plugin-proposal-object-rest-spread']
                        }
                    }
                },
                {
                    test: /\.(less|css)$/,
                    use: ['style-loader', 'css-loader', 'less-loader'],
                },
                {
                    test: /\.(js|jsx)?$/,
                    loader: 'babel-loader',
                    exclude: /node_modules/,
                    options: { presets: ['env', 'react', 'stage-0', 'stage-1'] }
                },
                {
                    test: /\.(png|jpg|gif)?$/,
                    use: ['url-loader?limit=8192&name=[name]_[sha512:hash:base64:7].[ext]'],
                },
                {
                    test: /\.(eot|woff|ttf|svg)$/,
                    use: ['file-loader?limit=81920&name=[name]_[sha512:hash:base64:7].[ext]']
                }
            ]
        },
        resolve: {
            extensions: ['.js', '.jsx', '.styl', '.html', '.json'],
            modules: ['node_modules']
        },
        optimization: {
            minimizer: [new UglifyJsPlugin()]
        },
        plugins: [
            // Provides jQuery for other JS bundled with Webpack
            new webpack.ProvidePlugin({
                $: 'jquery',
                jQuery: 'jquery',
                'jquery': 'jquery',
                'windows.jQuery': 'jquery',
            }),
        ]
    };


function toObject(paths) {
    var ret = {};
    console.log(paths);
    paths.forEach(function(path) {
        // you can define entry names mapped to [name] here
        ret[path.split('/').slice(-1)[0]] = path;
    });

    return ret;
}