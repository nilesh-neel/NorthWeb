﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;

namespace Heathrow.BIPM.Kestrel.Web.ViewModel
{
    public class MenuVM
    {
        [Required]
        public int menuId { get; set; }
        public string url { get; set; }

        public string operationalUrl { get; set; }
        public string businessUrl { get; set; }
        public string description { get; set; }

        public string cssIcon { get; set; }
        public int parentId { get; set; }
        public int orderId { get; set; }
        public bool isReport { get; set; }
        public string tooltip { get; set; }
        public string favDesc { get; set; }
    }

    public class MenuMapping : IMapper<MenuVM, Menu>
    {
        public MenuVM MapFrom(Menu _input)
        {
            return BindCoreToViewModel(_input);
        }

        public IEnumerable<MenuVM> MapFrom(IEnumerable<Menu> _input)
        {
            return _input.Select(x => BindCoreToViewModel(x));
        }

        public Menu MapTo(MenuVM _input)
        {
            return BindViewModelToCore(_input);
        }

        public IEnumerable<Menu> MapTo(IEnumerable<MenuVM> _input)
        {
            return _input.Select(x => BindViewModelToCore(x));
        }

        private static MenuVM BindCoreToViewModel(Menu _input)
        {
            return new MenuVM()
            {
                menuId = _input.MenuId,
                description = _input.Description,
                url = _input.OperationalUrl,
                cssIcon = _input.CssIcon,
                parentId = _input.ParentId,
                orderId = _input.OrderId,
                isReport = _input.IsReport,
                tooltip = _input.Tooltip,
                favDesc = _input.FavouritesDescription,
                businessUrl = _input.BusinessUrl,
                operationalUrl = _input.OperationalUrl,

            };
        }

        private static Menu BindViewModelToCore(MenuVM _input)
        {
            return new Menu()
            {
                MenuId = _input.menuId,
                Description = _input.description,
                OperationalUrl = Convert.ToString(_input.url),
                CssIcon = Convert.ToString(_input.cssIcon),
                ParentId = _input.parentId,
                OrderId = _input.orderId,
                IsReport = _input.isReport,
                Tooltip = _input.tooltip,
                FavouritesDescription = _input.favDesc,
            };
        }
    }

}