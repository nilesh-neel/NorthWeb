﻿using System.Collections.Generic;
using System.Linq;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;

namespace Heathrow.BIPM.Kestrel.Web.ViewModel
{
    public class FilterVM
    {
        public long FilterID { get; set; }
        public string UserID { get; set; }
        public int MenuID { get; set; }
        public string FilterText { get; set; }
        //public string ReportName { get; set; }
        public int ReportID { get; set; }

        public IList<FilterSelection> FilterItemSelection { get; set; }
        public IList<DropDownFilter> NotLoadedCategoryList { get; set; }
        public IList<DropDownFilter> NotLoadedSubCategoryList { get; set; }
        public IList<DropDownFilter> BaggageSystemList { get; set; }
        public IList<DropDownFilter> OutboundAircraftList { get; set; }
        public IList<DropDownFilter> DestinationList { get; set; }
        public IList<DropDownFilter> OutboundAirlineList { get; set; }
        public IList<DropDownFilter> OutboundTerminalList { get; set; }
        public IList<DropDownFilter> LastSeenLocationList { get; set; }
        public IList<DropDownFilter> OutboundHandlerList { get; set; }
        public IList<FilterConfiguration> FilterConfigList { get; set; }
        public IList<FilterSelection> PBIMappingList { get; set; }
    }
    /// <summary>
    ///  Filter mapping 
    /// </summary>

    public class FilterMapping : IMapper<FilterVM, FilterCollection>
    {
        private static FilterVM _filterVm = null;
        public FilterMapping()
        {
            _filterVm = new FilterVM();
        }

        public FilterVM MapFrom(FilterCollection filterData)
        {
            return TransformEntityToViewModel(filterData);
        }
        public FilterCollection MapTo(FilterVM viewModelData)
        {
            return TransformViewModelToEntity(viewModelData);
        }

        public IEnumerable<FilterCollection> MapTo(IEnumerable<FilterVM> viewModelData)
        {
            return viewModelData.Select(m => TransformViewModelToEntity(m));
        }

        public IEnumerable<FilterVM> MapFrom(IEnumerable<FilterCollection> collParam)
        {
            return collParam.Select(y => TransformEntityToViewModel(y));
        }

        private static FilterVM TransformEntityToViewModel(FilterCollection filterColl)
        {

            if (filterColl == null)
            {
                return null;
            }

            var filterData = (filterColl.FilterText != null) ? Newtonsoft.Json.JsonConvert.DeserializeObject<IList<FilterSelection>>(filterColl.FilterText) : null;

           
            return new FilterVM()
            {
                BaggageSystemList = filterColl.BaggageSystemList,
                NotLoadedCategoryList = filterColl.NotLoadedCategoryList,
                NotLoadedSubCategoryList = filterColl.NotLoadedSubCategoryList,
                DestinationList = filterColl.DestinationList,
                LastSeenLocationList = filterColl.LastSeenLocationList,
                OutboundAircraftList = filterColl.OutboundAircraftList,
                OutboundAirlineList = filterColl.OutboundAirlineList,
                OutboundHandlerList = filterColl.OutboundHandlerList,
                OutboundTerminalList = filterColl.OutboundTerminalList,
                FilterID = filterColl.FilterID,
                MenuID = filterColl.MenuID,
                UserID = filterColl.UserID,
                FilterItemSelection = filterData,
                FilterConfigList = filterColl.FilterConfigurationList,
                PBIMappingList = filterColl.PBIMappingList,

            };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        private static FilterCollection TransformViewModelToEntity(FilterVM viewModel)
        {
            if (viewModel == null) return null;

            var filterSelection = (viewModel.FilterItemSelection != null) ? Newtonsoft.Json.JsonConvert.SerializeObject(viewModel.FilterItemSelection) : string.Empty;

            return new FilterCollection()
            {
                MenuID = viewModel.MenuID,
                UserID = viewModel.UserID,
                FilterText = filterSelection,
                FilterID = viewModel.FilterID
            };
        }
    }


}