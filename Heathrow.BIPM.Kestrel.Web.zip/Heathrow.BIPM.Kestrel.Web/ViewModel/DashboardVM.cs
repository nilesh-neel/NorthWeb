﻿namespace Heathrow.BIPM.Kestrel.Web.ViewModel
{
    public class DashboardVM
    {
        public DashboardsVM[] value { get; set; }
        public string accessToken { get; set; }
    }

    public class DashboardsVM
    {
        public string id { get; set; }
        public string displayName { get; set; }
        public string embedUrl { get; set; }
        public bool isReadOnly { get; set; }
       

    }
}