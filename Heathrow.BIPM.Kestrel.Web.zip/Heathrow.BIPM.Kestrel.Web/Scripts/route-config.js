﻿$(function () {
    var mainContent = $("#dvRouteContainer");

    var routingApp = $.sammy("#dvRouteContainer", function () {
        this.get("#/Dashboard/Index", function (context) {
            $.get("/Dashboard/Index", function (data) {
                context.$element().html(data);
            });
        });
        this.get("#/Dashboard/Landing", function (context) {
            //$("#BigLoader").modal('show'); // If you want to show loader
            $.get("/Dashboard/Landing", function (data) {
                //$("#BigLoader").modal('hide');
                context.$element().html(data);
            });
        });
        this.get("#/Alerts/Index", function (context) {
            $.get("/Alerts/Index", function (data) {
                context.$element().html(data);
            });
        });

        this.get("#/BagList/Index", function (context) {
            $.get("/BagList/Index", function (data) {
                context.$element().html(data);
            });
        });
        this.get("#/Notifications/Index", function (context) {
            $.get("/Notifications/Index", function (data) {
                context.$element().html(data);
            });
        });
        this.get("#/AssignHomePage/Index", function (context) {
            $.get("/AssignHomePage/Index", function (data) {
                context.$element().html(data);
            });
        });
    });

    routingApp.run("#/Dashboard/Landing"); // default routing page.

    function IfLinkNotExist(type, path) {
        if (!(type !== null && path != null))
            return false;

        var isExist = true;

        if (type.toLowerCase() === "get") {
            if (routingApp.routes.get != undefined) {
                $.map(routingApp.routes.get, function (item) {
                    if (item.path.toString().replace("/#", "#").replace(/\\/g, '').replace("$/", "").indexOf(path) >= 0) {
                        isExist = false;
                    }
                });
            }
        } else if (type.toLowerCase() === "post") {
            if (routingApp.routes.post != undefined) {
                $.map(routingApp.routes.post, function (item) {
                    if (item.path.toString().replace("/#", "#").replace(/\\/g, '').replace("$/", "").indexOf(path) >= 0) {
                        isExist = false;
                    }
                });
            }
        }
        return isExist;
    }

});
