﻿//----------------------------------------------------------------------
//Class Name   : Alert Controller
//Purpose      : This is file use to handel all jquery click event related with Alert CRUD method.
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

(function ($) {
    'use strict';
    $(document).ready(function () {
        var alert = new Alert();
        var configTab = new TabConfig(true, false, false, false);
        $(".notification").click(function (event) {
            event.stopPropagation();
            $(this).children(".spanNotification").css("display", "none");
            $('.spanNotification').css("display", "none");
            var alertIconObj = new AlertIcon();
            alertIconObj.bindAlerts();
            $(".alertPopup").toggle();
        });
        $('.settingsIcon').on('click', function SettingsController() {

            //window.location.href = '/Alerts/Index/';
            alert.LoadAlertsLandingPage();
        });
        $('#congigureNewAlertBtn').on('click', function () {
            configTab.NewConfigurationButtonClick();
            alert.bindMultiSelectDroupDown();
        });
        $('#configureBackBtn').click(function (event) {         
            configTab.BackButtonClick();
        });

        $('#tabs a[href="#todaysAlerts"]').click(function (event) {
            alert.bindTodayAlerts();
        });
        $('#tabs a[href="#alertSettings"]').click(function (event) {
            $('#congigureNewAlertBtn').text('Configure New Alert');

            alert.bindMyAlertsSettings();
        });
        $('#tabs a[href="#configureAlerts"]').click(function (event) {

            $('#congigureNewAlertBtn').text('Configure New Alert');
            $('#congigureNewAlertBtn').css('display', 'block');
            $('.dataTables_paginate').css('display', 'block');
            alert.bindConfigureAlerts();         
        });

        $('#configureAlertsTable tbody td').click(function () {
            console.log('click...');
            alert($(this));

        });
        $('#viewAllBtn').on('click', function SettingsController() {
            //window.location.href = '/Alerts/Index/';
            $('#embedContainer').html('');
            $('.alertPopup').toggle();
            alert.LoadAlertsLandingPage();
        });
        $('.mSetting').on('click', function SettingsController() {
            window.location.href = '/Alerts/Index/';
        });
        $('#aAlerts').on('click', function SettingsController() {
            window.location.href = '/Alerts/Index/';
        });
        $('#configureAlertsTable .Edit').click(function () {
            $("#configureAlertsTable_wrapper,#tabs a[href='#alertSettings'],#tabs a[href='#todaysAlerts']").css('display', 'none');

            $('#configureBackBtn').css('display', 'block');
            $('.configureAlertForm').css('display', 'block');
        });      
     /*   $('#configureBackBtn').click(function(event) {
            $('#configureAlertsTable_wrapper').show();
            $('#configureBackBtn').css('display', 'none');
            $('.configureAlertForm').css('display', 'none');
            $('#congigureNewAlertBtn').css('display', 'block');
            $("#tabs a[href='#alertSettings'],#tabs a[href='#todayAlerts']").css('display', 'block');

        });*/
      
        
    });

})(jQuery);