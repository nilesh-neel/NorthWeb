﻿
var AlertIcon = (function () {

    var alertHtml = '';
    /****
    * Creates a new Menu object.
    * @constructor
    *
    */
    AlertIcon = function () { alertHtml = '';}

    /**
    /* fetch the menu data from database and bind to menu div..
    */
    AlertIcon.prototype.bindAlerts = function () {
        service = new Service('/Alerts/GetTodaysAlerts', 'application/html; charset=utf-8', 'html', null);
        service.get()
            .then(function (resp) {
                var todayAlertData = _.map(resp, function (x) {
                    return {
                        AlertId: x.alertId,                     
                        Description: x.description,
                        Time:x.time,                       
                        Response: '<p class="IconsStyles"><span class="' + (x.isAcknowledge ? 'Tick_mark_Fill' : 'Tick_mark_Fill_white') + '"></span> <span class="' + (x.isIgnore ? 'ignore_red_fill' : 'ignore_white_fill') + '"></span> <span class="' + (x.isBlank ? 'blank_out_yellow_fill' : 'blank_out_white_fill') + '"></span> </p>',                    
                    };
                });                
                for (i = 0; i < 5; i++)
                {
                    alertHtml += '<li><p>' + todayAlertData[i]['Description'] + '<p hidden>' + todayAlertData[i]['AlertId'] + '</p></p>';
                    alertHtml += todayAlertData[i]['Response'];
                    alertHtml+='<p> <span id="statusTime">'+todayAlertData[i]['Time']+'</span> </p></li>';
                }
                $('.alertList').html(alertHtml);
                AlertIcon.prototype.Response.call();
            })
            .catch(function (jqXHR, textStatus, err) {
                alert('Error : ' + err + ' ' + textStatus);
            });
       // jQuery.timeago(new Date(x.time))
    }
   
   
    AlertIcon.prototype.Response = function () {
        var alert = new Alert();
        var aData = [];
        $('.IconsStyles').on('click', function (e) {                        
                   if (e.target.parentElement.parentElement.tagName == 'TD') {                                    
                            var oTable = $(this).parents('table').dataTable();
                            var nTr = $(this).parents('tr')[0];
                            var gridData = oTable.fnGetData(nTr);
                            aData['AlertId'] = gridData['AlertId'];
                            aData['title'] = 'gridResponse';        
                    }
                    else {
                        aData['AlertId'] = e.target.parentElement.parentElement.childNodes[1].innerText;
                        aData['title'] = 'IconResponse';
                    }        
                switch (e.target.className) {
                case "Tick_mark_Fill": e.target.className = "Tick_mark_Fill_white";
                    aData['IsAcknowledge'] = false;
                   break;
                case "Tick_mark_Fill_white": e.target.className = "Tick_mark_Fill";
                    aData['IsAcknowledge'] = true;
                    break;
                case "ignore_red_fill": e.target.className = "ignore_white_fill";
                    aData['IsIgnore'] = false;
                    break;
                case "ignore_white_fill": e.target.className = "ignore_red_fill";
                    aData['IsIgnore'] = true;
                    break;
                case "blank_out_yellow_fill": e.target.className = "blank_out_white_fill";
                    aData['IsBlank'] = false;
                    break;
                case "blank_out_white_fill": e.target.className = "blank_out_yellow_fill";
                    aData['IsBlank'] = true;
                    break;
            }
                alert.bindResponse(aData);
        });
      
    }
    return AlertIcon;

})();