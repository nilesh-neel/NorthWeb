﻿//----------------------------------------------------------------------
//Class Name   : Alert Controller
//Purpose      : This is file use to handel all jquery click event related with BagList CRUD method.
//Created By   : Vignesh
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

(function () {
    'use strict';

    $(document).ready(function () {

        var bagList = new BagList();
        var selectedUserID = 1;// Get the Logged-in userID from Session
        bagList.LoadBagtagCnt(selectedUserID);


        $("#btnAddBagtags").off('click').on('click', function () {
            if (_.toNumber(sessionStorage.getItem('SelectedbagtagsCnt')) > 0) {
                bagList.AddBagTags();
            }
            else {
                Utility.alertMessage("Please select atleast one bagtag to add to My Bag List.", "warningMsg");
                return false;
            }

        });

        $("#btnRemoveBagtags").off('click').on('click', function () {
            var selectedBagtagsCnt = _.toNumber(sessionStorage.getItem('SelectedbagtagsCntRpt1')) + _.toNumber(sessionStorage.getItem('SelectedbagtagsCntRpt2'));
            sessionStorage.setItem('SelectedbagtagsCnt', selectedBagtagsCnt);
            if (selectedBagtagsCnt > 0) {
                // Append both Report selected bagtags by user
                var selectedbagtagsRpt1 = sessionStorage.getItem('SelectedbagtagsListRpt1') != null ? sessionStorage.getItem('SelectedbagtagsListRpt1') : "";
                var selectedbagtagsRpt2 = sessionStorage.getItem('SelectedbagtagsListRpt2') != null ? sessionStorage.getItem('SelectedbagtagsListRpt2') : "";
                var selectedbagtags = selectedbagtagsRpt1 + "," + selectedbagtagsRpt2;
                selectedbagtags = selectedbagtags.trim(',');
                var uniquebagtags = selectedbagtags.split(',').filter(function (item, i, allItems) {
                    return i == allItems.indexOf(item);
                }).join(',');
                sessionStorage.removeItem("SelectedbagtagsList");
                sessionStorage.setItem('SelectedbagtagsList', uniquebagtags);
                bagList.RemoveBagTags();
                sessionStorage.removeItem("SelectedbagtagsList");
                ssessionStorage.removeItem("SelectedbagtagsCnt");
            }
            else {
                   Utility.alertMessage("Please select atleast one bagtag to remove from My Bag List.", "warningMsg");
                   return false;
            }


            // old logic with 2 methods to embed the report
            //if (_.toNumber(sessionStorage.getItem('SelectedbagtagsCnt')) > 0) {
            //    bagList.RemoveBagTags();
            //    sessionStorage.removeItem("SelectedbagtagsList");
            //    sessionStorage.removeItem("SelectedbagtagsCnt");
            //}
            //else {
            //    Utility.alertMessage("Please select atleast one bagtag to remove from My Bag List.", "warningMsg");
            //    return false;
            //}
        });


        $('#lnkbtnMyBagList').off('click').on('click', function () {
            //$("#btnAddBagtags").hide();
            //$("#dvDateselection").hide();
            //$("#btnRemoveBagtags").show();
            //$("#dvOtherUserMyBagList").show();



          //  bagList.OthersMyBagListUsers();
            var selectedUserID = 1; // Get the Logged-in userID from Session 
            //bagList.GetUserExistingBagtags(selectedUserID); //old CR -- To load the MyBaglist screen report in single div


            //$("#divUserBagLst").show();
            //$("#divUserBagLst").css('display', 'block');
            //$('#viewContainer').hide();
            //$('#dvPowerBiEmbed').hide();
            //$('#dvPowerBiEmbed').css('display', 'none');
            
          //  bagList.LoadMyBaglistOprtnlHistrcDivs(selectedUserID); // New CR -- To load both Operational and Historic report in separete Divs
            

        });


        $('#btnViewOthersBaglist').off('click').on('click', function () {
            var selectedUserID =$('#ddlOtherUserBaglist').val();
            bagList.GetUserExistingBagtags(selectedUserID);//old CR -- To view the MyBaglist screen report of other selected user  in single div
            //bagList.LoadMyBaglistOprtnlHistrcDivs(selectedUserID);// New CR -- To view both Operational and Historic report in separete Divs of other selected user
            
        });


    });

})();