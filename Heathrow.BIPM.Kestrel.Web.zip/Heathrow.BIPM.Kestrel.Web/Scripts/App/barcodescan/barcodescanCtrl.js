﻿(function () {
    'use strict';


    var lastResult = [];
    $('.scan,.scanMobile').on('click', function () {
        $('#livestream_scanner').modal('show');
        lastResult = new Array();
        var barcode = new BarcodeScan();
        barcode.init();
    });

    Quagga.onProcessed(function (result) {
        var drawingCtx = Quagga.canvas.ctx.overlay,
            drawingCanvas = Quagga.canvas.dom.overlay;

        if (result) {
            if (result.boxes) {
                drawingCtx.clearRect(0, 0, parseInt(drawingCanvas.getAttribute("width")), parseInt(drawingCanvas.getAttribute("height")));
                result.boxes.filter(function (box) {
                    return box !== result.box;
                }).forEach(function (box) {
                    Quagga.ImageDebug.drawPath(box, { x: 0, y: 1 }, drawingCtx, { color: "green", lineWidth: 2 });
                });
            }

            if (result.box) {
                Quagga.ImageDebug.drawPath(result.box, { x: 0, y: 1 }, drawingCtx, { color: "#00F", lineWidth: 2 });
            }

            if (result.codeResult && result.codeResult.code) {
                Quagga.ImageDebug.drawPath(result.line, { x: 'x', y: 'y' }, drawingCtx, { color: 'red', lineWidth: 3 });
            }
        }
    });



    if (Quagga.initialized == undefined) {
        Quagga.onDetected(function (result) {
            var lastCode = result.codeResult.code;
            lastResult.push(lastCode);
            if (lastResult.length >= 20) {
                var code = orderByOccurrence(lastResult)[0];
                lastResult = [];

                if (!_.isNil(code) && code.length >= 10) {
                    //var $node = null,
                    //    canvas = Quagga.canvas.dom.image;

                    //$node = $('<li><div class="thumbnail"><div class="imgWrapper"><img /></div><div class="caption"><h4 class="code"></h4></div></div></li>');
                    //$node.find("img").attr("src", canvas.toDataURL());
                    //$node.find("h4.code").html(code);
                    //$("#result_strip ul.thumbnails").prepend($node);
                    $('#txtSearch').val(code);
                    $('#livestream_scanner').modal('hide');
                }
            }
        });
    }

    function orderByOccurrence(arr) {
        var counts = {};
        arr.forEach(function (value) {
            if (!counts[value]) {
                counts[value] = 0;
            }
            counts[value]++;
        });

        // return Object.keys(counts).sort(function(curKey, nextKey) {
        //     return counts[curKey] < counts[nextKey];
        // });
        return Object.keys(counts).filter((a) => counts[a] >= 3);
    }

})();