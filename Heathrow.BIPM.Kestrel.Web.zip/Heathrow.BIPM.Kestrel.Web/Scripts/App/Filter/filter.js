﻿(function ($) {
    'use strict';
    var userFilterselection = [];
    var userID = 'Admin';
    var filterID = 0;
    var filterResult = [];
    var filterVM = {};
    var filterConfig = [];

    $(document).ready(function () {
        Utility.multiDropDownConfiguration();
        singleDrpDownEventHandler();
        multipleDropDownHandler();
    });

    var singleDrpDownEventHandler = function () {

        $('.combobox').combobox(
            {
                select: function () {
                    ApplyPinState();
                }
            });
    }

    var multipleDropDownHandler = function () {

        $("select[multiple]").change(function () {
            ApplyPinState();
        });

    };

    $('#txtBagTag').on('change', function () {
        EnablePinState(this.value, sessionStorage.getItem('bagtag'));
    });

    $('#txtPaxName').on('change', function () {
        EnablePinState(this.value, sessionStorage.getItem('PaxName'));
    });

    $('#txtInbndFlight').on('change', function () {
        EnablePinState(this.value, sessionStorage.getItem('InbndFlight'));
    });

    $('#txtOutbndFlight').on('change', function () {
        EnablePinState(this.value, sessionStorage.getItem('OutbndFlight'));
    });

    $('#txtTimeBand').on('change', function () {
        EnablePinState(this.value, sessionStorage.getItem('timeBand'));
    });
    $('#txtRouteStartTime').on('change', function () {
        EnablePinState(this.value, sessionStorage.getItem('routeStartTime'));
    });


    $("#txtInbndFlight").on("keyup", function (e) {
        if (e.keyCode == 188) { // KeyCode For comma is 188
            var paramValue = $("#txtInbndFlight").val().split(",").filter(function (index) { return index; });
            if (!_.isEmpty(paramValue) && paramValue.length > 10) {

                alert('Search maximum 5 inbound flight are allowed'); return;
            }
        }
    });
    var EnablePinState = function (currentValue, previousValue) {

        if (currentValue !== previousValue && filterID > 0) {
            ApplyPinState();
        }
    }

    var configData = [];
    $('.filter').click(function () {
        $("#filterPanel").toggle();
        $(".filter").toggleClass("clickedIcons");
        $(".filter").toggleClass("customBorderSmall");

        if ($("#filterPanel").is(":visible")) {
            $('.filterCtrl').addClass('hidden');
            if (menuItemID !== 0) {
                configData = JSON.parse(sessionStorage.getItem('FilterData'));
                if (!_.isNil(configData)) {
                    filterResult = configData;
                    LoadFilterConfiguration(configData);
                }
            }
        }

    });

    var ApplyPinState = function () {
        if ($('.pinclicked').is(":visible")) {
            $('#pinIcon').toggleClass("Pin");
            $('#pinIcon').toggleClass("pinclicked");
        }
    }



    $('#btnApply').click(function () {

        if (!_.isEmpty(filterConfig.PBIMappingList)) {
            userFilterselection = [];
            for (var i = 0; i < filterConfig.PBIMappingList.length; i++) {
                assignValuesToFilterVM(filterConfig.PBIMappingList[i]);
            }
                       
            var powerBiUrl = sessionStorage.getItem('autoRefURL');
            var isReport = sessionStorage.getItem('autoRefURLIsReport');

            var dashboardPowerBiApi = new PowerBIAPP(powerBiUrl, isReport);
            dashboardPowerBiApi.applyFilterToReport(userFilterselection);
            filterVM.FilterItemSelection = userFilterselection;
            sessionStorage.removeItem("FilterUrl");
            sessionStorage.setItem('FilterUrl', JSON.stringify(filterVM.FilterItemSelection));
        }
    });

    $('#pinIcon').click(function () {
        //$('#pinIcon').toggleClass("Pin");
        //$('#pinIcon').toggleClass("pinclicked");
        if ($(".Pin").is(":visible")) {
            saveFilterConfiguration();
        }
    });

    /* Pin Icon functionality in filters panel start */

    $('#pinIconLink').hover(function (event) {

        $(this).removeClass('hovered-content');
        if ($('#pinIcon').hasClass("pinclicked")) {
            $('#pinIconLink').tooltip('hide');
            $(this).addClass('hovered-content');
        }
    });

    /* Range slider */

    var setTimeSlicer = function (controlField, fromValue, toValue) {

        $(controlField).ionRangeSlider({
            type: "double",
            min: 0,
            max: 24,
            from: 6,
            step: 2,
            from_shadow: true,
            to: 24,
            to_shadow: true,
            grid: true,
            grid_snap: true

        });
        if (fromValue > 0 && toValue > fromValue) {
            var slider = $(controlField).data("ionRangeSlider");
            slider.reset();

            slider.update({
                from: fromValue,
                to: toValue
            });
        }
    }

    /* daterangePicker for single calender*/

    $("#txtSingleDate,#txtMultiDate").daterangepicker({

        singleDatePicker: true,
        showDropdowns: true

    });

    /* Pin Icon functionality in filters panel end */

    var loadRouteDropDown = function () {

        $('#selectRoute').multiselect('loadOptions', [{
            name: 'T2->T5',
            value: 't5',
            checked: false
        },
        {
            name: 'T3 Direct',
            value: 't3',
            checked: false
        },
        {
            name: 'T3->T2',
            value: 't2',
            checked: false
        }
        ]);
    };


    var LoadFilterConfiguration = function (filterSelection)
    {
        filterConfig = [];
        filterConfig = filterSelection;
        if (!_.isNil(filterConfig.FilterConfigList)) {
            for (var i = 0; i < filterConfig.FilterConfigList.length; i++) {
                filterControlsShowHide(filterConfig.FilterConfigList[i].FilterControlID);
            }
        }
        if (!_.isEmpty(filterSelection)) {
            var actionResult = filterConfig;

            filterID = actionResult.FilterID;

            if (!_.isNil(actionResult.FilterItemSelection)) {
                assignValuesToControls(actionResult.FilterItemSelection)
                if ($('.Pin').is(":visible")) {
                    $('#pinIcon').toggleClass("Pin");
                    $('#pinIcon').toggleClass("pinclicked");
                }
            }
            else {
                // if (filterID > 0)
                ApplyPinState();
            }
        }
    }

    //var loadReportFilter = function (menuID) {

    //    // var service = null;
    //    filterConfig = [];
    //    $.when(new Service('/Filter/GetFilterConfigurationDetails?menuId=' + menuID, null, 'json', null).get(),
    //        new Service('/Filter/GetFilterByMenuID?menuID=' + menuID + '&userID=0', null, 'json', null).get())
    //        .done(function (config, filterData) {
    //            if (!_.isEmpty(config)) {
    //                var configResult = JSON.parse(config[0].result);
    //                filterConfig = configResult;

    //              //  filterControlDisplayOrder(filterConfig.ReportID) // based on the report control should be order

    //                if (!_.isNil(configResult.FilterConfigList)) {
    //                    for (var i = 0; i < configResult.FilterConfigList.length; i++) {
    //                        filterControlsShowHide(configResult.FilterConfigList[i].FilterControlID);
    //                    }
    //                }

    //                if (!_.isEmpty(filterData)) {
    //                    var actionResult = JSON.parse(filterData[0].result);

    //                    filterID = actionResult.FilterID;

    //                    if (!_.isNil(actionResult.FilterItemSelection)) {
    //                        assignValuesToControls(actionResult.FilterItemSelection)
    //                        if ($('.Pin').is(":visible")) {
    //                            $('#pinIcon').toggleClass("Pin");
    //                            $('#pinIcon').toggleClass("pinclicked");
    //                        }
    //                    }
    //                    else {
    //                       // if (filterID > 0)
    //                            ApplyPinState();
    //                    }
    //                }
    //            }
    //        });

    //};

    var saveFilterConfiguration = function () {
        userFilterselection = [];
        if (!_.isNil(filterConfig.PBIMappingList)) {
            for (var i = 0; i < filterConfig.PBIMappingList.length; i++) {
                assignValuesToFilterVM(filterConfig.PBIMappingList[i]);
            }

            if (!_.isEmpty(userFilterselection)) {
                filterVM.UserID = userID;
                filterVM.FilterID = filterID;
                filterVM.MenuID = menuItemID;
                filterVM.FilterItemSelection = userFilterselection;

                var service = new Service('/Filter/SaveFilters', 'application/json; charset=utf-8', 'json', filterVM);
                service.save().done(function () {
                    $('#pinIcon').toggleClass("Pin");
                    $('#pinIcon').toggleClass("pinclicked");
                    Utility.alertMessage("Filter configuration saved successfully.", "successMsg");
                }).fail(function (jqXHR, textStatus, errorThrown) {
                    Utility.alertMessage("Error occured while saving Filter configuration.", "errorMsg");
                });
            }
        }

    };

    var filterControlDisplayOrder = function (reportType) {
       // var orignalDiv = $("#dvMain").clone();
        switch (reportType) {
            case 9:
                BTRControlDisplay(true);
                break;
            case 10:
                BTRControlDisplay(false);
                break;
            case 11:
                ADPControlDisplay(true);
                break
            case 14:
                ADPControlDisplay(false, true);
                break;
            case 15:
                ADPControlDisplay(false, false);
                break;
            case 17:
                BJPControlDisplay(true);
                break;
            case 18:
                BJPControlDisplay(false);
                break;
            case 22:
                DDPControlDisplay(true);
                break;
            case 23:
                DDPControlDisplay(false);
                break;
            case 24:
                DDPControlDisplay(false);
                break;
            case 25:
                BSMSMRControlDisplay();
                break;
            case 27:
                ITTDLRControlDisplay();
                break;
            case 28:
                MDRControlDisplay(false);
                break;
            case 29:
                BSMSMRControlDisplay(true);
                break;
            default:
                break;
        }
    }
    var BTRControlDisplay = function (isInbndOrder) {
        $("#dvMain > #dvMultiDate").after($("#dvTimeBand"));
        $("#dvMain > #dvTimeBand").after($("#dvBagStatus"));
        $("#dvMain > #dvBagStatus").after($("#dvInbndhandler"));

        if (isInbndOrder) {
            $("#dvMain > #dvInbndhandler").after($("#dvInbndAirline"));
            $("#dvMain > #dvInbndAirline").after($("#dvInbndTerminal"));
            $("#dvMain > #dvInbndTerminal").after($("#dvInbndAircraft"));
        }
        else {

            $("#dvMain > #dvOutbndHandler").after($("#dvInbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvInbndTerminal"));
            $("#dvMain > #dvOutbndTerminal").after($("#dvInbndAircraft"));
        }
    };
    var ADPControlDisplay = function (isADPDBD, isADPSMR) {
        if (isADPDBD) {
            $("#dvMain > #dvSingleDate").after($("#dvInbndhandler"));
            $("#dvMain > #dvInbndhandler").after($("#dvInbndAirline"));
            $("#dvMain > #dvInbndAirline").after($("#dvInbndTerminal"));
            $("#dvMain > #dvInbndTerminal").after($("#dvInbndFlight"));
        }
        else {

            (isADPSMR) ? $("#dvMain > #dvSingleDate").after($("#dvInbndhandler")) : $("#dvMain > #dvMultiDate").after($("#dvInbndhandler"));
            $("#dvMain > #dvInbndhandler").after($("#dvInbndAirline"));
            $("#dvMain > #dvInbndAirline").after($("#dvInbndTerminal"));
            $("#dvMain > #dvInbndTerminal").after($("#dvInbndFlight"));
            $("#dvMain > #dvInbndFlight").after($("#dvInbndAircraft"));
        }
    };
    var BJPControlDisplay = function (isBJPSMR) {

        $("#dvMain > #dvMultiDate").after($("#dvInbndTerminal"));
        $("#dvMain > #dvInbndTerminal").after($("#dvOutbndTerminal"));
        if (isBJPSMR) {
            $("#dvMain > #dvOutbndTerminal").after($("#dvRoute"));
            $("#dvMain > #dvRoute").after($("#dvBaggageSystem"));
            $("#dvMain > #dvBaggageSystem").after($("#dvProcessArea"));
            $("#dvMain > #dvProcessArea").after($("#dvOOGBags"));
        }
        else {
            $("#dvMain > #dvOutbndTerminal").after($("#dvRouteStartTime"));
            $("#dvMain > #dvRouteStartTime").after($("#dvBaggageSystem"));
            //  $("#dvMain > #dvRouteEndTime").after($("#dvBaggageSystem"));
            $("#dvMain > #dvBaggageSystem").after($("#dvProcessArea"));
            $("#dvMain > #dvProcessArea").after($("#dvFailedSystem"));
            $("#dvMain > #dvFailedSystem").after($("#dvOOGBags"));
        }
    };
    var DDPControlDisplay = function (isDDPDBD) {

        if (isDDPDBD) {
            $("#dvMain > #dvSingleDate").after($("#dvTimeBand"));
            $("#dvMain > #dvTimeBand").after($("#dvOutbndHandler"));
            $("#dvMain > #dvOutbndHandler").after($("#dvOutbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvOutbndFlight"));
            $("#dvMain > #dvOutbndFlight").after($("#dvOutbndTerminal"));
        }
        else {
            $("#dvMain > #dvMultiDate").after($("#dvOutbndHandler"));
            $("#dvMain > #dvOutbndHandler").after($("#dvOutbndAirline"));
            $("#dvMain > #dvOutbndAirline").after($("#dvOutbndFlight"));
            $("#dvMain > #dvOutbndFlight").after($("#dvOutbndTerminal"));
            $("#dvMain > #dvOutbndTerminal").after($("#dvOutbndAircraft"));
        }
    };
    var BSMSMRControlDisplay = function () {
        $("#dvMain > #dvMultiDate").after($("#dvInbndFlight"));
        $("#dvMain > #dvInbndFlight").after($("#dvInbndAirline"));
        $("#dvMain > #dvInbndAirline").after($("#dvInbndhandler"));
        $("#dvMain > #dvInbndhandler").after($("#dvOutbndFlight"));
        $("#dvMain > #dvOutbndFlight").after($("#dvOutbndAirline"));
        $("#dvMain > #dvOutbndAirline").after($("#dvOutbndHandler"));
    };
    var ITTDLRControlDisplay = function () {
        $("#dvMain > #dvMultiDate").after($("#dvInbndTerminal"));
        $("#dvMain > #dvInbndTerminal").after($("#dvOutbndTerminal"));
        $("#dvMain > #dvOutbndTerminal").after($("#dvInbndhandler"));
        $("#dvMain > #dvInbndhandler").after($("#dvInbndAirline"));
        $("#dvMain > #dvInbndAirline").after($("#dvOutbndAirline"));
        $("#dvMain > #dvOutbndAirline").after($("#dvAtStart"));
        $("#dvMain > #dvAtStart").after($("#dvAtEnd"));
        $("#dvMain > #dvAtEnd").after($("#dvInbndITO"));
        $("#dvMain > #dvInbndITO").after($("#dvInTarget"));
        $("#dvMain > #dvInTarget").after($("#dvFailedMissed"));
    };
    var MDRControlDisplay = function (isMDRDLR) {
        $("#dvMain > #dvMultiDate").after($("#dvInbndTerminal"));
        $("#dvMain > #dvInbndTerminal").after($("#dvInbndAirline"));
        $("#dvMain > #dvInbndAirline").after($("#dvInbndhandler"));
        $("#dvMain > #dvInbndhandler").after($("#dvOutbndTerminal"));
        $("#dvMain > #dvOutbndTerminal").after($("#dvOutbndAirline"));
        $("#dvMain > #dvOutbndAirline").after($("#dvOutbndHandler"));
        (isMDRDLR) ? $("#dvMain > #dvOutbndAirline").after($("#dvMDStatus")) : $("#dvMain > #dvOutbndAirline").after($("#dvLastLocation"));
    };

    var multiDate = [];
    var assignValuesToControls = function (valueList) {
        if (valueList.length > 0) {
            for (var i = 0; i < valueList.length; i++) {
                FillValuesToControls(valueList[i]);
            }
        }
    };

    var FillValuesToControls = function (datasource) {

        var filterVal = [];
        switch (datasource.ControlMappingID) {
            case 1: // single Date
                controlVal = $("#txtSingleDate").val(moment(datasource.ColumnValue).format("YYYY-MM-DD"));
                break;
            case 2: // Multi Date
                multiDate.push(datasource.ColumnValue);
                if (multiDate.length > 1) {
                    filterVal = moment(multiDate[0]).format("YYYY-MM-DD") + ' -' + moment(multiDate[1]).format("YYYY-MM-DD");
                    $("#txtMultiDate").val(filterVal);
                }
                break;
            case 3: //  Relational Timeband
                filterVal = datasource.ColumnValue.split(":");
                setTimeSlicer('#txtTimeBand', parseInt(filterVal[0]), parseInt(filterVal[1]));
                sessionStorage.setItem('timeBand', datasource.ColumnValue);
                break;
            case 4: // Passenger Surname
                $("#txtPaxName").val(datasource.ColumnValue);
                sessionStorage.setItem('PaxName', $("#txtPaxName").val());
                break;
            case 5: // Bagtag 
                $("#txtBagTag").val(datasource.ColumnValue);
                sessionStorage.setItem('bagtag', datasource.ColumnValue);
                break;
            case 6: // Not Loaded Category 
                Utility.addValuesToMultiSelectDropDown('#selectNotLoaded', datasource.ColumnValue.toString());
                break;
            case 7: // Not Loaded Category 
                Utility.addValuesToMultiSelectDropDown('#selectNotLoadedSub', datasource.ColumnValue.toString());
                break;
            case 8: // Outbound Flight
                $("#txtOutbndFlight").val(datasource.ColumnValue);
                sessionStorage.setItem('OutbndFlight', datasource.ColumnValue);
                break;
            case 9: // Outbound Aircraft 
                Utility.addValuesToMultiSelectDropDown('#selectOutbndAircraft', datasource.ColumnValue);
                break;
            case 10: //Destination
                Utility.addValuesToMultiSelectDropDown('#selectDestination', datasource.ColumnValue.toString());
                break;
            case 11: // Outbound Airline
                Utility.addValuesToMultiSelectDropDown('#selectOutbndAirline', datasource.ColumnValue.toString());
                break;
            case 12: //Outbound Handler
                Utility.addValuesToMultiSelectDropDown('#selectOutbndHandler', datasource.ColumnValue.toString());
                break;
            case 13: //OutboundTerminal
                Utility.addValuesToMultiSelectDropDown('#selectOutbndTerminal', datasource.ColumnValue.toString());
                break;
            case 14: //Inbound Flight
                $("#txtInbndFlight").val(datasource.ColumnValue);
                sessionStorage.setItem('InbndFlight', datasource.ColumnValue);
                break;
            case 15: //Inbound Airline
                Utility.addValuesToMultiSelectDropDown('#selectInbndAirline', datasource.ColumnValue.toString());
                break;
            case 16: 
                Utility.addValuesToMultiSelectDropDown('#selectInbndAircraft', datasource.ColumnValue.toString());
                break;
            case 17:
                Utility.addValuesToMultiSelectDropDown('#selectOrigin', datasource.ColumnValue.toString());
                break;
            case 18:
                Utility.addValuesToMultiSelectDropDown('#selectInbndhandler', datasource.ColumnValue.toString());
                break;
            case 19:
                Utility.addValuesToMultiSelectDropDown('#selectInbndTerminal', datasource.ColumnValue.toString());
                break;
            case 20:
                Utility.addValuesToMultiSelectDropDown('#selectLastLocation', datasource.ColumnValue.toString());
                break;
            case 21:
                Utility.addValuesToMultiSelectDropDown('#selectBagStatus', datasource.ColumnValue.toString());
                break;
            case 22:
                Utility.SetValuesToDropDown('#selectBagType', datasource.ColumnValue);
                break;
            case 23:
                Utility.SetValuesToDropDown('#selectShortConnect', datasource.ColumnValue);
                break;
            case 24:
                Utility.SetValuesToDropDown('#selectOOGBags', datasource.ColumnValue);
                break;
            case 25:
                Utility.SetValuesToDropDown('#selectchox', datasource.ColumnValue);
                break;
            case 26:
                Utility.SetValuesToDropDown('#selectDeleteBags', datasource.ColumnValue);
                break;
            case 27:
                Utility.SetValuesToDropDown('#selectBRSonly', datasource.ColumnValue);
                break;
            case 28:
                Utility.SetValuesToDropDown('#selectDelBSM', datasource.ColumnValue);
                break;
            case 29:
                Utility.SetValuesToDropDown('#selectBagList', datasource.ColumnValue);
                break;
            case 30:
                Utility.addValuesToMultiSelectDropDown('#selectRoute', datasource.ColumnValue.toString());
                break;
            case 31:
                Utility.addValuesToMultiSelectDropDown('#selectProcessArea', datasource.ColumnValue.toString());
                break;
            case 32:
                Utility.addValuesToMultiSelectDropDown('#selectBaggageSystem', datasource.ColumnValue.toString());
                break;
            case 33:
                filterVal = datasource.ColumnValue.split(":");
                setTimeSlicer('#txtRouteStartTime', parseInt(filterVal[0]), parseInt(filterVal[1]));
                sessionStorage.setItem('routeStartTime', datasource.ColumnValue);
                break;
            case 34:
                Utility.SetValuesToDropDown('#selectInbndITO', datasource.ColumnValue);
                break;
            case 35:
                Utility.SetValuesToDropDown('#selectInTarget', datasource.ColumnValue);
                break;
            case 36:
                Utility.SetValuesToDropDown('#selectFailedMissed', datasource.ColumnValue);
                break;
            case 37:
                Utility.addValuesToMultiSelectDropDown('#selectAtStart', datasource.ColumnValue.toString());
                break;
            case 38:
                Utility.addValuesToMultiSelectDropDown('#selectAtEnd', datasource.ColumnValue.toString());
                break;
            case 39:
                Utility.addValuesToMultiSelectDropDown('#selectFailedSystem', datasource.ColumnValue.toString());
                break;
            case 40:
                Utility.addValuesToMultiSelectDropDown('#selectMDStatus', datasource.ColumnValue.toString());
                break;
            case 41:
                Utility.SetValuesToDropDown('#selectLateBSM', datasource.ColumnValue);
                //Late BSM
                break;
            default:
                break
        }

    };

    /**Load filter based on screen level **/

    //var loadFilterDropDown = function () {
    //    var successCallback = function (data) {
    //        if (!_.isEmpty(data)) {
    //            filterResult = JSON.parse(data);
    //        }
    //    };
    //    var errorCallback = function (data) {
    //        var errorMsg = data;
    //    }

    //    Utility.makeAjaxCallWithoutParameter('/Filter/GetFilterData', Utility.RequestType.Get, successCallback, errorCallback);
    //};

    //// #region ShowHideFilterControl

    var filterControlsShowHide = function (controlId) {
        switch (controlId) {
            case 1:
                $("#dvSingleDate").removeClass('hidden');
                break;
            case 2:
                $("#dvMultiDate").removeClass('hidden');
                break;
            case 3:
                $("#dvTimeBand").removeClass('hidden');
                $('#txtMinsBefore').val('30');  
                $('#txtMinsAfter').val('240');  
                break;
            case 4:
                $("#dvPaxName").removeClass('hidden');
                $('#txtPaxName').val('');
                break;
            case 5:
                $("#dvBagTag").removeClass('hidden');
                $('#txtBagTag').val('');
                break;
            case 6:
                $("#dvNotLoaded").removeClass('hidden');
                Utility.bindMultiDropDown('#selectNotLoaded', filterResult.NotLoadedCategoryList);
                break;
            case 7:
                $("#dvNotLoadedSub").removeClass('hidden');
                Utility.bindMultiDropDown('#selectNotLoadedSub', filterResult.NotLoadedSubCategoryList);
                break;
            case 8:
                $("#dvOutbndFlight").removeClass('hidden');
                $('#txtOutbndFlight').val('');
                break;
            case 9:
                $("#dvOutbndAircraft").removeClass('hidden');
                break;
            case 10:
                $("#dvDestination").removeClass('hidden');
                Utility.bindMultiDropDown('#selectDestination', filterResult.DestinationList);
                break;
            case 11:
                $("#dvOutbndAirline").removeClass('hidden');
                Utility.bindMultiDropDown('#selectOutbndAirline', filterResult.OutboundAirlineList);
                break;
            case 12:
                $("#dvOutbndHandler").removeClass('hidden');
                Utility.bindMultiDropDown('#selectOutbndHandler', filterResult.OutboundHandlerList);
                break;
            case 13:
                $("#dvOutbndTerminal").removeClass('hidden');
                Utility.bindMultiDropDown('#selectOutbndTerminal', filterResult.OutboundTerminalList);
                break;
            case 14:
                $("#dvInbndFlight").removeClass('hidden');
                $('#txtInbndFlight').val('');
                break;
            case 15:
                $("#dvInbndAirline").removeClass('hidden');
                Utility.bindMultiDropDown('#selectInbndAirline', filterResult.OutboundAirlineList);
                break;
            case 16:
                $("#dvInbndAircraft").removeClass('hidden');
                Utility.bindMultiDropDown('#selectInbndAircraft', filterResult.OutboundAircraftList);
                break;
            case 17:
                $("#dvOrigin").removeClass('hidden');
                Utility.bindMultiDropDown('#selectOrigin', filterResult.DestinationList);
                break;
            case 18:
                $("#dvInbndhandler").removeClass('hidden');
                Utility.bindMultiDropDown('#selectInbndhandler', filterResult.OutboundHandlerList);
                break;
            case 19:
                $("#dvInbndTerminal").removeClass('hidden');
                Utility.bindMultiDropDown('#selectInbndTerminal', filterResult.OutboundTerminalList);
                break;
            case 20:
                $("#dvLastLocation").removeClass('hidden');
                Utility.bindMultiDropDown('#selectLastLocation', filterResult.LastSeenLocationList);
                break;
            case 21:
                $("#dvBagStatus").removeClass('hidden');
                break;
            case 22:
                $("#dvBagType").removeClass('hidden');
                break;
            case 23:
                $("#dvShortConnect").removeClass('hidden');
                break;
            case 24:
                $("#dvOOGBags").removeClass('hidden');
                break;
            case 25:
                $("#dvchox").removeClass('hidden');
                break;
            case 26:
                $("#dvDeleteBags").removeClass('hidden');
                break;
            case 27:
                $("#dvBRSonly").removeClass('hidden');
                break;
            case 28:
                $("#dvDelBSM").removeClass('hidden');
                break;
            case 29:
                $("#ShowMyBagList").removeClass('hidden');
                break;
            case 30:
                $("#dvRoute").removeClass('hidden');
                loadRouteDropDown();
                break;
            case 31:
                $("#dvProcessArea").removeClass('hidden');
                Utility.bindMultiDropDown('#selectProcessArea', filterResult.LastSeenLocationList);
                break;
            case 32:
                $("#dvBaggageSystem").removeClass('hidden');
                break;
            case 33:
                $("#dvRouteStartTime").removeClass('hidden');
                setTimeSlicer('#txtRouteStartTime', 6, 24);
                break;
            case 34:
                $("#dvInbndITO").removeClass('hidden');
                Utility.addValuesToDropDown('#selectInbndITO', filterResult.LastSeenLocationList);
                break;
            case 35:
                $("#dvInTarget").removeClass('hidden');
                break;
            case 36:
                $("#dvFailedMissed").removeClass('hidden');
                break;
            case 37:
                $("#dvAtStart").removeClass('hidden');
                Utility.bindMultiDropDown('#selectAtStart', filterResult.LastSeenLocationList);
                break;
            case 38:
                $("#dvAtEnd").removeClass('hidden');
                Utility.bindMultiDropDown('#selectAtEnd', filterResult.LastSeenLocationList);
                break;
            case 39:
                $("#dvFailedSystem").removeClass('hidden');
                break;
            case 40:
                $("#dvMDStatus").removeClass('hidden');
                Utility.bindMultiDropDown('#selectMDStatus', filterResult.LastSeenLocationList);
                break;
            case 41:
                $("#dvLateBSM").removeClass('hidden'); 
                break;
            default:
                break
        }
    };

    //// #endregion


    var assignValuesToFilterVM = function (mappingList) {
        var controlVal = [];
        switch (mappingList.ControlMappingID) {
            case 1:
                controlVal = $("#txtSingleDate").val();
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 2:
                var date = $("#txtMultiDate").val();
                controlVal = date.split(" -");
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 3:
                //controlVal = $("#txtTimeBand").val();
                //controlVal = controlVal.replace(";", ":");
               // FilterValueConstruction(controlVal, mappingList);
                break;
            case 4:
                controlVal = $("#txtPaxName").val().split(",").filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 5:
                controlVal = $("#txtBagTag").val().split(",").filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 6:
                controlVal = $("#selectNotLoaded option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 7:
                controlVal = $("#selectNotLoadedSub option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 8:
                controlVal = $("#txtOutbndFlight").val();
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 9:
                controlVal = $("#selectOutbndAircraft option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 10:
                controlVal = $("#selectDestination option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 11:
                controlVal = $("#selectOutbndAirline option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 12:
                controlVal = $("#selectOutbndHandler option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 13:
                controlVal = $("#selectOutbndTerminal option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 14:
                controlVal = $("#txtInbndFlight").val();
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 15:
                controlVal = $("#selectInbndAirline option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 16:
                controlVal = $("#selectInbndAircraft option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 17:
                controlVal = $("#selectOrigin option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 18:
                controlVal = $("#selectInbndhandler option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 19:
                controlVal = $("#selectInbndTerminal option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 20:
                controlVal = $("#selectLastLocation option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 21:
                if(!($("#selectBagStatus option:selected").val() === $("#selectBagStatus option:first").val()))
                {
                    controlVal = $("#selectBagStatus option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                    FilterValueConstruction(controlVal, mappingList);
                }
                break;
            case 22:
                if (!($("#selectBagType option:selected").val() === $("#selectBagType option:first").val())) {
                   // controlVal = $('#selectBagType + span').children('input')[0].value;
                    controlVal = $("#selectBagType option:selected").val();
                    FilterValueConstruction(controlVal, mappingList);
                }
                break;
            case 23:
                if (!($("#selectShortConnect option:selected").val() === $("#selectShortConnect option:first").val())) {
                   // controlVal = $('#selectShortConnect + span').children('input')[0].value;
                    controlVal = $("#selectShortConnect option:selected").val();
                    FilterValueConstruction(controlVal, mappingList);
                }
                break;
            case 24:
                if (!($("#selectOOGBags option:selected").val() === $("#selectOOGBags option:first").val())) {
                    controlVal = $("#selectOOGBags option:selected").val(); 
                    FilterValueConstruction(controlVal, mappingList);
                }
                break;
            case 25:
                if (!($("#selectchox option:selected").val() === $("#selectchox option:first").val())) {
                    //controlVal = $('#selectchox + span').children('input')[0].value;
                    controlVal = $("#selectchox option:selected").val() ;
                    FilterValueConstruction(controlVal, mappingList);
                }
                break;
            case 26:
                if (!($("#selectDeleteBags option:selected").val() === $("#selectDeleteBags option:first").val())) {
                    //controlVal = $('#selectDeleteBags  + span').children('input')[0].value;
                    controlVal = $("#selectDeleteBags option:selected").val();
                    FilterValueConstruction(controlVal, mappingList);
                }
                break;
            case 27:
                if (!($("#selectBRSonly option:selected").val() === $("#selectBRSonly option:first").val())) {
                  //  controlVal =  $('#selectBRSonly  + span').children('input')[0].value;
                    controlVal = $("#selectBRSonly option:selected").val();
                    FilterValueConstruction(controlVal, mappingList);
                }
                break;
            case 28:
                if (!($("#selectDelBSM option:selected").val() === $("#selectDelBSM option:first").val())) {
                    //controlVal = $('#selectDelBSM  + span').children('input')[0].value;
                    controlVal = $("#selectDelBSM option:selected").val() ;
                    FilterValueConstruction(controlVal, mappingList);
                }
                break;
            case 29:
                if (!($("#selectBagList option:selected").val() === $("#selectBagList option:first").val())) {
                   // controlVal = $('#selectBagList  + span').children('input')[0].value;
                    controlVal = $("#selectBagList option:selected").val();
                    FilterValueConstruction(controlVal, mappingList);
                }
                break;
            case 30:
                controlVal = $("#selectRoute option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 31:
                controlVal = $("#selectProcessArea option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 32:
                controlVal = $("#selectBaggageSystem option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 33:
                controlVal = $("#txtRouteStartTime").val();
                controlVal = controlVal.replace(";", ":");
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 34:
                controlVal = $('#selectInbndITO  + span').children('input')[0].value;
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 35:
                if (!($("#selectInTarget option:selected").val() === $("#selectInTarget option:first").val())) {
                   // controlVal = $('#selectInTarget + span').children('input')[0].value;
                    controlVal = $("#selectInTarget option:selected").val();
                    FilterValueConstruction(controlVal, mappingList);
                }
                break;
            case 36:
                if (!($("#selectFailedMissed option:selected").val() === $("#selectFailedMissed option:first").val())) {
                   // controlVal = $('#selectFailedMissed  + span').children('input')[0].value;
                    controlVal = $("#selectFailedMissed option:selected").val();
                    FilterValueConstruction(controlVal, mappingList);
                }
                break;
            case 37:
                controlVal = $("#selectAtStart option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 38:
                controlVal = $("#selectAtEnd option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 39:
                if (!($("#selectFailedSystem option:selected").val() === $("#selectFailedSystem option:first").val())) {
                   // controlVal = $('#selectFailedSystem  + span').children('input')[0].value;
                    controlVal = $("#selectFailedSystem option:selected").val();
                    FilterValueConstruction(controlVal, mappingList);
                }
                break;
            case 40:
                controlVal = $("#selectMDStatus option:selected").toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                FilterValueConstruction(controlVal, mappingList);
                break;
            case 41:
                if(!($("#selectLateBSM option:selected").val() === $("#selectLateBSM option:first").val()))
                {
                    controlVal = $('#selectLateBSM option:selected').toArray().map(optionSelected).join(',').split(',').filter(function (index) { return index; });
                    FilterValueConstruction(controlVal, mappingList);
                }
                break;
            default:
                break
        }
    };

    function optionSelected(item) {
        return [item.value];
    }
    var FilterValueConstruction = function (controlValue, PBImappingData) {

        if (!_.isEmpty(controlValue)) {

            var inputVal = [];

            if (PBImappingData.ControlMappingID === 2) {

                for (var i = 0; i < controlValue.length; i++) {
                    inputVal = {
                        TableName: PBImappingData.TableName, ColumnName: PBImappingData.ColumnName, ColumnValue: [moment(controlValue[i]).format("YYYY/MM/DD")],
                        Operator: PBImappingData.Operator, ControlMappingID: PBImappingData.ControlMappingID
                    };
                    userFilterselection.push(inputVal);
                }

            }
            else {
                if (PBImappingData.ControlMappingID === 4 || PBImappingData.ControlMappingID === 8 || PBImappingData.ControlMappingID === 14 ||
                    PBImappingData.ControlMappingID === 3 || PBImappingData.ControlMappingID === 22 || PBImappingData.ControlMappingID === 23 || PBImappingData.ControlMappingID === 24 ||
                    PBImappingData.ControlMappingID === 25 || PBImappingData.ControlMappingID === 26 || PBImappingData.ControlMappingID === 27 || PBImappingData.ControlMappingID === 28 ||
                    PBImappingData.ControlMappingID === 29 || PBImappingData.ControlMappingID === 33 || PBImappingData.ControlMappingID === 34 || PBImappingData.ControlMappingID === 35 ||
                    PBImappingData.ControlMappingID === 36 || PBImappingData.ControlMappingID === 39)

                    inputVal = { TableName: PBImappingData.TableName, ColumnName: PBImappingData.ColumnName, ColumnValue: [controlValue], Operator: PBImappingData.Operator, ControlMappingID: PBImappingData.ControlMappingID };
                else
                    inputVal = { TableName: PBImappingData.TableName, ColumnName: PBImappingData.ColumnName, ColumnValue: controlValue, Operator: PBImappingData.Operator, ControlMappingID: PBImappingData.ControlMappingID };

                userFilterselection.push(inputVal);
            }
        }

    };

})(jQuery);