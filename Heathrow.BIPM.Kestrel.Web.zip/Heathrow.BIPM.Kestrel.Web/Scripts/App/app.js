﻿
(function ($) {
    'use strict';
    // add this global variable for the base web api url.
    window.baseUrl = "https://localhost:44372/";
    $('.homeLinkIcon').on('click',
        function () {
            window.location.href = '/Dashboard/Index';
        });

    $(document).ready(function () {

        //first bind the menu then call powerbi API.
        var objMenu = new Menu();
        objMenu.bindMenu();
        //  var objAlertIcon = new AlertIcon();
        //objAlertIcon.bindAlerts();
    });

    $('#btnLogout').on('click',
        function () {
            window.location.href = '/Account/SignOut';
        });


    $('.defaultIcons.help').on('click',
        function () {
            window.open('../Scripts/pdf-js/viewer.html', 'winName', 'location=0,width=500,height=514').focus();
        });

    var fullscreenWidget = function () {
        $('.panel .fa-expand').click(function () {
            var panel = $(this).closest('.panel');
            panel.toggleClass('widget-fullscreen');
            $(this).toggleClass('fa-expand fa-compress');
            $('body').toggleClass('fullscreen-widget-active');

        })
    };


    $('.defaultIcons.maximize').click(function () {
        //console.log('click');
        //$('#viewContainer').toggleFullScreen();
        //$('#viewContainer').toggleClass('widget-fullscreen');
        //$('#viewContainer').toggleClass('fullscreen-widget-active');

        // $('#embedContainer').toggleFullScreen();


        //$('#dvPowerBiEmbed').toggleClass('widget-fullscreen');
        //$('#dvPowerBiEmbed').toggleClass('fullscreen-widget-active');

        if ($('#divUserBagLst').css('display') == 'block') {
            $('#divUserBagLst').toggleClass('widget-fullscreen');
            $('#divUserBagLst').toggleClass('fullscreen-widget-active');
        }
        else {
            $('#dvPowerBiEmbed').toggleClass('widget-fullscreen');
            $('#dvPowerBiEmbed').toggleClass('fullscreen-widget-active');
        }

    });


    $('.defaultIcons.minimize').click(function () {

        //$('#dvPowerBiEmbed').toggleClass('widget-fullscreen');
        //$('#dvPowerBiEmbed').toggleClass('fullscreen-widget-active');

        if ($('#divUserBagLst').css('display') == 'block') {
            $('#divUserBagLst').toggleClass('widget-fullscreen');
            $('#divUserBagLst').toggleClass('fullscreen-widget-active');
        }
        else {
            $('#dvPowerBiEmbed').toggleClass('widget-fullscreen');
            $('#dvPowerBiEmbed').toggleClass('fullscreen-widget-active');
        }




    });



    //$('#toggle-fullscreen.expand').on('click', function () {
    //    $(document).toggleFullScreen();
    //    $('#toggle-fullscreen .fa').toggleClass('fa-expand fa-compress');
    //});

})(jQuery);