﻿var inputText = [];
var Search = (function () {
    'use strict';

    var searchEntity = [];
    var searchText;
    Search = function () { }
    var txtsearch = $('#txtSearch');
    var SearchEnum = { FlightNumber: 1, BagTag: 2, PassegerName: 3, AirLine: 4, InvalidBagtag: 5, InValid: 6 };
    var validationStatus;
    var searchPrefix = '';
    var prefix;
    var errorStatus = $('#lblError');


    $("#searchbtn").on("click", function () {
        searchText = [];
        prefix = null;
        var param = txtsearch.val().split(",").filter(function (index) { return index; });
        if (_.isEmpty(param)) { alert('Search criteria is not available. Please enter the search text'); return; }
       
        $.each(param, function (key, val) {
            searchText.push(val);
        });
       
        if (searchText.length > 5) {
            alert('search will allow maximum  5 Bag Tags or Passanger'); return;
        }
        else {

            SearchValidation(searchText);
            if (searchPrefix === 'F' && searchText.length > 1) {

                alert('search will allow one flight number at a time'); return;
            }
            var inputText = (searchPrefix === 'B' || searchPrefix === 'F') ? searchText.toString() : searchText;
            sessionStorage.setItem('searchCriteria', inputText);
            sessionStorage.setItem('searchPrefix', searchPrefix);
            inputText = (searchPrefix === 'F') ? inputText : '';
            var result = [];
            if (!_.isNil(searchPrefix)) {
                var service = new Service('/Search/GetSearch?query=' + inputText + '&searchType=' + searchPrefix, 'application/html; charset=utf-8', 'html', null);
                service.get()
                    .done(function (resp) {
                        var searchResult = JSON.parse(resp.result);

                        searchResult = assignValuesToEntity(searchResult);
                        result.push(searchResult);
                        var dashboardPowerBiApi = new PowerBIAPP(searchResult.PowerBIURL, true);
                        dashboardPowerBiApi.applyFilterToReport(result);
                        //dashboardPowerBiApi.embedPowerBIApi();
                        //dashboardPowerBiApi.embedPowerBIFilterApi(result);
                        //setTimeout(function () {
                        //    dashboardPowerBiApi.applyFilterToReport(result);
                        //}, 3000);
                       
                        $(".loader").css("display", "none");
                    }).fail(function (jqXHR, textStatus, errorThrown) {
                        Utility.alertMessage("Error occured while searching criteria.", "errorMsg");
                    });;
            }
        }
    });

    var assignValuesToEntity = function (searchData) {
        searchPrefix = sessionStorage.getItem('searchPrefix');
        searchEntity = sessionStorage.getItem('searchCriteria');
        searchData.ColumnValue = (searchPrefix === 'F') ? [searchEntity] : searchEntity.split(",");
        return searchData;

    };

    //  validate input parameter
    $("#txtSearch").on("keyup", function (e) {
        if (e.keyCode == 188) { // KeyCode For comma is 188
            var paramValue = txtsearch.val().split(",").filter(function (index) { return index; });
            if (!_.isEmpty(paramValue)) {
                var index = paramValue.length - 1;

                ValidateText(paramValue[index]);
            }
            else { alert('Your not entered valid search criteria'); }
        }

    });


    // Handle special characters start
    $('#txtSearch').on('keypress', function (event) {
        Utility.SpecialCharacterValidation(event);
    });

    $('#txtSearch').bind('paste', removeAlphaChars);

    function removeAlphaChars() {
        var self = $(this);
        setTimeout(function () {
            var initVal = self.val(),
                outputVal = initVal.replace(/[^a-zA-Z0-9,]/g, "");
            if (initVal != outputVal) self.val(outputVal);
        });
    }

    //End Handle special characters

    var ValidateText = function (param) {

        if (!_.isEmpty(param)) {
            var searchValue = validatationType(param)
            if (!_.isNil(searchValue) && prefix === searchValue) {
            }
            else {
                if (prefix === SearchEnum.FlightNumber) {
                    errorStatus.text('Search by Flight number only.Combination of search will be not allowed');
                    errorStatus.removeClass('hidden');
                }
                else if (prefix === SearchEnum.BagTag) {
                    errorStatus.text('Search by Bag Tag only.Combination of search will be not allowed');
                    errorStatus.removeClass('hidden');
                }
                else if (prefix === SearchEnum.PassegerName) {
                    errorStatus.text('Search by Passeger Name only.Combination of search will be not allowed');
                    errorStatus.removeClass('hidden');
                }
                else if (prefix === SearchEnum.AirLine) {
                    errorStatus.text('Search by Airline only.Combination of search will be not allowed');
                    errorStatus.removeClass('hidden');
                }
                else if (prefix === SearchEnum.InvalidBagtag) {
                    errorStatus.text('Search by valid bagtag.The bagtag minimum should be 6 character');
                    errorStatus.removeClass('hidden');

                }
                else if (prefix === SearchEnum.InValid) {
                    errorStatus.text('Please enter valid Search criteria');
                    errorStatus.removeClass('hidden');
                }
            }
        }
    }

    var SearchValidation = function (source) {

        for (var i = 0; i < source.length; i++) {

            ValidateText(source[i]);
        }

    }

    var validatationType = function (parameter) {
        var flightRegex = new RegExp(/^(([A-Za-z]{2,3})|([A-Za-z]\d)|(\d[A-Za-z]))(\d{1,4})([A-Za-z]?)$/);
        var bagtagRegex = new RegExp(/^\d{6,10}$/);
        var airlineRegex = new RegExp(/^\[a-zA-Z]{2,4}$/);
        var passengerRegex = new RegExp(/^([a-zA-Z]{2,30})+$/);
        var numericRegex = new RegExp(/^\d{1,5}$/);

        if (flightRegex.test(parameter)) {
            prefix = (_.isNil(prefix)) ? SearchEnum.FlightNumber : prefix;
            searchPrefix = "F";
            return SearchEnum.FlightNumber;
        } else if (bagtagRegex.test(parameter)) {
            prefix = (_.isNil(prefix)) ? SearchEnum.BagTag : prefix;
            searchPrefix = "B";
            return SearchEnum.BagTag;
        } else if (passengerRegex.test(parameter)) {
            prefix = (_.isNil(prefix)) ? SearchEnum.PassegerName : prefix;
            searchPrefix = "P";
            return SearchEnum.PassegerName
        } else if (airlineRegex.test(parameter)) {
            prefix = (_.isNil(prefix)) ? SearchEnum.AirLine : prefix;
            searchPrefix = "A";
            return SearchEnum.AirLine
        }
        else {
            if (numericRegex.test(parameter)) {
                prefix = SearchEnum.InvalidBagtag;
                searchPrefix = null;
                return 0;
            }
            else {
                prefix = SearchEnum.InValid;
                searchPrefix = null;
                return 0;
            }
        }
    }

    return Search;

})();