﻿(function () {
    'use strict';
    $(document).ready(function () {

        $("#ddlAudienceGrp").combobox({
            select: function (event, ui) {
                var SelectedGrpID = $('option:selected', this).val();
                LoadGrpRecipients(SelectedGrpID);
            }
        });
    });


    $('.share,#sharePanelCancel').click(function (event) {
        event.stopPropagation();
        $(this).children(".spanNotification").css("display", "none");
        $("#sharePanel").toggle();

        $(".share").toggleClass("clickedIcons");
        $(".share").toggleClass("customBorderSmall");
        LoadAudienceGrp();


        var filterResult = JSON.parse(sessionStorage.getItem('FilterUrl'));
        if (!_.isNil(filterResult)) {
            shareUrlFormation(filterResult); //To construct the Share Url only on share icon click
        }
    });
    $(".cancel").click(function () {

        if ($(this).parents(".sideNavBar")) {
            $(this).parents(".sideNavBar").css("display", "none");
            // $(".updatedNotesDetails").empty();
        }

    });


    var LoadShareUrl = function () {
        var urlId = sessionStorage.getItem('URLId');
        var rptName = sessionStorage.getItem('RptName')
        var noteData = { menuId: urlId, rptname: rptName };

        $.ajax({
            type: "GET",
            url: "/Share/LoadShareUrl",
            data: JSON.stringify(noteData),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                if (response != null && response.length > 0) {
                    $("#lblShareUrl").text(shareUrl);
                }
            },
            failure: function (response) {
                Utility.alertMessage("Error while shareUrl formation.", "errorMsg");
            },
            error: function (response) {
                Utility.alertMessage("Error while shareUrl formation.", "errorMsg");
            }
        });

    };

    var LoadAudienceGrp = function () {
        var noteData = {};

        $.ajax({
            type: "GET",
            url: "/Share/Share",
            data: JSON.stringify(noteData),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                if (response != null && response.length > 0) {
                    GetAudienceGrpData(response);
                }
            },
            failure: function (response) {
                //Utility.alertMessage("Error while share data fetch.", "errorMsg");
            },
            error: function (response) {
                //Utility.alertMessage("Error while share data fetch.", "errorMsg");
            }
        });

    };

    //get the Audience Group dropdown values
    var GetAudienceGrpData = function (response) {
        var option = '';
        for (var i = 0; i < response.length; i++) {
            option += '<option value="' + response[i].GroupId + '">' + response[i].Groupname + '</option>';
        }
        $('#ddlAudienceGrp').append(option);
    };

    var LoadGrpRecipients = function (SelectedGrpID) {
        var noteData = { GroupId: SelectedGrpID };

        $.ajax({
            type: "POST",
            url: "/Share/GetRecipients",
            data: JSON.stringify(noteData),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (response) {
                if (response != null && response.length > 0) {
                    GetGrpRecipients(response);
                }
            },
            failure: function (response) {
                //Utility.alertMessage("Error while fetching Recipients..", "errorMsg");
            },
            error: function (response) {
                //Utility.alertMessage("Error while fetching Recipients..", "errorMsg");
            }
        });

    };

    var GetGrpRecipients = function (response) {
        var option = '';
        var newOptions = [];
        for (var i = 0; i < response.length; i++) {
            option += '<option value="' + response[i].RecipientId + '">' + response[i].Recipientname + '</option>';

            newOptions.push(
                {
                    name: response[i].Recipientname,
                    value: response[i].RecipientId,
                    checked: false
                });
        }
        $('#ddlGrpRecipients').append(option);

        $('#ddlGrpRecipients').multiselect('loadOptions', newOptions);

        $('#ddlGrpRecipients').multiselect('refresh');


    };
    /**Share script Ends**/

    $("#sharePanelCancel").click(function () {
        $("#sharePanel").css("display", "none");
    });


    $("#shareSave").click(function () {

        // To get the selected value
        var selectedUsers = $("#ddlGrpRecipients option:selected").toArray().map(optionSelected).join(',');
        $('#RecipientSelectedNames').text(selectedUsers);
        function optionSelected(item) {
            return [item.value];
        }

        if (selectedUsers != "") {
            var ReportUrl = $("#lblShareUrl").text();
            var SelectedRecipients = { selectedrecipients: selectedUsers, Url: ReportUrl };
            var updatedNotes = [];

            $.ajax({
                type: "POST",
                url: "/Share/SendMail",
                data: JSON.stringify(SelectedRecipients),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (response) {
                    if (response != null) {
                        Utility.alertMessage("Report Url shared via Email Successfully.", "successMsg");
                    }
                },
                failure: function (response) {
                    Utility.alertMessage("Error while sending Email.", "errorMsg");
                },
                error: function (response) {
                    Utility.alertMessage("Error while sending Email.", "errorMsg");
                }
            });
        }
    });



    var shareUrlFormation = function (filterResult) {
        // For constructing the filter part in share url --- start
        var filtersApplied = "";

            for (var i = 0; i < filterResult.length; i++) {
                var childValue = "";
                if (filterResult[i].ColumnValue && filterResult[i].ColumnValue.length) {
                    for (var j = 0; j < filterResult[i].ColumnValue.length; j++) {
                        childValue += filterResult[i].ColumnValue[j] + ',';
                    }
                    childValue = childValue.substr(0, childValue.length - 1);
                }
                filtersApplied += filterResult[i].TableName + "\\" + filterResult[i].ColumnName + "\\" + filterResult[i].Operator + "\\" + childValue + "&";
            }
            filtersApplied = filtersApplied.substr(0, filtersApplied.length - 1);

            var shareUrl = location.href + "?report=" + sessionStorage.getItem('RptName') + "&id=" + sessionStorage.getItem('URLId') + "&" + filtersApplied;
            $("#lblShareUrl").text(shareUrl);

        // For constructing the Share Url to share the report via Email -- End
    }


})(jQuery);




