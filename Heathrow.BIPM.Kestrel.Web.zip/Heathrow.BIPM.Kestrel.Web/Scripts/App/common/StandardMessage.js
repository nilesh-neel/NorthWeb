﻿


var StandardMessage = (function () {


});



