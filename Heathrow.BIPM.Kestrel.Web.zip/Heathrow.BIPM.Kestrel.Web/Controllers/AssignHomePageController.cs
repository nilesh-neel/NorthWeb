﻿using System.Web.Mvc;
using Heathrow.BIPM.Kestrel.Core.Interface;

namespace Heathrow.BIPM.Kestrel.Web.Controllers
{
    [Authorize]
    public class AssignHomePageController : BaseController
    {
        private readonly IAssignHomePage _assignHomPageModule;

        public AssignHomePageController(IAssignHomePage assign)
        {
            _assignHomPageModule = assign;
            //  Map = _map;

        }
        [ChildActionOnly]
        public ActionResult Index()
        {

            return PartialView("_AssignHomePage");
        }
        public ActionResult IndexMain()
        {

            return View("AssignHomePage");
        }

        public ActionResult AssignHomePageView()
        {

            return PartialView("_AssignHomePage");
        }
        /* public ActionResult Get()
         {
              return Json(
                Map.MapFrom(_assignHomPageModule.Get()),
                JsonRequestBehavior.AllowGet);
         }*/
    }
}