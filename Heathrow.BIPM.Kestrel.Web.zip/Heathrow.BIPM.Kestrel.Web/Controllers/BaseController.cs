﻿/****************************************************************************************************************
Class Name   : BaseController.cs 
Purpose      : This authenticate each and every call/route/method before executing 
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System.Security.Claims;
using System.Web;
using System.Web.Mvc;
using Heathrow.BIPM.Kestrel.Business.Infrastructure;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Microsoft.Owin.Security.Cookies;

namespace Heathrow.BIPM.Kestrel.Web.Controllers
{
    //  [AllowCrossSite]
    // [EnableCors(origins: "*", headers: "*", methods: "*")]
    [Authorize]
    //[RoleAuthorize]
    public abstract class BaseController : Controller
    {
        internal AzureAdUser LoginInUser { get; set; }
        internal SessionTokenCache TokenStore { get; set; }

        protected BaseController()
        {

            LoginInUser = new AzureAdUser
            {
                DisplayName = "Dummy Name",
                Email = "dummyname@xyzairway.com",
                JobRoles = null,
                Organization = "xyzOrganization",
                Locations = null,
                Name = "Dummy",
                Phone = "xxxxxxxxxx"

            };

        }

        public void BaseIndex()
        {

        }
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (Request.IsAuthenticated)
            {
                // Get the signed in user's id and create a token cache
                string signedInUserId = ClaimsPrincipal.Current.FindFirst(ClaimTypes.NameIdentifier).Value;
                SessionTokenCache tokenStore = new SessionTokenCache(signedInUserId, HttpContext);
                if (tokenStore.HasData())
                {
                    TokenStore = tokenStore;
                    // Add the user to the view bag
                    LoginInUser = tokenStore.GetUserDetails();


                }
                else
                {
                    // The session has lost data. This happens often
                    Request.GetOwinContext().Authentication.SignOut(CookieAuthenticationDefaults.AuthenticationType);
                    filterContext.Result = RedirectToAction("SignIn", "Account");
                }

                ViewBag.LogInUser = LoginInUser;
            }
            base.OnActionExecuting(filterContext);
        }
    }
}