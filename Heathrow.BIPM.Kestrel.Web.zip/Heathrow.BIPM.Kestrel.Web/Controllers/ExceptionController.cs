﻿using System.Web.Mvc;

namespace Heathrow.BIPM.Kestrel.Web.Controllers
{
    [AllowAnonymous]
    public class ExceptionController : Controller
    {
        public ActionResult Error(string message, string debug)
        {
            ViewBag.DebugMessage = message;
            ViewBag.DebugError = debug;
            return View("Error");
        }
    }
}