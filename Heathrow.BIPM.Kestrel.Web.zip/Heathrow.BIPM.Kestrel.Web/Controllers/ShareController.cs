﻿/****************************************************************************************************************
Class Name   : ShareController.cs 
Purpose      : This is the share file in the application. To handle sharing of report URL to the selected Users...
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System.Web.Mvc;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;
using Heathrow.BIPM.Kestrel.Web.ViewModel;

namespace Heathrow.BIPM.Kestrel.Web.Controllers
{
    // [ModelStateException]
    // [BPMErrorHandler]
    public class ShareController : BaseController
    {

        private readonly IShareModule _shareModule;
        private readonly IMapper<ShareVM, Share> _map;

        public ShareController(IShareModule shareObj, IMapper<ShareVM, Share> map)
        {
            _shareModule = shareObj;
            _map = map;
        }

        // GET: Share
        #region Fetching and loading the Audience Group in dropdown
        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public ActionResult Share()
        {
            var shareResponse = _shareModule.GetAudienceGrp();
            var response = Json(shareResponse, JsonRequestBehavior.AllowGet);
            return response;
        }
        #endregion

        #region Fetching and loading the Group Recipients based on the selected Audience Group
        [OutputCache(NoStore = true, Duration = 0)]
        [HttpPost]
        public ActionResult GetRecipients(int GroupId)
        {
            var shareResponse = _shareModule.GetGrpRecipients(GroupId);
            var response = Json(shareResponse, JsonRequestBehavior.AllowGet);
            return response;
        }
        #endregion

        #region Sending Email through Office365
        [OutputCache(NoStore = true, Duration = 0)]
        [HttpPost]
        public ActionResult SendMail(string selectedrecipients, string Url)
        {
            var Mailresponse = _shareModule.SendEmail(selectedrecipients, Url);
            var response = Json(Mailresponse, JsonRequestBehavior.AllowGet);
            return response;
        }
        #endregion
    }
}