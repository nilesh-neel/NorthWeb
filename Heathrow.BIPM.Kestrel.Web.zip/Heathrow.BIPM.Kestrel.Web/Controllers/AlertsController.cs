﻿/****************************************************************************************************************
Class Name   : Alerts.cs 
Purpose      : Used as Owin Startup class to implements authentication and authorization in Application. 
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System.Threading.Tasks;
using System.Web.Mvc;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;
using Heathrow.BIPM.Kestrel.Web.ViewModel;

namespace Heathrow.BIPM.Kestrel.Web.Controllers
{
    
    public class AlertsController : BaseController
    {

        private readonly IMapper<AlertVM, Alerts> _map;     
        private readonly IAlertsModule _alertModule;
        private readonly ILookUpModule _lookupModule;
        private readonly IMapper<LookUpVM, LookupEnt> LookUpMap;

        public AlertsController(IAlertsModule alerts, ILookUpModule _lookup, IMapper<AlertVM, Alerts> map, IMapper<LookUpVM, LookupEnt> _mapLookup)
        {          
            _alertModule = alerts;
            _lookupModule = _lookup;
            _map = map; 
            LookUpMap = _mapLookup;
        }

        // GET: Alerts
     
        public ActionResult Index()
        {           
            return PartialView("_LandingPage");
        }

        [HttpGet]
        //[Route("TodayAlerts")]
        public async Task<JsonResult> GetTodaysAlerts()
        {                     
            return Json(_map.MapFrom(await _alertModule.GetAlerts()), JsonRequestBehavior.AllowGet);
           
        }

        [HttpGet]
        //[Route("TodayAlerts")]
        public async Task<JsonResult> GetConfigureAlerts()
        {
            return Json(_map.MapFrom(await _alertModule.GetConfigureAlerts()), JsonRequestBehavior.AllowGet);

        }
        public async Task<ActionResult> NewAlert()
        {           
            AlertVM alertVm = new AlertVM()
            {  
                
                location = LookUpMap.MapFrom(await _lookupModule.Bag_LocationList()),
                freq=LookUpMap.MapFrom(await _lookupModule.Bag_FrequencyList()),
                timeWin=LookUpMap.MapFrom(await _lookupModule.Bag_TimeWindowList()),
                measureName = LookUpMap.MapFrom(await _lookupModule.Bag_MeasureList()),            
                organisation = LookUpMap.MapFrom(await _lookupModule.Bag_OrganisationList()),              
                topic = LookUpMap.MapFrom(await _lookupModule.Bag_TopicList()),
                threshold = LookUpMap.MapFrom(await _lookupModule.Bag_ThresholdList()),
                operationalArea = LookUpMap.MapFrom(await _lookupModule.Bag_OperationalAreaList())
        };

            return PartialView("_NewAlert", alertVm);
        }
        [HttpPost]
        public async Task<ActionResult> NewAlert(AlertVM data)
        {
            var objNotifCore = _map.MapTo(data);
            int i = await _alertModule.Save(objNotifCore);
            return new EmptyResult();
        } 
        public async Task<ActionResult> Edit(string id)
        {
          
            AlertVM alertItem;
          

             alertItem =_map.MapFrom(await _alertModule.GetAlertsById(id));    
            alertItem.organisation = LookUpMap.MapFrom(await _lookupModule.Bag_OrganisationList());    
            alertItem.location = LookUpMap.MapFrom(await _lookupModule.Bag_LocationList());
            alertItem.freq = LookUpMap.MapFrom(await _lookupModule.Bag_FrequencyList());
            alertItem.timeWin = LookUpMap.MapFrom(await _lookupModule.Bag_TimeWindowList());
            alertItem.measureName = LookUpMap.MapFrom(await _lookupModule.Bag_MeasureList());
            alertItem.topic = LookUpMap.MapFrom(await _lookupModule.Bag_TopicList());
            alertItem.threshold = LookUpMap.MapFrom(await _lookupModule.Bag_ThresholdList());
            alertItem.operationalArea = LookUpMap.MapFrom(await _lookupModule.Bag_OperationalAreaList());  
            //notificationItem = notList.Find(x => x.notificationId == id);

            return PartialView("_ConfigurNewAlert", alertItem);
        }

        public async Task<ActionResult> AlertSetting(string id)
        {

            AlertVM alertItem;
            alertItem = _map.MapFrom(await _alertModule.GetAlertsById(id));
                      
            alertItem.topic = LookUpMap.MapFrom(await _lookupModule.Bag_TopicList());
            alertItem.threshold = LookUpMap.MapFrom(await _lookupModule.Bag_ThresholdList());
            alertItem.measureName = LookUpMap.MapFrom(await _lookupModule.Bag_MeasureList());
            alertItem.location = LookUpMap.MapFrom(await _lookupModule.Bag_LocationList());
            //notificationItem = notList.Find(x => x.notificationId == id);

            return PartialView("_EditAlertSetting", alertItem);
        }
        [HttpPost]
        public async Task<ActionResult> Edit(AlertVM data)
        {
            var objAlertCore = _map.MapTo(data);
            int i = await _alertModule.Update(objAlertCore);
            return new EmptyResult();
        }

        /* [HttpGet]
         [Route("Get")]
       public ActionResult GetAll() => Json(_map.MapFrom(_alertModule.GetAlerts()), JsonRequestBehavior.AllowGet);*/
       // [HttpPost]
  /*     [HttpGet]
        public async Task<ActionResult> RecipientList(int id)
        {
            // var recipient=LookUpMap.MapFrom(await _alertModule.Bag_RecipientList(id));
            var obj = LookUpMap.MapFrom(await _lookupModule.GetAllRecipient());
            var jsonObj= Json(obj, JsonRequestBehavior.AllowGet);
            return jsonObj;

            

        }*/

    }
}