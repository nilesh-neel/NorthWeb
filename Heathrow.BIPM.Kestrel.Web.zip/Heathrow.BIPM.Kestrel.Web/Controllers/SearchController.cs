﻿/****************************************************************************************************************
Class Name   : Global.cs 
Purpose      : This is the mail startup file in the application. To handle all startup even in web app like
               Dependency injection, Route config / web api registrations etc...
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System.Threading.Tasks;
using System.Web.Mvc;
using Heathrow.BIPM.Kestrel.Business.Interface;

namespace Heathrow.BIPM.Kestrel.Web.Controllers
{
    [Authorize]
    public class SearchController : BaseController
    {
        private readonly ISearchModule _searchbiz;


        public SearchController(ISearchModule searchInstance)
        {
            _searchbiz = searchInstance;
        }
     
        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public async Task<JsonResult> GetSearch(string query, string searchType)
        {
          var result = await(_searchbiz.GetSearchData(query, searchType));
          string actionResult = Newtonsoft.Json.JsonConvert.SerializeObject(result);

            return Json(new { result = actionResult }, JsonRequestBehavior.AllowGet);
        }

    }
}