﻿/****************************************************************************************************************
Class Name   : Global.cs 
Purpose      : This is the mail startup file in the application. To handle all startup even in web app like
               Dependency injection, Route config / web api registrations etc...
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System.Threading.Tasks;
using System.Web.Mvc;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;
using Heathrow.BIPM.Kestrel.Web.ViewModel;
using Newtonsoft.Json;

namespace Heathrow.BIPM.Kestrel.Web.Controllers
{
    [Authorize]
    public class FilterController : BaseController
    {
        private readonly IFilterModule _filterModule;
        private readonly IMapper<FilterVM, FilterCollection> _filterMapper;
        // GET: Filter

        /// <inheritdoc />
        /// <summary>
        /// Initialize filter object and implemented constructor injection 
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="dataMapper"></param>
        public FilterController(IFilterModule filter, IMapper<FilterVM, FilterCollection> dataMapper)
        {
            _filterModule = filter;
            _filterMapper = dataMapper;
        }

        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public async Task<JsonResult> GetFilterData()
        {
            var filterResult = _filterMapper.MapFrom(await _filterModule.GetAllFilter());
            var actionResult = JsonConvert.SerializeObject(filterResult);
            return Json(actionResult, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public async Task<JsonResult> SaveFilters(FilterVM data)
        {
            int actionResult = await _filterModule.SaveFilter( _filterMapper.MapTo(data));
            return Json(actionResult, JsonRequestBehavior.AllowGet);
        }

        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public async Task<JsonResult> GetFilterByMenuID(int menuID)
        {
            var result =  _filterMapper.MapFrom(await _filterModule.GetFilterByMenuID(menuID));
            string actionResult =  JsonConvert.SerializeObject(result);
            return  Json(new {  result = actionResult }, JsonRequestBehavior.AllowGet);
        }


        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public async Task<JsonResult> GetFilterConfigurationDetails(int menuId)
        {
            var result = _filterMapper.MapFrom(await _filterModule.GetFilterConfiguration(menuId));
            string configResult = JsonConvert.SerializeObject(result);
            return Json(new { result = configResult }, JsonRequestBehavior.AllowGet);
        }
    }
}