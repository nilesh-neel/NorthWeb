﻿/****************************************************************************************************************
Class Name   : NotificationsController.cs 
Purpose      :  To view/edit Today's Notification,My Notification Setting and Configure Notification
Created By   : Vaishnavi R
Created Date : 09/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System.Threading.Tasks;
using System.Web.Mvc;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;
using Heathrow.BIPM.Kestrel.Web.ViewModel;

namespace Heathrow.BIPM.Kestrel.Web.Controllers
{
    public class NotificationsController : BaseController
    {
        private readonly IMapper<NotificationVM, Notification> Map;
        private readonly IMapper<LookUpVM, LookupEnt> LookUpMap;
        private static INotificationModule _notifyModule;
        private readonly ILookUpModule _lookupModule;
        public NotificationsController(INotificationModule notify, ILookUpModule _lookup, IMapper<NotificationVM, Notification> _map, IMapper<LookUpVM, LookupEnt> _mapLookup)
        {
            _notifyModule = notify;
            _lookupModule = _lookup;
            Map = _map;
            LookUpMap = _mapLookup;
           
        }



        [ChildActionOnly]
        public ActionResult Index()
        {
            return PartialView("_LandingPage");
        }
        // GET: Notifications
        /// <summary>          
        /// It gets the json data from the database. 
        /// The json data is returned to jqDataTable. 
        /// </summary>        
        /// <returns>JSON data</returns> 
        [HttpGet]
        //[Route("TodayNotification")]
        public  async Task<JsonResult> GetTodaysNotification()
        {         
          return  Json(Map.MapFrom( await _notifyModule.GetUsersNotification(1)), JsonRequestBehavior.AllowGet);
           
        }
        //CREATE
        //Configure New Notification
        /// <summary>           
        /// It gets data from lookup table(for dropdown).
        /// The json data is returned to partial view. 
        /// </summary>        
        /// <returns>partial view for new notification</returns> 
        public async Task<ActionResult> NewNotification()
        {           
            NotificationVM notificationItem = new NotificationVM()
            {              
                notificationId = "",
                description = "",
                createdBy = "",
                startDate = System.DateTime.Now,
                modifiedBy = "",
                modifiedDate = System.DateTime.Now,
                URL = "",                             
                //topicEnt = LookUpMap.MapFrom(await _notifyModule.Bag_TopicList()),
                topicEnt = LookUpMap.MapFrom(await _lookupModule.Bag_TopicList()),
                locationEnt = LookUpMap.MapFrom(await _lookupModule.Bag_LocationList()),
                operationalAreaEnt = LookUpMap.MapFrom(await _lookupModule.Bag_OperationalAreaList()),
                organisationEnt= LookUpMap.MapFrom(await _lookupModule.Bag_OrganisationList())
                //  recipientsEnt = LookUpMap.MapFrom(_notifyModule.RecipientList()),
            };
           
            return PartialView("_NewNotification", notificationItem);
        }

        /// <summary> 
        /// The data submitted on click of save is posted. 
        /// Obtained data is saved in the database. 
        /// </summary> 
        /// <param name=”NotificationVM data”>ViewModel Data to save in database</param> 
        /// <returns></returns> 
        [HttpPost]
        public async Task<ActionResult> NewNotification(NotificationVM data)
        {
            var objNotifCore = Map.MapTo(data);          
            var i = await _notifyModule.ConfigureNewNotification(objNotifCore);
            return new EmptyResult();
        }
        //UPDATE
        /// <summary> 
        /// It gets record corresponding to selected id. 
        /// It populates dropdown from lookup table. 
        /// </summary> 
        /// <param name=”id”>Notification id to obtain record</param> 
        /// <returns>Partial view for Configure Notification</returns> 

        public async Task<ActionResult> Edit(string id)
        {
            NotificationVM notificationItem = Map.MapFrom(await _notifyModule.GetNotificationById(id));
          //  notificationItem.modifiedBy = LoginInUser.DisplayName;         
            notificationItem.topicEnt = LookUpMap.MapFrom(await _lookupModule.Bag_TopicList());
            notificationItem.locationEnt= LookUpMap.MapFrom(await _lookupModule.Bag_LocationList());
            notificationItem.operationalAreaEnt = LookUpMap.MapFrom(await _lookupModule.Bag_OperationalAreaList());
           notificationItem.organisationEnt = LookUpMap.MapFrom(await _lookupModule.Bag_OrganisationList());          
            //notificationItem = notList.Find(x => x.notificationId == id);
            return PartialView("_ConfigurNotifications", notificationItem);
        }
        /// <summary> 
        /// It gets record corresponding to selected id. 
        /// It populates dropdown from lookup table. 
        /// </summary> 
        /// <param name=”id”>Notification id to obtain record</param> 
        /// <returns>Partial View for My Notification Setting</returns> 

        public async Task<ActionResult> NotificationSetting(string id)
        {
            NotificationVM notificationItem = Map.MapFrom(await _notifyModule.GetNotificationById(id));
            notificationItem.topicEnt = LookUpMap.MapFrom(await _lookupModule.Bag_TopicList());
            notificationItem.locationEnt = LookUpMap.MapFrom(await _lookupModule.Bag_LocationList());
            return PartialView("_EditNotificationSetting", notificationItem);
           
        }
        /// <summary> 
        /// It gets data posted on click of save. 
        /// Obtained data is saved in database 
        /// </summary> 
        /// <param name=”NotificationVM data”>ViewModel to save in database</param> 
        /// <returns></returns> 

        [HttpPost]
        public async Task<ActionResult> Edit(NotificationVM data)
        {           
           var objNotifCore = Map.MapTo(data);

            var i = await _notifyModule.Update(objNotifCore);
            return new EmptyResult();
        }
    }
}