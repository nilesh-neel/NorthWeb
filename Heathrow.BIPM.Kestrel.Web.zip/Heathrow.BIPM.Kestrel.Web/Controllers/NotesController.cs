﻿/****************************************************************************************************************
Class Name   : NotesController.cs 
Purpose      : This file is used to save the User's newly added Notes data and also to display the existing Notes data.......
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System;
using System.Threading.Tasks;
using System.Web.Mvc;
using Heathrow.BIPM.Kestrel.Business.Interface;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Heathrow.BIPM.Kestrel.Core.Interface;
using Heathrow.BIPM.Kestrel.Web.ViewModel;

namespace Heathrow.BIPM.Kestrel.Web.Controllers
{
    //[CompressFilter]
    [Authorize]
    public class NotesController : BaseController
    {

        private readonly INotesModule _notesModule;
        private readonly IMapper<NotesVM, Notes> Map;

        public NotesController(INotesModule notes, IMapper<NotesVM, Notes> map)
        {
            _notesModule = notes;
            Map = map;
        }
        // GET: Notes
        #region Fetching and displaying the existing Notes
        [OutputCache(NoStore = true, Duration = 0)]
        [HttpPost]
        public async Task<ActionResult> FetchNotes(string bagtag, string flightnumber, string organisation,string UserId)
        {
            //if (!string.IsNullOrEmpty(bagtag) || (!string.IsNullOrEmpty(organisation)))
            //{
            var obj = Map.MapFrom(await _notesModule.Fetch(bagtag, flightnumber, organisation, UserId));
            var res = Json(obj, JsonRequestBehavior.AllowGet);
           
            //}
            return res;
        }
        #endregion
        #region Deleting respective Notes
        [HttpPost]
        public async Task<ActionResult> DeleteNote(int noteId, string bagtag, string flightnumber, string organisation, string UserId)
        {
            var obj = Map.MapFrom(await _notesModule.DeleteNotes(noteId, bagtag, flightnumber, organisation, UserId));
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion
        // GET: Notes/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }


        // POST: Notes/Create
        #region Saving the Created Notes
        [HttpPost]
        public async Task<ActionResult> Create(NotesVM _notesVM)
        {
            try
            {
                // TODO: Add insert logic here
                if (!ModelState.IsValid && string.IsNullOrEmpty(_notesVM.Notedesc))
                    return null;

                var objNoteCore = Map.MapTo(_notesVM);
                var obj = Map.MapFrom(await _notesModule.Save(objNoteCore));
                return Json(obj, JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                return View();
            }

        }
        #endregion

    }
}
