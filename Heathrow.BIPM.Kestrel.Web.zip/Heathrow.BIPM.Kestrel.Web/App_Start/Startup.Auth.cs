﻿using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using Heathrow.BIPM.Kestrel.Business;
using Heathrow.BIPM.Kestrel.Business.Infrastructure;
using Heathrow.BIPM.Kestrel.Core.Entity;
using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.Notifications;
using Microsoft.Owin.Security.OpenIdConnect;
using Owin;

namespace Heathrow.BIPM.Kestrel.Web
{
    public partial class Startup
    {
        /// <summary>
        /// In this method application validate the user credential against azure ad with OWIN middleware using OpenIdConnect authentication option.
        /// </summary>
        /// <param name="app"></param>
        public void ConfigureAuth(IAppBuilder app)
        {
            app.SetDefaultSignInAsAuthenticationType(CookieAuthenticationDefaults.AuthenticationType);
            app.UseCookieAuthentication(new CookieAuthenticationOptions()
            {
                //CookieName = ".AspNet.Cookies",
                //LogoutPath = new PathString("/Account/LogOff")
            });

            app.UseOpenIdConnectAuthentication(
                new OpenIdConnectAuthenticationOptions
                {

                    // The `Authority` represents the Microsoft v2.0 authentication and authorization service.
                    // The `Scope` describes the permissions that your app will need. See https://azure.microsoft.com/documentation/articles/active-directory-v2-scopes/                    
                    ClientId = AzureAdConfig.ClientId,
                    Authority = AzureAdConfig.AadAuthorityUri,
                    RedirectUri = AzureAdConfig.RedirectUrl,
                    Scope = "openid email profile offline_access " + AzureAdConfig.AzureGraphScopes,
                    //CallbackPath = new PathString("/Base/BaseIndex"),
                    TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = false,
                        RoleClaimType = "role"
                        // In a real application you would use IssuerValidator for additional checks, 
                        // like making sure the user's organization has signed up for your app.
                        //     IssuerValidator = (issuer, token, tvp) =>
                        //     {
                        //         if (MyCustomTenantValidation(issuer)) 
                        //             return issuer;
                        //         else
                        //             throw new SecurityTokenInvalidIssuerException("Invalid issuer");
                        //     },
                    },
                    Notifications = new OpenIdConnectAuthenticationNotifications
                    {
                        AuthorizationCodeReceived = OnAuthorizationCodeReceivedAsync,
                        AuthenticationFailed = OnAuthenticationFailedAsync
                    }
                });


            //app.UseWindowsAzureActiveDirectoryBearerAuthentication(
            //    new WindowsAzureActiveDirectoryBearerAuthenticationOptions
            //    {
            //        Audience = AzureAdConfig.RedirectUrl + "/api",
            //        Tenant = AzureAdConfig.AzureAdTenant,
            //        AuthenticationType = "OAuth2Bearer",
            //        //TokenValidationParameters = new TokenValidationParameters
            //        //{
            //        //    AuthenticationType = "OAuth2Bearer",
            //        //}
            //    });

        }

        private static Task OnAuthenticationFailedAsync(AuthenticationFailedNotification<OpenIdConnectMessage,
            OpenIdConnectAuthenticationOptions> notification)
        {
            notification.HandleResponse();

            if (notification.ProtocolMessage.Error != null && notification.ProtocolMessage.Error.Equals("interaction_required") &&
                notification.ProtocolMessage.ErrorDescription.Split(':')[0].Equals("AADSTS50105"))
            {
                notification.Response.Redirect("/Registration/RegistrationPage");
            }
            else
            {

                string redirect = $"/Exception/Error?message={notification.Exception.Message}";
                if (notification.ProtocolMessage != null &&
                    !string.IsNullOrEmpty(notification.ProtocolMessage.ErrorDescription))
                {
                    redirect += $"&debug={notification.ProtocolMessage.ErrorDescription}";
                }

                notification.Response.Redirect(redirect);
            }

            return Task.FromResult(0);
        }

        private static async Task OnAuthorizationCodeReceivedAsync(AuthorizationCodeReceivedNotification notification)
        {
            // Get the signed in user's id and create a token cache
            string signedInUserId = notification.AuthenticationTicket.Identity.FindFirst(ClaimTypes.NameIdentifier).Value;
            SessionTokenCache tokenStore = new SessionTokenCache(signedInUserId,
                notification.OwinContext.Environment["System.Web.HttpContextBase"] as HttpContextBase);

            var idClient = new ConfidentialClientApplication(AzureAdConfig.ClientId, AzureAdConfig.RedirectUrl,
                new ClientCredential(AzureAdConfig.ClientSecret), tokenStore.GetMsalCacheInstance(), null);

            try
            {
                string[] scopes = AzureAdConfig.AzureGraphScopes.Split(new char[] { ' ' });

                var result = await idClient.AcquireTokenByAuthorizationCodeAsync(
                    notification.Code, scopes);

                var cachedUser = await UserModule.GetUserDetailsAsync(result.AccessToken);
                tokenStore.SaveUserDetails(cachedUser);
            }
            catch (MsalException ex)
            {
                const string message = "AcquireTokenByAuthorizationCodeAsync threw an exception";
                notification.HandleResponse();
                notification.Response.Redirect($"/Exception/Error?message={message}&debug={ex.Message}");
            }

        }
    }
}