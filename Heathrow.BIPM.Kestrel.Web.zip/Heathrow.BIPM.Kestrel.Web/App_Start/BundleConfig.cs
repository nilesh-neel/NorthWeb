﻿using System.Web.Optimization;

namespace Heathrow.BIPM.Kestrel.Web
{
    public class BundleConfig
    {
        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at https://modernizr.com to pick only the tests you need.
            bundles.Add(new Bundle("~/bundles/modernizr").Include(
                "~/Scripts/modernizr-*",
                "~/Scripts/es6-promise.min.js"
               
            ));


            bundles.Add(new Bundle("~/bundles/route").Include(
                "~/Scripts/jquery-3.3.1.min.js",
                "~/Scripts/sammy.min.js",
                "~/Scripts/route-config.js",
                "~/Scripts/bootstrap.min.js"
                ));

            bundles.Add(new Bundle("~/bundles/vendor").Include(
                "~/Scripts/vendor/jquery-ui.min.js",
                //"~/Scripts/powerbi/adal.js",
                //"~/Scripts/powerbi/powerbi.js",
                //"~/Scripts/jquery.validate.min.js",
                //"~/Scripts/jquery.validate.unobtrusive.min.js",
                //"~/Scripts/jquery.unobtrusive-ajax.min.js",
                //"~/Scripts/jquery.scrollbar.min.js",

               // "~/Scripts/powerbi/powerBIApp.js",
                //"~/Scripts/validator.js",
                "~/Scripts/plugins/lodash.min.js",


               "~/Scripts/vendor/quagga/adapter-latest.js",
                "~/Scripts/vendor/quagga/quagga.js",

                "~/Scripts/plugins/jquery.dataTables.min.js",
                "~/Scripts/plugins/moment.min.js",
                "~/Scripts/plugins/daterangepicker.js",
                "~/Scripts/plugins/ion.rangeSlider.js",
                "~/Scripts/plugins/jquery.multiselect.js",
                "~/Scripts/plugins/comboBox.js",
                "~/Scripts/plugins/script.js"
            ));

            bundles.Add(new Bundle("~/bundles/appJS").IncludeDirectory(
                "~/Scripts/App/", "*.js", true));


            bundles.Add(new Bundle("~/bundles/notif").Include(

                "~/Scripts/App/common/editForm.js",
                "~/Scripts/daterangepicker.js"
            ));


            bundles.Add(new StyleBundle("~/bundles/Content").Include(
                "~/Content/jquery-ui.min.css",
                "~/Content/bootstrap.min.css",
                "~/Content/jquery.dataTables.min.css",
                "~/Content/daterangepicker.css",
                "~/Content/ion.rangeSlider.css",
                "~/Content/jquery.multiselect.css",

                "~/Content/skin2.css",
                "~/Content/barcodescan.css",
                "~/Content/style.css",
                "~/Content/baglist.css",
                "~/Content/custome.css",
                "~/Content/jquery.scrollbar.css"
            ));


            //#if DEBUG
            //            BundleTable.EnableOptimizations = false;
            //#else
            //                        BundleTable.EnableOptimizations = true;
            //#endif
            BundleTable.EnableOptimizations = false;
        }
    }
}