﻿//----------------------------------------------------------------------
//Class Name   : AlertsRepository 
//Purpose      : This is Data Service js file use to connect with the server side api/controller call. 
//               Whit this ajax call we can achive promise in javascripts. 
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using DbConnection = Heathrow.BPM.DataAccess.Common.DbConnection;

namespace Heathrow.BPM.DataAccess
{
    public class AlertsRepository : IAlerts
    {
        public AlertsRepository() { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="alert"></param>
        /// <returns></returns>
        public int Save(Alerts alert)
        {
            DbConnection oDal = new DbConnection();
            try
            {

                DataSet dsAlertList = new DataSet();

                oDal.ExecuteDataSet(ProcedureConstants.UpdateAlert, out dsAlertList,
                   new List<SqlParameter>()
                   {
                        new SqlParameter(){ParameterName ="@alertId", DbType = DbType.String, Value = alert.AlertId },
                        new SqlParameter(){ParameterName="@topic",DbType=DbType.String,Value=alert.Topic},
                        new SqlParameter(){ParameterName="@title",DbType=DbType.Int32,Value=alert.Title},
                        new SqlParameter(){ParameterName="@modifiedBy",DbType=DbType.String,Value=alert.ModifiedBy}

                        //To Do: Save list of locations for this.NotificationID and this.UserID
                        //Subscription for each notification
                   });

                // return dsNotificationList.Tables != null && dsNotificationList.Tables[0].Rows.Count > 0
                //     ? Convert.ToInt32(Convert.ToString(dsNotificationList.Tables[0].Rows[0][0]).Equals("success") ? 0 : 999)
                //     : 999;

                return 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }
        public Alerts GetAlertsById(string alertId)
        {
            DbConnection oDal = new DbConnection();
            try
            {

                DataSet dsPages = new DataSet();

                oDal.ExecuteDataSet(ProcedureConstants.SelectAlertsById, out dsPages,
                   new List<SqlParameter>()
                   {
                        new SqlParameter() { ParameterName = "@P_AlertId", DbType = DbType.String, Value = alertId }
                   });

                return dsPages.Tables != null &&
                        dsPages.Tables[0].Rows.Count > 0 ? new Alerts
                        {
                            AlertId = Convert.ToString(dsPages.Tables[0].Rows[0]["AlertID"]),
                            Title = Convert.ToString(dsPages.Tables[0].Rows[0]["Title"]),
                            Topic = Convert.ToString(Convert.ToString(dsPages.Tables[0].Rows[0]["Topic"]) == string.Empty ? "0" : "")
                        } : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }

        public IEnumerable<Alerts> GetAll()
        {
            DbConnection oDal = new DbConnection();

            try
            {
                DataSet dsAlert = new DataSet();
                oDal.ExecuteDataSet(ProcedureConstants.SelectAlertsById, out dsAlert);
                return dsAlert.Tables != null &&
                        dsAlert.Tables[0].Rows.Count > 0 ? BindDataToEntity(dsAlert) : null;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }

        private List<Alerts> BindDataToEntity(DataSet dsAlert)
        {
            try
            {
                return (from drAlert in dsAlert.Tables[0].AsEnumerable()
                        select (new Alerts
                        {
                            AlertId = Convert.ToString(drAlert["PageID"]),
                            Title = Convert.ToString(drAlert["PageURL"]),
                            Topic = Convert.ToString(Convert.ToString(drAlert["IsReadOnly"]) == string.Empty ? "0" : "")
                        })).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
