﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Heathrow.BPM.DataAccess.Common;

namespace Heathrow.BPM.DataAccess
{
    public class BagListRepository : Core.Interface.IBagList
    {
        public BagListRepository() { }

        public string GetUserExistingBagtags(string userId)
        {
            DbConnection oDAL = null;
            DataSet dsUserExistingBagtag = null;
            string UserExistingBagtags = string.Empty;
            try
            {

                oDAL = new DbConnection();
                dsUserExistingBagtag = new DataSet();
                oDAL.ExecuteDataSet(ProcedureConstants.UserExistingBagtagsCnt, out dsUserExistingBagtag,
                 new List<SqlParameter>()
                 {
                       new SqlParameter() { ParameterName = "@updateduser", DbType = DbType.String, Value = userId },

                 });

                if ((dsUserExistingBagtag != null) && (dsUserExistingBagtag.Tables.Count > 0) && (dsUserExistingBagtag.Tables[0].Rows.Count > 0))
                {
                    // Dataset Data to collection
                    // return ConvertDatatoCollection(dsNotesList);
                    if (dsUserExistingBagtag.Tables[0].Rows[0]["Bag_Tag"] != null)
                        return UserExistingBagtags = "'" + dsUserExistingBagtag.Tables[0].Rows[0]["Bag_Tag"].ToString().Replace(",","','") + "'";
                        //return UserExistingBagtags = dsUserExistingBagtag.Tables[0].Rows[0]["Bag_Tag"].ToString();
                    else
                        return UserExistingBagtags;
                }
                else
                    return UserExistingBagtags;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }

        public int GetUserExistingBagtagsCnt(string userId)
        {
            //
            DbConnection oDAL = null;
            DataSet dsUserExistingBagtag = null;
            int UserExistingBagtagCnt = 0;
            try
            {

                oDAL = new DbConnection();
                dsUserExistingBagtag = new DataSet();
                oDAL.ExecuteDataSet(ProcedureConstants.UserExistingBagtagsCnt, out dsUserExistingBagtag,
                 new List<SqlParameter>()
                 {
                       new SqlParameter() { ParameterName = "@updateduser", DbType = DbType.String, Value = userId },

                 });

                if ((dsUserExistingBagtag != null) && (dsUserExistingBagtag.Tables.Count > 0) && (dsUserExistingBagtag.Tables[0].Rows.Count > 0))
                {
                    // Dataset Data to collection
                    // return ConvertDatatoCollection(dsNotesList);
                    if (dsUserExistingBagtag.Tables[0].Rows[0]["BagTags_Count"] != null)
                        return UserExistingBagtagCnt = Convert.ToInt32(dsUserExistingBagtag.Tables[0].Rows[0]["BagTags_Count"]);
                    else
                        return UserExistingBagtagCnt;
                }
                else
                    return UserExistingBagtagCnt;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }

        }

        public int RemoveBagTags(string bagtags, string userId)
        {
            DbConnection oDAL = null;
            DataSet dsBagtag = null;
            int BagtagCount = 0;
            try
            {

                oDAL = new DbConnection();
                dsBagtag = new DataSet();
                oDAL.ExecuteDataSet(ProcedureConstants.RemoveBagtags, out dsBagtag,
                 new List<SqlParameter>()
                 {
                       new SqlParameter() { ParameterName = "@Bagtag", DbType = DbType.String, Value = bagtags },
                       new SqlParameter() { ParameterName = "@updateduser", DbType = DbType.String, Value = userId },

                 });

                if ((dsBagtag != null) && (dsBagtag.Tables.Count > 0) && (dsBagtag.Tables[0].Rows.Count > 0))
                {
                    // Dataset Data to collection
                    // return ConvertDatatoCollection(dsNotesList);
                    if (dsBagtag.Tables[0].Rows[0]["BagTags_Count"] != null)
                        return BagtagCount = Convert.ToInt32(dsBagtag.Tables[0].Rows[0]["BagTags_Count"]);
                    else
                        return BagtagCount;
                }
                else
                    return BagtagCount;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }

        public int SaveBagTags(string bagtags, string userId)
        {
            DbConnection oDAL = null;
            DataSet dsBagtag = null;
            int BagtagCount = 0;
            try
            {

                oDAL = new DbConnection();
                dsBagtag = new DataSet();
                oDAL.ExecuteDataSet(ProcedureConstants.SaveBagtags, out dsBagtag,
                 new List<SqlParameter>()
                 {
                       new SqlParameter() { ParameterName = "@Bagtag", DbType = DbType.String, Value = bagtags },
                       new SqlParameter() { ParameterName = "@updateduser", DbType = DbType.String, Value = userId },

                 });

                if ((dsBagtag != null) && (dsBagtag.Tables.Count > 0) && (dsBagtag.Tables[0].Rows.Count > 0))
                {
                    // Dataset Data to collection
                    // return ConvertDatatoCollection(dsNotesList);
                    if (dsBagtag.Tables[0].Rows[0]["BagTags_Count"] != null)
                        return BagtagCount = Convert.ToInt32(dsBagtag.Tables[0].Rows[0]["BagTags_Count"]);
                    else
                        return BagtagCount;
                }
                else
                    return BagtagCount;

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }

    }
}
