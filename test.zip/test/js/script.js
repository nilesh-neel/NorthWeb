/*** read more ***/
$(document).ready(function() {
  var showChar = 200;
  var ellipsestext = "...";
  var moretext = "more";
  var lesstext = "less";
  $('.more').each(function() {
    var content = $(this).html();

    if(content.length > showChar) {

      var c = content.substr(0, showChar);
      var h = content.substr(showChar-1, content.length - showChar);

      var html = c + '<span class="moreelipses">'+ellipsestext+'</span>&nbsp;<span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">'+moretext+'</a></span>';

      $(this).html(html);
    }

  });

  $(".morelink").click(function(){
    if($(this).hasClass("less")) {
      $(this).removeClass("less");
      $(this).html(moretext);
    } else {
      $(this).addClass("less");
      $(this).html(lesstext);
    }
    $(this).parent().prev().toggle();
    $(this).prev().toggle();
    return false;
  });
});/** read More ends ***/

/*datatables initialization  code*/
$(function(){

 var todaysAlerts = $('#todaysAlertTable').dataTable({
  "pagingType": "full_numbers",
  "ordering": false,
  "info":     false,
  "bLengthChange": false,
  "bAutoWidth":false,
  "searching": false,
  "responsive" : true,
  "oLanguage": {
      "oPaginate": {
          "sFirst": "First",
          "sNext": '<img class="Next" src="" />',
          "sPrevious": '<img class="Previous" src="" />',
          "sLast": "Last"
      }
  }
});

var alertsSettings = $('#alertSettingTable').dataTable({
  "pagingType": "full_numbers",
  "ordering": false,
  "info":     false,
  "bLengthChange": false,
  "bAutoWidth":false,
  "searching": false,
  "responsive" : true,
  "oLanguage": {
      "oPaginate": {
          "sFirst": "First",
          "sNext": '<img class="Next" src="" />',
          "sPrevious": '<img class="Previous" src="" />',
          "sLast": "Last"
      }
  }
});

var oTable = $('#configureAlertsTable').dataTable( {
  "pagingType": "full_numbers",
  "ordering": false,
  "info":     false,
  "bLengthChange": false,
  "bAutoWidth":false,
  "searching": false,
  "responsive" : true,
  "oLanguage": {
      "oPaginate": {
          "sFirst": "First",
          "sNext": '<img class="Next" src="" />',
          "sPrevious": '<img class="Previous" src="" />',
          "sLast": "Last"
      }
  }
});

var todaysNotif = $('#TodaysNotificationsTable').dataTable({
  "pagingType": "full_numbers",
  "ordering": false,
  "info":     false,
  "bLengthChange": false,
  "bAutoWidth":false,
  "searching": false,
  "responsive" : true,
  "oLanguage": {
      "oPaginate": {
          "sFirst": "First",
          "sNext": '<img class="Next" src="" />',
          "sPrevious": '<img class="Previous" src="" />',
          "sLast": "Last"
      }
  }
});

var notifiSettings = $('#notificationSettingsTable').dataTable({
  "pagingType": "full_numbers",
  "ordering": false,
  "info":     false,
  "bLengthChange": false,
  "bAutoWidth":false,
  "searching": false,
  "responsive" : true,
  "oLanguage": {
      "oPaginate": {
          "sFirst": "First",
          "sNext": '<img class="Next" src="" />',
          "sPrevious": '<img class="Previous" src="" />',
          "sLast": "Last"
      }
  }
});

var configureNotif = $('#ConfigureNotificationTable').dataTable({
  "pagingType": "full_numbers",
  "ordering": false,
  "info":     false,
  "bLengthChange": false,
  "bAutoWidth":false,
  "searching": false,
  "responsive" : true,
  "oLanguage": {
      "oPaginate": {
          "sFirst": "First",
          "sNext": '<img class="Next" src="" />',
          "sPrevious": '<img class="Previous" src="" />',
          "sLast": "Last"
      }
  }
});

var reportTable = $('#reportsTable').dataTable({
  "pagingType": "full_numbers",
  "ordering": false,
  "info":     false,
  "bLengthChange": false,
  "bAutoWidth":false,
  "searching": false,
  "responsive" : true,
  "oLanguage": {
      "oPaginate": {
          "sFirst": "First",
          "sNext": '<img class="Next" src="" />',
          "sPrevious": '<img class="Previous" src="" />',
          "sLast": "Last"
      }
  }
});


$('#configureAlertsTable tbody td').on('click', '.Show_details' ,function () {
  var nTr = $(this).parents('tr')[0];
  if ( oTable.fnIsOpen(nTr) )
  {
      /* This row is already open - close it */
      //this.src = "./images/Icons/DefaultIcons.png";
      $(this).closest("tr").find("td").toggleClass("showDetailsActive");
      $(this).toggleClass("clickedIcons");
      $(this).next().toggleClass("clickedIcons");
      oTable.fnClose( nTr );
      $("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
    }
  else
  {
      /* Open this row */
      //this.src = "./images/Icons/DefaultIcons.png";
       $(this).closest("tr").find("td").toggleClass("showDetailsActive");
       $(this).toggleClass("clickedIcons");
       $(this).next().toggleClass("clickedIcons");
      oTable.fnOpen( nTr, fnFormatDetails(oTable, nTr), 'details' );
      $("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
  }
} );

$('#notificationSettingsTable tbody td ').on('click', '.Show_details' ,function () {
  var nTr = $(this).parents('tr')[0];


  if ( notifiSettings.fnIsOpen(nTr) )
  {
      /* This row is already open - close it */
     // this.src = "./images/Icons/DefaultIcons.png";
      $(this).closest("tr").find("td").toggleClass("showDetailsActive");
      $(this).toggleClass("clickedIcons");
      $(this).next().toggleClass("clickedIcons");
      notifiSettings.fnClose( nTr );
      $("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
  }
  else
  {
      /* Open this row */

//this.src = "./images/Icons/DefaultIcons.png";
      $(this).closest("tr").find("td").toggleClass("showDetailsActive");
      $(this).toggleClass("clickedIcons");
      $(this).next().toggleClass("clickedIcons");
      notifiSettings.fnOpen( nTr, fnFormatNotification(notifiSettings, nTr), 'details' );
      $("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
  }
} );




/* Pin Icon functionality in filters panel start */

$('#pinIcon').click(function(event){
  $('#pinIcon').toggleClass("Pin");
  $('#pinIcon').toggleClass("pinclicked");
});

$('#pinIconLink').hover(function(event){

  $(this).removeClass('hovered-content');
    if( $('#pinIcon').hasClass("pinclicked"))
    {
      $('#pinIconLink').tooltip('hide');
      $(this).addClass('hovered-content');
    
    }
});

/* Pin Icon functionality in filters panel end */


/* mutiselect in share panel start */

 $('select[multiple].active.3col').multiselect({
            columns: 1,
            placeholder: 'Select',
            search: false,
            minHeight          : 150,   // minimum height of option overlay
            maxHeight          : 150,  // maximum height of option overlay
            maxWidth           : 245,
            selectAll: false
        });

/* mutiselect in share panel end */

/* vertical tabs click functionality*/

$('a[href="#notification"]').click(function(event) {
  $('#configureBackBtn,#congigureNewAlertBtn,#newReportBtn ,.alertTabs,.reportTabs,.assignHomeTabs ').css('display','none');
  $('.configureAlertForm').css('display','none');
  $(".dataTables_paginate").css('display','block');
  $(".notificationTabs").css('display','block');
  $('a[href="#todaysNotifications"').trigger('click');
});

$('a[href="#alerts"]').click(function(event) {
  $('#configureBackBtn,#congigureNewAlertBtn,#newReportBtn,.assignHomeTabs ').css('display','none');
  $('.configureAlertForm').css('display','none');
  $(".dataTables_paginate").css('display','block');
  $(".notificationTabs,.reportTabs").css('display','none');
  $(".alertTabs,#tabs a[href='#alertSettings'],#tabs a[href='#todaysAlerts']").css('display','block');
  $('a[href="#todaysAlerts"').trigger('click');
});

$('a[href="#reports"]').click(function(event) {
  $('#configureBackBtn,#congigureNewAlertBtn ,.alertTabs,.notificationTabs,.assignHomeTabs ').css('display','none');
  $('.configureAlertForm').css('display','none');
  $(".dataTables_paginate").css('display','block');
  $(".reportTabs,#newReportBtn").css('display','block');
  $('a[href="#reportsTab"').trigger('click');
});


$('a[href="#assignHomePageNav"]').click(function(event) {
  $('#configureBackBtn,#congigureNewAlertBtn ,.alertTabs,.notificationTabs,#newReportBtn,.reportTabs ').css('display','none');
  $('.configureAlertForm').css('display','none');
  $(".dataTables_paginate").css('display','none');
  $(".assignHomeTabs").css('display','block');
  $('a[href="#assignHomePagePanel"').trigger('click');
});


/*Alerts Tabs Click functionality start*/

$('#tabs a[href="#configureAlerts"]').click(function(event) {
  $('#congigureNewAlertBtn').css('display','block');
  $(".dataTables_paginate").css('display','block');
});

$('#tabs a[href="#todaysAlerts"]').click(function(event) {
    $('#congigureNewAlertBtn').css('display','none');
});

$('#tabs a[href="#alertSettings"]').click(function(event) {
  $('#congigureNewAlertBtn').css('display','block');
 
});

/*Alerts Tabs Click functionality end*/



/* Edit button functionality in configureSettings tab start*/
  $("#configureAlertsTable .Edit").click(function(){
    $("#configureAlertsTable_wrapper,#tabs a[href='#alertSettings'],#tabs a[href='#todaysAlerts']").css('display','none');
    $('#congigureNewAlertBtn').css('display','none');
    $('#configureBackBtn').css('display','block');
    $('.configureAlertForm').css('display','block');
  });

  
/* back button functionality in configureSettings tab start*/
  $('#configureBackBtn').click(function(event){
    $("#configureAlertsTable_wrapper").show();
    $('#configureBackBtn').css('display','none');
    $('.configureAlertForm').css('display','none');
    $('#congigureNewAlertBtn').css('display','block');
    $("#tabs a[href='#alertSettings'],#tabs a[href='#todaysAlerts']").css('display','block');
    
  });




});

$(document).ready(function(){

   /***refresh***/
  $(".refresh").click(function(){
        
        $(".refreshMessage").css("display","block");
    });



  
 $(".closeText").click(function(){
      $(".refreshMessage").css("display","none");
    });

  /***refresh close***/

  $('.hamburger').click(function(event) {
    event.stopPropagation();
    $('#homeNavigationBar').toggleClass('active');
  });
  
    $(".logout").click(function(){
        $("#exampleModalCenter").modal('show');
    });

      /**logout toggle***/
    $("#dropDownIcon").click(function(event){
      event.stopPropagation();
    $(".settingsLogout").toggle();
    });

    $(document).click( function(){
     $(".settingsLogout,.alertPopup").hide();
     $('#homeNavigationBar').removeClass('active');
    });

    /**logout toggle ends***/
    
    

    /**note script**/
    $('.notes,.filter,.share,.cancel').click(function(event) {
     event.stopPropagation();
     $(this).children(".spanNotification").css("display","none");
     $("#"+$(this).data("sidepanel")).toggle();
     
     if($(this).parent().data("iconclick"))//cancel click
      {
         
         $("."+$(this).parent().data("iconclick")).toggleClass("clickedIcons");
         $("."+$(this).parent().data("iconclick")).toggleClass("customBorderSmall");
      }
      
      else//icon click
      {
         $(this).toggleClass("clickedIcons");
         $(this).toggleClass("customBorderSmall");
      }
    
     });
    
   
  

   /**note script Ends**/
     $(".notification" ).click(function(event) {
       event.stopPropagation();
     $(this).children(".spanNotification").css("display","none");
        $(".alertPopup").toggle();
     });
    
  /** alert Popup**/
      $(".alertPopup" ).click(function(event) {
       event.stopPropagation();
     });
   $("#viewAllBtn" ).click(function(event) {
       event.stopPropagation();
     });

/***hambereger hover***/
    jQuery('.hambergerDiv').hover(function () {

          jQuery(this).find('.defaultIcons').toggleClass("clickedIcons").toggleClass("defaultIcons");
           }, function () {
          jQuery(this).find('.clickedIcons').toggleClass("clickedIcons").toggleClass("defaultIcons");
});

/***Menu  hover***/
     jQuery('ul.menu li').hover(function () {

          jQuery(this).find('span').toggleClass("clickedIcons").toggleClass("defaultIcons");
           }, function () {
          jQuery(this).find('span').toggleClass("clickedIcons").toggleClass("defaultIcons");
      });
/****vertical tabs hover***/


   jQuery('#verticalTabs li').click(function () {

          
          jQuery('#verticalTabs li').find('span:first-child').removeClass("clickedIcons").addClass("defaultIcons");
          jQuery(this).find('span:first-child').toggleClass("clickedIcons").toggleClass("defaultIcons");
           
      });


  
});
// Example starter JavaScript for disabling form submissions if there are invalid fields
/***Date Range Picker***/

$(function() {
   
    $('input[name="daterange"]').daterangepicker(
{
    locale: {
      format: 'YYYY-MM-DD'
    },
    startDate: '2013-02-01',
    endDate: '2013-03-31'
});
});
/*** Date Range Picker End ***/



/*** Form validation***/
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();


/****Form Validation End ***/



var expanded = false;

function showCheckboxes() {
  //var checkboxes = $("#checkboxes");
  if (!expanded) {
    //checkboxes.style.display = "block";
    $("#checkmarkOuterDiv").css('display','block');
    expanded = true;
  } else {
    //checkboxes.style.display = "none";
    $("#checkmarkOuterDiv").css('display','none');
    expanded = false;
  }
}

var panelSlided = false;
// $(".slidePanel").css('display','none');

function showAlertDetails(){

  if (!panelSlided) {
    //checkboxes.style.display = "block";
    $(".slidePanel").css('display','block');
    panelSlided = true;
  } else {
    //checkboxes.style.display = "none";
    $(".slidePanel").css('display','none');
    panelSlided = false;
  }

}
$(".Show_details").click(function(){
  
//$(this).closest("tr").find("td").toggleClass("showDetailsActive");
//$(this).toggleClass("clickedIcons").toggleClass("customBorderSmall");
//$(this).next().toggleClass("clickedIcons");

});



/* Range slider */

$("#range_35").ionRangeSlider({
  type: "double",
  min: 0,
  max: 24,
  from: 10,
  step: 2,

  from_min: 0,
  from_max: 24,
  from_shadow: true,
  to: 24,
  to_min: 6,
  to_max: 24,
  to_shadow: true,
  grid: true,
  grid_snap: true

});

/* daterangePicker for single calender*/ 

$( "#startDate,#endDate" ).daterangepicker({

        singleDatePicker: true,
        showDropdowns: true

});


/* tooltip styling and html */

$('[data-toggle="tooltip"]').each(function(){
  var options = { 
    html: true 
  };

  if ($(this)[0].hasAttribute('data-type')) {
      options['template'] = 
        '<div class="tooltip ' + $(this).attr('data-type') + '" role="tooltip">' + 
        '	<div class="tooltip-arrow"></div>' + 
        '	<div class="tooltip-inner"></div>' + 
        '</div>';
  }

  $(this).tooltip(options);
});



/* Row expansion Template for configure Alerts Table */
function fnFormatDetails ( oTable, nTr )
{
    var aData = oTable.fnGetData( nTr );
    var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
    sOut += '<tr><td>Alert ID:</td><td>'+aData[0]+'</td></tr>';
    sOut += '<tr><td>Measure Name:</td><td>Probon namepue</td></tr>';
    sOut += '<tr><td>Title:</td><td>'+aData[1]+'</td></tr>';
    sOut += '<tr><td>Audience Group:</td><td>'+aData[1]+'</td></tr>';
    sOut += '<tr><td>Recipients:</td><td>'+aData[1]+'</td></tr>';
    sOut += '<tr><td>Description:</td><td>Lorem ipsum peutriea haver baker dovery tragic hebnac looping fidharo.</td></tr>';
    sOut += '<tr><td>Topic:</td><td>'+aData[2]+'</td></tr>';
    sOut += '<tr><td>Location:</td><td>'+aData[3]+'</td></tr>';
    sOut += '<tr><td>Thershold:</td><td>'+aData[1]+'</td></tr>';
    sOut += '<tr><td>Thershold Value:</td><td>'+aData[1]+'</td></tr>';
    sOut += '<tr><td>Mandatory/optional:</td><td>optional</td></tr>';
    sOut += '<tr><td>Start Date:</td><td>12/01/2018</td></tr>';
    sOut += '<tr><td>End Date:</td><td>20/01/2018</td></tr>';
    sOut += '<tr><td>Disable Alert:</td><td>No</td></tr>';
    sOut += '<tr><td>Created By:</td><td>'+aData[4]+'</td></tr>';
    sOut += '<tr><td>Created:</td><td>'+aData[5]+'</td></tr>';
    sOut += '<tr><td>Modified By:</td><td>'+aData[7]+'</td></tr>';
    sOut += '<tr><td>Modified:</td><td>'+aData[6]+'</td></tr>';
    sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
    sOut += '</table>';
     
    return sOut;
}

/*Row expansion Template for notificationSettings Table */
function fnFormatNotification ( oTable, nTr )
{
    var aData = oTable.fnGetData( nTr );
    var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
    sOut += '<tr><td>Topic:</td><td>'+aData[1]+'</td></tr>';
    sOut += '<tr><td>Location:</td><td>'+aData[2]+'</td></tr>';
    sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
    sOut += '</table>';
     
    return sOut;
}







