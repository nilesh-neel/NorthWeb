﻿namespace Heathrow.BPM.Core.Entity
{
    public class Share
    {
        public int GroupId { get; set; }
        public string Groupname { get; set; }
        public int RecipientId { get; set; }
        public string Recipientname { get; set; }

    }
}
