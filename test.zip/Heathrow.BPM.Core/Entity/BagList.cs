﻿using System;

namespace Heathrow.BPM.Core.Entity
{
    public class BagList
    {
        public int BagListID { get; set; }

        public string Bagtags { get; set; }

        public string UserId { get; set; }

        public DateTime UpdatedDate { get; set; }

    }
}
