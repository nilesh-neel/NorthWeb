﻿using System.Collections.Generic;

namespace Heathrow.BPM.Core
{
    /// <summary>
    /// Filter Data transfer object 
    /// </summary>

    public class FilterCollection
    {
        /// <summary>
        /// Filter ID
        /// </summary>
        public long FilterID { get; set; }

        /// <summary>
        /// UserID
        /// </summary>
        public string UserID { get; set; }

        /// <summary>
        /// Menu ID
        /// </summary>
        public int MenuID { get; set; }

        /// <summary>
        /// MenuName
        /// </summary>
        public string MenuName { get; set; }

        /// <summary>
        /// Filter Text
        /// </summary>
        public string FilterText { get; set; }

        /// <summary>
        /// Filter Selection
        /// </summary>
        public short FilterSelection { get; set; }


       // public FilterParameter FilterInput { get; set; }

       public IList<TextFilter> BagTagList { get; set; }

        public IList<TextFilter> PassengersList { get; set; }

        public IList<TextFilter> InBoundFlightList { get; set; }
        public IList<TextFilter> OutBoundFlightList { get; set; }

        public IList<DropDownFilter> BagTypeList { get; set; }
        public IList<DropDownFilter> BagSystemList { get; set; }

        public IList<DropDownFilter> ShortConnectList { get; set; }
        public IList<DropDownFilter> OOGBagsList { get; set; }
        public IList<DropDownFilter> AfterChoxList { get; set; }
        public IList<DropDownFilter> DeletedBagsList { get; set; }
        public IList<DropDownFilter> MissedBRSList { get; set; }
        public IList<DropDownFilter> DeletedBSMList { get; set; }
        public IList<DropDownFilter> MyBagList { get; set; }
        public IList<DropDownFilter> InboundITOList { get; set; }
        public IList<DropDownFilter> InTargetList { get; set; }
        public IList<DropDownFilter> FailedMissedList { get; set; }
        public IList<DropDownFilter> FailedInSystemList { get; set; }
    }
    public class DropDownFilter
    {
        public int ID { get; set; }
        public string Name { get; set; }
    }
    public class TextFilter
    {
        public long ID { get; set; }
        public string Text { get; set; }
    }

}



