﻿namespace Heathrow.BPM.Core.Interface
{
    public interface IBagList
    {
        int SaveBagTags(string bagtags, string userId);
        int GetUserExistingBagtagsCnt(string userId);

        string GetUserExistingBagtags(string userId);

        int RemoveBagTags(string bagtags, string userId);
    }
}
