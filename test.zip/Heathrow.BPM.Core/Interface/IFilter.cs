﻿namespace Heathrow.BPM.Core.Interface
{
    /// <summary>
    ///  Create Filter interface
    /// </summary>
  public interface IFilter
    {
        int SaveFilter(FilterCollection filterData);
        FilterCollection GetFilterByMenuID(int menuID, int userID);
        FilterCollection GetAllFilter();

        FilterCollection GetAllUserDetails();

    }
}
