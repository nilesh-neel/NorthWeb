﻿/****************************************************************************************************************
Class Name   : PowerBiModule.cs 
Purpose      : Account Controller use to login and logout user from the application.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Text;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Collections.Generic;


namespace Heathrow.BPM.Business
{
    public class PowerBiModule : IBpmPowerBi
    {
        public async Task<string> GetEmbeddedToken()
        {
            var paramsList = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("grant_type", "password"),
                new KeyValuePair<string, string>("scope", "openid"),
                new KeyValuePair<string, string>("resource", PowerBiConfig.PowerBiApiResource),
                new KeyValuePair<string, string>("client_id", AzureAdConfig.ClientId),
                new KeyValuePair<string, string>("client_secret", AzureAdConfig.ClientSecret),
                new KeyValuePair<string, string>("username", PowerBiConfig.PowerBiUserName),
                new KeyValuePair<string, string>("password", PowerBiConfig.PowerBiUserPassword)
            };
            //string url = $"https://login.windows.net/{tenantId}/oauth2/token";
            string url = string.Format(PowerBiConfig.PowerBiAuthorityUri, AzureAdConfig.AzureAdTenant);
            HttpClient hc = new HttpClient();
            HttpContent content = new FormUrlEncodedContent(paramsList);
            HttpResponseMessage hrm = hc.PostAsync(url, content).Result;
            string responseData = "";

            if (!hrm.IsSuccessStatusCode)
                return JsonConvert.DeserializeObject<AccessToken>(responseData).access_token;
            Stream data = await hrm.Content.ReadAsStreamAsync();
            using (StreamReader reader = new StreamReader(data, Encoding.UTF8))
            {
                responseData = reader.ReadToEnd();
            }

            //var accessToken = JsonConvert.DeserializeObject<AccessToken>(responseData).access_token;

            //var tokenCredentials = new TokenCredentials(accessToken, "Bearer");
            // string _groupId = "ee94827c-74e3-4922-a353-6ad84244c177";

            //using (var client = new PowerBIClient(new Uri(PowerBiConfig.PowerBiApiUrl), tokenCredentials))
            //{
            //    var grp = client.Groups.GetGroups().Value.ToList();
            //    var reportListd = client.Reports.GetReportsInGroup("0fc4287c-461d-46bc-a2da-ec29f0962ab3");
            //    EmbedToken embedToken = await client.Reports.GenerateTokenInGroupAsync(_groupId, "f7d642f8-6934-4e28-95f3-22efadb9a1fb", new GenerateTokenRequest(accessLevel: "View"));
            //}

            return JsonConvert.DeserializeObject<AccessToken>(responseData).access_token;
        }

        public async Task<AccessToken> GetEmbeddedTokenObject()
        {
            var oauthEndpoint = new Uri(string.Format(PowerBiConfig.PowerBiAuthorityUri, AzureAdConfig.AzureAdTenant));

            using (var client = new HttpClient())
            {
                var result = await client.PostAsync(oauthEndpoint, new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("resource", PowerBiConfig.PowerBiApiResource),
                    new KeyValuePair<string, string>("client_id", AzureAdConfig.ClientId),
                    new KeyValuePair<string, string>("grant_type", "password"),
                    new KeyValuePair<string, string>("username",  PowerBiConfig.PowerBiUserName),
                    new KeyValuePair<string, string>("password",  PowerBiConfig.PowerBiUserPassword),
                    new KeyValuePair<string, string>("scope", "openid"),
                }));

                var content = await result.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<AccessToken>(content);
            }
        }


        /*
        public async Task<Stream> GetMyProfilePhoto(string accessToken)
        {

            // Get the profile photo of the current user (from the user's mailbox on Exchange Online). 
            // This operation in version 1.0 supports only a user's work or school mailboxes and not personal mailboxes. 
            string endpoint = "https://graph.microsoft.com/v1.0/me/photo/$value";

            using (var client = new HttpClient())
            {
                using (var request = new HttpRequestMessage(HttpMethod.Get, endpoint))
                {
                    //request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                    var response = await client.SendAsync(request);

                    // If successful, Microsoft Graph returns a 200 OK status code and the photo's binary data. If no photo exists, returns 404 Not Found.
                    if (response.IsSuccessStatusCode)
                    {
                        return await response.Content.ReadAsStreamAsync();
                    }
                    else
                    {
                        // If no photo exists, the sample uses a local file.
                        return File.OpenRead(System.Web.Hosting.HostingEnvironment.MapPath("/Content/test.jpg"));
                    }
                }
            }
        }
        private async void SetAccessToken()
        {
            //var credential = new UserPasswordCredential(PowerBiConfig.PowerBiUserName, PowerBiConfig.PowerBiUserPassword);

            //// Authenticate using created credentials
            //var authenticationContext = new AuthenticationContext(PowerBiConfig.PowerBiAuthorityUri);
            //var authenticationResult = await authenticationContext.AcquireTokenAsync(PowerBiConfig.PowerBiApiResource, AzureAdConfig.ClientId, credential);

            //if (authenticationResult == null)
            //    new Exception("Authentication Failed.");

            //var tokenCredentials = new TokenCredentials(authenticationResult.AccessToken, "Bearer");

            ////Microsoft.IdentityModel.Clients.ActiveDirectory.TokenCache TC = new Microsoft.IdentityModel.Clients.ActiveDirectory.TokenCache();

            ////AuthenticationContext AC = new AuthenticationContext(PowerBIConfig.PowerBiAuthorityUri, TC);
            ////Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential cc = new Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential(AzureADConfig.ClientId, AzureADConfig.ClientSecret);
            ////var embaedToken = await AC.AcquireTokenByAuthorizationCodeAsync(accessToken, new Uri(PowerBIConfig.DashboardRedirectUrl), cc);





            //using (var client = new PowerBIClient(new Uri(PowerBiConfig.PowerBiApiUrl), tokenCredentials))
            //{
            //    var grp = client.Groups.GetGroups().Value.ToList();
            //    var reportListd = client.Reports.GetReportsInGroup("0fc4287c-461d-46bc-a2da-ec29f0962ab3");
            //    EmbedToken embedToken = await client.Reports.GenerateTokenInGroupAsync(_groupId, "f7d642f8-6934-4e28-95f3-22efadb9a1fb", new GenerateTokenRequest(accessLevel: "View"));
            //}
        }

    */
    }
}
