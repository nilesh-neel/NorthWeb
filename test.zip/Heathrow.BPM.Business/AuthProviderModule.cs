﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Helpers;
using Heathrow.BPM.Business.Infrastructure;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;
using Microsoft.Graph;
using Microsoft.Identity.Client;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using AuthenticationResult = Microsoft.IdentityModel.Clients.ActiveDirectory.AuthenticationResult;
using ClientCredential = Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential;
using TokenCache = Microsoft.IdentityModel.Clients.ActiveDirectory.TokenCache;

//using Microsoft.Identity.Client;

namespace Heathrow.BPM.Business
{
    public class AuthProviderModule : IAuthProvider
    {

        public async Task<string> GetUserAccessTokenAsync()
        {
            try
            {
                //ClaimsIdentity claimsId = ClaimsPrincipal.Current.Identity as ClaimsIdentity;
                //var data = await GetGroupsFromGraphAPI(claimsId);

                string signedInUserId = ClaimsPrincipal.Current.FindFirst(ClaimTypes.NameIdentifier).Value;
                // var tok = AcquireToken(signedInUserId);
                HttpContextWrapper httpContext = new HttpContextWrapper(HttpContext.Current);
                var userTokenCache = new SessionTokenCache(signedInUserId, httpContext).GetMsalCacheInstance();
                //var cachedItems = tokenCache.ReadItems(appId); // see what's in the cache

                ConfidentialClientApplication idClient = new ConfidentialClientApplication(AzureAdConfig.ClientId,
                    AzureAdConfig.AadAuthorityUri,
                    new Microsoft.Identity.Client.ClientCredential(AzureAdConfig.ClientSecret), userTokenCache, null);
                var accounts = await idClient.GetAccountsAsync();

                Microsoft.Identity.Client.AuthenticationResult result =
                    await idClient.AcquireTokenSilentAsync(AzureAdConfig.AzureGraphScopes.Split(new char[] { ' ' }),
                        accounts.FirstOrDefault());
                return result.AccessToken;
            }

            // Unable to retrieve the access token silently.
            catch (Exception)
            {
                throw new ServiceException(
                    new Error
                    {
                        Code = GraphErrorCode.AuthenticationFailure.ToString(),
                        Message = "Error message when unable to retrieve the access token silently."
                    });
            }
        }
        public GraphServiceClient GetGraphServiceClient()
        {
            return new GraphServiceClient(new DelegateAuthenticationProvider(
                async (requestMessage) =>
                {
                    // Append the access token to the request.
                    requestMessage.Headers.Authorization =
                        new AuthenticationHeaderValue("bearer", await GetUserAccessTokenAsync());

                    // Get event times in the current time zone.
                    requestMessage.Headers.Add("Prefer", "outlook.timezone=\"" + TimeZoneInfo.Local.Id + "\"");
                }));
        }
        public async Task<string> GetPowerBiAccessTokenAsync()
        {
            try
            {
                string signedInUserId = ClaimsPrincipal.Current.FindFirst(ClaimTypes.NameIdentifier).Value;
                HttpContextWrapper httpContext = new HttpContextWrapper(HttpContext.Current);
                var userTokenCache = new SessionTokenCache(signedInUserId, httpContext).GetMsalCacheInstance();
                //var cachedItems = tokenCache.ReadItems(appId); // see what's in the cache

                ConfidentialClientApplication idClient = new ConfidentialClientApplication(AzureAdConfig.ClientId,
                    PowerBiConfig.PowerBiAuthorityUri,
                    new Microsoft.Identity.Client.ClientCredential(AzureAdConfig.ClientSecret), userTokenCache, null);
                var accounts = await idClient.GetAccountsAsync();


                //  var res = idClient.AcquireTokenForClientAsync("Report.Read.All Group.Read ".Split(new char[] { ' ' })).Result;

                var scopeWithUrl = AzureAdConfig.AzureGraphScopes + " Report.Read.All Group.Read ";
                var result = await idClient.AcquireTokenSilentAsync(scopeWithUrl.Split(new char[] { ' ' }),
                    accounts.FirstOrDefault(), PowerBiConfig.AadAuthorityUri, true);
                return result.AccessToken;
            }

            // Unable to retrieve the access token silently.
            catch (Exception ex)
            {
                //throw new ServiceException(
                //    new Error
                //    {
                //        Code = GraphErrorCode.AuthenticationFailure.ToString(),
                //        Message = "Error message when unable to retrieve the access token silently."
                //    });
                return "";
            }
        }

        #region "Test Code WIP"
        private void GetGroup()
        {
            if (ClaimsPrincipal.Current.Identity is ClaimsIdentity userClaimsId)
            {
                var data = userClaimsId.FindAll("groups").Select(c => c.Value).ToList();
            }
        }
        public string AcquireToken(string userObjectId)
        {
            try
            {
                TokenCache cc = new TokenCache();
                ClientCredential cred = new ClientCredential(AzureAdConfig.ClientId, AzureAdConfig.ClientSecret);
                AuthenticationContext authContext = new AuthenticationContext(PowerBiConfig.PowerBiAuthorityUri, cc);
                AuthenticationResult result = authContext.AcquireTokenSilentAsync(PowerBiConfig.PowerBiApiResource,
                    cred, new UserIdentifier(userObjectId, UserIdentifierType.UniqueId)).Result;
                return result.AccessToken;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return e.Message;

            }

        }
        private static async Task<List<string>> GetGroupsFromGraphAPI(ClaimsIdentity claimsIdentity)
        {
            List<string> groupObjectIds = new List<string>();

            // Acquire the Access Token
            HttpContextWrapper httpContext = new HttpContextWrapper(HttpContext.Current);
            TokenCache cc = new TokenCache();

            ClientCredential credential = new ClientCredential(AzureAdConfig.ClientId, AzureAdConfig.ClientSecret);
            AuthenticationContext authContext = new AuthenticationContext(AzureAdConfig.AadAuthorityUri, cc);

            //AuthenticationResult result = await authContext.AcquireTokenSilentAsync("https://graph.windows.net", credential,
            //    new UserIdentifier(claimsIdentity.FindFirst("http://schemas.microsoft.com/identity/claims/objectidentifier").Value, UserIdentifierType.UniqueId));


            var claimData = claimsIdentity.Claims;

            foreach (var claim in claimsIdentity.Claims)
            {
                claim.Type.Equals("groups");
            }

            // Get the GraphAPI Group Endpoint for the specific user from the _claim_sources claim in token
            string groupsClaimSourceIndex = (Json.Decode(claimsIdentity.FindFirst("_claim_names").Value)).groups;
            var groupClaimsSource =
                (Json.Decode(claimsIdentity.FindFirst("_claim_sources").Value))[groupsClaimSourceIndex];
            string requestUrl = groupClaimsSource.endpoint + "?api-version=1.6"; // + ConfigHelper.GraphApiVersion;

            // Prepare and Make the POST request
            HttpClient client = new HttpClient();
            HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, requestUrl);
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", ""); // result.AccessToken);
            StringContent content = new StringContent("{\"securityEnabledOnly\": \"false\"}");
            content.Headers.ContentType = new MediaTypeHeaderValue("application/json");
            request.Content = content;
            HttpResponseMessage response = await client.SendAsync(request);

            // Endpoint returns JSON with an array of Group ObjectIDs
            if (response.IsSuccessStatusCode)
            {
                string responseContent = await response.Content.ReadAsStringAsync();
                var groupsResult = (Json.Decode(responseContent)).value;

                foreach (string groupObjectID in groupsResult)
                    groupObjectIds.Add(groupObjectID);
            }
            else
            {
                throw new WebException();
            }

            return groupObjectIds;
        }
        public async Task<string> GetUserAccessTokenAsyncNew()
        {

            // Initialize the cache.
            HttpContextWrapper httpContext = new HttpContextWrapper(HttpContext.Current);
            var tokenCache = new SessionTokenCache(ClaimsPrincipal.Current.FindFirst(ClaimTypes.NameIdentifier).Value, httpContext).GetMsalCacheInstance();
            //var cachedItems = tokenCache.ReadItems(appId); // see what's in the cache

            string[] segments = httpContext.Request.Path.Split(new char[] { '/' });


            ConfidentialClientApplication idClient = new ConfidentialClientApplication(AzureAdConfig.ClientId,
                PowerBiConfig.PowerBiAuthorityUri,
                new Microsoft.Identity.Client.ClientCredential(AzureAdConfig.ClientSecret), tokenCache, null);

            ConfidentialClientApplication cca = new ConfidentialClientApplication(
                AzureAdConfig.ClientId, PowerBiConfig.RedirectUrl, new Microsoft.Identity.Client.ClientCredential(AzureAdConfig.ClientSecret),
                tokenCache,
                null);
            var accounts = await cca.GetAccountsAsync();


            string[] scopes = AzureAdConfig.AzureGraphScopes.Split(new char[] { ' ' });
            try
            {
                var result = await cca.AcquireTokenSilentAsync(scopes, accounts.FirstOrDefault());
                return result.AccessToken;
            }

            // Unable to retrieve the access token silently.
            catch (Exception ex)
            {
                throw new ServiceException(
                    new Error
                    {
                        Code = GraphErrorCode.AuthenticationFailure.ToString(),
                        Message = "Error"
                    });
            }
        }
        #endregion
    }
}
