﻿using System.Collections.Generic;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Business
{
    public class NotesModule : INotesModule
    {
        private static INotes _notes { get; set; }
        public NotesModule(INotes notes)
        {
            _notes = notes;
        }

        public IList<Notes> Save(Notes notes)
        {
            if (notes == null && string.IsNullOrEmpty(notes.Notedesc)) return null;
            return _notes.SaveNotes(notes);
        }

        public IList<Notes> Fetch(string Bagtag, string Flightnumber, string Organization)
        {
            return _notes.FetchNotes(Bagtag, Flightnumber, Organization);
        }

        public IList<Notes> DeleteNotes(int notesId, string Bagtag, string Flightnumber, string Organization)
        {
            return _notes.DeleteNotes(notesId, Bagtag, Flightnumber, Organization);
        }
    }
}
