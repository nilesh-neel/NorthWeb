﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Interface;
using System.Web.Mvc;
using Heathrow.BPM.Web.ViewModel;

namespace Heathrow.BPM.Web.Controllers
{
    [Authorize]
    public class AssignHomePageController : BaseController
    {
        private readonly IAssignHomePage _assignHomPageModule;

        public AssignHomePageController(IAssignHomePage assign)
        {
            _assignHomPageModule = assign;
            //  Map = _map;

        }
        public ActionResult Index()
        {

            return View("AssignHomePage");
        }

        public ActionResult AssignHomePageView()
        {

            return PartialView("_AssignHomePage");
        }
        /* public ActionResult Get()
         {
              return Json(
                Map.MapFrom(_assignHomPageModule.Get()),
                JsonRequestBehavior.AllowGet);
         }*/
    }
}