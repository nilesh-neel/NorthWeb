﻿/****************************************************************************************************************
Class Name   : Global.cs 
Purpose      : This is the mail startup file in the application. To handle all startup even in web app like
               Dependency injection, Route config / web api registrations etc...
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System.Web.Mvc;
using Heathrow.BPM.Web.ViewModel;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Web.Controllers
{
    [Authorize]
    public class ShareController : BaseController
    {
        private readonly IShareModule _shareModule;
        private readonly IMapper<ShareVM, Share> _map;

        public ShareController(IShareModule shareObj, IMapper<ShareVM, Share> map)
        {
            //shareModule = new ShareModule();
            _shareModule = shareObj;
            _map = map;
            //Map = _map;
        }

        // GET: Share
        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public ActionResult Share()
        {
            var shareResponse = _shareModule.GetAudienceGrp();
            // var obj = Map.MapFrom(shareModule.GetAudienceGrp());
            var response = Json(shareResponse, JsonRequestBehavior.AllowGet);
            return response;
        }

        [OutputCache(NoStore = true, Duration = 0)]
        [HttpPost]
        public ActionResult GetRecipients(int GroupId)
        {
            var shareResponse = _shareModule.GetGrpRecipients(GroupId);
            // var obj = Map.MapFrom(shareModule.GetAudienceGrp());
            var response = Json(shareResponse, JsonRequestBehavior.AllowGet);
            return response;
        }
    }
}