﻿


var StandardMessage = (function () {



    StandardMessage = function () {
        this.message = msg;
        this.colorCode = color;

    }
    StandardMessage.prototype.alert = function () {
        $('.refreshMessage').children(':first').text(this.message);
        $(".refreshMessage").css('background-color', this.colorCode);
        $(".refreshMessage").css('display', 'block');
    };



    return StandardMessage;

});

(function () {
    Message.prototype = Object.create(StandardMessage.prototype);
    Message.prototype.constructor = Message;
    Message.prototype._super = StandardMessage;
})();

var Message = function () {

    Message = function (message, colorCode) {
        this._super.call(this, message, colorCode);
    }


    StandardMessage.prototype.info = function (message) {
        this._super.call(this, message, '#31708f');
        this._super.alert.call(this);
    };

    StandardMessage.prototype.warning = function () {
        $(".refreshMessage").css('background-color', '#FBC153');
        $(".refreshMessage").css('display', 'block');
    };

    StandardMessage.prototype.success = function () {
        $(".refreshMessage").css('background-color', '#A5CB68');
        $(".refreshMessage").css('display', 'block');
    };

    StandardMessage.prototype.error = function () {
        $(".refreshMessage").css('background-color', '#E4384A');
        $(".refreshMessage").css('display', 'block');
    };


}



