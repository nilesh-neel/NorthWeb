﻿'use strict';
var Utility =
    {
        isNullOrEmpty: function (variable) {
            if (variable !== null && typeof (variable) !== 'null' && typeof (variable) !== NaN && typeof (variable) !== 'undefined' && $.trim(variable).length > 0) {
                return false;
            }

            return true;
        },

        // This a common method to make ajax calls without parameter
        makeAjaxCallWithoutParameter: function (actionUrl, requestType, successCallback, errorCallback) {
            $.ajax({
                url: actionUrl,
                type: requestType,
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                async: false,
                success: function (response) {
                    if (!Utility.isNullOrEmpty(response)) {
                        if (successCallback !== undefined && successCallback !== null) {
                            successCallback(response);
                        }
                    }
                },
                error: function (xhr) {
                    if (!Utility.isNullOrEmpty(errorCallback)) {
                        errorCallback(xhr);
                    }
                }
            });
        },

        makeAjaxCall: function (actionUrl, requestType, postData, successCallback, errorCallback) {
            //  var validationMessage = "";
            if (!Utility.isNullOrEmpty(postData)) {
                $.ajax({
                    cache: false,
                    url: actionUrl,
                    type: requestType,
                    dataType: 'json',
                    data: postData,
                    contentType: 'application/json; charset=utf-8',
                    async: false,
                    success: function (data) {
                        if (!Utility.isNullOrEmpty(data.result)) {

                            successCallback(data);

                        }
                    },
                    error: function (xhr) {
                        if (!Utility.isNullOrEmpty(errorCallback)) {
                            errorCallback(xhr);
                        }
                    }
                });
            }

        },

        //This will add values to the dropdown list
        addValuesToDropDown: function ($dropDown, values) {
            $.each(values, function (key, property) {
                $dropDown.append($('<option></option>').attr('value', property.ID).text(property.Name));
            });

        },

        SetValuesToDropDown: function ($dropDown, values) {
            if (values !== null) {
                var controlSelector = '#' + $dropDown[0].id + ' + span';
                $('controlSelector').find('option').attr('selected', false);
                $(controlSelector).children('input').val(values);
            }

        },

        bindMultiDropDown: function ($dropDown, values) {

            var controlName = '#' + $dropDown[0].id;
            var newOptions = [];
            for (var i = 0; i < values.length; i++) {
                newOptions.push(
                    {
                        name: values[i].Name,
                        value: values[i].ID,
                        checked: false
                    });
            }
            $(controlName).multiselect('loadOptions', newOptions);

            $(controlName).multiselect('refresh');
        },

        addValuesToMultiSelectDropDown: function ($dropDown, selectedvalues) {

            if (selectedvalues !== null) {
                var controlName = '#' + $dropDown[0].id;
                var selectedOptions = selectedvalues.split(',');
                for (var i in selectedOptions) {
                    var optionVal = selectedOptions[i];
                    $(controlName).find('option[value=' + optionVal + ']').prop('selected', 'selected');
                }
                $(controlName).multiselect('reload');
            }
        },

        // This is common method for making ajax calls without parameters to get html data and load. 
        getPartialView: function (actionUrl, successCallback, errorCallback) {
            $.ajax({
                url: actionUrl,
                type: 'GET',
                contentType: RequestContentType,
                success: function (data) {
                    if (!Utility.isNullOrEmpty(successCallback)) {
                        successCallback(data);
                    }
                },
                error: function (xhr) {

                    if (!Utility.isNullOrEmpty(errorCallback)) {
                        errorCallback();
                    }
                    else {
                        //  Utility.checkAndRedirect(xhr);
                    }
                }
            });
        },

        textSearchFilter: function (controlField, filterList) {
            var controlID = '#' + controlField[0].id;

            $(function () {

                function split(val) {
                    return val.split(/,\s*/);
                }
                function extractLast(term) {
                    return split(term).pop();
                }

                $(controlID)
                    // don't navigate away from the field on tab when selecting an item
                    .on('keydown', function (event) {
                        if (event.keyCode === $.ui.keyCode.TAB &&
                            $(this).autocomplete('instance').menu.active) {
                            event.preventDefault();
                        }
                    })
                    .autocomplete({
                        minLength: 2,
                        source: function (request, response) {
                            // delegate back to autocomplete, but extract the last term
                            response($.ui.autocomplete.filter(
                                filterList, extractLast(request.term)));
                        },
                        focus: function () {
                            // prevent value inserted on focus
                            return false;
                        },
                        select: function (event, ui) {
                            var terms = split(this.value);
                            // remove the current input
                            terms.pop();
                            // add the selected item
                            terms.push(ui.item.value);
                            // add placeholder to get the comma-and-space at the end
                            terms.push('');
                            this.value = terms.join(', ');
                            return false;
                        }
                    });
            });
        },

        multiDropDownConfiguration: function (controlName) {
            $(controlName).multiselect({
                columns: 1,
                placeholder: 'Select',
                search: false,

                texts: {
                    placeholder: 'Select options', // text to use in dummy input
                    // search: 'Type here',         // search input placeholder text
                    selectedOptions: ' selected',      // selected suffix text
                    selectAll: 'Select all',     // select all text
                    unselectAll: 'Unselect all',   // unselect all text
                    noneSelected: 'None Selected'   // None selected text

                },
                minHeight: 150,   // minimum height of option overlay
                maxHeight: 150,  // maximum height of option overlay
                maxWidth: 245,
                selectAll: false,

            });
        },

        fillAutoCompleteList: function (sourceList, valueList) {
            $.each(valueList, function (key, control) {
                sourceList.push(control.Text);
            });
        },
        SpecialCharacterValidation: function (event) {
            var regex = new RegExp('^[a-zA-Z0-9,]+$');
            var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
            if (!regex.test(key)) {
                event.preventDefault();
                return false;
            }
        },

        RequestType:
            {
                Get: 'GET',
                Post: 'POST',
                Delete: 'DELETE'
            },

        QueryStringToJSON: function () {
            var pairs = decodeURIComponent(location.search).slice(1).split('&');

            var result = {};
            pairs.forEach(function (pair) {
                pair = pair.split('=');
                result[pair[0]] = decodeURIComponent(pair[1] || '');
            });

            return JSON.parse(JSON.stringify(result));
        },
    };