﻿var Notifications = (function () {

    'use strict';

    var service;
    var msg = new StandardMessage("msg");
    Notifications = function () {

    };
    Notifications.prototype.LoadNotificationLandingPage = function () {
      //  $('#dvPowerBiEmbed').hide();
       // $('#viewContainer').show();
        this.bindTodayNotification();
    
    }

    Notifications.prototype.bindTodayNotification = function () {
       
        service = new Service('/Notifications/GetTodaysNotification', 'application/html; charset=utf-8', 'html', null);
        service.get()
            .then(function (resp) {
                var todayNotificationData = _.map(resp, function (x) {
                    return {
                        Description: x.description,
                        Time: moment(x.createdDate).format('LLL'),
                        Topic: _.chain(x.topic).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        Locations: _.chain(x.location).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        View: '<span class="Show_details  defaultIcons"></span>'
                    };
                });

                var column = [
                    { "data": "Description" },
                    { "data": "Topic" },
                    { "data": "Locations" },   
                    { "data": "Time" },                                
                    { "data": "View" }
                ];
                var grid = new CustomGrid('#todaysNotificationTable', todayNotificationData, column, true);
                grid.CreateGrid(true);

            })
            .catch(function (jqXHR, textStatus, err) {
                alert('Error : ' + err + " " + textStatus);
            });
    }


    /* This  method use to bind the My Notification Settings Tab
            *  */
    Notifications.prototype.bindMyNotificationSettings = function () {
        service = new Service('/Notifications/GetTodaysNotification', 'application/html; charset=utf-8', 'html', null);
        service.get()
            .then(function (resp) {
                var myNotificationData = _.map(resp, function (x) {
                    return {
                        NotificationId: x.notificationId,
                        Description: x.description,                       
                        Topic: _.chain(x.topic).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        Locations: _.chain(x.location).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        View: '<span class="Show_details  defaultIcons"></span><span class="Edit  defaultIcons"></span>'
                    };
                });

                var column = [
                    { "data": "NotificationId" },
                    {"data":"Description"},
                    { "data": "Topic" },
                    { "data": "Locations" },                    
                    { "data": "View" }
                ];

                var grid = new CustomGrid('#notificationSettingsTable', myNotificationData, column, true, true);
               
                grid.CreateGrid(false,true);

            })
            .catch(function (jqXHR, textStatus, err) {
                console.log(jqXHR.stack);
                alert('Error : ' + jqXHR.message + " " + textStatus);
            });
    }

    Notifications.prototype.bindConfigureNotifications = function () {
        service = new Service('/Notifications/GetTodaysNotification', 'application/html; charset=utf-8', 'html', null);  
        service.get()
            .then(function (resp) {
                var configureNotificationData = _.map(resp, function (x) {
                    return {
                        NotificationId: x.notificationId,
                        Description: x.description.substring(0,20),
                        Topic: _.chain(x.topic).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        Locations: _.chain(x.location).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),

                        Created: moment(x.createdDate).format(" DD/MM/YYYY"),
                        End: moment(x.endDate).format(" DD/MM/YYYY"),
                        Disable: '<td><label class="container"  class="textLabel"><input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td>',
                        Modified: moment(x.modifiedDate).format(" DD/MM/YYYY, hh:mm"),
                        ModifiedBy: x.modifiedBy,
                        View: '<span class="Show_details defaultIcons"></span><span class="Edit  defaultIcons"></span>',
                        Audience: _.chain(x.audienceGroup).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        Recipients:_.chain(x.recipients).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        Additional: _.chain(x.measureName).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value(),
                        CreatedBy: x.createdBy
                                         
                    };
                });

                var column = [
                    { "data": "NotificationId"},
                    { "data": "Description" },
                    { "data": "Topic" },
                    { "data": "Locations" },
                    { "data": "Created" },
                    { "data": "End" },
                    { "data": "Disable" },
                    { "data": "Modified" },
                    { "data": "ModifiedBy" },
                    { "data": "View" }
                ];

                var grid = new CustomGrid('#ConfigureNotificationTable', configureNotificationData, column, true, true);

                grid.CreateGrid(false, true);
            })
            .catch(function (jqXHR, textStatus, err) {
                alert('Error : ' + err + " " + textStatus);
            });
    }

   

    Notifications.prototype.updateConfigureNotifications = function () {
        
        alert('in notif');
        var s = msg.successful();
      //  "<div class=\"refreshMessage\">< div > " + s + "</div><div class=\"closeText defaultIcons\"></div></div>"
      
      //  service = new Service('/Notifications/Update', 'application/html; charset=utf-8', 'html', null);
         // Message.prototype.success.call(this, "Data fetch success");
     //  return service.update();
                         
    }
    return Notifications;

})();

