﻿//----------------------------------------------------------------------
//Class Name   : Menu 
//Purpose      : Dashboard Controller file use to load first default power bi dashboard/report. 
//               Whit this ajax call we can achive promise in javascripts. 
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

(function () {
    'use strict';
    $(document).ready(function () {


        var intervalId;
        var dashboardPowerBiApi = new PowerBIAPP(null, 'true');
        dashboardPowerBiApi.embedPowerBIApi();
        /***
        //ToDo:
        *The demo refresh rate(15 Second)set for the testing purpose.It may be crash with actual power bi report refresh call.
       */
        $('#spnAutoUpdate').on('click', function () {
            var self = $(this);
            if (self.data('update') === true) {

                var powerBiUrl = sessionStorage.getItem('autoRefURL');
                var isReport = sessionStorage.getItem('autoRefURLIsReport');

                intervalId = setInterval(function () {
                    console.log('Interval 15 seconds call..');
                    if (!_.isNull(powerBiUrl)) {
                        dashboardPowerBiApi = new PowerBIAPP(powerBiUrl, isReport);
                        dashboardPowerBiApi.embedPowerBIApi();

                    } else {
                        dashboardPowerBiApi.refreshReport();
                    }
                    $('#divDate').html(moment().format(' DD/MM/YYYY, hh:mm:ss'));
                }, 15000);
                self.data('update', false);
            } else {
                console.log('Interval 15 seconds call clear..');
                clearInterval(intervalId);
                self.data('update', true);
            }
        });

        $('.print').on('click', function () {
            dashboardPowerBiApi.printReport();
        });


        $('.drillReportli>a').on('click', function () {
            debugger;
            dashboardPowerBiApi.reportDetails();
        });

    });

})();