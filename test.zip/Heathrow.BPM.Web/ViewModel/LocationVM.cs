﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Web.ViewModel
{
    public class LocationVM
    {
        public int locationID { get; set; }
        public string locationDesc { get; set; }
       // public List<LocationVM> Locations { get; set; }
    }
    /* public class LocationMapping : IMapper<LocationVM, Location>
     {
         public LocationVM MapFrom(Location _input)
         {
             return BindCoreToViewModel(_input);
         }


         public IEnumerable<LocationVM> MapFrom(IEnumerable<Location> _input)
         {
             return _input.Select(x => BindCoreToViewModel(x));
         }

         public Location MapTo(LocationVM _input)
         {
             return BindViewModelToCore(_input);
         }

         public IEnumerable<Location> MapTo(IEnumerable<LocationVM> _input)
         {
             return _input.Select(x => BindViewModelToCore(x));
         }

         private static List<LocationVM> BindCoreToViewModel(List<Location> _input)
         {
             return (from loc in _input
                     select (new LocationVM()
                     {
                         locationID = loc.LocationID,
                         locationDesc = loc.LocationDescription
                     })).ToList();
         }
         private static List<Location> BindViewModelToCore(List<LocationVM> _input)
         {
             return (from loc in _input
                     select (new Location()
                     {
                         LocationID = loc.locationID,
                         LocationDescription = loc.locationDesc
                     })).ToList();
         }
     }
     */
    public class LocationMapping : IMapper<LocationVM, Location>
    {
        public LocationVM MapFrom(Location _input)
        {
            return BindCoreToViewModel(_input);
        }

        public IEnumerable<LocationVM> MapFrom(IEnumerable<Location> _input)
        {
            return _input.Select(x => BindCoreToViewModel(x));
        }

        public Location MapTo(LocationVM _input)
        {
            return BindViewModelToCore(_input);
        }

        public IEnumerable<Location> MapTo(IEnumerable<LocationVM> _input)
        {
            return _input.Select(x => BindViewModelToCore(x));
        }

        private static LocationVM BindCoreToViewModel(Location _input)
        {
            return new LocationVM()
            {
                locationID = _input.LocationID,
                locationDesc = _input.LocationDescription,
               
            };
        }

        private static Location BindViewModelToCore(LocationVM _input)
        {
            return new Location()
            {
                LocationID = _input.locationID,
                LocationDescription = _input.locationDesc,
              
            };
        }
    }

}