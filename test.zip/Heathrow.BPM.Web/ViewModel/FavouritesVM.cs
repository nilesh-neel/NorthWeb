﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Heathrow.BPM.Web.ViewModel
{
    public class FavouritesVM
    {

        public int favouriteId { get; set; }

        public string userId { get; set; }
        [Required]
        public string url { get; set; }
        public string description { get; set; }
        [Required]
        public int menuId { get; set; }
        public bool isReport { get; set; }
    }

    public class FavouriteMapping : IMapper<FavouritesVM, Favourites>
    {
        public FavouritesVM MapFrom(Favourites _input)
        {
            return BindCoreToViewModel(_input);
        }


        public IEnumerable<FavouritesVM> MapFrom(IEnumerable<Favourites> _input)
        {
            return _input.Select(x => BindCoreToViewModel(x));
        }

        public Favourites MapTo(FavouritesVM _input)
        {
            return BindViewModelToCore(_input);
        }

        public IEnumerable<Favourites> MapTo(IEnumerable<FavouritesVM> _input)
        {
            return _input.Select(x => BindViewModelToCore(x));
        }

        private static FavouritesVM BindCoreToViewModel(Favourites _input)
        {
            return new FavouritesVM()
            {

                favouriteId = _input.FavouriteId,
                menuId = _input.FavouriteLink.MenuId,
                description = _input.FavouriteLink.Description,
                url = _input.FavouriteLink.MenuUrl,
                userId = _input.UserId,
                isReport = _input.FavouriteLink.IsReport
            };
        }

        private static Favourites BindViewModelToCore(FavouritesVM _input)
        {
            return new Favourites()
            {

                FavouriteId = _input.favouriteId,
                UserId = _input.userId,
                FavouriteLink = new Menu()
                {
                    MenuId = _input.menuId,
                    Description = _input.description,
                    MenuUrl = Convert.ToString(_input.url),
                    IsReport = Convert.ToBoolean(_input.isReport)
                }
            };
        }
    }

}