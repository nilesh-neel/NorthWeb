﻿/****************************************************************************************************************
Class Name   : IRegistrationModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System.Collections.Generic;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Business
{
    public class LocationModule : ILocationModule
    {
       
        private static ILocation _location { get; set; }
        public LocationModule( ILocation location)
        {
            
            _location = location;
        }

        public IEnumerable<Location> GetAllLocation()
        {
            return _location.GetLocation();
        }
    }
}
