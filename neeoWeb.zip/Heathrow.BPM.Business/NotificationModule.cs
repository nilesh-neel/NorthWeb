﻿/****************************************************************************************************************
Class Name   : NotificationModule.cs 
Purpose      : This class use to inject the dependency of DataAccess Layer, which is not reference in to the web application project.
Created By   : Nilesh More 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System.Collections.Generic;
using System.Linq;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Business
{
    public class NotificationModule : INotificationModule
    {

        private static ILookup Lookup { get; set; }

        private static INotification NotificationRepository { get; set; }
        public NotificationModule(INotification notification, ILookup lookup)
        {
            NotificationRepository = notification;
            Lookup = lookup;
        }

        public int Save(Notification notification)
        {
            return NotificationRepository.Save(notification);
        }

        public IEnumerable<Notification> GetNotificationById(string notificationId)
        {
            //Get from repository based on id for topic,tip of the day
            //  _lookup.GetLookupDetailsById(TopicID);
            // _lookup.GetLookupDetailsById(TipID);

            var obj = NotificationRepository.GetNotificationByNotificationId(notificationId);
           foreach(var item in obj)
            {
                var topicList = Lookup.GetLookupDetailsById(2).Select(lookupEnt => lookupEnt.LookupTypeName).ToList();
              //  item.Topic = GetLookupItemName();


            }
            return NotificationRepository.GetNotificationByNotificationId(notificationId);
        }


        //get Todays Notification
        public IEnumerable<Notification> GetTodaysNotification()
        {       
            return NotificationRepository.GetTodaysNotification();
        }
    }
}
