﻿/****************************************************************************************************************
Class Name   : UserModule.cs 
Purpose      : This class use to fetch the login in user details for the azure ad with use of azure graph services.
Created By   : Nilesh More 
Created Date : 10/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using Heathrow.BPM.Business.Infrastructure;
using Heathrow.BPM.Core.Entity;
using Newtonsoft.Json.Linq;
using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using Heathrow.BPM.Business.Interface;
using Microsoft.Identity.Client;


namespace Heathrow.BPM.Business
{
    public class UserModule : IUserModule
    {
        public UserModule()
        {
        }

        public async Task<string> GetUserAccessTokenAsync()
        {

            string signedInUserId = ClaimsPrincipal.Current.FindFirst(ClaimTypes.NameIdentifier).Value;
            HttpContextWrapper httpContext = new HttpContextWrapper(HttpContext.Current);
            Microsoft.Identity.Client.TokenCache userTokenCache = new SessionTokenCache(signedInUserId, httpContext).GetMsalCacheInstance();
            //var cachedItems = tokenCache.ReadItems(appId); // see what's in the cache

            ConfidentialClientApplication cca = new ConfidentialClientApplication(
               AzureAdConfig.ClientId, AzureAdConfig.AadAuthorityUri, new Microsoft.Identity.Client.ClientCredential(AzureAdConfig.ClientSecret),
                userTokenCache,
                null);
            try
            {
                Microsoft.Identity.Client.AuthenticationResult result = await cca.AcquireTokenForClientAsync(AzureAdConfig.AzureGraphScopes.Split(new char[] { ' ' }));
                //Microsoft.Identity.Client.AuthenticationResult result = await cca.AcquireTokenForClientAsync(AzureADConfig.AzureGraphScopes.Split(new char[] { ' ' }));
                return result.AccessToken;
            }

            // Unable to retrieve the access token silently.
            catch (Exception ex)
            {
                //HttpContext.Current.Request.GetOwinContext().Authentication.Challenge(
                //    new AuthenticationProperties() { RedirectUri = "/" },
                //    OpenIdConnectAuthenticationDefaults.AuthenticationType);

                throw ex;
            }
        }


        // Get the current user's email address from their profile.
        public async Task<string> GetMyEmailAddress(string accessToken)
        {

            // Get the current user. 
            // The app only needs the user's email address, so select the mail and userPrincipalName properties.
            // If the mail property isn't defined, userPrincipalName should map to the email for all account types. 
            string endpoint = "https://graph.microsoft.com/v1.0/me";
            string queryParameter = "?$select=mail,userPrincipalName";
            AzureUserInfo me = new AzureUserInfo();


            using (var client = new HttpClient())
            {
                using (var request = new HttpRequestMessage(HttpMethod.Get, endpoint + queryParameter))
                {
                    request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                    // This header has been added to identify our sample in the Microsoft Graph service. If extracting this code for your project please remove.
                    request.Headers.Add("SampleID", "aspnet-connect-rest-sample");

                    using (var response = await client.SendAsync(request))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            var json = JObject.Parse(await response.Content.ReadAsStringAsync());
                            me.Address = !string.IsNullOrEmpty(json.GetValue("mail").ToString()) ? json.GetValue("mail").ToString() : json.GetValue("userPrincipalName").ToString();
                        }
                        return me.Address?.Trim();
                    }
                }
            }
        }
        public async Task<string> GetUserDetailsFromAzureServer(string accessToken)
        {

            // Get the current user. 
            // The app only needs the user's email address, so select the mail and userPrincipalName properties.
            // If the mail property isn't defined, userPrincipalName should map to the email for all account types. 
            string endpoint = "https://graph.microsoft.com/v1.0/me";
            string queryParameter = "?$select=mail,userPrincipalName";
            AzureUserInfo me = new AzureUserInfo();


            using (var client = new HttpClient())
            {
                using (var request = new HttpRequestMessage(HttpMethod.Get, endpoint))
                {
                    request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                    // This header has been added to identify our sample in the Microsoft Graph service. If extracting this code for your project please remove.
                    request.Headers.Add("SampleID", "aspnet-connect-rest-sample");

                    using (var response = await client.SendAsync(request))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            //                            var json = JObject.Parse(await response.Content.ReadAsStringAsync());
                            // me.Address = !string.IsNullOrEmpty(json.GetValue("displayName").ToString()) ? json.GetValue("displayName").ToString() : json.GetValue("givenName").ToString();
                            return await response.Content.ReadAsStringAsync();
                        }
                        return null;
                    }
                }
            }
        }


        public async Task<Stream> GetUserProfilePhoto(string accessToken)
        {

            // Get the profile photo of the current user (from the user's mailbox on Exchange Online). 
            // This operation in version 1.0 supports only a user's work or school mailboxes and not personal mailboxes. 
            //string endpoint = "https://graph.microsoft.com/v1.0/me/photo/$value";
            string endpoint = "https://graph.microsoft.com/v1.0/me/drive/root/children/mypic.jpg/content";

            using (var client = new HttpClient())
            {
                using (var request = new HttpRequestMessage(HttpMethod.Get, endpoint))
                {
                    //request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                    var response = await client.SendAsync(request);

                    // If successful, Microsoft Graph returns a 200 OK status code and the photo's binary data. If no photo exists, returns 404 Not Found.
                    if (response.IsSuccessStatusCode)
                    {
                        return await response.Content.ReadAsStreamAsync();
                    }
                    else
                    {
                        // If no photo exists, the sample uses a local file.
                        return File.OpenRead(System.Web.Hosting.HostingEnvironment.MapPath("/Content/test.jpg"));
                    }
                }
            }
        }
    }
}
