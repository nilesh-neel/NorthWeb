﻿/****************************************************************************************************************
Class Name   : PowerBiModule.cs 
Purpose      : Account Controller use to login and logout user from the application.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/



using System.Web;
using System.Text;
using Heathrow.BPM.Business.Infrastructure;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;

using Newtonsoft.Json;

using Newtonsoft.Json.Linq;
using System;
using System.Collections.Specialized;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Threading.Tasks;


using Microsoft.Identity.Client;
using Microsoft.Rest;
using Microsoft.PowerBI.Api.V2;
using Microsoft.PowerBI.Api.V2.Models;
using System.Collections.Generic;


namespace Heathrow.BPM.Business
{
    public class PowerBiModule : IBpmPowerBi
    {

        public string AADAuthorityUri { get; set; }

        public PowerBiModule()
        {

        }
        public NameValueCollection GetAuthorizationCode()
        {
            AADAuthorityUri = AzureAdConfig.AadAuthorityUri;
            return new NameValueCollection
            {
                //Azure AD will return an authorization code. 
                {"response_type", "code"},

                //Client ID is used by the application to identify themselves to the users that they are requesting permissions from. 
                //You get the client id when you register your Azure app.
                {"client_id",AzureAdConfig.ClientId},

                //Resource uri to the Power BI resource to be authorized
                //The resource uri is hard-coded for sample purposes
                {"resource", PowerBiConfig.PowerBiApiResource},

                //After app authenticates, Azure AD will redirect back to the web app. In this sample, Azure AD redirects back
                //to Default page (Default.aspx).
                { "redirect_uri", PowerBiConfig.RedirectUrl}
            };
        }

        public string RedirectOnAuthentication(string authorizationCode)
        {

            //if (authorizationCode != null)
            //{
            //    // Get auth token from auth code       
            //    var TC = new Microsoft.IdentityModel.Clients.ActiveDirectory.TokenCache();

            //    AuthenticationContext AC = new AuthenticationContext(PowerBIConfig.PowerBiAuthorityUri, TC);
            //    var cc = new Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential(AzureADConfig.ClinetId, AzureADConfig.ClientSecret);

            //    return AC.AcquireTokenByAuthorizationCode(authorizationCode, new Uri(PowerBIConfig.DashboardRedirectUrl), cc).AccessToken;
            //}
            //else { return null; }
            return "";

        }

        public string GetDashboardDetails(string accessToken)
        {
            string responseContent = string.Empty;

            //Configure dashboards request
            System.Net.WebRequest request = System.Net.WebRequest.Create(String.Format("{0}dashboards", PowerBiConfig.PowerBiDataset)) as System.Net.HttpWebRequest;
            request.Method = "GET";
            request.ContentLength = 0;
            request.Headers.Add("Authorization", String.Format("Bearer {0}", Convert.ToString(accessToken)));

            //Get dashboards response from request.GetResponse()
            using (var response = request.GetResponse() as System.Net.HttpWebResponse)
            {
                //Get reader from response stream
                using (var reader = new System.IO.StreamReader(response.GetResponseStream()))
                {
                    responseContent = reader.ReadToEnd();

                }
            }
            return responseContent ?? "";
        }


        //private static async Task<string> GetUserInfo(string tenantId, string userId, string token)
        //{
        //    //Fixed 401 from previous build - newer Graph API in use now
        //    string graphRequest = $"https://graph.windows.net/{tenantId}/users/{userId}?api-version=1.6";
        //    HttpClient client = new HttpClient();

        //    client.DefaultRequestHeaders.Authorization = new Windows.Web.Http.Headers.HttpCredentialsHeaderValue("Bearer", token);
        //    var response = await client.GetAsync(new Uri(graphRequest));

        //    string content = await response.Content.ReadAsStringAsync();
        //    //  var user = JsonConvert.DeserializeObject<AADUser>(content);
        //    return content;
        //}

        protected void GetReportDetails()
        {
            var workspaceId = PowerBiConfig.WorkspaceId;
            var reportId = PowerBiConfig.ReportId;
            var powerBiApiUrl = PowerBiConfig.PowerBiApiUrl;

            //using (var client = new PowerBIClient(new Uri(powerBiApiUrl), new TokenCredentials(Convert.ToString(Session["AccessToken"]), "Bearer")))
            //{
            //    Report report;

            //    //// Settings' workspace ID is not empty
            //    if (!string.IsNullOrEmpty(WorkspaceId))
            //    {
            //        // Gets a report from the workspace.
            //        report = GetReportFromWorkspace(client, WorkspaceId, reportId);
            //    }
            //    // Settings' report and workspace Ids are empty, retrieves the user's first report.
            //    else if (string.IsNullOrEmpty(reportId))
            //    {
            //        var test = client.Reports.GetReports();
            //        report = client.Reports.GetReports().Value.FirstOrDefault();
            //        AppendErrorIfReportNull(report, "No reports found. Please specify the target report ID and workspace in the applications settings.");
            //    }
            //    // Settings contains report ID. (no workspace ID)
            //    else
            //    {
            //        // report = client.Reports.GetReports().Value;
            //        report = client.Reports.GetReports().Value.FirstOrDefault(r => r.Id == reportId);
            //        AppendErrorIfReportNull(report, string.Format("Report with ID: '{0}' not found. Please check the report ID. For reports within a workspace with a workspace ID, add the workspace ID to the application's settings", reportId));
            //    }

            //    if (report != null)
            //    {
            //        List<Report> reports = new List<Report>();
            //        reports.Add(report);

            //        return reports.ToList();
            //    }
            //    return null;
            //}
        }

        public async Task<string> GetUserAccessTokenAsync()
        {
            //string signedInUserId = ClaimsPrincipal.Current.FindFirst(ClaimTypes.NameIdentifier).Value;
            //HttpContextWrapper httpContext = new HttpContextWrapper(HttpContext.Current);
            //Microsoft.Identity.Client.TokenCache userTokenCache = new SessionTokenCache(signedInUserId, httpContext).GetMsalCacheInstance();
            ////var cachedItems = tokenCache.ReadItems(appId); // see what's in the cache

            //ConfidentialClientApplication cca = new ConfidentialClientApplication(
            //   AzureAdConfig.ClientId, PowerBiConfig.PowerBiApiResource, new Microsoft.Identity.Client.ClientCredential(AzureAdConfig.ClientSecret),
            //    userTokenCache,
            //    null);
            //try
            //{
            //    Microsoft.Identity.Client.AuthenticationResult result = await cca.AcquireTokenSilentAsync(AzureAdConfig.AzureGraphScopes.Split(new char[] { ' ' }), cca.Users.First());
            //    //Microsoft.Identity.Client.AuthenticationResult result = await cca.AcquireTokenForClientAsync(AzureADConfig.AzureGraphScopes.Split(new char[] { ' ' }));
            //    return result.AccessToken;
            //}

            //// Unable to retrieve the access token silently.
            //catch (Exception ex)
            //{
            //    //HttpContext.Current.Request.GetOwinContext().Authentication.Challenge(
            //    //    new AuthenticationProperties() { RedirectUri = "/" },
            //    //    OpenIdConnectAuthenticationDefaults.AuthenticationType);

            //    throw ex;
            //}
            return null;
        }


        // Get the current user's email address from their profile.
        public async Task<string> GetMyEmailAddress(string accessToken)
        {

            // Get the current user. 
            // The app only needs the user's email address, so select the mail and userPrincipalName properties.
            // If the mail property isn't defined, userPrincipalName should map to the email for all account types. 
            string endpoint = "https://graph.microsoft.com/v1.0/me";
            string queryParameter = "?$select=mail,userPrincipalName";
            AzureUserInfo me = new AzureUserInfo();


            using (var client = new HttpClient())
            {
                using (var request = new HttpRequestMessage(HttpMethod.Get, endpoint + queryParameter))
                {
                    request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                    // This header has been added to identify our sample in the Microsoft Graph service. If extracting this code for your project please remove.
                    request.Headers.Add("SampleID", "aspnet-connect-rest-sample");

                    using (var response = await client.SendAsync(request))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            var json = JObject.Parse(await response.Content.ReadAsStringAsync());
                            me.Address = !string.IsNullOrEmpty(json.GetValue("mail").ToString()) ? json.GetValue("mail").ToString() : json.GetValue("userPrincipalName").ToString();
                        }
                        return me.Address?.Trim();
                    }
                }
            }
        }
        public async Task<string> GetUserDetailsFromAzureServer(string accessToken)
        {

            // Get the current user. 
            // The app only needs the user's email address, so select the mail and userPrincipalName properties.
            // If the mail property isn't defined, userPrincipalName should map to the email for all account types. 
            string endpoint = "https://graph.microsoft.com/v1.0/me";
            string queryParameter = "?$select=mail,userPrincipalName";
            AzureUserInfo me = new AzureUserInfo();


            using (var client = new HttpClient())
            {
                using (var request = new HttpRequestMessage(HttpMethod.Get, endpoint))
                {
                    request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                    // This header has been added to identify our sample in the Microsoft Graph service. If extracting this code for your project please remove.
                    request.Headers.Add("SampleID", "aspnet-connect-rest-sample");

                    using (var response = await client.SendAsync(request))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            //                            var json = JObject.Parse(await response.Content.ReadAsStringAsync());
                            // me.Address = !string.IsNullOrEmpty(json.GetValue("displayName").ToString()) ? json.GetValue("displayName").ToString() : json.GetValue("givenName").ToString();
                            return await response.Content.ReadAsStringAsync();
                        }
                        return null;
                    }
                }
            }
        }


        public async Task<Stream> GetUserProfilePhoto(string accessToken)
        {

            // Get the profile photo of the current user (from the user's mailbox on Exchange Online). 
            // This operation in version 1.0 supports only a user's work or school mailboxes and not personal mailboxes. 
            //string endpoint = "https://graph.microsoft.com/v1.0/me/photo/$value";
            string endpoint = "https://graph.microsoft.com/v1.0/me/drive/root/children/mypic.jpg/content";

            using (var client = new HttpClient())
            {
                using (var request = new HttpRequestMessage(HttpMethod.Get, endpoint))
                {
                    //request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                    var response = await client.SendAsync(request);

                    // If successful, Microsoft Graph returns a 200 OK status code and the photo's binary data. If no photo exists, returns 404 Not Found.
                    if (response.IsSuccessStatusCode)
                    {
                        return await response.Content.ReadAsStreamAsync();
                    }
                    else
                    {
                        // If no photo exists, the sample uses a local file.
                        return File.OpenRead(System.Web.Hosting.HostingEnvironment.MapPath("/Content/test.jpg"));
                    }
                }
            }
        }
        private static string _groupId = "ee94827c-74e3-4922-a353-6ad84244c177";
        public async Task<string> GetEmbadedToken()
        {
            try
            {
                var vals = new List<KeyValuePair<string, string>>
                {
                    new KeyValuePair<string, string>("grant_type", "password"),
                    new KeyValuePair<string, string>("scope", "openid"),
                    new KeyValuePair<string, string>("resource", "https://analysis.windows.net/powerbi/api"),
                    new KeyValuePair<string, string>("client_id", AzureAdConfig.ClientId),
                    new KeyValuePair<string, string>("client_secret", AzureAdConfig.ClientSecret),
                    new KeyValuePair<string, string>("username", PowerBiConfig.PowerBiUserName),
                    new KeyValuePair<string, string>("password", PowerBiConfig.PowerBiUserPassword)
                };
                string tenantId = AzureAdConfig.AzureAdTenant;
                string url = string.Format("https://login.windows.net/{0}/oauth2/token", tenantId);
                HttpClient hc = new HttpClient();
                HttpContent content = new FormUrlEncodedContent(vals);
                HttpResponseMessage hrm = hc.PostAsync(url, content).Result;
                string responseData = "";
                if (hrm.IsSuccessStatusCode)
                {
                    Stream data = await hrm.Content.ReadAsStreamAsync();
                    using (StreamReader reader = new StreamReader(data, Encoding.UTF8))
                    {
                        responseData = reader.ReadToEnd();
                    }
                }

                var accessToken = JsonConvert.DeserializeObject<AccessToken>(responseData).access_token;

                var tokenCredentials = new TokenCredentials(accessToken, "Bearer");


                using (var client = new PowerBIClient(new Uri(PowerBiConfig.PowerBiApiUrl), tokenCredentials))
                {
                    var grp = client.Groups.GetGroups().Value.ToList();
                    var reportListd = client.Reports.GetReportsInGroup("0fc4287c-461d-46bc-a2da-ec29f0962ab3");
                    EmbedToken embedToken = await client.Reports.GenerateTokenInGroupAsync(_groupId, "f7d642f8-6934-4e28-95f3-22efadb9a1fb", new GenerateTokenRequest(accessLevel: "View"));
                }


                return JsonConvert.DeserializeObject<AccessToken>(responseData).access_token;


            }
            catch (Exception ex)
            {

                throw ex;
            }


        }

        public async Task<Stream> GetMyProfilePhoto(string accessToken)
        {

            // Get the profile photo of the current user (from the user's mailbox on Exchange Online). 
            // This operation in version 1.0 supports only a user's work or school mailboxes and not personal mailboxes. 
            string endpoint = "https://graph.microsoft.com/v1.0/me/photo/$value";

            using (var client = new HttpClient())
            {
                using (var request = new HttpRequestMessage(HttpMethod.Get, endpoint))
                {
                    //request.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                    var response = await client.SendAsync(request);

                    // If successful, Microsoft Graph returns a 200 OK status code and the photo's binary data. If no photo exists, returns 404 Not Found.
                    if (response.IsSuccessStatusCode)
                    {
                        return await response.Content.ReadAsStreamAsync();
                    }
                    else
                    {
                        // If no photo exists, the sample uses a local file.
                        return File.OpenRead(System.Web.Hosting.HostingEnvironment.MapPath("/Content/test.jpg"));
                    }
                }
            }
        }
        private async void SetAccessToken()
        {
            //var credential = new UserPasswordCredential(PowerBiConfig.PowerBiUserName, PowerBiConfig.PowerBiUserPassword);

            //// Authenticate using created credentials
            //var authenticationContext = new AuthenticationContext(PowerBiConfig.PowerBiAuthorityUri);
            //var authenticationResult = await authenticationContext.AcquireTokenAsync(PowerBiConfig.PowerBiApiResource, AzureAdConfig.ClientId, credential);

            //if (authenticationResult == null)
            //    new Exception("Authentication Failed.");

            //var tokenCredentials = new TokenCredentials(authenticationResult.AccessToken, "Bearer");

            ////Microsoft.IdentityModel.Clients.ActiveDirectory.TokenCache TC = new Microsoft.IdentityModel.Clients.ActiveDirectory.TokenCache();

            ////AuthenticationContext AC = new AuthenticationContext(PowerBIConfig.PowerBiAuthorityUri, TC);
            ////Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential cc = new Microsoft.IdentityModel.Clients.ActiveDirectory.ClientCredential(AzureADConfig.ClientId, AzureADConfig.ClientSecret);
            ////var embaedToken = await AC.AcquireTokenByAuthorizationCodeAsync(accessToken, new Uri(PowerBIConfig.DashboardRedirectUrl), cc);





            //using (var client = new PowerBIClient(new Uri(PowerBiConfig.PowerBiApiUrl), tokenCredentials))
            //{
            //    var grp = client.Groups.GetGroups().Value.ToList();
            //    var reportListd = client.Reports.GetReportsInGroup("0fc4287c-461d-46bc-a2da-ec29f0962ab3");
            //    EmbedToken embedToken = await client.Reports.GenerateTokenInGroupAsync(_groupId, "f7d642f8-6934-4e28-95f3-22efadb9a1fb", new GenerateTokenRequest(accessLevel: "View"));
            //}
        }


    }
}
