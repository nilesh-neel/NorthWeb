﻿using System.IO;
using System.Threading.Tasks;

namespace Heathrow.BPM.Business.Interface
{
    public interface IUserModule
    {
        Task<string> GetMyEmailAddress(string accessToken);
        Task<string> GetUserAccessTokenAsync();
        Task<string> GetUserDetailsFromAzureServer(string accessToken);
        Task<Stream> GetUserProfilePhoto(string accessToken);
    }
}