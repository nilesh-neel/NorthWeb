﻿namespace Heathrow.BPM.Business.Interface
{
    public interface IBagListModule
    {
        string GetUserExistingbagtags(string UserId);
        int GetUserExistingbagtagsCnt(string UserId);
        int RemoveBagTags(string Bagtags, string UserId);
        int SaveBagTags(string Bagtags, string UserId);
    }
}