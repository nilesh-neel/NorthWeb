﻿using System.Collections.Generic;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Business.Interface
{
    public interface IAssignHomePageModule
    {
        IEnumerable<AssignHomePage> Get();
        int Save(AssignHomePage assignhomepage);
    }
}