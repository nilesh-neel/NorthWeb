﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Business
{
    public class FavouriteModule : IFavouriteModule
    {
        private static IFavourites FavouriteRepo { get; set; }
        private static IRepository<Menu> MenuRepo { get; set; }

        public FavouriteModule(IFavourites fav, IRepository<Menu> menu)
        {
            MenuRepo = menu;
            FavouriteRepo = fav;
        }


        public async Task<IEnumerable<Favourites>> Save(Favourites fav)
        {
            var menuDetails = MenuRepo.All().Where(a => a.MenuId.Equals(fav.FavouriteLink.MenuId));
            if (!menuDetails.Any()) return null;
            var favMenuList = await FavouriteRepo.GetUserFavourites(fav.UserId);
            favMenuList.Append(new Favourites { UserId = fav.UserId, FavouriteLink = menuDetails.FirstOrDefault() });
            return favMenuList != null ? await FavouriteRepo.Save(fav) == 0 ? favMenuList : null : null;

        }
     
        public async Task<IEnumerable<Favourites>> GetUserFavourites(string _userId)
        {
            try
            {
                return await FavouriteRepo.GetUserFavourites(_userId);
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
