﻿using System.Collections.Generic;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Core.Interface
{
    public interface IShare
    {
        IList<Share> FetchAudienceGrp();

        IList<Share> FetchRecipients(int AudienceGrpId);
    }
}
