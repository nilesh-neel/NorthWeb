﻿using System.Collections.Generic;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Core.Interface
{
    public interface INotification
    {
        IEnumerable<Notification> GetNotificationByNotificationId(string _notificationId);
        int Save(Notification _notification);
        IEnumerable<Notification> GetTodaysNotification();
    }
}
