﻿namespace Heathrow.BPM.Core.Entity
{
    public class Location 
    {
        public int LocationID { get; set; }
        public string LocationDescription { get; set; }

    }
}
