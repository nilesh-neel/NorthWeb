﻿namespace Heathrow.BPM.Core.Entity
{
    public class ConnectionKey
    {
    }
}
