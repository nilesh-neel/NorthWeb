﻿using System;
using System.Collections.Generic;
using Heathrow.BPM.DataAccess.Common;
using Heathrow.BPM.Core;
using System.Data.SqlClient;
using System.Data;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.DataAccess
{
   public class SearchRepository : ISearch
    {
        private readonly DbConnection _dbConnection = null;
        private DataSet _dsSearchList = null;
        private static IList<TextFilter> _searchList = null;

        public SearchRepository()
        {
            _dbConnection = new DbConnection();
        }
        public IList<TextFilter> GetSearchData(string searchText, string prefix)
        {
            try
            {
                _dbConnection.ExecuteDataSet(ProcedureConstants.FetchSearchData, out _dsSearchList,
                     new List<SqlParameter>()
                       {
                       new SqlParameter() { ParameterName = "@searchText", DbType = DbType.String, Value = searchText },
                       new SqlParameter() { ParameterName = "@searchPrefix", DbType = DbType.String, Value = prefix }
                     });

                return  BindSearchDataToEntity(_dsSearchList);
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error is occured while retrieving the search", ex);
            }
            finally
            {
                _dbConnection.CloseConnection();
            }
        }

        private static IList<TextFilter> BindSearchDataToEntity(DataSet dsData)
        {
            if (dsData != null && dsData.Tables.Count > 0)
            {
                _searchList = new List<TextFilter>();

                foreach (DataRow row in dsData.Tables[0].Rows)
                {
                    _searchList.Add(new TextFilter
                    {
                        ID = Convert.ToInt32(row["ID"]),
                        Text = Convert.ToString(row["Name"]),
                    });

                }
            }
            return _searchList;
        }

    }
}
