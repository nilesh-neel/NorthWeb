﻿//----------------------------------------------------------------------
//Class Name   : BaggageDbContext
//Purpose      : This is the default entity framework partial class use to initialize the connection string
//               and other entity framework task 
//Created By   : Nilesh More
//Created Date : 26/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------


using Heathrow.BPM.Security;
using System;
using System.Configuration;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;

namespace Heathrow.BPM.DataAccess
{
    public partial class BaggageDbContext
    {
        private static readonly string EncryptionKey = ConfigurationManager.AppSettings["EncryptionKey"];
        private static readonly string SConnString = ConfigurationManager.ConnectionStrings["BaggageDbContext"].ToString();
        private static string _sConnName;
        public static string ConnectionString
        {
            get
            {
                if (String.IsNullOrEmpty(_sConnName))
                {
                    AesEncryption sec = new AesEncryption();
                    _sConnName = sec.Decrypt(SConnString, EncryptionKey);
                    return _sConnName;
                }
                return _sConnName;
            }
        }
        public BaggageDbContext()
            : base(ConnectionString)
        {
        }

        public virtual ObjectResult<usp_GetMenu_Result> usp_GetMenu()
        {
            return ((IObjectContextAdapter)this).ObjectContext.ExecuteFunction<usp_GetMenu_Result>("usp_GetMenu");
        }

        public virtual ObjectResult<usp_GetFavourites_Result> usp_GetFavourites(string user_ID)
        {
            var user_IDParameter = user_ID != null ?
                new ObjectParameter("User_ID", user_ID) :
                new ObjectParameter("User_ID", typeof(string));

            return ((IObjectContextAdapter)this).ObjectContext.ExecuteFunction<usp_GetFavourites_Result>("usp_GetFavourites", user_IDParameter);
        }

        public virtual ObjectResult<Nullable<int>> usp_SaveFavourites(string user_ID, Nullable<int> menu_Id, Nullable<int> favourite_ID)
        {
            var user_IDParameter = user_ID != null ?
                new ObjectParameter("User_ID", user_ID) :
                new ObjectParameter("User_ID", typeof(string));

            var menu_IdParameter = menu_Id.HasValue ?
                new ObjectParameter("Menu_Id", menu_Id) :
                new ObjectParameter("Menu_Id", typeof(int));

            var favourite_IDParameter = favourite_ID.HasValue ?
                new ObjectParameter("Favourite_ID", favourite_ID) :
                new ObjectParameter("Favourite_ID", typeof(int));

            return ((IObjectContextAdapter)this).ObjectContext.ExecuteFunction<Nullable<int>>("usp_SaveFavourites", user_IDParameter, menu_IdParameter, favourite_IDParameter);
        }
    }
}
