﻿using System;
using System.Collections.Generic;
using Heathrow.BPM.Core.Entity;
using System.Data;
using System.Data.SqlClient;
using static System.Convert;
using Heathrow.BPM.DataAccess.Common;

namespace Heathrow.BPM.DataAccess
{
    public class ShareRepository : Core.Interface.IShare
    {
        public ShareRepository() { }

        public IList<Share> FetchAudienceGrp()
        {
            DbConnection oDal = null;
            DataSet dsAudienceGrp = null;
            try
            {
                oDal = new DbConnection();
                dsAudienceGrp = new DataSet();

                oDal.ExecuteDataSet(ProcedureConstants.FetchAudienceGrp, out dsAudienceGrp);


                if ((dsAudienceGrp != null) && (dsAudienceGrp.Tables.Count > 0) && (dsAudienceGrp.Tables[0].Rows.Count > 0))
                {
                    // Dataset Data to collection
                    return ConvertDatatoCollection(dsAudienceGrp);
                }
                else
                    return new List<Share> { };
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }

        public IList<Share> FetchRecipients(int AudienceGrpId)
        {
            DbConnection oDal = null;
            DataSet dsGrpRecipients = null;
            try
            {
                if (AudienceGrpId != 0 && AudienceGrpId != null)
                {
                    oDal = new DbConnection();
                    dsGrpRecipients = new DataSet();

                    oDal.ExecuteDataSet(ProcedureConstants.FetchGrpRecipients, out dsGrpRecipients,
                       new List<SqlParameter>()
                       {
                       new SqlParameter() { ParameterName = "@Audiencegrpid", DbType = DbType.Int32, Value = AudienceGrpId },


                       });

                    if ((dsGrpRecipients != null) && (dsGrpRecipients.Tables.Count > 0) && (dsGrpRecipients.Tables[0].Rows.Count > 0))
                    {
                        // Dataset Data to collection
                        return ConvertDatatoCollection(dsGrpRecipients);
                    }
                    else
                        return new List<Share> { };
                }
                else
                    return new List<Share> { };
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }


        private IList<Share> ConvertDatatoCollection(DataSet ds)
        {
            IList<Share> shareList = null;
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                shareList = new List<Share>();

                if (ds.Tables[0].Columns.Contains("Recipient_ID") && ds.Tables[0].Columns.Contains("Recipient_Name"))
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        shareList.Add(new Share
                        {
                            GroupId = ToInt32(row["Group_ID"]),
                            Groupname = Convert.ToString(row["Group_Name"]),
                            RecipientId = ToInt32(row["Recipient_ID"]),
                            Recipientname = Convert.ToString(row["Recipient_Name"]),
                        });
                    }

                }
                else
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        shareList.Add(new Share
                        {
                            GroupId = ToInt32(row["Group_ID"]),
                            Groupname = Convert.ToString(row["Group_Name"]),
                        });
                    }
                }
            }
            return shareList;
        }

    }
}
