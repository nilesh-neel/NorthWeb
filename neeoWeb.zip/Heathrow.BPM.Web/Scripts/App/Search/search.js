﻿var inputText = [];
var Search = (function () {
    'use strict';

    var URL = '/Search/GetSearch';
    var searchEntity = [];
    var searchText = [];
    Search = function () { }
    var txtsearch = $('#txtSearch');
    var SearchEnum = { FlightNumber: 1, BagTag: 2, PassegerName: 3, AirLine: 4 };
    var validationStatus;
    var searchPrefix = '';
    var prefix;
    var errorStatus = $('#lblError');


    $('#searchbtn').on('click', function () {

        var param = txtsearch.val().split(',').filter(function (index) { return index; });
        if (_.isEmpty(param)) { alert('Search criteria is not available. Please enter the search text'); return; }
        searchText = [];
        $.each(param, function (key, val) {
            searchText.push(val);
        });
        SearchValidation(searchText);
        if (searchText.length > 5) {
            alert('search will allow maximum  5 Bag Tags, Flight Number or Passanger'); return;
        }
        else {

            var inputText = searchText.toString();

            searchEntity = { query: inputText, searchType: searchPrefix };
            var successHandler = function (data) {
                if (!_.isNil(data.result)) {
                    window.location.href = '/AssignHomePage/Index/';  // need to change bag list screen URL

                }
            };
            var errorHandler = function (dataval) {
                alert(dataval);
            };
            Utility.makeAjaxCall(URL, 'GET', searchEntity, successHandler, errorHandler);
        }

    });


    //  validate input parameter
    $('#txtSearch').on('keyup', function (e) {
        if (e.keyCode == 188) { // KeyCode For comma is 188
            var paramValue = txtsearch.val().split(',').filter(function (index) { return index; });
            if (!_.isEmpty(paramValue)) {
                var index = paramValue.length - 1;

                ValidateText(paramValue[index]);
            }
            else { alert('Your not entered valid search criteria'); }

        }

    });


    // Handle special characters start
    $('#txtSearch').on('keypress', function (event) {
        Utility.SpecialCharacterValidation(event);
    });

    $('#txtSearch').bind('paste', removeAlphaChars);
    
function removeAlphaChars() {
    var self = $(this);
    setTimeout(function () {
        var initVal = self.val(),
            outputVal = initVal.replace(/[^a-zA-Z0-9,]/g, '');
        if (initVal != outputVal) self.val(outputVal);
    });
}

    //End Handle special characters

var ValidateText = function (inputText) {


    var param = (_.isNil(inputText.Text)) ? inputText : inputText;
    if (!_.isEmpty(param)) {
        var searchValue = validatationType(param)
        if (!_.isNil(searchValue) && prefix === searchValue) {
        }
        else {
            if (prefix === SearchEnum.FlightNumber) {
                errorStatus.text('Search by Flight number only.Combination of search will be not allowed');
                errorStatus.removeClass('hidden');
            }
            else if (prefix === SearchEnum.BagTag) {
                errorStatus.text('Search by Bag Tag only.Combination of search will be not allowed');
                errorStatus.removeClass('hidden');
            }
            else if (prefix === SearchEnum.PassegerName) {
                errorStatus.text('Search by Passeger Name only.Combination of search will be not allowed');
                errorStatus.removeClass('hidden');
            }
            else if (prefix === SearchEnum.AirLine) {
                errorStatus.text('Search by Airline only.Combination of search will be not allowed');
                errorStatus.removeClass('hidden');
            }

        }
    }
}

var SearchValidation = function (source) {

    for (var i = 0; i < source.length; i++) {

        ValidateText(source[i]);
    }

}

var validatationType = function (parameter) {
    var flightRegex = new RegExp(/^(([A-Za-z]{2,3})|([A-Za-z]\d)|(\d[A-Za-z]))(\d{1,4})([A-Za-z]?)$/);
    var bagtagRegex = new RegExp(/^\d{6,10}$/);
    var airlineRegex = new RegExp(/^\[a-zA-Z]{2,4}$/);
    var passengerRegex = new RegExp(/^([a-zA-Z]{3,30})+$/);

    if (flightRegex.test(parameter)) {
        prefix = (_.isNil(prefix)) ? SearchEnum.FlightNumber : prefix;
        searchPrefix = 'F';
        return SearchEnum.FlightNumber;
    } else if (bagtagRegex.test(parameter)) {
        prefix = (_.isNil(prefix)) ? SearchEnum.BagTag : prefix;
        searchPrefix = 'B';
        return SearchEnum.BagTag;
    } else if (passengerRegex.test(parameter)) {
        prefix = (_.isNil(prefix)) ? SearchEnum.PassegerName : prefix;
        searchPrefix = 'P';
        return SearchEnum.PassegerName
    } else if (airlineRegex.test(parameter)) {
        prefix = (_.isNil(prefix)) ? SearchEnum.AirLine : prefix;
        searchPrefix = 'A';
        return SearchEnum.AirLine
    }
}

return Search;

}) ();