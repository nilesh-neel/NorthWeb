﻿
(function ($) {
    'use strict';
 
    $('.homeLinkIcon').on('click', function () {
        window.location.href = '/Dashboard/Index';
    });


    $('#spnScan').on('click', function () {
        $('#livestream_scanner').modal('show');
    });

    $(document).ready(function () {

        //first bind the menu then call powerbi API.
        var objMenu = new Menu();
        objMenu.bindMenu();
    });

    var dangerAlter = function () {
        $('.danger-alert').css('display', 'block');

        $('#danger-alert').fadeTo(2000, 500).slideUp(500, function () {
            $('#danger-alert').slideUp(500);
        });

        if (XMLHttpRequest.status === 400) {
            $('#messageToClient').text(XMLHttpRequest.responseText);
        }
        else { $('#messageToClient').text('Error in application..'); }
    };

})(jQuery);