﻿


var StandardMessage = (function () {


});



