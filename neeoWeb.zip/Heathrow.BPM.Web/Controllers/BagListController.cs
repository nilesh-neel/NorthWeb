﻿/****************************************************************************************************************
Class Name   : Global.cs 
Purpose      : This is the mail startup file in the application. To handle all startup even in web app like
               Dependency injection, Route config / web api registrations etc...
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System.Web.Mvc;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Web.Controllers
{
    [Authorize]
    public class BagListController : Controller
    {
        private readonly IBagListModule _bagListModule;
        public string UserId = "Admin";

        public BagListController(IBagListModule baglist)
        {
            _bagListModule = baglist;
        }
        // GET: BagList
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public JsonResult GetUserExistingBagtagsCount()
        {
            //string UserId = "Admin";
            int UserExistingBagtagsCnt = _bagListModule.GetUserExistingbagtagsCnt(UserId);
            return Json(UserExistingBagtagsCnt.ToString(), JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetUserExistingBagtags()
        {
            string strUserExistingBagtags = _bagListModule.GetUserExistingbagtags(UserId);
            return Json(strUserExistingBagtags.ToString(), JsonRequestBehavior.AllowGet);
        }

        [OutputCache(NoStore = true, Duration = 0)]
        [HttpPost]
        public ActionResult AddtoMyBaglist(string bagtaglist, int selectedBagtagCnt, string UserId)
        {
            int BagtagsCount = _bagListModule.SaveBagTags(bagtaglist, UserId);
            return Json(BagtagsCount, JsonRequestBehavior.AllowGet);
        }

        public ActionResult RemoveFrmMyBaglist(string bagtaglist, int selectedBagtagCnt, string UserId)
        {
            int BagtagsCount = _bagListModule.RemoveBagTags(bagtaglist, UserId);
            return Json(BagtagsCount, JsonRequestBehavior.AllowGet);
        }

    }
}