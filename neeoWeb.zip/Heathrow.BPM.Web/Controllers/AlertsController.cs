﻿/****************************************************************************************************************
Class Name   : Alerts.cs 
Purpose      : Used as Owin Startup class to implements authentication and authorization in Application. 
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Interface;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Web.ViewModel;
using Newtonsoft.Json;
using System.IO;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Web.Controllers
{
    [Authorize]
    public class AlertsController : Controller
    {

        private readonly IMapper<AlertVM, Alerts> _map;
        private readonly IAlertsModule _alertModule;

        public AlertsController(IAlertsModule alerts, IMapper<AlertVM, Alerts> map)
        {
            _alertModule = alerts;
            _map = map;
        }

        // GET: Alerts
        public ActionResult Index()
        {
            //_alertModule.GetAlertsById("123");
            //List<AlertVM> alertVm;

            //using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/alerts.json")))
            //{
            //    alertVm = JsonConvert.DeserializeObject<List<AlertVM>>(readFile.ReadToEnd());
            //}


            return PartialView("_LandingPage");
        }

        [HttpGet]
        //[Route("TodayAlerts")]
        public JsonResult GetTodaysAlers()
        {
            List<AlertVM> alertVm;

            using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/alerts.json")))
            {
                alertVm = JsonConvert.DeserializeObject<List<AlertVM>>(readFile.ReadToEnd());
            }

            return Json(alertVm, JsonRequestBehavior.AllowGet);
        }


        public ActionResult Edit(string id)
        {
            List<AlertVM> alertVm;

            using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/alerts.json")))
            {
                alertVm = JsonConvert.DeserializeObject<List<AlertVM>>(readFile.ReadToEnd());
            }


            return PartialView("_ConfigurNewAlert", alertVm.FirstOrDefault());
        }

        [HttpGet]
        [Route("Get")]
        public ActionResult GetAll() => Json(_map.MapFrom(_alertModule.GetData()), JsonRequestBehavior.AllowGet);


        [HttpGet]
        [Route("Get")]
        public ActionResult GetAlertById()
        {
            return Json(
                _map.MapFrom(_alertModule.GetAlertsById("ALT01")),
                JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult Update(AlertVM data)
        {

            if (!ModelState.IsValid)
                return null;

            var objNotifyCore = _map.MapTo(data);

            if (_alertModule.Save(objNotifyCore).Equals(0))
                return Json("Data save succes.", JsonRequestBehavior.AllowGet);
            return Json("Data save fail.", JsonRequestBehavior.AllowGet);

        }

    }
}