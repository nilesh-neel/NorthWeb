﻿/****************************************************************************************************************
Class Name   : NotificationsController.cs 
Purpose      : In this controller we are loading the menu for the weg application.
Created By   : Vaishnavi R
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using Heathrow.BPM.Core.Interface;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Web.ViewModel;
using System.IO;
using Heathrow.BPM.Business.Interface;
using Newtonsoft.Json;

namespace Heathrow.BPM.Web.Controllers
{
    [Authorize]
    public class NotificationsController : Controller
    {
        private readonly IMapper<NotificationVM, Notification> Map;
        private readonly INotificationModule _notifyModule;

        public NotificationsController(INotificationModule notify, ILookup _lookup, IMapper<NotificationVM, Notification> _map)
        {
            _notifyModule = notify;
            Map = _map;
        }
        // GET: Notifications
        public ActionResult Index()
        {

            return View("NotificationsSettings");
        }

        public ActionResult TodaysNotification()
        {

            return PartialView("_TodaysNotification");
        }
        [HttpGet]
        //[Route("TodayNotification")]
        public JsonResult GetTodaysNotification()
        {
            List<NotificationVM> notificationVm;

            using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/notification.json")))
            {
                notificationVm = JsonConvert.DeserializeObject<List<NotificationVM>>(readFile.ReadToEnd());
            }

            return Json(notificationVm, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        [Route("Get")]
        public ActionResult GetAll()
        {

            return Json(
               Map.MapFrom(_notifyModule.GetTodaysNotification()),
                JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        [Route("Get")]
        public ActionResult GetNotificationById()
        {
            return Json(
                Map.MapFrom(_notifyModule.GetNotificationById("NOT01")),
                JsonRequestBehavior.AllowGet);
        }

        public ActionResult Edit(string id)
        {

            /*   List<NotificationVM> notificationVm;
               NotificationVM notificationItem;
               using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/notification.json")))
               {
                   notificationVm = JsonConvert.DeserializeObject<List<NotificationVM>>(readFile.ReadToEnd());

               }

               notificationItem = notificationVm.Find(x => x.notificationId == id);
               return PartialView("_ConfigurNewNotifications", notificationItem);
               */
            List<NotificationVM> notificationVm;
            using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/notification.json")))
            {
                notificationVm = JsonConvert.DeserializeObject<List<NotificationVM>>(readFile.ReadToEnd());

            }

            var notificationItem = notificationVm.Find(x => x.notificationId == id);

            return PartialView("_ConfigurNotifications", notificationItem);

        }

        public ActionResult NewNotification()
        {
            List<NotificationVM> notificationVm;

            using (StreamReader readFile = new StreamReader(Server.MapPath("~/Helper/DummyData/notification.json")))
            {
                notificationVm = JsonConvert.DeserializeObject<List<NotificationVM>>(readFile.ReadToEnd());
            }


            return PartialView("_NewNotification", notificationVm.FirstOrDefault());

        }
        [HttpPost]
        public void Update(NotificationVM data)
        {

            /*    if (_notifyModule.Save(objNotifCore).Equals(0))
                    return Json("Data save succes.", JsonRequestBehavior.AllowGet);
                return Json("Data save fail.", JsonRequestBehavior.AllowGet);
                */
            // if (!ModelState.IsValid)
            // Response.Write(@"<script language='javascript'>alert('invalid.');</script>");

            var objNotifCore = Map.MapTo(data);

            /*  if (_notifyModule.Save(objNotifCore).Equals(1))
                  Response.Write(@"<script language='javascript'>alert('Data  success entered.');</script>");
              else
                  Response.Write(@"<script language='javascript'>alert('Data failed entered.');</script>");*/

        }
    }
}