﻿using System.Web.Http;
using Heathrow.BPM.Business.Infrastructure;
using Heathrow.BPM.Core.Interface;
using System.Web.Mvc;
using Unity;
using Unity.Mvc5;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Web.ViewModel;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Business;
using Unity.Lifetime;
using Unity.Extension;
using Heathrow.BPM.Core;

namespace Heathrow.BPM.Web.Configuration
{
    public class Bootstrap
    {
        public static void Initialise()
        {
            var container = BuildUnityContainer();
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
            GlobalConfiguration.Configuration.DependencyResolver = new Unity.WebApi.UnityDependencyResolver(container);
        }

        internal static IUnityContainer BuildUnityContainer()
        {
            var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            // Database context, one per request, ensure it is disposed
            /*/* container.BindInRequestScope<IDbContext, Core.HeathrowBPMDataAccess>();*//*/*/

            //Bind the various domain model services and repositories that e.g. our controllers require         
            //container.BindInRequestScope<IFavourites, FavouritesModule>();

            container.BindInRequestScope<IMapper<FavouritesVM, Favourites>, FavouriteMapping>();
            container.BindInRequestScope<IMapper<RegistrationVM, Registration>, RegistrationMapping>();
            container.BindInRequestScope<IMapper<NotificationVM, Notification>, NotificationMapping>();
            container.BindInRequestScope<IMapper<LocationVM, Location>, LocationMapping>();
            container.BindInRequestScope<IMapper<AlertVM, Alerts>, AlertMapping>();
            container.BindInRequestScope<IMapper<MenuVM, Menu>, MenuMapping>();
            container.BindInRequestScope<IBpmPowerBi, PowerBiModule>();
            container.BindInRequestScope<IMapper<NotesVM, Notes>, NotesMapping>();
            container.BindInRequestScope<IMapper<FilterVM, FilterCollection>, FilterMapping>();

            container.AddNewExtension<ChildDependencyExtension>();

            //container.RegisterType<IBpmPowerBi>(new InjectionFactory(c => HttpContext.Current.GetOwinContext().Authentication));
            //container.RegisterType<ApplicationSignInManager>(new PerRequestLifetimeManager());



            return container;
        }

    }
    public static class UnityIocExtensions
    {
        public static void BindInRequestScope<T1, T2>(this IUnityContainer container) where T2 : T1
        {
            container.RegisterType<T1, T2>(new HierarchicalLifetimeManager());
        }

        public static void BindInSingletonScope<T1, T2>(this IUnityContainer container) where T2 : T1
        {
            container.RegisterType<T1, T2>(new ContainerControlledLifetimeManager());
        }
        public static void InjectStub<I>(this IUnityContainer container, I instance)
        {
            container.RegisterInstance(instance, new ContainerControlledLifetimeManager());
        }
        public static void AddExtension<T>(this IUnityContainer container) where T : UnityContainerExtension
        {
            container.AddNewExtension<T>();
        }
    }

}