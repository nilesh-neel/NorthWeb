﻿/****************************************************************************************************************
Class Name   : BundleConfig.cs 
Purpose      : BundleConfig is special class where we bundle all our javaScripts and css file in to the one single file
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System.Web.Optimization;

namespace Heathrow.BPM.Web
{
    public class BundleConfig
    {
        // For more information on bundling, visit https://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at https://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                //"~/Scripts/modernizr-*",
                "~/Scripts/es6-promise.min.js",
                        "~/Scripts/polyfill.min"

                        ));

            bundles.Add(new ScriptBundle("~/bundles/vendor").Include(
                 "~/Scripts/jquery-3.3.1.js",
                 "~/Scripts/jquery-ui.min.js",
                 "~/Scripts/jquery.validate.min.js",
                 "~/Scripts/jquery.validate.unobtrusive.min.js",
                 "~/Scripts/jquery.unobtrusive-ajax.min.js",
                 "~/Scripts/powerbi/adal.js",
                 "~/Scripts/powerbi/powerbi.js",
                 "~/Scripts/powerbi/powerBIApp.js",
                 "~/Scripts/validator.js",
                 "~/Scripts/lodash.min.js",
                 "~/Scripts/bootstrap.min.js",
                  "~/Scripts/bootstrap.js",

                 "~/Scripts/quagga/adapter-latest.js",
                 "~/Scripts/quagga/quagga.js",

                 "~/Scripts/jquery.dataTables.min.js",
                 "~/Scripts/moment.min.js",
                 "~/Scripts/daterangepicker.js",
                 "~/Scripts/ion.rangeSlider.js",
                 "~/Scripts/jquery.multiselect.js",
                 "~/Scripts/comboBox.js",
                 "~/Scripts/jquery.scrollbar.min.js",
                 "~/Scripts/script.js"));

            bundles.Add(new ScriptBundle("~/bundles/appJS").IncludeDirectory(
                   "~/Scripts/App/", "*.js", true));


            bundles.Add(new StyleBundle("~/bundles/Content").Include(
                      "~/Content/jquery-ui.min.css",
                      "~/Content/bootstrap.min.css",
                      "~/Content/jquery.dataTables.min.css",
                      "~/Content/daterangepicker.css",
                      "~/Content/ion.rangeSlider.css",
                      "~/Content/jquery.multiselect.css",
                      "~/Content/jquery.scrollbar.css",
                       "~/Content/skin2.css",
                      "~/Content/barcodescan.css",
                      "~/Content/style.css",
                      "~/Content/baglist.css",
                      "~/Content/custome.css"
                ));


//#if DEBUG
//            BundleTable.EnableOptimizations = false;
//#else
//                        BundleTable.EnableOptimizations = true;
//#endif

        }
    }
}
