﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Heathrow.BPM.Web.ViewModel
{
    public class NotificationVM
    {
        /*    public string NotificationId { get; set; }
            public string Description { get; set; }
            public string Title { get; set; }
            public string Topic { get; set; }

            public string Location { get; set; }
            public string HelpUrl { get; set; }
            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }
            public string Time { get; set; }
            public bool IsSubscribe { get; set; }
            public bool IsOnScreen { get; set; }
            public bool IsEmail { get; set; }
            public bool IsMobile { get; set; }*/
        public int[] selectLocation { get; set; }
        public int selectedTopic { get; set; }
        public int selectedAudience { get; set; }
        public int selectedRecipient { get; set; }

        public string notificationId { get; set; }
        public string description { get; set; }
        public string createdBy { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime createdDate { get; set; }

        public string modifiedBy { get; set; }
        public DateTime modifiedDate { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        //public DateTime endDate { get; set; }
        public string URL { get; set; }
        public bool isSubscribe { get; set; }
        public bool isOnScreen { get; set; }
        public bool isEmail { get; set; }
        public bool isMobile { get; set; }
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime CreationDate { get; set; }
        public List<DemoLookUpVm> location { get; set; }
        //  public List<DemoLookUpVm> measureName { get; set; }
        public List<DemoLookUpVm> audienceGroup { get; set; }
        public List<DemoLookUpVm> recipients { get; set; }
        public List<DemoLookUpVm> topic { get; set; }
        public List<DemoLookUpVm> threshold { get; set; }
        public List<DemoLookUpVm> mandatoryOptionals { get; set; }
    }
    public class NotificationMapping : IMapper<NotificationVM, Notification>
    {
        public NotificationVM MapFrom(Notification _input)
        {
            return BindCoreToViewModel(_input);
        }
        public IEnumerable<NotificationVM> MapFrom(IEnumerable<Notification> _input)
        {
            return _input.Select(x => BindCoreToViewModel(x));
        }

        public Notification MapTo(NotificationVM _input)
        {
            return BindViewModelToCore(_input);
        }

        public IEnumerable<Notification> MapTo(IEnumerable<NotificationVM> _input)
        {
            return _input.Select(x => BindViewModelToCore(x));
        }

        private static NotificationVM BindCoreToViewModel(Notification _input)
        {
            return new NotificationVM()
            {

                /*   notificationId = _input.NotificationID,
                   Description = _input.Description,
                   Title = _input.Title,
                   Topic = _input.Topic,
                   TipID=_input.TipID,
                  // Location = _input.Location,
                 //  TipOfTheDay = _input.TipOfTheDay,
                   HelpUrl = _input.HelpUrl,
                   StartDate = _input.StartDate.Date,
                   EndDate = _input.EndDate.Date,
                   Time=_input.StartDate.TimeOfDay.ToString(),
                   IsSubscribe = _input.IsSubscribe,
                   IsOnScreen = _input.IsOnScreen,
                   IsEmail = _input.IsEmail,
                   IsMobile = _input.IsMobile,
                   Location = string.Join(",", _input.Locations.ToArray()),*/

                notificationId = _input.NotificationID,
                description = _input.Description,
                // topic = _input.Topic,
                createdBy = _input.CreatedBy,
                createdDate = _input.CreatedDate,
                //   endDate=_input.EndDate,
                // location = _input.Location,
                modifiedBy = _input.ModifiedBy,
                modifiedDate = _input.ModifiedDate,
                isSubscribe = _input.IsSubscribe,
                isOnScreen = _input.IsOnScreen,
                isEmail = _input.IsEmail,
                isMobile = _input.IsMobile,
                selectLocation = _input.SelectLocationId,
                selectedTopic = _input.SelectedTopic,
                selectedRecipient = _input.SelectedRecipients,
                selectedAudience = _input.SelectedAudienceGroup,
                URL = _input.HelpUrl


            };
        }

        private static Notification BindViewModelToCore(NotificationVM _input)
        {
            return new Notification()
            {

                /*    NotificationID = _input.NotificationId,
                    Description = _input.Description,
                    Title = _input.Title,
                    Topic = _input.Topic,
                    TipID=_input.TipID,
                  //  Location = _input.Location,
                  //  TipOfTheDay = _input.TipOfTheDay,
                    HelpUrl = _input.HelpUrl,
                    StartDate = _input.StartDate.Date,
                    EndDate = _input.EndDate.Date,
                    Time=_input.StartDate.TimeOfDay.ToString(),
                    IsSubscribe = _input.IsSubscribe,
                    IsOnScreen = _input.IsOnScreen,
                    IsEmail = _input.IsEmail,
                    IsMobile = _input.IsMobile*/
                NotificationID = _input.notificationId,
                Description = _input.description,
                // Topic = _input.topic,
                CreatedBy = _input.createdBy,
                CreatedDate = _input.createdDate,
                //   EndDate=_input.endDate,
                //Location = _input.location,
                ModifiedBy = _input.modifiedBy,
                ModifiedDate = _input.modifiedDate,
                IsSubscribe = _input.isSubscribe,
                IsOnScreen = _input.isOnScreen,
                IsEmail = _input.isEmail,
                IsMobile = _input.isMobile,
                SelectLocationId = _input.selectLocation,
                SelectedRecipients = _input.selectedRecipient,
                SelectedAudienceGroup = _input.selectedAudience,
                SelectedTopic = _input.selectedTopic,
                HelpUrl = _input.URL
            };
        }
    }

}