﻿/****************************************************************************************************************
Class Name   : FavoritesController.cs 
Purpose      : Save user Favorites 
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Web.ViewModel;
using System;
using System.Threading.Tasks;
using System.Web.Mvc;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Web.Controllers
{
    // [ModelStateException]
    // [BPMErrorHandler]
    public class FavoritesController : BaseController
    {
        private readonly IFavouriteModule _favoritesModule;
        private readonly IMapper<FavouritesVM, Favourites> _mapFav;

        public FavoritesController(IFavouriteModule fav, IMapper<FavouritesVM, Favourites> mapFav)
        {
            _favoritesModule = fav;
            _mapFav = mapFav;
        }

        [HttpGet]
        public ActionResult GetData()
        {
            return Json(
                _mapFav.MapFrom(_favoritesModule.GetUserFavourites("ASDASF234AS").Result),
                JsonRequestBehavior.AllowGet);
        }


        [HttpGet]
        public async Task<ActionResult> Get()
        {
            return Json(
                _mapFav.MapFrom(await _favoritesModule.GetUserFavourites("ASDASF234AS")),
                JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public async Task<JsonResult> SaveData(string menuId, string url)
        {
            try
            {
                //if (!ModelState.IsValid)
                //    throw new ModelStateException(ModelState);

                var data = new FavouritesVM { menuId = Convert.ToInt32(menuId), url = url };

                var objFavCore = _mapFav.MapTo(data);
                objFavCore.UserId = "ASDASF234AS";
                var result = await _favoritesModule.Save(objFavCore);
                return result != null ? Json(_mapFav.MapFrom(result), JsonRequestBehavior.AllowGet) :
                    Json("Data save fail.", JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(ex.Message, JsonRequestBehavior.AllowGet);
            }

        }

    }
}