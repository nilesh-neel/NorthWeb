﻿/****************************************************************************************************************
Class Name   : BagListController.cs 
Purpose      : This file is used to save the User's BagList data....
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System.Threading.Tasks;
using System.Web.Mvc;
using Heathrow.BPM.Business.Interface;
using Newtonsoft.Json;

namespace Heathrow.BPM.Web.Controllers
{
    public class BagListController : BaseController
    {
        private readonly IBagListModule _bagListModule;
        public int UserId = 1;// Get the logged-in userID from Session

        public BagListController(IBagListModule baglist)
        {
            _bagListModule = baglist;
        }
        // GET: BagList
        public ActionResult Index()
        {
            return View();
        }


        #region Get the Existing BagTags and BagTags Count of the Logged-in User
        //[HttpGet]
        //public async Task<JsonResult> GetUserExistingBagtagsCount()
        //{
        //    //string UserId = "Admin";
        //    int UserExistingBagtagsCnt = await _bagListModule.GetUserExistingbagtagsCnt(UserId);
        //    return Json(UserExistingBagtagsCnt.ToString(), JsonRequestBehavior.AllowGet);
        //}
        

        [HttpGet]
        public async Task<JsonResult> GetUserExistingBagtags(int otherUserId)
        {
            var strUserExistingBagtags =await  _bagListModule.GetUserExistingbagtags(otherUserId);
            return Json(strUserExistingBagtags, JsonRequestBehavior.AllowGet);

        }
        #endregion

        #region Fetching the Users List to display the Baglist details of selected User
        [HttpGet]
        public JsonResult GetMybaglistOtherUsers()
        {

            var UserListResponse = _bagListModule.LoadMybaglistOtherUsers();
            return Json(UserListResponse, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Saving the Added BagTags selected by the Logged-in User
        [OutputCache(NoStore = true, Duration = 0)]
        [HttpPost]
        public async Task<ActionResult> AddtoMyBaglist(string bagtaglist, int selectedBagtagCnt, int UserId)
        {
            var strUpdatedBagtags = await _bagListModule.SaveBagTags(bagtaglist, UserId);
            return Json(strUpdatedBagtags, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Deleting/Removing BagTags selected by the Logged-in User
        [OutputCache(NoStore = true, Duration = 0)]
        [HttpPost]
        public async Task<ActionResult> RemoveFrmMyBaglist(string bagtaglist, int selectedBagtagCnt, int UserId)
        {
            var strUpdatedBagtags = await _bagListModule.RemoveBagTags(bagtaglist, UserId);
            return Json(strUpdatedBagtags, JsonRequestBehavior.AllowGet);
        }
        #endregion
    }
}