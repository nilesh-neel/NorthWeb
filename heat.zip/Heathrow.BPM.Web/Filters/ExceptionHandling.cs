﻿/****************************************************************************************************************
Class Name   : ExceptionHandling.cs 
Purpose      : This file is used to handle the Exceptions globally across the application and track those exceptions in the Azure Appinsights .......
Created By   : Vignesh AshokKumar 
Created Date : 11/Nov/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using Heathrow.BPM.Web.ViewModel;
using System;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Configuration;
using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.Extensibility;
using System.Configuration;
using System.Security.Claims;
using Heathrow.BPM.Core.Entity;


namespace Heathrow.BPM.Web.Filters
{
    public class ExceptionHandling : HandleErrorAttribute,IExceptionFilter
    {
        public override void OnException(ExceptionContext exceptionContext)
        {
            string signedInUserId = ClaimsPrincipal.Current.FindFirst(ClaimTypes.NameIdentifier).Value;
            string applicationName= ConfigurationManager.AppSettings["ApplicationName"];
            //string UserEmail = ClaimsPrincipal.Current.FindFirst(ClaimTypes.Email).Value;


            //    base.OnException(filterContext);
            exceptionContext.ExceptionHandled = true;
            if (exceptionContext.HttpContext.Session != null)
                exceptionContext.HttpContext.Session.RemoveAll();
            //set this to true so that IIS 7 does not use its own error pages
            exceptionContext.HttpContext.Response.TrySkipIisCustomErrors = true;

            #region AppInsights Telemetryconfig code
            string instrumentationid = ConfigurationManager.AppSettings["AppInsightsInstrumentationId"];
            //string instrumentationid = "be7ff5c2-5c54-4c90-ad22-10f8ab3f9d30"; // please keep in config file. will change with env.
            TelemetryConfiguration configuration = TelemetryConfiguration.Active;
            configuration.InstrumentationKey = instrumentationid;

            var telemetryClient = new TelemetryClient(configuration);
            Exception ex = new Exception(exceptionContext.Exception.Message); // error you want to log
            //var properties = new Dictionary<string, string>
            //{{"Application", "Kestrel Portal"},{"Logged-in User", "Kestrel Admin"},{"Exception Desc", exceptionContext.HttpContext.Error.InnerException.Message.ToString()}};

            var properties = new Dictionary<string, string>
            {{"Application", applicationName},{"Source", exceptionContext.Exception.Source},
             {"Inner Exception",Convert.ToString(exceptionContext.Exception.InnerException)},
             {"StackTrace",exceptionContext.Exception.StackTrace },
             {"Target Site",Convert.ToString(exceptionContext.Exception.TargetSite.ReflectedType)},{"User ID",signedInUserId},{"Email", ""} };

            //var measurements = new Dictionary<string, string>
            //{{"User ID",signedInUserId}}; // If required can get the User ID from Session

            // Send the exception telemetry:
            telemetryClient.TrackException(ex, properties, null);

            //telemetryClient.TrackException(ex, null, null);
            telemetryClient.TrackTrace(exceptionContext.HttpContext.Trace.ToString()); // used to log audit logs

            telemetryClient.Flush();
            #endregion
        }
    }
}