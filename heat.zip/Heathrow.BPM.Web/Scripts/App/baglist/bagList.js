﻿//----------------------------------------------------------------------
//Class Name   : Alert
//Purpose      : This is baglist Class js file use for the all bind configuration available in baglist module.. 
//Created By   : Vignesh AshokKumar
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

var BagList = (function () {

    'use strict';

    var service;
    /****
     * Creates a new BagList object.
     * @constructor
     *
     */
    BagList = function () {

    };

    BagList.prototype.AddBagTags = function () {

        var bagtags = sessionStorage.getItem('SelectedbagtagsList');
        var SelectedbagtagsCnt = _.toNumber(sessionStorage.getItem('SelectedbagtagsCnt'));
        var ExistingbagtagCnt = _.toNumber($("#lblMybagListcount").text());
        var Existingbagtags = sessionStorage.getItem('ExistingBagtags').length > 0 ? sessionStorage.getItem('ExistingBagtags').replace("'", "") : "";
        var totalbagtagCnt = ExistingbagtagCnt + SelectedbagtagsCnt;
        var selectedBagtagsArr = bagtags.split(",");
        var ExistingbagtagsArr = Existingbagtags.split(",");
        var LoggedinUserID = 1;// Get the Logged-in userID from Session 

        for (var i = 0; i < selectedBagtagsArr.length; i++) {
            if (ExistingbagtagsArr.includes(selectedBagtagsArr[i])) {
                $('#dvAlertMsg').text('You are trying to add bag tags that are already present in your My Bag List.');
                $('.refreshMessage').css("background-color", "#FBC153");
                $('.refreshMessage').css('display', 'block');
                //return false;
                break;
            }
        }

        if (totalbagtagCnt > 100) {
            $('#dvAlertMsg').text('My Bag List has exceeded its capacity (100 Bag Tags). Remove Bag Tag’s and try again.');
            $('.refreshMessage').css("background-color", "#FBC153");
            $('.refreshMessage').css('display', 'block');
            return false;
        }
        else {
            bagtags = Existingbagtags.length > 0 ? Existingbagtags + ',' + bagtags : bagtags;
            var bagtagsJson = '[{"TableName":"BagItemListFact","ColumnName":"TagNumber","ColumnValue":["' + bagtags.trim(',') + '"]}]';
            var bagData = { bagtaglist: bagtagsJson, selectedBagtagCnt: SelectedbagtagsCnt, UserId: LoggedinUserID };

            service = new Service('/BagList/AddtoMyBaglist', 'application/json; charset=utf-8', 'json', bagData);
            service.save()
                .then(function (resp) {
                    var result = JSON.parse(resp);
                    var existingtags = result[0].ColumnValue.toString();
                    var existingtagsArr = existingtags.split(",");
                    var existingtagsCnt = _.toNumber(existingtagsArr.length);
                    $("#lblMybagListcount").text(existingtagsCnt);
                    sessionStorage.setItem('ExistingBagtags', existingtags);
                    $('#dvAlertMsg').text('Bagtags added successfully.');
                    $('.refreshMessage').css("background-color", "#A5CB68");
                    $('.refreshMessage').css('display', 'block');
                }).fail(function (jqXHR, textStatus, errorThrown) {
                    $('#dvAlertMsg').text('Error while adding BagTags.');
                    $('.refreshMessage').css("background-color", "#E4384A");
                    $('.refreshMessage').css('display', 'block');
                });
        }


    }

    BagList.prototype.RemoveBagTags = function () {

        var Existingbagtags = sessionStorage.getItem('ExistingBagtags').length > 0 ? sessionStorage.getItem('ExistingBagtags').replace("'", "") : "";
        var bagtags = sessionStorage.getItem('SelectedbagtagsList');
        var RemoveSelectedbagtagsCnt = sessionStorage.getItem('SelectedbagtagsCnt');
        var LoggedinUserID = 1;// Get the Logged-in userID from Session 
        if (RemoveSelectedbagtagsCnt < 1) {
            $('#dvAlertMsg').text('Select atleast one BagTag to remove.');
            $('.refreshMessage').css("background-color", "#FBC153");
            $('.refreshMessage').css('display', 'block');
            return false;
        }
        else {
            var selectedBagtagsArr = bagtags.split(",");
            var ExistingbagtagsArr = Existingbagtags.split(",");
            //alert("test");
            //alert(ExistingbagtagsArr.length);
            ExistingbagtagsArr = $.grep(ExistingbagtagsArr, function (value) {
                return $.inArray(value, selectedBagtagsArr) < 0;
            });

            var Remainingbagtagscount = _.toNumber(ExistingbagtagsArr.length);
            //alert(Remainingbagtagscount);

            var Remainingbagtags = ExistingbagtagsArr.toString();
            //alert(Remainingbagtags);
            

            var bagtagsJson = '[{"TableName":"BagItemListFact","ColumnName":"TagNumber","ColumnValue":["' + Remainingbagtags.trim(',') + '"]}]';
            var bagData = { bagtaglist: bagtagsJson, selectedBagtagCnt: Remainingbagtagscount, UserId: LoggedinUserID };

            service = new Service('/BagList/RemoveFrmMyBaglist', 'application/json; charset=utf-8', 'json', bagData);
            service.save()
                .then(function (resp) {
                    //var res = JSON.parse(resp);
                    //$("#lblMybagListcount").text(res);
                    var result = JSON.parse(resp);
                    var existingtags = result[0].ColumnValue.toString();
                    var existingtagsArr = existingtags.split(",");
                    var existingtagsCnt = _.toNumber(existingtagsArr.length);
                    $("#lblMybagListcount").text(existingtagsCnt);
                    $('#dvAlertMsg').text('Bagtags removed successfully.');
                    $('.refreshMessage').css("background-color", "#A5CB68");
                    $('.refreshMessage').css('display', 'block');
                }).fail(function (jqXHR, textStatus, errorThrown) {
                    $('#dvAlertMsg').text('Error while removing BagTags.');
                    $('.refreshMessage').css("background-color", "#E4384A");
                    $('.refreshMessage').css('display', 'block');
                });
            BagList.prototype.GetUserExistingBagtags.call(LoggedinUserID); //old CR -- To refresh and load the MyBaglist screen report in single div after removing bagtags
            //BagList.prototype.LoadMyBaglistOprtnlHistrcDivs.call(LoggedinUserID); // New CR -- To refresh and load both Operational and Historic report in separete Divs after removing bagtags
        }
    }

    BagList.prototype.OthersMyBagListUsers = function () {
        service = new Service('/BagList/GetMybaglistOtherUsers', 'application/json; charset=utf-8', 'json');
        service.get()
            .then(function (resp) {
                BagList.prototype.LoadMybaglistOtherusers.call(this, resp);
            }).fail(function (jqXHR, textStatus, errorThrown) {
                $('#dvAlertMsg').text('Error while loading MyBagList Users dropdown.');
                $('.refreshMessage').css("background-color", "#E4384A");
                $('.refreshMessage').css('display', 'block');
            });
    }


    BagList.prototype.LoadMybaglistOtherusers = function (response) {
        var option = '';
        for (var i = 0; i < response.length; i++) {
            option += '<option value="' + response[i].OthersMybaglistUserId + '">' + response[i].UserEmail + '</option>';
        }
        $('#ddlOtherUserBaglist').empty();
        $('#ddlOtherUserBaglist').append(option);
    }

    // This methods are to load the MyBaglist both for logged in user and to view other selected user's MyBaglist
    BagList.prototype.GetUserExistingBagtags = function (selectedUserID) {
        var selectedUserIDForBaglist = { otherUserId: selectedUserID };
        service = new Service('/BagList/GetUserExistingBagtags', 'application/json; charset=utf-8', 'json', selectedUserIDForBaglist);
        service.get()
            .then(function (resp) {
                var result = JSON.parse(resp);
                var existingtags = result[0].ColumnValue.toString();
                var existingtagsArr = existingtags.split(",");
                var existingtagsCnt = _.toNumber(existingtagsArr.length) > 0 ? _.toNumber(existingtagsArr.length) : 0;
                $("#lblMybagListcount").text(existingtagsCnt);
                sessionStorage.setItem('ExistingBagtags', existingtags);
                var dashboardPowerBiApi = new PowerBIAPP("https://app.powerbi.com/reportEmbed?reportId=2a4981ad-6ff6-41dc-a88b-c2b50edf10c3&groupId=0fc4287c-461d-46bc-a2da-ec29f0962ab3", 'true');
                dashboardPowerBiApi.embedPowerBIFilterApi(existingtags);
            }).fail(function (jqXHR, textStatus, errorThrown) {
                $('#dvAlertMsg').text('Error occured while fetching BagTags.');
                $('.refreshMessage').css("background-color", "#E4384A");
                $('.refreshMessage').css('display', 'block');
            });
    }

     // This method is to load the MyBaglist with both operationl and Historic Divs Report for logged in user and to view other selected user's MyBaglist
    BagList.prototype.LoadMyBaglistOprtnlHistrcDivs = function (selectedUserID) {
        var selectedUserIDForBaglist = { otherUserId: selectedUserID };
        service = new Service('/BagList/GetUserExistingBagtags', 'application/json; charset=utf-8', 'json', selectedUserIDForBaglist);
        service.get()
            .then(function (resp) {
                //var res = JSON.parse(resp);
                sessionStorage.setItem('ExistingBagtags', resp);
                // For Operational Report -- Embedding
                var dashboardPowerBiApi1 = new PowerBIAPP("https://app.powerbi.com/reportEmbed?reportId=2a4981ad-6ff6-41dc-a88b-c2b50edf10c3&groupId=0fc4287c-461d-46bc-a2da-ec29f0962ab3", 'true');
                dashboardPowerBiApi1.embedPowerBIFilterApi(resp);
                
                //dashboardPowerBiApi1.embedPowerBIFilterApiRpt1(resp);
                // For Historic Report -- Embedding
                //var dashboardPowerBiApi2 = new PowerBIAPP("https://app.powerbi.com/reportEmbed?reportId=2a4981ad-6ff6-41dc-a88b-c2b50edf10c3&groupId=0fc4287c-461d-46bc-a2da-ec29f0962ab3", 'true');
                //dashboardPowerBiApi2.embedPowerBIFilterApiRpt2(resp);
            }).fail(function (jqXHR, textStatus, errorThrown) {
                $('#dvAlertMsg').text('Error occured while fetching BagTags.');
                $('.refreshMessage').css("background-color", "#E4384A");
                $('.refreshMessage').css('display', 'block');
            });
    }

    return BagList;
})();