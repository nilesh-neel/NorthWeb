﻿
(function ($) {
    'use strict';

    $('.homeLinkIcon').on('click',
        function () {
            window.location.href = '/Dashboard/Index';
        });

    $(document).ready(function () {

        //first bind the menu then call powerbi API.
        var objMenu = new Menu();
        objMenu.bindMenu();
    });

    $('#btnLogout').on('click',
        function () {
            window.location.href = '/Account/SignOut';
        });


    $('.defaultIcons.help').on('click',
        function () {
            window.open('../Scripts/pdf-js/viewer.html', 'winName', 'location=0,width=500,height=514').focus();
        });

    var fullscreenWidget = function () {
        $('.panel .fa-expand').click(function () {
            var panel = $(this).closest('.panel');
            panel.toggleClass('widget-fullscreen');
            $(this).toggleClass('fa-expand fa-compress');
            $('body').toggleClass('fullscreen-widget-active');

        })
    };


    $('.defaultIcons.maximize').click(function () {
        //console.log('click');
        //$('#viewContainer').toggleFullScreen();
        //$('#viewContainer').toggleClass('widget-fullscreen');
        //$('#viewContainer').toggleClass('fullscreen-widget-active');

        // $('#embedContainer').toggleFullScreen();
        $('#dvPowerBiEmbed').toggleClass('widget-fullscreen');
        $('#dvPowerBiEmbed').toggleClass('fullscreen-widget-active');


    });


    $('.defaultIcons.minimize').click(function () {

        $('#dvPowerBiEmbed').toggleClass('widget-fullscreen');
        $('#dvPowerBiEmbed').toggleClass('fullscreen-widget-active');
    });



    //$('#toggle-fullscreen.expand').on('click', function () {
    //    $(document).toggleFullScreen();
    //    $('#toggle-fullscreen .fa').toggleClass('fa-expand fa-compress');
    //});


    var dangerAlter = function () {
        $('.danger-alert').css('display', 'block');

        $('#danger-alert').fadeTo(2000, 500).slideUp(500, function () {
            $('#danger-alert').slideUp(500);
        });

        if (XMLHttpRequest.status === 400) {
            $('#messageToClient').text(XMLHttpRequest.responseText);
        }
        else { $('#messageToClient').text('Error in application..'); }
    };

})(jQuery);