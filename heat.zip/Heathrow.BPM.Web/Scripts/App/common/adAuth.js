﻿//----------------------------------------------------------------------
//Class Name   : adAuth 
//Purpose      : Purpose of this file is to connect with Azure authrentication with MSAL Js, for jquery ajax call. 
//Created By   : Nilesh More
//Created Date : 12/Nov/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------



var Authentication = (function ($) {

    window.config = {
        clientID: '854de9ef-285c-43b1-85f6-a405cf75d4bc',
    };

    Authentication = function () {
        return new Msal.UserAgentApplication(window.config.clientID, null, this.authCallback);
    };

    Authentication.prototype.authCallback = function (errorDesc, token, error, tokenType) {
        if (token) {
        }
        else {
            console.log(error + ":" + errorDesc);
        }

    };

})();