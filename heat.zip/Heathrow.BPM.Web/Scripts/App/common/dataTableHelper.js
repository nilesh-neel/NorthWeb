﻿//----------------------------------------------------------------------
//Class Name   : CustomGrid
//Purpose      : This is Custome Grid Class js file use to create the default JqData Table object with common css and other. 
//               mandantory features like order enable/disable paginate etc... 
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

var CustomGrid = (function () {
    'use strict';

    /****
   * Creates a new Alert object.
   * @constructor
   * @param {string} tableDiv pass the div id to configure the table.
   * @param {object} tableData pass the data to bind the table.
   * @param {object} tableColumn pass the number of column to bind the JqData Table
   * @param {bool} showDetails pass boolean value to show view detils button 
   * @param {bool} allowEdit pass boolean value to show edit detils button
   */
    CustomGrid = function (tableDiv, tableData, tableColumn, showDetails, allowEdit) {
        this.GridDivName = tableDiv;
        this.Data = tableData;
        this.Column = tableColumn;
        this.AllowShow = _.isNull(showDetails) || _.isUndefined(showDetails) ? false : true;
        this.AllowEdit = _.isNull(allowEdit) || _.isUndefined(allowEdit) ? false : true;
        //this.TableObject = $(this.GridDivName).dataTable();
    };

    function triggerRowExpansion(nTr, prevClickedIcon, otable, me, tempName) {
        if ($(nTr).find(prevClickedIcon).hasClass('customBorderSmall')) {
            $(nTr).find(prevClickedIcon).closest("tr").find("td").toggleClass("showDetailsActive");
            $(nTr).find(prevClickedIcon).next().toggleClass("clickedIcons");
            $(nTr).find(prevClickedIcon).toggleClass("customBorderSmall");
            $(nTr).find(prevClickedIcon).closest("td").find("span").removeClass("clickedIcons");
            otable.fnClose(nTr);
        }

        if (otable.fnIsOpen(nTr)) {
            /* This row is already open - close it */
            otable.fnClose(nTr);
            $(me).closest("tr").find("td").toggleClass("showDetailsActive");
            $(me).removeClass("clickedIcons");
            $(me).toggleClass("customBorderSmall");
            $(me).next().toggleClass("clickedIcons");
            $(nTr).find(prevClickedIcon).closest("td").find("span").toggleClass("clickedIcons");
            // $("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
        }
        else {
            /* Open this row */
            $(me).closest("tr").find("td").toggleClass("showDetailsActive");
            $(me).addClass("clickedIcons");
            $(me).next().toggleClass("clickedIcons");
            $(me).toggleClass("customBorderSmall");
            $(nTr).find(prevClickedIcon).closest("td").find("span").toggleClass("clickedIcons");
            otable.fnOpen(nTr, tempName(otable, nTr), 'details');
            //$("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
        }
    }

    CustomGrid.prototype.CreateGrid = function (configForAlert, configForNotify) {

        $(this.GridDivName).dataTable({
            "data": this.Data,
            "columns": this.Column,
            "pagingType": 'full_numbers',
            "ordering": false,
            "info": false,
            "bLengthChange": false,
            "bAutoWidth": false,
            "searching": false,
            "responsive": true,
            "oLanguage": {
                "oPaginate": {
                    "sFirst": 'First',
                    "sNext": '<img class="Next" src="" />',
                    "sPrevious": '<img class="Previous" src="" />',
                    "sLast": 'Last'
                }
            },
            "fnDrawCallback": function (oSettings) {
                $('span.Show_details').closest('td').addClass('showdetailsTDstyle');
                $('span.Edit').closest('td').addClass('showdetailsTDstyle');
                $('table tr td label.container').closest('td').addClass('tableCheckmarkStyleOveride');

            },
            "bDestroy": true
        });

        if (this.AllowShow)
            CustomGrid.prototype.ShowDetails.call(this);

        //if (this.AllowEdit)
        //    CustomGrid.prototype.EditRow(this, configForAlert);

        if (this.AllowEdit) { this.EditRow(configForAlert, configForNotify); }
    }

    CustomGrid.prototype.ShowDetails = function () {
        $(this.GridDivName + ' tbody td').on('click', '.Show_details', function () {
            var me = this;
            var Edit = '.Edit';
            var tableName = $(this).closest('table').attr('id');

            var oTable = $(this).parents('table').dataTable();
            var nTr = $(this).parents('tr')[0];
             var aData = oTable.fnGetData(nTr);
            // var id = aData['NotificationId'];
            
            var oTable = $(this).parents('table').dataTable();
            triggerRowExpansion(nTr, Edit, oTable, me, fnFormatNotification);
           
            $("#sub").attr('checked', aData['Subscribe']);
            $("#screen").attr('checked',aData['Screen']);
            $("#email").attr('checked',aData['Email']);
            $("#mobile").attr('checked',aData['Mobile']);
           
        });
    }


    CustomGrid.prototype.EditRow = function (configAlertTab, configNotifyTab) {
    
      //Row expansion
            $(this.GridDivName + ' .Edit').click(function () {                       
                var me = this;
                var Show_details = '.Show_details';
                var tableName = $(this).closest('table').attr('id');
                
                var nTr = $(this).parents('tr')[0];
                var oTable = $(this).parents('table').dataTable();
                triggerRowExpansion(nTr, Show_details, oTable, me, fnFormatEdit);
                if(configAlertTab)
                {
                    var aData = oTable.fnGetData(nTr);
                    var id = aData['AlertId'];
                    $('#load').load('Alerts/Edit/'+id);
                }
                if(configNotifyTab)
                {
                     var aData = oTable.fnGetData(nTr);
                      var id = aData['NotificationId'];
                      $('#load').load('Notifications/Edit/' + id);
                }
            });
     
        
//End of Row Expansion
   

    }

    CustomGrid.prototype.Ellipsis = function (cutoff) {
        return function (data, type, row) {
            return data.length > cutoff ? data.substr(0, cutoff) + '…' : data;
        }
    }

    CustomGrid.prototype.CommaSeperatedString = function (listToSplit) {
        return _.chain(listToSplit).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value();
    }


    return CustomGrid;
})();