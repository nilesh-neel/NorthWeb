﻿//----------------------------------------------------------------------
//Class Name   : Menu 
//Purpose      : Menu Class file use to bind the left side menu. 
//               Whit this ajax call we can achive promise in javascripts. 
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------
//Global Variable for the filter module.
var menuItemID = 0;
var Menu = (function () {

    var menuHtml = '';
    /****
    * Creates a new Menu object.
    * @constructor
    *
    */
    Menu = function () { }

    /**
    /* fetch the menu data from database and bind to menu div..
    */
    Menu.prototype.bindMenu = function () {
        var service = new Service('api/menu');

        $.when(service.get()
            .then(function (menuData, favData) {

                sessionStorage.setItem('menuList', JSON.stringify(menuData));

                var parentMenu = _.takeWhile(menuData, function (o) { return o.parentId === 0; });

                for (var i = 0; i < parentMenu.length; i++) {

                    var childList = _.filter(menuData, { parentId: parentMenu[i].menuId });
                    if (_.isEmpty(childList)) {
                        menuHtml += '<li title="' + parentMenu[i].tooltip + '"><span class="' + parentMenu[i].cssIcon + '"></span></li>';
                    }
                    else {
                        var childhtml = '';
                        _.forEach(childList, function (child) {
                            childhtml += '<a title="' + child.tooltip + '"id="' + child.menuId + '"data-isreport="' + child.isReport + '"data-powerbiurl="' + child.url + '"data-powerbiOperUrl="' + child.operationalUrl + '"data-powerbiBussUrl="' + child.businessUrl + '" href=#>' + child.description + '</a>';
                        }) + '</li>';
                        menuHtml += '<li title="' + parentMenu[i].tooltip + '"class="subDropdown"><span class="' + parentMenu[i].cssIcon + '"></span><div class="dropdown-content">' + childhtml + '</div></li>';
                    }
                }

                menuHtml += '<li><span class="defaultIcons .mSetting"></span></li>';
                $('.menu').html(menuHtml);
                Favourites.prototype.GetFavourites.call();
                Menu.prototype.autoRefresh.call();

                //Menu is generating dynamically, Hence, menu hover event should be add after menu construction. 

                $('ul.menu li').hover(function () {
                    $(this).find('span').toggleClass("clickedIcons").toggleClass("defaultIcons");
                }, function () {
                    $(this).find('span').toggleClass("clickedIcons").toggleClass("defaultIcons");
                });

            }).catch(function (jqXHR, textStatus, err) {
                alert('Unable to fetch data for menu: ' + jqXHR.message);
            })
        );
    }

    //ToDo: manage the menu for the multilevel..

    Menu.prototype.bindChildMenu = function (childMenuList) {
        var childhtml = '';
        _.forEach(childMenuList, function (child) {
            childhtml += '<a id="' + child.menuId + '"data-isreport="' + child.isReport + '"data-powerbiurl="' + child.url + '"data-powerbiOperUrl="' + child.operationalUrl + '"data-powerbiBussUrl="' + child.businessUrl + '" href=#>' + child.description + '</a>';
        }) + '</li>';
        return '<li class="subDropdown"><span class="' + parentMenu[i].cssIcon + '"></span><div class="dropdown-content">' + childhtml + '</div></li>';
    }



    /**
    / auto refresh the power bi report.This method fetch the value from the localSession.
    */
    Menu.prototype.autoRefresh = function () {
        $('.dropdown-content a').on('click', function () {
            var self = $(this);
            menuItemID = parseInt(self[0].id);
            sessionStorage.setItem('URLId', self[0].getAttribute('id'));
            sessionStorage.setItem('autoRefURL', self[0].getAttribute('data-powerbiurl'));
            sessionStorage.setItem('autoRefURLIsReport', self[0].getAttribute('data-isreport'));

            sessionStorage.setItem('autoRefBussURL', self[0].getAttribute('data-powerbiBussUrl'));
            sessionStorage.setItem('autoRefOperURL', self[0].getAttribute('data-powerbiOperUrl'));


            sessionStorage.setItem('RptName', self[0].innerText);
            Menu.prototype.getFilterData.call();

            //check the for favorite menu 

            Favourites.prototype.markFavouritesCss.call(this, menuItemID);

            // Display the Add/Remove Baglist buttons only for Baglist screen -- start
            if (self[0].getAttribute('id') == "18") { // ID of Baglist screen
                $("#btnAddBagtags").show();
                $("#btnRemoveBagtags").hide();
                $("#dvOtherUserMyBagList").hide();
                $("#dvDateselection").hide();
            }
            else {
                $("#dvDateselection").show();
                $("#btnAddBagtags").hide();
                $("#btnRemoveBagtags").hide();
                $("#dvOtherUserMyBagList").hide();

            }
           
            
            // Display the Add/Remove Baglist buttons only for Baglist screen -- End

            var oPowerBiApi = new PowerBIAPP(self[0].getAttribute('data-powerbiurl'), self[0].getAttribute('data-isreport'));
            oPowerBiApi.embedPowerBIApi();
        });
    }

    Menu.prototype.ShareUrlFormation = function (filterResult) {
        // For constructing the filter part in share url --- start

        var filtersApplied = "";
        for (var i = 0; i < filterResult.length; i++) {
            var childValue = "";
            for (var j = 0; j < filterResult[i].ColumnValue.length; j++) {
                childValue += filterResult[i].ColumnValue[j] + ',';
            }
            childValue = childValue.substr(0, childValue.length - 1);
            filtersApplied += filterResult[i].TableName + "\\" + filterResult[i].ColumnName + "\\" + filterResult[i].Operator + "\\" + childValue + "&";
        }

        filtersApplied = filtersApplied.substr(0, filtersApplied.length - 1);

        var shareUrl = location.href + "?report=" + sessionStorage.getItem('RptName') + "&id=" + sessionStorage.getItem('URLId') + "&" + filtersApplied;
        $("#lblShareUrl").text(shareUrl);

        // For constructing the Share Url to share the report via Email -- End
    }


    //To Load the filter data in Tempdata
    Menu.prototype.getFilterData = function () {
        var powerBiUrl = sessionStorage.getItem('autoRefURL');
        var isReport = sessionStorage.getItem('autoRefURLIsReport');

        var service = new Service('/Filter/GetFilterByMenuID?menuID=' + menuItemID, 'application/html; charset=utf-8', 'html', null);
        service.get()
            .then(function (resp) {
                if (resp.result !== "null") {
                    var filterResult = JSON.parse(resp.result).FilterItemSelection;
                    if (!_.isNil(filterResult)) {
                        var dashboardPowerBiApi = new PowerBIAPP(powerBiUrl, isReport);
                        dashboardPowerBiApi.applyFilterToReport(filterResult);
                        Menu.prototype.ShareUrlFormation(filterResult);//To construct the Share Url
                    }
                }
            });
    }


    return Menu;

})();
