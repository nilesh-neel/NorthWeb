$(document).ready(function () {
    var showChar = 200;
    var ellipsestext = "...";
    var moretext = "more";
    var lesstext = "less";
    $('.more').each(function () {
        var content = $(this).html();

        if (content.length > showChar) {

            var c = content.substr(0, showChar);
            var h = content.substr(showChar - 1, content.length - showChar);

            var html = c + '<span class="moreelipses">' + ellipsestext + '</span>&nbsp;<span class="morecontent"><span>' + h + '</span>&nbsp;&nbsp;<a href="" class="morelink">' + moretext + '</a></span>';

            $(this).html(html);
        }

    });

    $(".morelink").click(function () {
        if ($(this).hasClass("less")) {
            $(this).removeClass("less");
            $(this).html(moretext);
        } else {
            $(this).addClass("less");
            $(this).html(lesstext);
        }
        $(this).parent().prev().toggle();
        $(this).prev().toggle();
        return false;
    });
});/** read More ends ***/

/*datatables initialization  code*/
$(function () {

    var todaysAlerts = $('#todaysAlertTable').dataTable({
        "pagingType": "full_numbers",
        "ordering": false,
        "info": false,
        "bLengthChange": false,
        "bAutoWidth": false,
        "searching": false,
        "iDisplayLength": 12,
        "responsive": true,
        "oLanguage": {
            "oPaginate": {
                "sFirst": "First",
                "sNext": '<img class="Next" src="" />',
                "sPrevious": '<img class="Previous" src="" />',
                "sLast": "Last"
            }
        }

    });

    var alertsSettings = $('#alertSettingTable').dataTable({
        "pagingType": "full_numbers",
        "ordering": false,
        "info": false,
        "bLengthChange": false,
        "bAutoWidth": false,
        "searching": false,
        "iDisplayLength": 6,
        "responsive": true,
        "oLanguage": {
            "oPaginate": {
                "sFirst": "First",
                "sNext": '<img class="Next" src="" />',
                "sPrevious": '<img class="Previous" src="" />',
                "sLast": "Last"
            }
        }
    });

    var oTable = $('#configureAlertsTable').dataTable({
        "pagingType": "full_numbers",
        "ordering": false,
        "info": false,
        "bLengthChange": false,
        "bAutoWidth": false,
        "searching": false,
        "responsive": true,
        "oLanguage": {
            "oPaginate": {
                "sFirst": "First",
                "sNext": '<img class="Next" src="" />',
                "sPrevious": '<img class="Previous" src="" />',
                "sLast": "Last"
            }
        }
        // "aoColumnDefs": [{ "bVisible": true, "aTargets": [0,1,2,3,4,5,6,7,8] }]
    });





    var todaysNotif = $('#TodaysNotificationsTable').dataTable({
        "pagingType": "full_numbers",
        "ordering": false,
        "info": false,
        "bLengthChange": false,
        "bAutoWidth": false,
        "searching": false,
        "responsive": true,
        "oLanguage": {
            "oPaginate": {
                "sFirst": "First",
                "sNext": '<img class="Next" src="" />',
                "sPrevious": '<img class="Previous" src="" />',
                "sLast": "Last"
            }
        }
    });

    var notifiSettings = $('#notificationSettingsTable').dataTable({
        "pagingType": "full_numbers",
        "ordering": false,
        "info": false,
        "bLengthChange": false,
        "bAutoWidth": false,
        "searching": false,
        "responsive": true,
        "oLanguage": {
            "oPaginate": {
                "sFirst": "First",
                "sNext": '<img class="Next" src="" />',
                "sPrevious": '<img class="Previous" src="" />',
                "sLast": "Last"
            }
        }
    });

    var configureNotif = $('#ConfigureNotificationTable').dataTable({
        "pagingType": "full_numbers",
        "ordering": false,
        "info": false,
        "bLengthChange": false,
        "bAutoWidth": false,
        "searching": false,
        "responsive": true,
        "oLanguage": {
            "oPaginate": {
                "sFirst": "First",
                "sNext": '<img class="Next" src="" />',
                "sPrevious": '<img class="Previous" src="" />',
                "sLast": "Last"
            }
        }
    });

    var reportDataTable = $('#reportsTable').dataTable({
        "pagingType": "full_numbers",
        "ordering": false,
        "info": false,
        "bLengthChange": false,
        "bAutoWidth": false,
        "searching": false,
        "responsive": true,
        "oLanguage": {
            "oPaginate": {
                "sFirst": "First",
                "sNext": '<img class="Next" src="" />',
                "sPrevious": '<img class="Previous" src="" />',
                "sLast": "Last"
            }
        }
    });

    function triggerRowExpansion(nTr, prevClickedIcon, otable, me, tempName) {

        //console.log($(nTr));

        otable.api().rows().every(function () {
            //&& !$(this.node()).hasClass('show_row')
            if (otable.fnIsOpen(this) && !($(this.node()).hasClass('show_row'))) {
                //console.log(this.node());
                //console.log(nTr);
                //console.log($(nTr));
                //otable.fnClose(this);
                // $(this.node()).removeClass('show_row')
                // $(this.node()).removeClass();
                $(this.node()).find("td").removeClass("showDetailsActive");
                $(this.node()).find("td span.clickedIcons").removeClass("clickedIcons").removeClass('customBorderSmall');
            }

        });

        // if ( !otable.fnIsOpen(nTr) )
        // {

        if ($(nTr).find(prevClickedIcon).hasClass('customBorderSmall')) {
            $(nTr).find(prevClickedIcon).closest("tr").find("td").toggleClass("showDetailsActive");
            $(nTr).find(prevClickedIcon).next().toggleClass("clickedIcons");
            $(nTr).find(prevClickedIcon).toggleClass("customBorderSmall");
            $(nTr).find(prevClickedIcon).closest("td").find("span").removeClass("clickedIcons");
            otable.fnClose(nTr);

        }

        if (otable.fnIsOpen(nTr)) {
            /* This row is already open - close it */
            // $(nTr).removeClass('show_row');
            otable.fnClose(nTr);
            $(me).closest("tr").find("td").toggleClass("showDetailsActive");
            $(me).removeClass("clickedIcons");
            $(me).toggleClass("customBorderSmall");
            $(me).next().toggleClass("clickedIcons");
            $(nTr).find(prevClickedIcon).closest("td").find("span").toggleClass("clickedIcons");
            // $("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
        }
        else {
            /* Open this row */
            // $(nTr).addClass('show_row');
            $(me).closest("tr").find("td").toggleClass("showDetailsActive");
            $(me).addClass("clickedIcons");
            $(me).next().toggleClass("clickedIcons");
            $(me).toggleClass("customBorderSmall");
            $(nTr).find(prevClickedIcon).closest("td").find("span").toggleClass("clickedIcons");
            otable.fnOpen(nTr, tempName(otable, nTr), 'details');

            //$("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
        }

        //}
    }

    $('table tbody td ').on('click', '.Show_details', function () {


        var nTr = $(this).parents('tr')[0];

        $(this).closest('table').find('tr.show_row').removeClass('show_row');
        $(nTr).addClass('show_row');


        var me = this;
        var Edit = '.Edit';
        var tableName = $(this).closest('table').attr('id');

        //console.log($(this).closest('table').attr('id'));
        //console.log(nTr);






        if (tableName === 'alertSettingTable') {

            triggerRowExpansion(nTr, Edit, alertsSettings, me, fnFormatalertsSettings);

        }

        if (tableName === 'configureAlertsTable') {

            triggerRowExpansion(nTr, Edit, oTable, me, fnFormatDetails);

        }

        if (tableName === 'ConfigureNotificationTable') {

            triggerRowExpansion(nTr, Edit, configureNotif, me, fnFormatConfNotification);

        }

        if (tableName === 'notificationSettingsTable') {


            triggerRowExpansion(nTr, Edit, notifiSettings, me, fnFormatNotification);

        }

        if (tableName === 'todaysAlertTable') {

            triggerRowExpansion(nTr, Edit, todaysAlerts, me, fnFormatTodaysAlerts);

        }

        if (tableName === 'TodaysNotificationsTable') {

            triggerRowExpansion(nTr, Edit, todaysNotif, me, fnFormatTodaysNotif);

        }

        if (tableName === 'reportsTable') {
            triggerRowExpansion(nTr, Edit, reportDataTable, me, fnFormatReportsTable);

        }

    });

    $('table tbody td ').on('click', '.Edit', function () {
        var nTr = $(this).parents('tr')[0];;
        var me = this;
        var Show_details = '.Show_details';
        var tableName = $(this).closest('table').attr('id');

        $(this).closest('table').find('tr.show_row').removeClass('show_row');
        $(nTr).addClass('show_row');
        if (tableName === 'alertSettingTable') {

            triggerRowExpansion(nTr, Show_details, alertsSettings, me, fnFormatEditAlertsDetails);

        }

        if (tableName === 'configureAlertsTable') {

            triggerRowExpansion(nTr, Show_details, oTable, me, fnFormatEditAlertsDetails);

        }

        if (tableName === 'ConfigureNotificationTable') {

            triggerRowExpansion(nTr, Show_details, configureNotif, me, fnFormatEditNotificationDetails);

        }

        if (tableName === 'notificationSettingsTable') {


            triggerRowExpansion(nTr, Show_details, notifiSettings, me, fnFormatEditNotificationDetails);

        }

        if (tableName === 'reportsTable') {
            triggerRowExpansion(nTr, Show_details, reportDataTable, me, fnFormatEditNotificationDetails);

        }


        /***datepicker***/
        $(".formCalendarIcon").daterangepicker({
            singleDatePicker: true,
            showDropdowns: true
        });
        /***datepicker ends***/

        //$(".combobox").combobox();
        //$(".custom-combobox-input ").attr("placeholder", "Select");

        /*multi select*/

        //$('select[multiple]').multiselect({
        //    columns: 1,
        //    placeholder: 'Select',
        //    search: true,

        //    texts: {
        //        placeholder: 'Select options', // text to use in dummy input
        //        search: 'Type here',         // search input placeholder text
        //        selectedOptions: ' selected',      // selected suffix text
        //        selectAll: 'Select all',     // select all text
        //        unselectAll: 'Unselect all',   // unselect all text
        //        noneSelected: 'None Selected'   // None selected text
        //    },
        //    minHeight: 150,   // minimum height of option overlay
        //    maxHeight: 150,   // maximum height of option overlay
        //    maxWidth: 245,
        //    selectAll: false
        //});

        /*multiselect end */

    });





    /* Pin Icon functionality in filters panel start */

    //$('#pinIcon').click(function (event) {


    //    $('#pinIcon').toggleClass("Pin");
    //    $('#pinIcon').toggleClass("pinclicked");
    //});

    //$('#pinIconLink').hover(function (event) {

    //    $(this).removeClass('hovered-content');
    //    if ($('#pinIcon').hasClass("pinclicked")) {
    //        $('#pinIconLink').tooltip("hide");
    //        $(this).addClass('hovered-content');


    //    }
    //});

    /* Pin Icon functionality in filters panel end */

    //$('select[multiple]').multiselect({
    //    columns: 1,
    //    placeholder: 'Select',
    //    search: true,

    //    texts: {
    //        placeholder: 'Select options', // text to use in dummy input
    //        search: 'Type here',         // search input placeholder text
    //        selectedOptions: ' selected',      // selected suffix text
    //        selectAll: 'Select all',     // select all text
    //        unselectAll: 'Unselect all',   // unselect all text
    //        noneSelected: 'None Selected'   // None selected text
    //    },
    //    minHeight: 150,   // minimum height of option overlay
    //    maxHeight: 150,   // maximum height of option overlay
    //    maxWidth: 245,
    //    selectAll: false
    //});

    /* mutiselect in share panel end */

    /* vertical tabs click functionality*/

    $('a[href="#alerts"]').click(function (event) {
        $('#tabs ul li').css('display', 'none');
        $('.configureAlertForm').css('display', 'none');
        $("#configureAlertsTable_wrapper").show();
        $('.alertTabs').css('display', 'block');
        $(".dataTables_paginate").css('display', 'block');
        $('a[href="#todaysAlerts"]').trigger('click');
    });

    $('a[href="#notification"]').click(function (event) {
        $('#tabs ul li').css('display', 'none');
        $('.configureAlertForm').css('display', 'none');
        $('.notificationTabs').css('display', 'block');
        $(".dataTables_paginate").css('display', 'block');
        $('a[href="#todaysNotifications"]').trigger('click');
    });

    $('a[href="#reports"]').click(function (event) {

        $('#tabs ul li').css('display', 'none');
        $('.configureAlertForm').css('display', 'none');
        $('.reportTabs').css('display', 'block');
        $(".dataTables_paginate").css('display', 'block');
        $('a[href="#reportsTab"]').trigger('click');


    });

    $('#tabs a[href="#todaysAlerts"]').click(function (event) {
        $('.configureAlertForm').css('display', 'none');
        $('.configureBtn').css('display', 'block');
        $('.configureBtn button').css('display', 'none');


    });


    $('#tabs a[href="#alertSettings"]').click(function (event) {
        $('.configureAlertForm').css('display', 'none');
        $('.configureBtn').css('display', 'block');
        $('.configureBtn button').css('display', 'none');


    });

    $('#tabs a[href="#configureAlerts"]').click(function (event) {
        $('.configureBtn').css('display', 'block');
        $('.configureBtn button').css('display', 'none');
        $('#congigureNewAlertBtn').css('display', 'block');

    });

    $('#tabs a[href="#todaysNotifications"]').click(function (event) {
        $('.configureAlertForm').css('display', 'none');
        $('.configureBtn').css('display', 'block');
        $('.configureBtn button').css('display', 'none');


    });

    $('#tabs a[href="#notificationSettings"]').click(function (event) {
        $('.configureAlertForm').css('display', 'none');
        $('.configureBtn').css('display', 'block');
        $('.configureBtn button').css('display', 'none');


    });

    $('#tabs a[href="#configureNotifications"]').click(function (event) {
        $('.configureAlertForm').css('display', 'none');
        $('.configureBtn').css('display', 'block');
        $('.configureBtn button').css('display', 'none');


    });


    $('#tabs a[href="#reportsTab"]').click(function (event) {
        $('.configureAlertForm').css('display', 'none');

        $('.configureBtn').css('display', 'block');
        $('.configureBtn button').css('display', 'none');
        $('#newReportBtn').css('display', 'block');

    });

    $('#tabs a[href="#assignHomePagePanel"]').click(function (event) {
        $('.configureAlertForm').css('display', 'none');

        $('.configureBtn').css('display', 'block');
        $('.configureBtn button').css('display', 'none');


    });





    $('a[href="#reports"]').click(function (event) {

        $('#tabs ul li').css('display', 'none');
        $('.configureAlertForm').css('display', 'none');
        $('.reportTabs').css('display', 'block');
        $('#newReportBtn').css('display', 'block');
        $(".dataTables_paginate").css('display', 'block');
        $('a[href="#reportsTab"]').trigger('click');


    });





    $('a[href="#assignHomePageNav"]').click(function (event) {
        $('#tabs ul li').css('display', 'none');
        $('.configureAlertForm').css('display', 'none');
        $('.assignHomeTabs').css('display', 'block');
        $(".dataTables_paginate").css('display', 'none');
        $('a[href="#assignHomePagePanel"]').trigger('click');

    });


    // /* congigureNewAlertBtn button functionality in configureSettings tab start*/
    $("#congigureNewAlertBtn").click(function () {

        $('#tabs ul li').css('display', 'none');
        $('.congigureTab').css('display', 'block');
        // $('#tabs a[href="#configureAlerts"]').click();
        $("#configureAlertsTable_wrapper").css('display', 'none');
        $('.configureBtn').css('display', 'block');
        $('.configureBtn button').css('display', 'none');
        $('#configureBackBtn').css('display', 'block');
        $('.configureAlertForm').css('display', 'block');



    });

    $("#configureBackBtn").click(function () {
        $('#tabs ul li').css('display', 'none');
        $('.alertTabs').css('display', 'block');
        $('.configureBtn').css('display', 'block');
        $('.configureBtn button,.configureAlertForm').css('display', 'none');
        // $("#tabs a[href='#alertSettings'] , #tabs a[href='#todaysAlerts']").css('display','block');
        $("#configureAlertsTable_wrapper").show();
        $("#tabs a[href='#configureAlerts']").click();


    });



    function fittabletoscreen() {

        //console.log("fittabletoscreen is called");

        //console.log($(window).width());
        //console.log($(window).height);

        if ($(window).width() <= 1024 && $(window).width() >= 768) {


            alertsSettings.fnSetColumnVis(6, false, false);
            alertsSettings.fnSetColumnVis(7, false, false);
            alertsSettings.fnSetColumnVis(0, true, true);
            alertsSettings.fnSetColumnVis(3, true, true);
            alertsSettings.fnSetColumnVis(4, true, true);
            oTable.fnSetColumnVis(0, true, true);
            oTable.fnSetColumnVis(3, true, true);
            oTable.fnSetColumnVis(5, true, true);
            oTable.fnSetColumnVis(4, false, false);
            oTable.fnSetColumnVis(6, false, false);
            oTable.fnSetColumnVis(7, false, false);
            configureNotif.fnSetColumnVis(4, false, false);
            configureNotif.fnSetColumnVis(6, false, false);
            configureNotif.fnSetColumnVis(7, false, false);
            configureNotif.fnSetColumnVis(8, false, false);
            configureNotif.fnSetColumnVis(3, true, true);
            configureNotif.fnSetColumnVis(5, true, true);
            todaysAlerts.fnSetColumnVis(4, true, true);
            notifiSettings.fnSetColumnVis(3, true, true);

        }

        else if ($(window).width() <= 767 && $(window).width() >= 320) {
            todaysAlerts.fnSetColumnVis(4, false, false);
            alertsSettings.fnSetColumnVis(0, false, false);
            alertsSettings.fnSetColumnVis(3, false, false);
            alertsSettings.fnSetColumnVis(4, false, false);
            alertsSettings.fnSetColumnVis(6, false, false);
            alertsSettings.fnSetColumnVis(7, false, false);
            notifiSettings.fnSetColumnVis(3, false, false);

            oTable.fnSetColumnVis(0, false, false);
            oTable.fnSetColumnVis(3, false, false);
            oTable.fnSetColumnVis(4, false, false);
            oTable.fnSetColumnVis(5, false, false);
            oTable.fnSetColumnVis(6, false, false);
            oTable.fnSetColumnVis(7, false, false);

            configureNotif.fnSetColumnVis(3, false, false);
            configureNotif.fnSetColumnVis(4, false, false);
            configureNotif.fnSetColumnVis(5, false, false);
            configureNotif.fnSetColumnVis(6, false, false);
            configureNotif.fnSetColumnVis(7, false, false);
            configureNotif.fnSetColumnVis(8, false, false);



        }

        else {
            alertsSettings.fnSetColumnVis(6, true, true);
            alertsSettings.fnSetColumnVis(7, true, true);
            alertsSettings.fnSetColumnVis(0, true, true);
            alertsSettings.fnSetColumnVis(3, true, true);
            alertsSettings.fnSetColumnVis(4, true, true);

            oTable.fnSetColumnVis(4, true, true);
            oTable.fnSetColumnVis(6, true, true);
            oTable.fnSetColumnVis(7, true, true);
            oTable.fnSetColumnVis(0, true, true);
            oTable.fnSetColumnVis(3, true, true);
            oTable.fnSetColumnVis(5, true, true);
            configureNotif.fnSetColumnVis(3, true, true);
            configureNotif.fnSetColumnVis(4, true, true);
            configureNotif.fnSetColumnVis(5, true, true);
            configureNotif.fnSetColumnVis(6, true, true);
            configureNotif.fnSetColumnVis(7, true, true);
            configureNotif.fnSetColumnVis(8, true, true);
            todaysAlerts.fnSetColumnVis(4, true, true);
            notifiSettings.fnSetColumnVis(3, true, true);
        }

    };


    fittabletoscreen();  //initial call
    $(window).resize(function () {
        //change in landscape and portrait view
        //console.log('resize called');
        fittabletoscreen();
    });




});

$(document).ready(function () {


    /***datepicker***/
    $(".formCalendarIcon").daterangepicker({

        singleDatePicker: true,
        showDropdowns: true

    });
    /***datepicker ends***/

    /**search **/

    $(".searchImg").click(function () {
        if ($(this).siblings(".searchIcon").val())
            $(".loader").css("display", "inline-block");

    });

    /**search ends**/
    /*** vertical breadcrumb ****/
    $(".navADPBreadCrumb").click(function () {
        //console.log("hi");
        event.stopPropagation();
        $(".verticalNavigation").toggle();

    });


    /***refresh***/
    $(".refresh").click(function () {

        $(".refreshMessage").css("display", "block");
    });


    $(".closeText").click(function () {
        $(".refreshMessage").css("display", "none");
    });

    /***refresh close***/

    $('.hamburger').click(function (event) {
        event.stopPropagation();
        $('#homeNavigationBar').toggleClass('active');
    });

    $(".logout").click(function () {
        $("#exampleModalCenter").modal('show');
    });

    /**logout toggle***/
    $(".user").click(function (event) {
        event.stopPropagation();
        $(".settingsLogout").toggle();
    });

    $("#userDetailsPanel").click(function (event) {
        event.stopPropagation();
        $('.settingsLogout').attr("style", "display: inline-block !important");
    });

    $(document).click(function (e) {
        $(".settingsLogout,.alertPopup,.verticalNavigation").hide();
        $('#homeNavigationBar').removeClass('active');
        //console.log('e.target.id', e);
        if (e.target.id !== "mobileSearchInputBox" && e.target.id !== "searchMobile" && e.target.id === "userDetailsPanel")
        //if(e.target.id!=="mobileSearchInputBox" && e.target.id!=="searchMobile")
        {
            $(".searchDivMobile").css("display", "none");
            $('.searchImgMobile').attr("style", "display: inline-block !important");
            $('.settingsLogout').attr("style", "display: inline-block !important");
        }
    });


    /**logout toggle ends***/



    /**note script**/
    $('.share,.cancel').click(function (event) {
        event.stopPropagation();
        $(".sideNavBar").not("#" + $(this).data("sidepanel")).css("display", "none");
        $(this).children(".spanNotification").css("display", "none");
        
        $("#" + $(this).data("sidepanel")).toggle();

        if ($(this).parent().data("iconclick"))//cancel click
        {

            $("." + $(this).parent().data("iconclick")).toggleClass("clickedIcons");
            $("." + $(this).parent().data("iconclick")).toggleClass("customBorderSmall");
        }

        else//icon click
        {
            $('.share,.cancel').not(this).removeClass("clickedIcons");
            $('.share,.cancel').not(this).removeClass("customBorderSmall");
            $(this).toggleClass("clickedIcons");
            $(this).toggleClass("customBorderSmall");
        }

    });




    /**note script Ends**/
    $(".notification").click(function (event) {
        event.stopPropagation();
        $(this).children(".spanNotification").css("display", "none");
        $(".alertPopup").toggle();
    });

    /** alert Popup**/
    $(".alertPopup").click(function (event) {
        event.stopPropagation();
    });
    $("#viewAllBtn").click(function (event) {
        event.stopPropagation();
    });


    $(document).ready(function () {  /***hambereger hover***/
        jQuery('.hambergerDiv').on('hover', function () {

            jQuery(this).find('.defaultIcons').toggleClass("clickedIcons").toggleClass("defaultIcons");
        }, function () {
            jQuery(this).find('.clickedIcons').toggleClass("clickedIcons").toggleClass("defaultIcons");
        });

        /***Menu  hover***/
        jQuery("ul.menu").on('hover', 'li', function () {
            console.log('ul.menu.li hover');
            jQuery(this).find('span').toggleClass("clickedIcons").toggleClass("defaultIcons");
        }, function () {
            console.log('ul.menu.li hover callback..');
            jQuery(this).find('span').toggleClass("clickedIcons").toggleClass("defaultIcons");
        });



        /****vertical tabs hover***/

        jQuery('#verticalTabs li').click(function () {


            jQuery('#verticalTabs li').find('span:first-child').removeClass("clickedIcons").addClass("defaultIcons");
            jQuery(this).find('span:first-child').toggleClass("clickedIcons").toggleClass("defaultIcons");

        });



    });


    /***groomcroll***/


    $('.scrollbar-inner').scrollbar();


    /***groomscroll Ends***/
});
// Example starter JavaScript for disabling form submissions if there are invalid fields
/***Date Range Picker***/

$(function () {

    $('input[name="daterange"]').daterangepicker(
        {
            locale: {
                format: 'YYYY-MM-DD'
            },
            startDate: '2013-02-01',
            endDate: '2013-03-31'
        });
});
/*** Date Range Picker End ***/

/*** Form validation***/
(function () {
    'use strict';
    window.addEventListener('load', function () {
        // Fetch all the forms we want to apply custom Bootstrap validation styles to
        var forms = document.getElementsByClassName('needs-validation');
        // Loop over them and prevent submission
        var validation = Array.prototype.filter.call(forms, function (form) {
            form.addEventListener('submit', function (event) {
                if (form.checkValidity() === false) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    }, false);
})();

/****Form Validation End ***/

var expanded = false;

function showCheckboxes() {
    //var checkboxes = $("#checkboxes");
    if (!expanded) {
        //checkboxes.style.display = "block";
        $("#checkmarkOuterDiv").css('display', 'block');
        expanded = true;
    } else {
        //checkboxes.style.display = "none";
        $("#checkmarkOuterDiv").css('display', 'none');
        expanded = false;
    }
}

var panelSlided = false;
// $(".slidePanel").css('display','none');

function showAlertDetails() {

    if (!panelSlided) {
        //checkboxes.style.display = "block";
        $(".slidePanel").css('display', 'block');
        panelSlided = true;
    } else {
        //checkboxes.style.display = "none";
        $(".slidePanel").css('display', 'none');
        panelSlided = false;
    }

}


/* Range slider */

$("#range_35").ionRangeSlider({
    type: "double",
    min: 0,
    max: 24,
    from: 10,
    to: 18,
    grid: true

});

/* daterangePicker for single calender*/



/* tooltip styling and html */

$('[data-toggle="tooltip"]').each(function () {
    var options = {
        html: true
    };

    if ($(this)[0].hasAttribute('data-type')) {
        options['template'] =
            '<div class="tooltip ' + $(this).attr('data-type') + '" role="tooltip">' +
            ' <div class="tooltip-arrow"></div>' +
            ' <div class="tooltip-inner"></div>' +
            '</div>';
    }

    $(this).tooltip(options);
});

/* Row expansion Template for configure Alerts Table */
function fnFormatDetails(oTable, nTr) {
    var aData = oTable.fnGetData(nTr);
    var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
    sOut += '<tr><td>Alert ID:</td><td>' + aData[0] + '</td></tr>';
    sOut += '<tr><td>Measure Name:</td><td>Probon namepue</td></tr>';
    sOut += '<tr><td>Title:</td><td>' + aData[1] + '</td></tr>';
    sOut += '<tr><td>Audience Group:</td><td>' + aData[1] + '</td></tr>';
    sOut += '<tr><td>Recipients:</td><td>' + aData[1] + '</td></tr>';
    sOut += '<tr><td>Description:</td><td>Lorem ipsum peutriea haver baker dovery tragic hebnac looping fidharo.</td></tr>';
    sOut += '<tr><td>Topic:</td><td>' + aData[2] + '</td></tr>';
    sOut += '<tr><td>Location:</td><td>' + aData[3] + '</td></tr>';
    sOut += '<tr><td>Thershold:</td><td>' + aData[1] + '</td></tr>';
    sOut += '<tr><td>Thershold Value:</td><td>' + aData[1] + '</td></tr>';
    sOut += '<tr><td>Mandatory/optional:</td><td>optional</td></tr>';
    sOut += '<tr><td>Start Date:</td><td>12/01/2018</td></tr>';
    sOut += '<tr><td>End Date:</td><td>20/01/2018</td></tr>';
    sOut += '<tr><td>Disable Alert:</td><td>No</td></tr>';
    sOut += '<tr><td>Created By:</td><td>' + aData[4] + '</td></tr>';
    sOut += '<tr><td>Created:</td><td>' + aData[5] + '</td></tr>';
    sOut += '<tr><td>Modified By:</td><td>' + aData[7] + '</td></tr>';
    sOut += '<tr><td>Modified:</td><td>' + aData[6] + '</td></tr>';
    sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
    sOut += '</table>';

    return sOut;
}

function fnFormatEditAlertsDetails(oTable, nTr) {
    var aData = oTable.fnGetData(nTr);
    var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
    sOut += '<tr><td> <label class="formItalictext">*Mandatory Fields</label></td><td></td></tr>';
    sOut += '<tr><td>Not ID:</td><td>ALT_02</td></tr>';
    sOut += '<tr><td>Measure Name:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Measure Name*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="" selected disabled>select</option><option value="Lorem ipsum">Lorem ipsum</option><option value="fiat">Fiat</option><option value="audi">Audi</option><option value="ActionScript">ActionScript</option></select></div></div></td></tr>';
    sOut += '<tr><td>Title:</td><td><input type="text" class="form-control" id="inputName" placeholder="Enter Title (50 characters)" data-error="*Mandatory Field" required></td></tr>';
    sOut += '<tr><td>Audience Group:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Audience Group*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Recipients:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Recipients*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Description:</td><td><textarea type="textarea" width="262px" height="50px" data-error="*Mandatory Field" class="form-control" placeholder="Enter Description (140 characters)" required></textarea></td></tr>';
    sOut += '<tr><td>Topic:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Topic*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Location:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Location*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Thershold:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Thershold*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Thershold Value:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Thershold Value*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Mandatory/optional:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Mandatory/optional*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Start Date:</td><td><input type="text"  class="formCalendarIcon " /></td></tr>';
    sOut += '<tr><td>End Date:</td><td> <input type="text" class="formCalendarIcon " /></td></tr>';
    sOut += '<tr><td>Disable Alert:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Disable Alert*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Created By:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
    sOut += '<tr><td>Created:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
    sOut += '<tr><td>Modified By:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
    sOut += '<tr><td>Modified:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
    sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
    sOut += '<tr><td></td><td style="text-align:right;"><button class="btn btn-sm btn-default">Cancel</button><button class="btn btn-default ">Save</button></td></tr>';
    sOut += '</table>';

    return sOut;
}

function fnFormatEditNotificationDetails(oTable, nTr) {
    var aData = oTable.fnGetData(nTr);
    var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
    sOut += '<tr><td> <label class="formItalictext">*Mandatory Fields</label></td><td></td></tr>';
    sOut += '<tr><td>Not ID:</td><td>ALT_02</td></tr>';
    sOut += '<tr><td>Measure Name:</td><td><div class="multiselect"><select multiple="multiple" name="Measure Name*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="Lorem ipsum">Lorem ipsum</option><option value="fiat">Fiat</option><option value="Lorem ipsum2">Lorem ipsum2</option><option value="Lorem ipsum1">Lorem ipsum1</option><option value="audi">Audi</option><option value="ActionScript">ActionScript</option></select></div></td></tr>';
    sOut += '<tr><td>Title:</td><td><input type="text" class="form-control" id="inputName" placeholder="Enter Title (50 characters)" data-error="*Mandatory Field" required></td></tr>';
    sOut += '<tr><td>Audience Group:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Audience Group*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Recipients:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Recipients*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Description:</td><td><textarea type="textarea" width="262px" height="50px" data-error="*Mandatory Field" class="form-control" placeholder="Enter Description (140 characters)" required></textarea></td></tr>';
    sOut += '<tr><td>Topic:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Topic*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Location:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Location*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Thershold:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Thershold*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Thershold Value:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Thershold Value*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Mandatory/optional:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Mandatory/optional*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Start Date:</td><td><input type="text"  class="formCalendarIcon " /></td></tr>';
    sOut += '<tr><td>End Date:</td><td> <input type="text" class="formCalendarIcon " /></td></tr>';
    sOut += '<tr><td>Disable Alert:</td><td><div class="dropdown"><div class="ui-widget form-group comboStylings"><select class="combobox" name="Disable Alert*" data-error="*Mandatory Field" class="form-control topMargin comboSelect" required><option value="">Select</option><option value="saab">Saab</option><option value="fiat">Fiat</option><option value="audi">Audi</option></select></div></div></td></tr>';
    sOut += '<tr><td>Created By:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
    sOut += '<tr><td>Created:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
    sOut += '<tr><td>Modified By:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
    sOut += '<tr><td>Modified:</td><td><input type="text" class="form-control" id="inputName" placeholder="Type here" data-error="*Mandatory Field" required></td></tr>';
    sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
    sOut += '<tr><td></td><td style="text-align:right;"><button class="btn btn-sm btn-default">Cancel</button><button class="btn btn-default ">Save</button></td></tr>';
    sOut += '</table>';

    return sOut;
}

/*Row expansion Template for notificationSettings Table */
function fnFormatNotification(oTable, nTr) {
    var aData = oTable.fnGetData(nTr);
    var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
    sOut += '<tr><td>Topic:</td><td>' + aData[1] + '</td></tr>';
    sOut += '<tr><td>Location:</td><td>' + aData[2] + '</td></tr>';
    sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
    sOut += '</table>';

    return sOut;
}



function fnFormatalertsSettings(oTable, nTr) {
    var aData = oTable.fnGetData(nTr);
    var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
    sOut += '<tr><td>Topic:</td><td>' + aData[1] + '</td></tr>';
    sOut += '<tr><td>Location:</td><td>' + aData[2] + '</td></tr>';
    sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
    sOut += '</table>';

    return sOut;
}

function fnFormatTodaysAlerts(oTable, nTr) {

    var aData = oTable.fnGetData(nTr);

    var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
    sOut += '<tr><td>Time</td><td>' + aData[1] + '</td></tr>';
    sOut += '<tr><td>Description:</td><td>' + aData[0] + '</td></tr>';
    sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
    sOut += '</table>';

    return sOut;
}

function fnFormatTodaysNotif(oTable, nTr) {

    var aData = oTable.fnGetData(nTr);

    var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
    sOut += '<tr><td>Topic</td><td>' + aData[1] + '</td></tr>';
    sOut += '<tr><td>Description:</td><td>' + aData[0] + '</td></tr>';
    sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
    sOut += '</table>';

    return sOut;
}

function fnFormatConfNotification(oTable, nTr) {

    var aData = oTable.fnGetData(nTr);

    var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
    sOut += '<tr><td>NOT_ID</td><td>' + aData[0] + '</td></tr>';
    sOut += '<tr><td>Topic:</td><td>' + aData[1] + '</td></tr>';
    sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
    sOut += '</table>';

    return sOut;
}

function fnFormatReportsTable(oTable, nTr) {

    var aData = oTable.fnGetData(nTr);

    var sOut = '<table cellpadding="2" class="slidingRow" cellspacing="0" border="0" style="padding-left:0px;">';
    sOut += '<tr><td>NOT_ID</td><td>' + aData[0] + '</td></tr>';
    sOut += '<tr><td>Topic:</td><td>' + aData[1] + '</td></tr>';
    sOut += '<tr><td>&nbsp;</td><td><label  for"Subscribe" class="textLabel panelCheckBox">Subscribe<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"On Screen" class="textLabel panelCheckBox">On Screen<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label  for"Email" class="textLabel panelCheckBox">Email<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label><label for"Mobile" class="textLabel panelCheckBox">Mobile<input type="checkbox" checked="checked" data-error="*Mandatory Field" required><span class="checkmark"></span></label></td></tr>';
    sOut += '</table>';

    return sOut;
}

$("span.Show_details").closest("td").addClass("showdetailsTDstyle");
$("span.Edit").closest("td").addClass("showdetailsTDstyle");
$('.ui-autocomplete-input').css('width', '100px');
$('table tr td label.container').closest("td").addClass("tableCheckmarkStyleOveride");

/***breadcrumbs***/
$(".menu li").click(function () {
    $(".breadcrumb li").remove();
    $(".verticalNavigation li").remove();
    var menuVal = $(this).data("menulist");
    $.each(menu, function (key, value) {
        if (menuVal == key) {
            $(".navADP").html(menuVal);
            var elm = "";
            $.each(value, function (k, val) {
                if ($(".breadcrumb").css("display") !== "none") {
                    elm += "<li><a href='#' >" + val + "</a></li>";
                }
                else {
                    elm += "<li class='customStyling'><a href='#' >" + val + "</a></li>";
                }
            });
            $(".breadcrumb").append(elm);
            $(".breadcrumb li:eq(0)").addClass("active");
            $(".verticalNavigation").append(elm);
        }
    });
});

var menu = {
    Home: null,
    Baglist: null,
    BagDetails: null,
    Status: null,
    FlightDetailsInbound: { 0: "Flight Details - Inbound" },

    FlightDetailsOutbound: { 0: "Flight Details - Outbound" },
    ADP: {
        0: "ADP Dashboard  ",
        1: "ADP Summary  ",

        2: "ADP Detail "

    },
    DDP: {
        0: "DDP Dashboard",
        1: "DDP Detail",
        2: "DDP Summary"

    },

    BJP: {
        0: "BJP Dashboard ",
        1: "BJP Summary ",

        2: "BJP Detail"

    },
    BaggageStatusInbound: { 0: "Baggage Status Inbound" },
    BaggageStatusOutbound: { 0: "Baggage Status Outbound" },
    NLB: {
        0: "NLB Dashboard",
        1: "NLB Summary",
        2: "NLB Detail"

    },
    ARR: {
        0: "Arriving Flights Next 2 Hours",
        1: "Flight Arrivals Dashboard"

    },

    ITT: {
        0: "ITT Dashboard",
        1: "ITT Detail"

    },
    VOL: {
        0: "Departure Volumes Summary"
    },
    BSM: {
        0: "Late BSM Summary"
    },
    MDR: {
        0: "Mass Disruption Summary",
        1: "Mass Disruption Detail"
    },
    setting: { 0: "Alerts" }


};

/***breadcrumbs End***/

$('body').on('click', '.breadcrumb li a', function () {
    $(".breadcrumb li").removeClass("active");
    $(this).parent().addClass("active");
});

$(".searchImgMobile").click(function () {
    event.stopPropagation();
    $(".searchDivMobile").css("display", "block");
    $('.searchImgMobile').attr("style", "display: none !important");
});