﻿using System.Collections.Generic;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Core.Interface
{
    public interface ILocation
    {
        IEnumerable<Locations> GetLocation();
    }
}
