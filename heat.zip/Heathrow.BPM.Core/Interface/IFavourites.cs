﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Core.Interface
{
    public interface IFavourites : IRepository<Favourites>
    {
        //  IEnumerable<Favourites> GetUserFavourites(string _userId);
        Task<int> Save(Favourites _favourites);
        Task<List<Favourites>> GetUserFavourites(string _userId);
    }
}
