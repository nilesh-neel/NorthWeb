﻿namespace Heathrow.BPM.Core.Entity
{
    public class Locations :BaseLookUpEnt
    {
     

    }
   
}
