﻿/****************************************************************************************************************
Class Name   : BagList.cs 
Purpose      : This is the Entity file for BagList Module in the application...
Created By   : Vignesh AshokKumar 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Heathrow.BPM.Core.Entity
{
    [ComplexType]
    public class BagList
    {
        [Column("BagList_ID", Order = 0)]
        public int BagListID { get; set; }

        [Column("Bag_Tag", Order = 0)]
        public string Bagtags { get; set; }

        public string UserId { get; set; }

        [Column("User_ID", Order = 0)]
        public int OthersMybaglistUserId { get; set; }

        [Column("First_Name", Order = 1)]
        public string UserFirstname { get; set; }

        [Column("Last_Name", Order = 2)]
        public string UserLasttname { get; set; }

        [Column("Email", Order = 3)]
        public string UserEmail { get; set; }

        [Column("Organization", Order = 4)]
        public string UserOrg { get; set; }

        [Column("Job_Role", Order = 5)]
        public string UserRole { get; set; }


        public DateTime UpdatedDate { get; set; }

    }
   
}
