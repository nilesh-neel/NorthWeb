﻿using System.Collections.Generic;

namespace Heathrow.BPM.Core.Entity
{
  public class AssignHomePage
    {
        public string AudienceGroup { get; set; }
        public List<string> Recipients { get; set; }
    }
}
