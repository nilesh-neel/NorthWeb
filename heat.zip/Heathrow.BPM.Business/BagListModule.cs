﻿/****************************************************************************************************************
Class Name   : BagListModule.cs 
Purpose      : This class implements the Business Logic of the BagList Module.
Created By   : Vignesh AshokKumar 
Created Date : 11/Sep/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Business
{
    public class BagListModule : IBagListModule
    {
        private static IBagList _baglist { get; set; }

        public BagListModule(IBagList bagList)
        {
            _baglist = bagList;
        }

        public Task<string> GetUserExistingbagtags(int UserId)
        {
            try
            {
                return _baglist.GetUserExistingBagtags(UserId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public Task<int> GetUserExistingbagtagsCnt(int UserId)
        //{
        //    try
        //    {
        //        return _baglist.GetUserExistingBagtagsCnt(UserId);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        public Task<string> RemoveBagTags(string Bagtags, int UserId)
        {
            try
            {
                return _baglist.RemoveBagTags(Bagtags,UserId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<string> SaveBagTags(string Bagtags, int UserId)
        {
            try
            {
                return _baglist.SaveBagTags(Bagtags, UserId);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<IList<BagList>> LoadMybaglistOtherUsers()
        {
            try
            {
                return _baglist.GetMybaglistOtherUsers();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
