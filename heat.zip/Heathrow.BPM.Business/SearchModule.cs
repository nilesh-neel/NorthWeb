﻿using System.Collections.Generic;
using Heathrow.BPM.Core;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Interface;
using System.Threading.Tasks;

namespace Heathrow.BPM.Business
{
    
    public class SearchModule : ISearchModule
    {

        private readonly ISearch searchInstance;
        public SearchModule(ISearch searchObj)
        {
            searchInstance = searchObj;
        }

        public async Task<ReportConfiguration> GetSearchData(string searchQuery, string searchPrefix)
        {
            return await searchInstance.GetSearchData(searchQuery, searchPrefix);
        }

    
    }
}
