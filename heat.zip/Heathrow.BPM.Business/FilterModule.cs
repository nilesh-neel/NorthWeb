﻿using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core;
using Heathrow.BPM.Core.Interface;
using System.Threading.Tasks;

namespace Heathrow.BPM.Business
{
    /// <summary>
    ///  Baggage filter business 
    /// </summary>
    public class FilterModule : IFilterModule
    {
        private readonly IFilter _filterRepository;

        public FilterModule(IFilter filterData)
        {
            _filterRepository = filterData;
        }

        /// <summary>
        /// Create Filter business 
        /// </summary>
        /// <param name="filterEntity"></param>
        /// <returns></returns>
        public int SaveFilter(FilterCollection filterEntity)
        {
            return _filterRepository.SaveFilter(filterEntity);
        }

        /// <summary>
        /// Get Filter Business 
        /// </summary>
        /// <param name="menuID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public FilterCollection GetFilterByMenuID(int menuID)
        {
            return _filterRepository.GetFilterByMenuID(menuID);
        }

        public FilterCollection GetAllFilter()
        {
            return _filterRepository.GetAllFilter();
        }
        public FilterCollection GetFilterConfiguration(int menuId)
        {
            return _filterRepository.GetFilterConfiguration(menuId);
        }

    }
}
