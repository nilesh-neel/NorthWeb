﻿//----------------------------------------------------------------------
//Class Name   : BagListRepository 
//Purpose      : This is Data Service js file use to connect with the server side api/controller call. 
//               Whit this ajax call we can achive promise in javascripts. 
//Created By   : Vignesh AshokKumar
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using static System.Convert;
using System.Linq;
using Newtonsoft.Json;

namespace Heathrow.BPM.DataAccess
{

    #region Baglist Repository
    public class BagListRepository : GenericRepository<BagList>,IBagList
    {
        public BagListRepository(BaggageDbContext context) : base(context)
        {

        }

        public async Task<IList<BagList>> GetMybaglistOtherUsers()
        {
            try
            {
                var oBaglistOthrUsrs = await Task.Run(() => ((BaggageDbContext)Context).usp_FetchMybaglistOtherUsers());
                
                //var oBaglistOthrUsrs = await Task.Run(() => ((BaggageDbContext)Context).VWFetchMybaglistOtherUsers);
                //var oBaglistOthrUsrs = await Task.Run(() => ((BaggageDbContext)Context).fnFetchMybaglistOtherUsers());

                return oBaglistOthrUsrs?.Select(a => new BagList
                {
                    OthersMybaglistUserId = a.User_ID,
                    UserFirstname=a.First_Name,
                    UserLasttname=a.Last_Name,
                    UserEmail=a.Email,
                    UserOrg=a.Organization,
                    UserRole=a.Job_Role
                }).ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<string> GetUserExistingBagtags(int userId)
        {
            try
            {
                var oBagTags = await Task.Run(() => ((BaggageDbContext)Context).usp_FetchUserexistingBagtags(userId).FirstOrDefault());
                return oBagTags.ToString().Length > 0 ? oBagTags.ToString() : "";
                //return Convert.ToString(temp[0].Bag_Tag != null ? temp[0].Bag_Tag : "");

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public async Task<int> GetUserExistingBagtagsCnt(int userId)
        //{
        //    try
        //    {
        //        var oExistingBagTagsCnt = await Task.Run(() => ((BaggageDbContext)Context).usp_UserexistingBagtagsCount(userId));

        //        return ToInt32(oExistingBagTagsCnt.FirstOrDefault().BagTags_Count);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        public async Task<string> RemoveBagTags(string bagtags, int userId)
        {
            try
            {
                var oRemoveBagTags = await Task.Run(() => ((BaggageDbContext)Context).usp_RemoveBagtags(bagtags, userId).FirstOrDefault());
                return oRemoveBagTags.ToString();
                //return ToInt32(oRemoveBagTags.FirstOrDefault().BagTags_Count);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<string> SaveBagTags(string bagtags, int userId)
        {
            try
            {
                var oSaveBagTags = await Task.Run(() => ((BaggageDbContext)Context).usp_SaveBagtags(bagtags, userId).FirstOrDefault());
                return oSaveBagTags.ToString();
                //return Convert.ToString(oSaveBagTags.FirstOrDefault());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
    #endregion
}
