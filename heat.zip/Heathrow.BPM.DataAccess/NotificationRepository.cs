﻿using System.Web;
using System.Data.SqlClient;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.IO;

using Newtonsoft.Json;

using System;
using Newtonsoft.Json.Linq;

namespace Heathrow.BPM.DataAccess
{
    public class NotificationRepository : INotification
    {
        public NotificationRepository() { }


        public int Save(Notification _notification)
        {
            DbConnection oDAL = new DbConnection();
            // int index = 0;
            JArray jsonArray;
            //  string[] temp = new string[] { };

            try
            {

                using (StreamReader readFile = new StreamReader(HttpContext.Current.Server.MapPath("~/Helper/DummyData/notification.json")))
                {
                    var json = readFile.ReadToEnd();
                    string result = string.Empty;
                    jsonArray = JArray.Parse(json);
                    dynamic data = JObject.Parse(jsonArray[0].ToString());
                    var loc = jsonArray[0]["location"];

                    //Fetch corresponding location name based on id
                    foreach (var locid in _notification.SelectLocationId)
                    {
                        foreach (var id in loc.Where(obj => obj["id"].Value<int>() == locid))
                        {
                            var x = (id["name"].Value<string>());
                            //   _notification.Locations.Add("");
                        }
                    }

                    DataSet dsNotificationList = new DataSet();

                    oDAL.ExecuteDataSet(ProcedureConstants.UpdateNotification, out dsNotificationList,
                    new List<SqlParameter>()
                    {
                       new SqlParameter(){ParameterName ="@notificationId", DbType = DbType.String, Value = _notification.NotificationID },
                       new SqlParameter(){ParameterName="@recipientId",DbType=DbType.Int32,Value=_notification.SelectedRecipients},
                       new SqlParameter() {ParameterName="@notificationDescription",DbType=DbType.String,Value=_notification.Description },
                       new SqlParameter() {ParameterName="@helpUrl",DbType=DbType.String,Value=_notification.HelpUrl },

                       new SqlParameter() {ParameterName="@createdBy",DbType=DbType.String,Value=_notification.CreatedBy },
                       new SqlParameter() {ParameterName="@audienceId",DbType=DbType.Int32,Value=_notification.SelectedAudienceGroup },
                       new SqlParameter() {ParameterName="@locationId",DbType=DbType.String,Value=string.Join(",", _notification.SelectLocationId) },
                       new SqlParameter() {ParameterName="@modifiedBy",DbType=DbType.String,Value=_notification.ModifiedBy },
                       new SqlParameter() {ParameterName="@subscribe",DbType=DbType.Boolean,Value=_notification.IsSubscribe? 1 : 0 },

                       new SqlParameter() {ParameterName="@onscreen",DbType=DbType.Boolean,Value=_notification.IsOnScreen? 1 : 0 },

                       new SqlParameter() {ParameterName="@email",DbType=DbType.Boolean,Value=_notification.IsEmail? 1 : 0 },

                       new SqlParameter() {ParameterName="@mobile",DbType=DbType.Boolean,Value=_notification.IsMobile? 1 : 0 }
                     

                       //To Do: Save list of locations for this.NotificationID and this.UserID
                       //Subscription for each notification
                    });
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
            return 1;
        }

        public void Savejson(Notification _notification)
        {
            int index = 0;
            JArray jsonArray;
            string[] temp = new string[] { };
            try
            {
                using (StreamReader r = new StreamReader(HttpContext.Current.Server.MapPath("~/Helper/DummyData/notification.json")))
                {
                    var json = r.ReadToEnd();
                    string result = string.Empty;
                    jsonArray = JArray.Parse(json);
                    //  dynamic data = JObject.Parse(jsonArray[0].ToString());

                    foreach (var item in jsonArray.Where(obj => obj["notificationId"].Value<string>() == _notification.NotificationID))
                    {

                        // System.Diagnostics.Debug.Write(item["description"]);
                        index = (jsonArray.IndexOf(item));

                        item["description"] = _notification.Description;
                        item["isEmail"] = _notification.IsEmail;
                        item["isMobile"] = _notification.IsMobile;
                        item["isOnScreen"] = _notification.IsOnScreen;
                        item["isSubscribe"] = _notification.IsSubscribe;
                        item["modifiedBy"] = _notification.ModifiedBy;
                        item["createdDate"] = _notification.CreatedDate;
                        item["modifiedDate"] = _notification.ModifiedDate;
                        item["endDate"] = _notification.EndDate;
                        item["createdBy"] = _notification.CreatedBy;
                        result = item.ToString();
                    }

                    jsonArray[index] = JObject.Parse(result);
                }
                string output = Newtonsoft.Json.JsonConvert.SerializeObject(jsonArray, Newtonsoft.Json.Formatting.Indented);
                File.WriteAllText(HttpContext.Current.Server.MapPath("~/Helper/DummyData/notification.json"), output);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IEnumerable<Notification> GetNotificationByNotificationId(string _notificationId)
        {
            DbConnection oDAL = new DbConnection();
            try
            {

                DataSet dsNotificationList = new DataSet();

                oDAL.ExecuteDataSet(ProcedureConstants.GetNotificationById, out dsNotificationList,
                   new List<SqlParameter>()
                   {
                        new SqlParameter() { ParameterName = "@notificationId", DbType = DbType.String, Value =  _notificationId }
                   });

                return dsNotificationList.Tables != null &&
                        dsNotificationList.Tables[0].Rows.Count > 0 ? BindDataToEntity(dsNotificationList, _notificationId) : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }

        public IEnumerable<Notification> GetTodaysNotification()
        {
            DbConnection oDAL = new DbConnection();
            try
            {
                DataSet dsNotificationList = new DataSet();
                oDAL.ExecuteDataSet(ProcedureConstants.GetAllNotification, out dsNotificationList);
                return dsNotificationList.Tables != null &&
                    dsNotificationList.Tables[0].Rows.Count > 0 ? BindAllDataToEntity(dsNotificationList) : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDAL.CloseConnection();
            }
        }

        private List<Notification> BindDataToEntity(DataSet dsNotification, string _notificationId)
        {
            try
            {
                return (from drAlert in dsNotification.Tables[0].AsEnumerable()
                        select (new Notification
                        {
                            NotificationID = _notificationId,
                            Description = Convert.ToString(dsNotification.Tables[0].Rows[0]["Description"]),

                            //  Topic = Convert.ToString(dsNotification.Tables[0].Rows[0]["Topic"]),
                            //  Location = Convert.ToString(dsNotification.Tables[0].Rows[0]["Location"]),
                            //  TipOfTheDay= Convert.ToString(dsNotification.Tables[0].Rows[0]["Tip_Of_The_Day"]),
                            HelpUrl = Convert.ToString(dsNotification.Tables[0].Rows[0]["Help_Url"]),
                            StartDate = Convert.ToDateTime(dsNotification.Tables[0].Rows[0]["Start_Date"]),
                            // EndDate = Convert.ToDateTime(dsNotification.Tables[0].Rows[0]["End_Date"]),
                            Time = Convert.ToString(dsNotification.Tables[0].Rows[0]["Time"]),
                            IsSubscribe = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Subscribe"]),
                            IsOnScreen = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_OnScreen"]),
                            IsEmail = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Email"]),
                            IsMobile = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Mobile"])

                        })).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            //return null;
        }
        private List<Notification> BindAllDataToEntity(DataSet dsNotification)
        {
            try
            {
                return (from drAlert in dsNotification.Tables[0].AsEnumerable()
                        select (new Notification
                        {
                            Description = Convert.ToString(dsNotification.Tables[0].Rows[0]["Description"]),
                            Topic = Convert.ToString(dsNotification.Tables[0].Rows[0]["Topic"]),
                            StartDate = Convert.ToDateTime(dsNotification.Tables[0].Rows[0]["Start_Date"]),
                            // EndDate = Convert.ToDateTime(dsNotification.Tables[0].Rows[0]["End_Date"]),
                            Time = Convert.ToString(dsNotification.Tables[0].Rows[0]["Time"]),

                            // NotificationID = Convert.ToString(dsNotification.Tables[0].Rows[0]["NotificationID"]),
                            //  Topic = Convert.ToString(dsNotification.Tables[0].Rows[0]["Topic"]),
                            //  Location = Convert.ToString(dsNotification.Tables[0].Rows[0]["Location"]),
                            //  TipOfTheDay= Convert.ToString(dsNotification.Tables[0].Rows[0]["Tip_Of_The_Day"]),
                            //   HelpUrl = Convert.ToString(dsNotification.Tables[0].Rows[0]["Help_Url"]),

                            //IsSubscribe = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Subscribe"]),
                            // IsOnScreen = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_OnScreen"]),
                            //  IsEmail = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Email"]),
                            //  IsMobile = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Mobile"])

                        })).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            //return null;
        }
    }
}
