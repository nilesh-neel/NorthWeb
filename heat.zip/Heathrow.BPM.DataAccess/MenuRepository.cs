﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Heathrow.BPM.DataAccess
{
    public class MenuRepository : IMenu
    {
        public IEnumerable<Menu> GetAllMenu()
        {
            DbConnection oDal = new DbConnection();
            try
            {

                DataSet dsMenuList = new DataSet();
                oDal.ExecuteDataSet(ProcedureConstants.GetAllMenu, out dsMenuList);
                return dsMenuList.Tables != null &&
                        dsMenuList.Tables[0].Rows.Count > 0 ? BindDataToEntity(dsMenuList) : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }
        public IEnumerable<Menu> GetAllEntityMenu()
        {
            DbConnection oDal = new DbConnection();
            try
            {

                DataSet dsMenuList = new DataSet();
                oDal.ExecuteDataSet(ProcedureConstants.GetAllMenu, out dsMenuList);
                return dsMenuList.Tables != null &&
                        dsMenuList.Tables[0].Rows.Count > 0 ? BindDataToEntity(dsMenuList) : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }

        private List<Core.Entity.Menu> BindDataToEntity(DataSet dsMenu)
        {
            try
            {
                return (from drAlert in dsMenu.Tables[0].AsEnumerable()
                        select (new Core.Entity.Menu
                        {
                            MenuId = Convert.ToInt32(drAlert["MenuId"]),
                            Description = Convert.ToString(drAlert["Description"]),
                            OperationalUrl = Convert.ToString(drAlert["MenuUrl"]),
                            CssIcon = Convert.ToString(drAlert["CssIcon"]),
                            ParentId = Convert.ToInt32(drAlert["ParentId"]),
                            OrderId = Convert.ToInt32(drAlert["OrderId"]),
                            IsReport = Convert.ToBoolean(drAlert["IsReport"]),
                            Tooltip = Convert.ToString(drAlert["Tooltip"]),
                            FavouritesDescription= Convert.ToString(drAlert["FavouritesDescription"]),
                        })).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        IEnumerable<Menu> IMenu.GetAllMenu()
        {
            try
            {
               // var result = _context.Menus.ToList();
                return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<IEnumerable<Menu>> GetAllMenuAsync()
        {
            throw new NotImplementedException();
        }
    }

}
