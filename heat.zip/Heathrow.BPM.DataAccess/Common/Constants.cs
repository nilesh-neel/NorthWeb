﻿namespace Heathrow.BPM.DataAccess.Common
{
    public class ProcedureConstants
    {
        public const string SelectAlertsById = "USP_GetAlertsById";

        public const string GetFavouritesByUser = "usp_GetFavourites";
        public const string SaveFavouritesByUser = "usp_SaveFavourites";

        public const string GetAllMenu = "usp_GetMenu";
        public const string InsertUser = "usp_InsertUser";
        //Notes
        public const string GetLocation = "sp_GetLookupItems";
        public const string GetLookupItemName = "";
        public const string InsertNotes = "usp_SaveNotes";
        public const string FetchNotes = "usp_FetchNotes";
        public const string DeleteNotes = "usp_DeleteNotes";
        //Notification

        public const string GetNotificationById = "";
        public const string UpdateNotification = "sp_ConfigureNewNotification";
        public const string GetAllNotification = "";

        //Alert
        public const string UpdateAlert= "sp_ConfigureNewAlert";

        public const string AssignHomePage = "";
        public const string GetAssignHomePage = "";

        // Filter
        public const string GetAllFilter = "usp_GetFilterDetails";
        public const string SaveFilter = "usp_SaveFilterDetail";
        public const string GetFilterByUser = "usp_GetFilterDataByMenuID";
        public const string GetFiterConfigDetails = "usp_GetFilterConfiguration";  // Get PBI report mapping fields details for

        // Share
        public const string FetchAudienceGrp = "usp_FetchAudienceGroup";
        public const string FetchGrpRecipients = "usp_FetchGroupRecipients";

        //BagList
        public const string SaveBagtags = "usp_SaveBagtags";
        public const string RemoveBagtags = "usp_RemoveBagtags";
        public const string UserExistingBagtagsCnt = "usp_FetchUserexistingBagtags";
        public const string FetchMybaglistOtherUsers = "usp_FetchMybaglistOtherUsers";

        // Search
        public const string FetchSearchData = "usp_FilterSearch";
    }
}
