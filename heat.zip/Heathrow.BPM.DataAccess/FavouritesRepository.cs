﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System.Linq;
using System.Threading.Tasks;

namespace Heathrow.BPM.DataAccess
{
    public class FavouritesRepository : GenericRepository<Favourites>, IFavourites
    {
        public FavouritesRepository(BaggageDbContext context) : base(context)
        {

        }

        public async Task<List<Favourites>> GetUserFavourites(string userId)
        {
            try
            {
                var oFavMenu = await Task.Run(() => ((BaggageDbContext)Context).usp_GetFavourites(userId));
                return oFavMenu?.Select(a => new Favourites
                {
                    FavouriteId = a.FavouriteId,
                    UserId = userId,
                    FavouriteLink = new Menu
                    {

                        MenuId = a.MenuId,
                        Description = a.Description,
                        IsReport = Convert.ToBoolean(a.IsReport),
                        OperationalUrl = a.OperationalUrl
                    }
                }).ToList();


                //var test = _context.Database.SqlQuery<Object>(ProcedureConstants.GetFavouritesByUser + " " + "@User_ID",
                //     new SqlParameter[]
                //   {
                //        new SqlParameter() { ParameterName = "User_ID", DbType = DbType.String, Value = _userId }
                //   }
                //    ).ToListAsync();

                //var result = await ExecuteQueryAsync(ProcedureConstants.GetFavouritesByUser + " " + "@User_ID", new SqlParameter[]
                //   {
                //        new SqlParameter() { ParameterName = "@User_ID", DbType = DbType.String, Value = _userId }
                //   });
                //return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public async Task<int> Save(Favourites favourites)
        {
            try
            {
                var oFavMenu = await Task.Run(() => ((BaggageDbContext)Context).usp_SaveFavourites(favourites.UserId, favourites.FavouriteLink.MenuId, favourites.FavouriteId));
                return oFavMenu != null ? Convert.ToInt32(oFavMenu) : 999;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public IEnumerable<Favourites> GetFavouritesByUserId(string userId)
        {
            DbConnection oDal = new DbConnection();
            try
            {

                DataSet dsFavList = new DataSet();

                oDal.ExecuteDataSet(ProcedureConstants.GetFavouritesByUser, out dsFavList,
                   new List<SqlParameter>()
                   {
                        new SqlParameter() { ParameterName = "@User_ID", DbType = DbType.String, Value = userId }
                   });

                return dsFavList.Tables != null &&
                        dsFavList.Tables[0].Rows.Count > 0 ? BindDataToEntity(dsFavList, userId) : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }


        private List<Favourites> BindDataToEntity(DataSet dsFavourate, string userId)
        {
            try
            {
                return (from drAlert in dsFavourate.Tables[0].AsEnumerable()
                        select (new Favourites
                        {
                            FavouriteId = Convert.ToInt32(dsFavourate.Tables[0].Rows[0]["Favourite_ID"]),
                            UserId = userId,
                            FavouriteLink = new Menu()
                            {
                                MenuId = Convert.ToInt32(dsFavourate.Tables[0].Rows[0]["Menu_ID"]),
                                Description = Convert.ToString(dsFavourate.Tables[0].Rows[0]["Menu_Desc"]),
                                // MenuUrl = Convert.ToString(dsFavourate.Tables[0].Rows[0]["Menu_Url"]),
                                // IsReport = Convert.ToBoolean(dsFavourate.Tables[0].Rows[0]["IsReport"])
                            }

                        })).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
