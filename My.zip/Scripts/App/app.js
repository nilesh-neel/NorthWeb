﻿(function ($) {
    'use strict';

    $('.homeLinkIcon').on('click', function () {
        window.location.href = '/Dashboard/Index';
    });


})(jQuery);