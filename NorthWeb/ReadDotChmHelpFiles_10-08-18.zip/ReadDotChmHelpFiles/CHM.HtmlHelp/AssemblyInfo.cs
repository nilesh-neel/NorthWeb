using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("HtmlHelp library")]
[assembly: AssemblyDescription("Library for reading compiled HtmlHelp files (.chm)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("HtmlHelp library")]
[assembly: AssemblyCopyright("(c)2004 by Klaus Weisser, All rights reserved")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		

[assembly: AssemblyVersion("0.4.*")]

[assembly: AssemblyDelaySign(false)]
//[assembly: AssemblyKeyFile("..\\..\\vmasoft.snk")]
[assembly: AssemblyKeyName("")]
