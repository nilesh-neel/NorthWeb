﻿//----------------------------------------------------------------------
//Class Name   : Menu 
//Purpose      : Menu Class file use to bind the left side menu. 
//               Whit this ajax call we can achive promise in javascripts. 
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------
//Global Variable for the filter module.
var menuItemID = 0;
var Menu = (function () {

    var menuHtml = '';
    /****
    * Creates a new Menu object.
    * @constructor
    *
    */
    Menu = function () { }

    /**
    /* fetch the menu data from database and bind to menu div..
    */
    Menu.prototype.bindMenu = function () {
        var service = new Service('/Menu/GetAllMenu');

        $.when(service.get()
            .then(function (menuData, favData) {

                sessionStorage.setItem('menuList', menuData);

                var parentMenu = _.takeWhile(menuData, function (o) { return o.parentId === 0; });

                for (var i = 0; i < parentMenu.length; i++) {

                    var childList = _.filter(menuData, { parentId: parentMenu[i].menuId });
                    if (_.isEmpty(childList)) {
                        menuHtml += '<li><span class="' + parentMenu[i].cssIcon + '"></span></li>';
                    }
                    else {
                        var childhtml = '';
                        _.forEach(childList, function (child) {
                            childhtml += '<a id="' + child.menuId + '"data-isreport="' + child.isReport + '"data-powerbiurl="' + child.url + '" href=#>' + child.description + '</a>';
                        }) + '</li>';
                        menuHtml += '<li class="subDropdown"><span class="' + parentMenu[i].cssIcon + '"></span><div class="dropdown-content">' + childhtml + '</div></li>';
                    }
                }

                menuHtml += '<li><span class="defaultIcons .mSetting"></span></li>';
                $('.menu').html(menuHtml);
                Favourites.prototype.GetFavourites.call();
                Menu.prototype.autoRefresh.call();

            }).catch(function (jqXHR, textStatus, err) {
                alert('Unable to fetch data for menu: ' + jqXHR.message);
            })
        );
    }

    //ToDo: manage the menu for the multilevel..

    Menu.prototype.bindChildMenu = function (childMenuList) {
        var childhtml = '';
        _.forEach(childMenuList, function (child) {
            childhtml += '<a id="' + child.menuId + '"data-isreport="' + child.isReport + '"data-powerbiurl="' + child.url + '" href=#>' + child.description + '</a>';
        }) + '</li>';
        return '<li class="subDropdown"><span class="' + parentMenu[i].cssIcon + '"></span><div class="dropdown-content">' + childhtml + '</div></li>';
    }



    /**
    / auto refresh the power bi report.This method fetch the value from the localSession.
    */
    Menu.prototype.autoRefresh = function () {
        $('.dropdown-content a').on('click', function () {
            var self = $(this);
            menuItemID = parseInt(self[0].id);
            sessionStorage.setItem('URLId', self[0].getAttribute('id'))
            sessionStorage.setItem('autoRefURL', self[0].getAttribute('data-powerbiurl'));
            sessionStorage.setItem('autoRefURLIsReport', self[0].getAttribute('data-isreport'));

            var oPowerBiApi = new PowerBIAPP(self[0].getAttribute('data-powerbiurl'), self[0].getAttribute('data-isreport'));
            oPowerBiApi.embedPowerBIApi();
        });
    }


    return Menu;

})();
