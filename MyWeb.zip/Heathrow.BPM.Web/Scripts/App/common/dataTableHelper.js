﻿//----------------------------------------------------------------------
//Class Name   : CustomGrid
//Purpose      : This is Custome Grid Class js file use to create the default JqData Table object with common css and other. 
//               mandantory features like order enable/disable paginate etc... 
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

var CustomGrid = (function () {
    'use strict';

    /****
   * Creates a new Alert object.
   * @constructor
   * @param {string} tableDiv pass the div id to configure the table.
   * @param {object} tableData pass the data to bind the table.
   * @param {object} tableColumn pass the number of column to bind the JqData Table
   * @param {bool} showDetails pass boolean value to show view detils button 
   * @param {bool} allowEdit pass boolean value to show edit detils button
   */
    CustomGrid = function (tableDiv, tableData, tableColumn, showDetails, allowEdit) {
        this.GridDivName = tableDiv;
        this.Data = tableData;
        this.Column = tableColumn;
        this.AllowShow = _.isNull(showDetails) || _.isUndefined(showDetails) ? false : true;
        this.AllowEdit = _.isNull(allowEdit) || _.isUndefined(allowEdit) ? false : true;
        //this.TableObject = $(this.GridDivName).dataTable();
    };

    CustomGrid.prototype.CreateGrid = function (configForAlert, configForNotify) {

        $(this.GridDivName).dataTable({
            "data": this.Data,
            "columns": this.Column,
            "pagingType": "full_numbers",
            "ordering": false,
            "info": false,
            "bLengthChange": false,
            "bAutoWidth": false,
            "searching": false,
            "responsive": true,
            "oLanguage": {
                "oPaginate": {
                    "sFirst": "First",
                    "sNext": '<img class="Next" src="" />',
                    "sPrevious": '<img class="Previous" src="" />',
                    "sLast": "Last"
                }
            },
            "fnDrawCallback": function (oSettings) {
                $("span.Show_details").closest("td").addClass("showdetailsTDstyle");
                $("span.Edit").closest("td").addClass("showdetailsTDstyle");
                $('table tr td label.container').closest("td").addClass("tableCheckmarkStyleOveride");

            },
            "bDestroy": true
        });

        if (this.AllowShow)
            CustomGrid.prototype.ShowDetails.call(this);

        //if (this.AllowEdit)
        //    CustomGrid.prototype.EditRow(this, configForAlert);

        if (this.AllowEdit) { this.EditRow(configForAlert, configForNotify); }
    }
    CustomGrid.prototype.ShowDetails = function () {
        $(this.GridDivName + ' tbody td').on('click', '.Show_details', function () {
            var nTr = $(this).parents('tr')[0];
            var oTable = $(this).parents('table').dataTable();
            if (oTable.fnIsOpen(nTr)) {
                /* This row is already open - close it */
                //this.src = "./images/Icons/DefaultIcons.png";
                $(this).closest("tr").find("td").toggleClass("showDetailsActive");
                $(this).toggleClass("clickedIcons");
                $(this).next().toggleClass("clickedIcons");
                oTable.fnClose(nTr);
                $("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
            }
            else {
                /* Open this row */
                //this.src = "./images/Icons/DefaultIcons.png";
                $(this).closest("tr").find("td").toggleClass("showDetailsActive");
                $(this).toggleClass("clickedIcons");
                $(this).next().toggleClass("clickedIcons");

                oTable.fnOpen(nTr, fnFormatNotification(oTable, nTr), 'details');
                $("#verticalTabs").height($(".zeroStyling:nth-child(2)").height());
            }
        });
    }
    CustomGrid.prototype.EditRow = function (configAlertTab,configNotifyTab) {
        if (configAlertTab) {
            $(this.GridDivName + ' .Edit').click(function () {
                $("#alertSettingTable_wrapper,#configureAlertsTable_wrapper,#tabs a[href='#alertSettings'],#tabs a[href='#todaysAlerts']").css('display', 'none');
                $('#congigureNewAlertBtn').css('display', 'none');
                $('#configureBackBtn').css('display', 'block');
                $('.configureAlertForm').css('display', 'block');
                $('.configureAlertForm').load('Alerts/Edit');


            });
        }
        else if (configNotifyTab) {
           
            $(this.GridDivName + ' .Edit').click(function () {
              /*  $("#alertSettingTable_wrapper,#configureAlertsTable_wrapper,#tabs a[href='#alertSettings'],#tabs a[href='#todaysAlerts']").css('display', 'none');
               
                $('#configureBackBtn').css('display', 'block');
                $('.configureAlertForm').css('display', 'block');
                $('.configureAlertForm').load('Alerts/Edit');*/
                var nTr = $(this).parents('tr')[0];
                var oTable = $(this).parents('table').dataTable();
                var aData = oTable.fnGetData(nTr);
                var id = aData["NotificationId"];
                $("#notificationSettingsTable_wrapper,#ConfigureNotificationTable_wrapper,#tabs a[href='#notificationSettings'],#tabs a[href='#configureNotifications'],#tabs a[href='#todaysNotifications']").css('display', 'none');
                $('#configureBackBtn').css('display', 'block');
                $('.editNotificationTab').css('display', 'block');
                $('.configureAlertForm').css('display', 'block');
                $('#congigureNewAlertBtn').css('display', 'none');
                $('.configureAlertForm').load('Notifications/Edit/'+id);
              

            });
        }

    }

    CustomGrid.prototype.Ellipsis = function (cutoff) {
        return function (data, type, row) {
            return data.length > cutoff ? data.substr(0, cutoff) + '…' : data;
        }
    }

    CustomGrid.prototype.CommaSeperatedString = function (listToSplit) {
        return _.chain(listToSplit).filter({ isSelected: true }).map(function (d) { return d.name }).join(', ').value();
    }


    return CustomGrid;
})();