﻿



(function ($) {
    'use strict';
    $(document).ready(function () {
        var notifications = new Notifications();
        var configTab = new TabConfig(false, true, false, false);
      
        $('#notification').on('click', function SettingsController() {
           
            notifications.LoadNotificationLandingPage();
           
        });

        $('#congigureNewAlertBtn').on('click', function () {
            configTab.NewConfigurationButtonClick();
        //    alert.bindMultiSelectDroupDown();
            $('#congigureNewAlertBtn').css('display', 'none');
        });

        
        $('#tabs a[href="#todaysNotifications"]').click(function (event) {
            notifications.bindTodayNotification();
        });
        $('#tabs a[href="#notificationSettings"]').click(function (event) {
            $('#congigureNewAlertBtn').css('display', 'block');

            $('#congigureNewAlertBtn').text('Configure New Notification');
            notifications.bindMyNotificationSettings();
        });
        $('#tabs a[href="#configureNotifications"]').click(function (event) {
          

           // notifications.updateConfigureNotifications();
            notifications.bindConfigureNotifications();

        });
      
      /*  $('#save').click(function (event) {
            //notifications.saveMessage("Successful");
           // notifications.updateConfigureNotifications();
            alert('save click')
        });*/

    });

})(jQuery);
