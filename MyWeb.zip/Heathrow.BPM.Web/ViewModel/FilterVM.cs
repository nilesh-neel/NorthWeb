﻿using Heathrow.BPM.Core;
using Heathrow.BPM.Core.Interface;
using System.Collections.Generic;
using System.Linq;
namespace Heathrow.BPM.Web
{
    public class FilterVM
    {
        /// <summary>
        /// Filter ID
        /// </summary>
        public long FilterID { get; set; }

        /// <summary>
        /// UserID
        /// </summary>
        public string UserID { get; set; }

        /// <summary>
        /// Menu ID
        /// </summary>
        public int MenuID { get; set; }

        /// <summary>
        /// MenuName
        /// </summary>
        public string MenuName { get; set; }

        /// <summary>
        /// Filter Text
        /// </summary>
        public string FilterText { get; set; }

        /// <summary>
        /// Filter Selection
        /// </summary>
        public short FilterSelection { get; set; }

        public FilterParameter FilterInput { get; set; }

        public IList<TextFilter> BagTagList { get; set; }

        public IList<TextFilter> PassengersList { get; set; }
        public IList<TextFilter> InBoundFlightList { get; set; }
        public IList<TextFilter> OutBoundFlightList { get; set; }

        public IList<DropDownFilter> BagTypeList { get; set; }
        public IList<DropDownFilter> BagSystemList { get; set; }
        public IList<DropDownFilter> ShortConnectList { get; set; }
        public IList<DropDownFilter> OOGBagsList { get; set; }
        public IList<DropDownFilter> AfterChoxList { get; set; }
        public IList<DropDownFilter> DeletedBagsList { get; set; }
        public IList<DropDownFilter> MissedBRSList { get; set; }
        public IList<DropDownFilter> DeletedBSMList { get; set; }
        public IList<DropDownFilter> MyBagList { get; set; }
        public IList<DropDownFilter> InboundITOList { get; set; }

        public IList<DropDownFilter> InTargetList { get; set; }

        public IList<DropDownFilter> FailedMissedList { get; set; }
        public IList<DropDownFilter> FailedInSystemList { get; set; }
    }

    public class FilterParameter
    {
        public string Date { get; set; }

        public string Timeband { get; set; }

        public string PaxSurname { get; set; }

        public string BagTag { get; set; }
        public string NotLoadedCategory { get; set; }

        public string NotLoadedSubCategory { get; set; }
        public string OutboundFlight { get; set; }
        public string OutboundAircraft { get; set; }
        public string Destination { get; set; }
        public string OutboundAirline { get; set; }
        public string OutboundHandler { get; set; }
        public string OutboundTerminal { get; set; }

        public string InboundFlight { get; set; }
        public string InboundAirline { get; set; }
        public string InboundAircraft { get; set; }
        public string Origin { get; set; }
        public string InboundHandler { get; set; }
        public string InboundTerminal { get; set; }
        public string LastSeenLocation { get; set; }
        public string BagStatus { get; set; }
        public string BagType { get; set; }
        public string ShortConnect { get; set; }
        public string OOGBags { get; set; }
        public string SeenAfterChox { get; set; }
        public string ShowDeletedBags { get; set; }
        public string ShowMissedBRS { get; set; }
        public string ShowDelBSMs { get; set; }
        public string ShowMyBagList { get; set; }

        public string Route { get; set; }
        public string ProcessArea { get; set; }
        public string BaggageSystem { get; set; }
        public string RouteStartTime { get; set; }
        public string RouteEndTime { get; set; }
        public string InboundITO { get; set; }
        public string InTarget { get; set; }
        public string FailedThenMissed { get; set; }
        public string SeenAtStart { get; set; }
        public string SeenAtEnd { get; set; }
        public string NotLoadedFailedInSystem { get; set; }
        public string MDStatusLocation { get; set; }

    }


    public class FilterMapping : IMapper<FilterVM, FilterCollection>
    {
        public FilterVM MapFrom(FilterCollection filterData)
        {
            return TransformEntityToViewModel(filterData);
        }
        public FilterCollection MapTo(FilterVM viewModelData)
        {
            return TransformViewModelToEntity(viewModelData);
        }

        public IEnumerable<FilterCollection> MapTo(IEnumerable<FilterVM> viewModelData)
        {
            return viewModelData.Select(m => TransformViewModelToEntity(m));
            // return new IEnumerable<FilterCollection>();
        }

        public IEnumerable<FilterVM> MapFrom(IEnumerable<FilterCollection> collParam)
        {
            return collParam.Select(y => TransformEntityToViewModel(y));
        }

        private static FilterVM TransformEntityToViewModel(FilterCollection filterColl)
        {
            if (filterColl == null)
            {
                return null;
            }

            var filterData = (filterColl.FilterText != null) ? Newtonsoft.Json.JsonConvert.DeserializeObject<FilterParameter>(filterColl.FilterText) : null;

            return new FilterVM()
            {
                BagSystemList = filterColl.BagSystemList,
                BagTypeList = filterColl.BagTypeList,
                AfterChoxList = filterColl.AfterChoxList,
                DeletedBagsList = filterColl.DeletedBagsList,
                DeletedBSMList = filterColl.DeletedBSMList,
                FailedInSystemList = filterColl.FailedInSystemList,
                MissedBRSList = filterColl.MissedBRSList,
                FailedMissedList = filterColl.FailedMissedList,
                InboundITOList = filterColl.InboundITOList,
                InTargetList = filterColl.InTargetList,
                MyBagList = filterColl.MyBagList,
                OOGBagsList = filterColl.OOGBagsList,
                ShortConnectList = filterColl.ShortConnectList,
                FilterID = filterColl.FilterID,
                MenuID = filterColl.MenuID,
                UserID = filterColl.UserID,
                FilterInput = filterData,
                BagTagList = filterColl.BagTagList,
                PassengersList = filterColl.PassengersList,
                InBoundFlightList = filterColl.InBoundFlightList,
                OutBoundFlightList = filterColl.OutBoundFlightList

            };
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        private static FilterCollection TransformViewModelToEntity(FilterVM viewModel)
        {
            if (viewModel == null) return null;

            var filterSelection = (viewModel.FilterInput != null) ? Newtonsoft.Json.JsonConvert.SerializeObject(viewModel.FilterInput) : string.Empty;

            return new FilterCollection()
            {
                FilterSelection = viewModel.FilterSelection,
                MenuID = viewModel.MenuID,
                MenuName = viewModel.MenuName,
                UserID = viewModel.UserID,
                FilterText = filterSelection,
                FilterID = viewModel.FilterID
            };
        }

    }

}