﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Heathrow.BPM.Web.ViewModel;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Web.Controllers
{
    public class ShareController : Controller
    {
        private static ShareModule shareModule;
        private readonly IMapper<ShareVM, Share> Map;

       // public ShareController(IShare _share, IMapper<ShareVM, Share> _map)
       public ShareController(IShare shareObj)
        {
            //shareModule = new ShareModule();
            shareModule = new ShareModule(shareObj);
            //Map = _map;
        }

        // GET: Share
        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public ActionResult Share()
        {
            var response = new JsonResult { };
            var shareResponse = shareModule.GetAudienceGrp();
            // var obj = Map.MapFrom(shareModule.GetAudienceGrp());
            response = Json(shareResponse, JsonRequestBehavior.AllowGet);
            return response;
        }

        [OutputCache(NoStore = true, Duration = 0)]
        [HttpPost]
        public ActionResult GetRecipients(int GroupId)
        {
            var response = new JsonResult { };
            var shareResponse = shareModule.GetGrpRecipients(GroupId);
            // var obj = Map.MapFrom(shareModule.GetAudienceGrp());
            response = Json(shareResponse, JsonRequestBehavior.AllowGet);
            return response;
        }
    }
}