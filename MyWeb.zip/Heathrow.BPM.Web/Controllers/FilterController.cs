﻿using Heathrow.BPM.Business;
using Heathrow.BPM.Core;
using Heathrow.BPM.Core.Interface;
using Newtonsoft.Json;
using System.Web.Mvc;

namespace Heathrow.BPM.Web.Controllers
{
    public class FilterController : Controller
    {
        private static FilterModule filterbiz = null;
        private readonly IMapper<FilterVM, FilterCollection> filterMapper = null;
        // GET: Filter

        /// <summary>
        /// Initialize filter object and implemented constructor injection 
        /// </summary>
        /// <param name="filter"></param>
        /// <param name="dataMapper"></param>
        public FilterController(IFilter filter, IMapper<FilterVM, FilterCollection> dataMapper)
        {
            filterbiz = new FilterModule(filter);
            filterMapper = dataMapper;

        }

        /// <summary>
        /// Get all filters based on page level and user 
        /// </summary>
        /// <returns>JSON filter object</returns>

        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public JsonResult GetFilterData()
        {
            var filterResult = filterMapper.MapFrom(filterbiz.GetAllFilterData());

            var actionResult = JsonConvert.SerializeObject(filterResult);

            return Json(actionResult, JsonRequestBehavior.AllowGet);

        }

        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public JsonResult GetUserData()
        {
            var filterResult = filterMapper.MapFrom(filterbiz.GetAllUserDetails());

            string actionResult = JsonConvert.SerializeObject(filterResult);

            return Json(actionResult, JsonRequestBehavior.AllowGet);

        }

        [HttpPost]
        public JsonResult SaveFilters(FilterVM filterValue)
        {
            if (filterValue == null && string.IsNullOrEmpty(filterValue.FilterText))
            {
                return null;
            }

            int actionResult = filterbiz.SaveFilter(filterMapper.MapTo(filterValue));

            return Json(actionResult,JsonRequestBehavior.AllowGet);
        }

        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public JsonResult GetFilterByMenuID(int menuID,int userID)
        {
            string actionResult = JsonConvert.SerializeObject(filterMapper.MapFrom(filterbiz.GetFilterByMenu(menuID,userID)));

            return Json(new { result = actionResult }, JsonRequestBehavior.AllowGet);
        }

        public PartialViewResult Index => PartialView("_Filter");
    }
}