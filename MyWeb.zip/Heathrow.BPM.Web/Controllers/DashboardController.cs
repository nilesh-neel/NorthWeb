﻿/****************************************************************************************************************
Class Name   : DashboardController.cs 
Purpose      : Dashboard file use to set the user pic and get the token for the power bi reports.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System;
using System.Threading.Tasks;
using System.Web.Mvc;
using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Web.Filters;

namespace Heathrow.BPM.Web.Controllers
{
    [Authorize]
    [AllowCrossSite]
    public class DashboardController : Controller
    {
        private readonly IBpmPowerBi _bpmPowerBi;
        public DashboardController(IBpmPowerBi bpmPowerBi)
        {
            _bpmPowerBi = bpmPowerBi;

        }

        // GET: Dashboard
        public async Task<ActionResult> Index()
        {
            // Signal OWIN to send an authorization request to Azure.
            if (!Request.IsAuthenticated)
                RedirectToAction("SignIn", "Account");
            try
            {
                //string signedInUserID = ClaimsPrincipal.Current.FindFirst(ClaimTypes.NameIdentifier).Value;
                //TokenCache userTokenCache = new SessionTokenCache(signedInUserID,
                //                  HttpContext.GetOwinContext().Environment["System.Web.HttpContextBase"] as HttpContextBase).GetMsalCacheInstance();
                //ConfidentialClientApplication cca = new ConfidentialClientApplication(AzureADConfig.ClientId, PowerBIConfig.PowerBiAPIResource,
                //    new ClientCredential(AzureADConfig.ClientSecret), userTokenCache, null);
                //if (cca.Users.Count().Equals(0))
                //    RedirectToAction("SignIn", "Account");

                //var acceToken = await _bpmPowerBi.GetUserAccessTokenAsync();
                //var result = await _bpmPowerBi.GetUserDetailsFromAzureServer(acceToken);
                //var objUser = JsonConvert.DeserializeObject<AzureUserInfoVM>(result);
                //var userPic = await _bpmPowerBi.GetUserProfilePhoto(acceToken);
                //ViewBag.DisplayName = objUser.displayName;
                //byte[] byteArr = ((MemoryStream)userPic).ToArray();
                //ViewBag.userPic = byteArr;
                return View();
            }
            catch (Exception)
            {
                RedirectToAction("SignIn", "Account");
            }

            return View();
        }

        [HttpGet]
        [Authorize]
        public async Task<ActionResult> GetData()
        {
            var token = await _bpmPowerBi.GetEmbadedToken();
            if (string.IsNullOrEmpty(token))
                RedirectToAction("SignIn", "Account");


            //var acceToken = await _bpmPowerBi.GetUserAccessTokenAsync();
            //var result = await _bpmPowerBi.GetUserDetailsFromAzureServer(acceToken);
            //var objUser = JsonConvert.DeserializeObject<AzureUserInfoVM>(result);
            //var userPic = await _bpmPowerBi.GetUserProfilePhoto(acceToken);
            //ViewBag.DisplayName = objUser.displayName;
            //byte[] byteArr = ((MemoryStream)userPic).ToArray();
            //ViewBag.userPic = byteArr;
            return Json(token, JsonRequestBehavior.AllowGet);
        }
    }
}