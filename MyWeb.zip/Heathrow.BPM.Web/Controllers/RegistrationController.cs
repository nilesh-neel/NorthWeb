﻿using Heathrow.BPM.Core.Entity;
using System.Web.Mvc;
using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Web.ViewModel;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

namespace Heathrow.BPM.Web.Controllers
{
    public class RegistrationController : Controller
    {
          
          private static RegistrationModule _registrationModule;
          private static LocationModule _locationModule;
          
          private readonly IMapper<RegistrationVM, Registration> Map;
          private readonly IMapper<LocationVM, Location> MapLocation;
          
        public RegistrationController(IRegistration registration, IMapper<RegistrationVM, Registration> _map,IMapper<LocationVM,Location>_mapLocation,ILocation location,ILookup lookup)
          {
                _registrationModule = new RegistrationModule(registration,lookup);
                _locationModule = new LocationModule(location);
               
                 Map = _map;
                MapLocation = _mapLocation;
        }
         
          // GET: Registration/Create
          public ActionResult RegistrationPage()
          {
            //     List < string > loc= _registrationModule.locationlist().Select(LookupEnt => LookupEnt.LookupName).ToList();
                var obj = new RegistrationVM() {
                myloc = _registrationModule.locationlist().Select(LookupEnt => LookupEnt.LookupTypeName).ToList(),
                myrole = _registrationModule.rolelist().Select(LookupEnt => LookupEnt.LookupTypeName).ToList(),
                  AccessReason="",
                  Email="",
                  FirstName="",
                  LastName="",
                  Organization="",
                  SelectedJobRole="",
                  SelectedLocation=""                  
               };


            Debug.Assert(obj != null);
            return View(obj);
          }

        // POST: Registration/Create
        [HttpPost]
        public ActionResult RegistrationPage(RegistrationVM data)
        {
            if (!ModelState.IsValid)
                return null;

            var objRegCore = Map.MapTo(data);
            
        /*     if (_registrationModule.Save(objRegCore).Equals(1))
                Response.Write(@"<script language='javascript'>alert('Data  success entered.');</script>");
            else
                Response.Write(@"<script language='javascript'>alert('Data failed entered.');</script>");
        */
            return View();
            
        }
       [HttpGet]
        [Route("Get")]
        public ActionResult GetAll()
        { 
           
            return Json(
                MapLocation.MapFrom(_locationModule.GetAllLocation()),
                JsonRequestBehavior.AllowGet);
        }
       
    }
}