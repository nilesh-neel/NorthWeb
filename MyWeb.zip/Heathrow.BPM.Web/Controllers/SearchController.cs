﻿using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Heathrow.BPM.Web.Controllers
{
    public class SearchController : Controller
    {
        private static SearchModule searchbiz = null;


        public SearchController(ISearch searchInstance)
        {
            searchbiz = new SearchModule(searchInstance);
        }
        // GET: Search
        //public ActionResult Index()
        //{
        //    return View();
        //}
        [OutputCache(NoStore = true, Duration = 0)]
        [HttpGet]
        public JsonResult GetSearch(string query, string searchType)
        {
            var actionResult = string.Empty;

            if (!string.IsNullOrEmpty(query))
            {
                IList<Core.TextFilter> result = searchbiz.GetSearchData(query, searchType);
                 actionResult = Newtonsoft.Json.JsonConvert.SerializeObject(result);
            }

            return Json(new { result = actionResult }, JsonRequestBehavior.AllowGet);
        }
      
    }
}