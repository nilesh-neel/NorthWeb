﻿/****************************************************************************************************************
Class Name   : FavoritesController.cs 
Purpose      : Save user Favorites 
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Web.ViewModel;
using System;
using System.Threading.Tasks;
using System.Web.Mvc;
namespace Heathrow.BPM.Web.Controllers
{
    // [ModelStateException]
    // [BPMErrorHandler]
    public class FavoritesController : Controller
    {
        private static FavouritesModule _favoritesModule;
        private readonly IMapper<FavouritesVM, Favourites> MapFav;

        public FavoritesController(FavouritesModule fav, IMapper<FavouritesVM, Favourites> _mapFav)
        {
            _favoritesModule = fav;
            MapFav = _mapFav;


        }

        [HttpGet]
        [Route("Get")]
        public async Task<ActionResult> GetAll(string _userId)
        {
            return Json(
                MapFav.MapFrom(await _favoritesModule.GetUserFavourites(_userId)),
                JsonRequestBehavior.AllowGet);
        }

        [HttpPost]

        public async Task<JsonResult> Save(FavouritesVM data)
        {
            try
            {
                if (!ModelState.IsValid)
                    throw new ModelStateException(ModelState);

                var objFavCore = MapFav.MapTo(data);
                objFavCore.UserId = "ASDASF234AS";
                var result = await _favoritesModule.Save(objFavCore);
                return result != null ? Json(MapFav.MapFrom(result), JsonRequestBehavior.AllowGet) :
                    Json("Data save fail.", JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(ex.Message, JsonRequestBehavior.AllowGet);
            }

        }

    }
}