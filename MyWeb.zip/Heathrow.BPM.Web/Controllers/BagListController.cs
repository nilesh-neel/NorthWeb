﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Web.Controllers
{
    public class BagListController : Controller
    {
        private static BagListModule bagListModule;
        public string UserId = "Admin";

        public BagListController(IBagList _baglist)
        {
            bagListModule = new BagListModule(_baglist);
        }
        // GET: BagList
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public JsonResult GetUserExistingBagtagsCount()
        {
            //string UserId = "Admin";
            int UserExistingBagtagsCnt = bagListModule.GetUserExistingbagtagsCnt(UserId);
            return Json(UserExistingBagtagsCnt.ToString(), JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetUserExistingBagtags()
        {
            string strUserExistingBagtags = bagListModule.GetUserExistingbagtags(UserId);
            return Json(strUserExistingBagtags.ToString(), JsonRequestBehavior.AllowGet);
        }

        [OutputCache(NoStore = true, Duration = 0)]
        [HttpPost]
        public ActionResult AddtoMyBaglist(string bagtaglist, int selectedBagtagCnt, string UserId)
        {
            int BagtagsCount = bagListModule.SaveBagTags(bagtaglist, UserId);
            return Json(BagtagsCount, JsonRequestBehavior.AllowGet);
        }

        public ActionResult RemoveFrmMyBaglist(string bagtaglist, int selectedBagtagCnt, string UserId)
        {
            int BagtagsCount = bagListModule.RemoveBagTags(bagtaglist, UserId);
            return Json(BagtagsCount, JsonRequestBehavior.AllowGet);
        }

    }
}