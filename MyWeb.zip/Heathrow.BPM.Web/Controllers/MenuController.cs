﻿/****************************************************************************************************************
Class Name   : MenuController.cs 
Purpose      : In this controller we are loading the menu for the weg application.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using Heathrow.BPM.Business;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Web.ViewModel;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Heathrow.BPM.Web.Controllers
{
    [Authorize]
    public class MenuController : Controller
    {
        private readonly IMapper<MenuVM, Menu> Map;
        private static MenuModule _menuModule { get; set; }

        public MenuController(MenuModule menu, IMapper<MenuVM, Menu> _map)
        {
            _menuModule = menu;
            Map = _map;
        }

        [HttpGet]
        [Route("MenuList")]
        public async Task<JsonResult> GetAllMenu() => 
            Json(Map.MapFrom(await _menuModule.GetAllMenu()), JsonRequestBehavior.AllowGet);
    }
}