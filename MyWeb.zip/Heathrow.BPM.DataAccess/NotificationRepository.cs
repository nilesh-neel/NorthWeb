﻿//----------------------------------------------------------------------
//Class Name   : NotificationRepository 
//Purpose      : Fetch notification details from the database . 
//Created By   : Vaishnavi R
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------

using System.Web;
using System.Data.SqlClient;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System;
using Heathrow.BPM.Core.Entity;
using Newtonsoft.Json.Linq;

namespace Heathrow.BPM.DataAccess
{
    public class NotificationRepository : INotification
    {
        public NotificationRepository() { }


        public int Save(Notification notification)
        {
            DbConnection oDal = new DbConnection();
            int index = 0;
            JArray jsonArray;
            /*   DataSet dsNotificationList = new DataSet();

               oDAL.ExecuteDataSet(ProcedureConstants.UpdateNotification, out dsNotificationList,
                  new List<SqlParameter>()
                  {
                       new SqlParameter(){ParameterName ="@notificationId", DbType = DbType.String, Value = _notification.NotificationID },
                       new SqlParameter(){ParameterName="@topic",DbType=DbType.String,Value=_notification.Topic},

                       new SqlParameter(){ParameterName="@helpURL",DbType=DbType.String,Value=_notification.HelpUrl}

                       //To Do: Save list of locations for this.NotificationID and this.UserID
                       //Subscription for each notification
                  });

            // return dsNotificationList.Tables != null && dsNotificationList.Tables[0].Rows.Count > 0
            //     ? Convert.ToInt32(Convert.ToString(dsNotificationList.Tables[0].Rows[0][0]).Equals("success") ? 0 : 999)
            //     : 999;

          */


           try
            {
                using (StreamReader r = new StreamReader(HttpContext.Current.Server.MapPath("~/Helper/DummyData/notification.json")))
                { 
                var json = r.ReadToEnd();
                string result = string.Empty;
                jsonArray = JArray.Parse(json);
                //  dynamic data = JObject.Parse(jsonArray[0].ToString());

                foreach (var item in jsonArray.Where(obj => obj["notificationId"].Value<string>() == notification.NotificationID))
                {

                    // System.Diagnostics.Debug.Write(item["description"]);
                    index = (jsonArray.IndexOf(item));

                        foreach (var x in item)
                        {
                           
                        }

                    item["description"] = notification.Description;
                    result = item.ToString();
                }
                jsonArray[index] = JObject.Parse(result);
               }   
                 string output = Newtonsoft.Json.JsonConvert.SerializeObject(jsonArray, Newtonsoft.Json.Formatting.Indented);
                 File.WriteAllText(HttpContext.Current.Server.MapPath("~/Helper/DummyData/notification.json"), output);

               
            
                    //StreamWriter sw = new StreamWriter(HttpContext.Current.Server.MapPath("~/Helper/DummyData/notification.json"));
                    // sw.WriteLine(jsonArray);
            }

                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    oDal.CloseConnection();
                }
            return 1;
        }

        public IEnumerable<Notification> GetNotificationByNotificationId(string notificationId)
        {
            DbConnection oDal = new DbConnection();
            try
            {

                DataSet dsNotificationList = new DataSet();

                oDal.ExecuteDataSet(ProcedureConstants.GetNotificationById, out dsNotificationList,
                   new List<SqlParameter>()
                   {
                        new SqlParameter() { ParameterName = "@notificationId", DbType = DbType.String, Value =  notificationId }
                   });

                return dsNotificationList.Tables != null &&
                        dsNotificationList.Tables[0].Rows.Count > 0 ? BindDataToEntity(dsNotificationList, notificationId) : null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }

        public IEnumerable<Notification> GetTodaysNotification()
        {
            DbConnection oDal = new DbConnection();
            try
            {
                DataSet dsNotificationList = new DataSet();
                oDal.ExecuteDataSet(ProcedureConstants.GetAllNotification, out dsNotificationList);
                return dsNotificationList.Tables != null &&
                    dsNotificationList.Tables[0].Rows.Count > 0 ? BindAllDataToEntity(dsNotificationList) : null;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }

        private List<Notification> BindDataToEntity(DataSet dsNotification, string notificationId)
        {
               try
                {
                    return (from drAlert in dsNotification.Tables[0].AsEnumerable()
                            select (new Notification
                            {
                                NotificationID = notificationId,
                                Description= Convert.ToString(dsNotification.Tables[0].Rows[0]["Description"]),
                                Title = Convert.ToString(dsNotification.Tables[0].Rows[0]["Title"]),
                              //  Topic = Convert.ToString(dsNotification.Tables[0].Rows[0]["Topic"]),
                              //  Location = Convert.ToString(dsNotification.Tables[0].Rows[0]["Location"]),
                              //  TipOfTheDay= Convert.ToString(dsNotification.Tables[0].Rows[0]["Tip_Of_The_Day"]),
                                HelpUrl = Convert.ToString(dsNotification.Tables[0].Rows[0]["Help_Url"]),
                                StartDate=Convert.ToDateTime(dsNotification.Tables[0].Rows[0]["Start_Date"]),
                               // EndDate = Convert.ToDateTime(dsNotification.Tables[0].Rows[0]["End_Date"]),
                                Time= Convert.ToString(dsNotification.Tables[0].Rows[0]["Time"]),
                                IsSubscribe =Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Subscribe"]),
                                IsOnScreen = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_OnScreen"]),
                                IsEmail = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Email"]),
                                IsMobile = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Mobile"])

                            })).ToList();
                }
                catch (Exception)
                {
                    throw;
                }
            //return null;
        }
        private List<Notification> BindAllDataToEntity(DataSet dsNotification)
        {
            try
            {
                return (from drAlert in dsNotification.Tables[0].AsEnumerable()
                        select (new Notification
                        {
                            Description = Convert.ToString(dsNotification.Tables[0].Rows[0]["Description"]),
                            Topic = Convert.ToString(dsNotification.Tables[0].Rows[0]["Topic"]),
                            StartDate = Convert.ToDateTime(dsNotification.Tables[0].Rows[0]["Start_Date"]),
                           // EndDate = Convert.ToDateTime(dsNotification.Tables[0].Rows[0]["End_Date"]),
                            Time = Convert.ToString(dsNotification.Tables[0].Rows[0]["Time"]),

                            // NotificationID = Convert.ToString(dsNotification.Tables[0].Rows[0]["NotificationID"]),
                            //  Topic = Convert.ToString(dsNotification.Tables[0].Rows[0]["Topic"]),
                            //  Location = Convert.ToString(dsNotification.Tables[0].Rows[0]["Location"]),
                            //  TipOfTheDay= Convert.ToString(dsNotification.Tables[0].Rows[0]["Tip_Of_The_Day"]),
                            //   HelpUrl = Convert.ToString(dsNotification.Tables[0].Rows[0]["Help_Url"]),

                            //IsSubscribe = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Subscribe"]),
                            // IsOnScreen = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_OnScreen"]),
                            //  IsEmail = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Email"]),
                            //  IsMobile = Convert.ToBoolean(dsNotification.Tables[0].Rows[0]["is_Mobile"])

                        })).ToList();
            }
            catch (Exception)
            {
                throw;
            }
            //return null;
        }
    }
}
