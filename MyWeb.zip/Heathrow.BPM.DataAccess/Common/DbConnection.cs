﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Heathrow.BPM.Security;

namespace Heathrow.BPM.DataAccess.Common
{
    public class DbConnection
    {
        // private static string sConnString = ConfigurationManager.ConnectionStrings["ConString"].ToString();

        private readonly string _encryptionKey = ConfigurationManager.AppSettings["EncryptionKey"];
        private readonly string _sConnString = ConfigurationManager.ConnectionStrings["ConString"].ToString();


        #region Connection Properties
        private SqlConnection _sqlConn;
        private static string _sConnName;
        public string ConnectionString
        {
            get
            {
                if (!String.IsNullOrEmpty(_sConnString))
                {
                    AesEncryption sec = new AesEncryption();
                    _sConnName = sec.Decrypt(_sConnString, _encryptionKey);
                    return _sConnName;
                }
                return _sConnName;
            }
        }

        #endregion

        #region Connection Functions
        public SqlConnection OpenConnection()
        {
            try
            {
                if (_sqlConn != null)
                {
                    if (_sqlConn.State == ConnectionState.Closed)
                    {
                        if (_sqlConn.ConnectionString == "")
                            _sqlConn = new SqlConnection(_sConnName);
                        _sqlConn.Open();
                        return _sqlConn;
                    }
                    else
                    {
                        //return _sqlConn;
                        SqlConnection oNewConn = new SqlConnection(_sConnName);
                        oNewConn.Open();
                        return oNewConn;
                    }
                }
                else
                {
                    _sqlConn = new SqlConnection(_sConnName);
                    _sqlConn.Open();
                    return _sqlConn;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public SqlConnection OpenConnection(SqlConnection oConnection)
        {
            try
            {
                if (oConnection != null)
                {
                    if (oConnection.State == ConnectionState.Closed)
                    {
                        if (oConnection.ConnectionString == "")
                            oConnection = new SqlConnection(_sConnName);
                        oConnection.Open();
                        return oConnection;
                    }
                    else
                    {
                        return oConnection;
                    }
                }
                else
                {
                    _sqlConn = new SqlConnection(_sConnName);
                    _sqlConn.Open();
                    return _sqlConn;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public SqlConnection OpenConnection(string sConnectionString)
        {
            try
            {
                SqlConnection oConnection = new SqlConnection(sConnectionString);
                oConnection.Open();
                return oConnection;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void CloseConnection()
        {
            CloseConnection(_sqlConn);
        }
        public void CloseConnection(SqlConnection oConnection)
        {
            try
            {
                if (oConnection != null)
                {
                    if (oConnection.State == ConnectionState.Open)
                    {
                        if (oConnection.Equals(_sqlConn))
                            oConnection.Close();
                        else
                        {
                            oConnection.Close();
                            oConnection.Dispose();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion


        public void ExecuteDataSet(string strCommand, out DataSet dsOuput, List<SqlParameter> oParamCollection = null, DataTable dtInput = null, DataSet dsInput = null)
        {
            //int iReturnValue = 0;
           
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand(strCommand, connection))
                    {
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                           
                            command.CommandType = CommandType.StoredProcedure;
                            if (oParamCollection != null)
                            {
                                //AttachParameters(command, oParamCollection);
                                foreach (SqlParameter p in oParamCollection)
                                {
                                    if (p != null)
                                    {
                                        // Check for derived output value with no value assigned
                                        if ((p.Direction == ParameterDirection.InputOutput ||
                                            p.Direction == ParameterDirection.Input) &&
                                            (p.Value == null))
                                        {
                                            p.Value = DBNull.Value;
                                        }
                                        command.Parameters.Add(p);
                                    }
                                }
                            }
                            else if (dtInput != null)
                            {
                                command.Parameters.AddWithValue("@P_TABLE_VAR", dtInput);
                            }
                            else if (dsInput != null)
                            {
                                if (dsInput.Tables.Count > 0)
                                {
                                    int iTableIndex = 1;
                                    foreach (DataTable dtInputTemp in dsInput.Tables)
                                    {
                                        command.Parameters.AddWithValue("@P_TABLE_VAR" + iTableIndex.ToString(), dtInputTemp);
                                        iTableIndex++;
                                    }
                                }
                            }

                            dsOuput = new DataSet();
                            adapter.Fill(dsOuput);
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
                //iReturnValue = 0x65;
            }

        }

        public SqlParameter CreateParameterError(string strParamName)
        {
            SqlParameter oParam = new SqlParameter();
            oParam.ParameterName = strParamName;
            oParam.SqlDbType = SqlDbType.Int;
            oParam.Direction = ParameterDirection.Output;
            oParam.Value = DBNull.Value;
            return oParam;
        }

    }
}
