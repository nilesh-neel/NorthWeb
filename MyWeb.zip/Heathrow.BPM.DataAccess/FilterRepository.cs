﻿using Heathrow.BPM.Core;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using static System.Convert;

namespace Heathrow.BPM.DataAccess
{
    /// <summary>
    ///  Save Filter configuration into  Data souruce 
    /// </summary>
    public class FilterRepository : IFilter
    {
        private readonly DbConnection _dbConnection = null;
        private DataSet dsFilterList = null;
        private static FilterCollection filterDto = null;
        public FilterRepository()
        {
            _dbConnection = new DbConnection();
        }

        /// <summary>
        /// Save pinned filter configuration into Database
        /// </summary>
        /// <param name="filterData"></param>
        /// <returns></returns>
        public int SaveFilter(FilterCollection filterData)
        {
            try
            {
                _dbConnection.ExecuteDataSet(ProcedureConstants.SaveFilter, out dsFilterList,
                    new List<SqlParameter>()
                       {
                        
                       new SqlParameter() { ParameterName = "@FilterID", DbType = DbType.Int64, Value = filterData.FilterID },
                       new SqlParameter() { ParameterName = "@userID", DbType = DbType.String, Value = filterData.UserID },
                       new SqlParameter() { ParameterName = "@menuID", DbType = DbType.Int32, Value = filterData.MenuID },
                       new SqlParameter() { ParameterName = "@menuName", DbType = DbType.String, Value =  filterData.MenuName },
                       new SqlParameter() { ParameterName = "@filterText", DbType = DbType.String, Value = filterData.FilterText },
                       new SqlParameter() { ParameterName = "@filterSelection", DbType = DbType.Int16, Value = filterData.FilterSelection },
                       new SqlParameter() { ParameterName = "@createdUser", DbType = DbType.String, Value = filterData.UserID },
                       new SqlParameter() { ParameterName = "@last_User", DbType = DbType.String, Value = filterData.UserID }
                       });

            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error is occured while saving filters", ex);
            }
            finally
            {
                _dbConnection.CloseConnection();

            }

            return 0;
        }

        /// <summary>
        ///  Get all Filter configuration Details from Database
        /// </summary>
        /// <param name="menuId"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public FilterCollection GetFilterByMenuID(int menuId, int userId)
        {
            try
            {
                _dbConnection.ExecuteDataSet(ProcedureConstants.GetFilterByUser, out dsFilterList,
                     new List<SqlParameter>()
                       {
                     //  new SqlParameter() { ParameterName = "@userID", DbType = DbType.String, Value = userID },
                       new SqlParameter() { ParameterName = "@menuID", DbType = DbType.Int32, Value = menuId }
                     });

                return BindFilterDataToEntity(dsFilterList);
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error is occured while retrieving the filters", ex);
            }
            finally
            {
                _dbConnection.CloseConnection();
            }
        }
        public FilterCollection GetAllFilter()
        {
            try
            {
                _dbConnection.ExecuteDataSet(ProcedureConstants.GetAllFilter, out dsFilterList);
                return BindDataToEntity(dsFilterList);
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error is occured while retrieving the filters", ex);
            }
            finally
            {
                _dbConnection.CloseConnection();

            }
        }


        public FilterCollection GetAllUserDetails()
        {
            try
            {
                _dbConnection.ExecuteDataSet(ProcedureConstants.GetPassengerDetails, out dsFilterList);
                return ConvertDataToUserEntity(dsFilterList);
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Error is occured while retrieving the filters", ex);
            }
            finally
            {
                _dbConnection.CloseConnection();

            }
        }

        private static FilterCollection ConvertDataToUserEntity(DataSet dsData)
        {
            if (dsData != null && dsData.Tables.Count > 0)
            {
                if (dsData.Tables.Count > 1)
                {
                    filterDto = new FilterCollection
                    {
                        BagTagList = new List<TextFilter>(),
                        PassengersList = new List<TextFilter>(),
                        InBoundFlightList = new List<TextFilter>(),
                        OutBoundFlightList = new List<TextFilter>()
                    };
                }

                foreach (DataRow row in dsData.Tables[0].Rows)
                {
                    filterDto.PassengersList.Add(new TextFilter
                    {
                        ID = ToInt64(row["UserID"]),
                        Text = Convert.ToString(row["UserName"])
                    });
                }

                foreach (DataRow item in dsData.Tables[1].Rows)
                {
                    filterDto.BagTagList.Add(new TextFilter
                    {
                        ID = ToInt64(item["BagTagID"]),
                        Text = Convert.ToString(item["BagTag"])
                    });
                }

    

                foreach (DataRow row in dsData.Tables[2].Rows)
                {
                    filterDto.InBoundFlightList.Add(new TextFilter
                    {
                        ID = ToInt64(row["BagTagID"]),
                        Text = Convert.ToString(row["BagTag"])
                    });
                }

                foreach (DataRow row in dsData.Tables[3].Rows)
                {
                    filterDto.OutBoundFlightList.Add(new TextFilter
                    {
                        ID = ToInt64(row["BagTagID"]),
                        Text = Convert.ToString(row["BagTag"])
                    });
                }

            }
            return filterDto;
        }

        private static FilterCollection BindDataToEntity(DataSet dsData)
        {

            if (dsData != null && dsData.Tables.Count > 0)
            {

                if (dsData.Tables.Count > 1)
                {
                    filterDto = new FilterCollection
                    {
                        BagSystemList = new List<DropDownFilter>(),
                        BagTypeList = new List<DropDownFilter>(),
                        ShortConnectList = new List<DropDownFilter>(),
                        AfterChoxList = new List<DropDownFilter>(),
                        DeletedBagsList = new List<DropDownFilter>(),
                        DeletedBSMList = new List<DropDownFilter>(),
                        FailedInSystemList = new List<DropDownFilter>(),
                        FailedMissedList = new List<DropDownFilter>(),
                        InboundITOList = new List<DropDownFilter>(),
                        MissedBRSList = new List<DropDownFilter>(),
                        InTargetList = new List<DropDownFilter>(),
                        MyBagList = new List<DropDownFilter>(),
                        OOGBagsList = new List<DropDownFilter>(),
                    };
                    foreach (DataRow item in dsData.Tables[0].Rows)
                    {
                        filterDto.BagTypeList.Add(new DropDownFilter
                        {
                            ID = ToInt32(item["BagItemTypeID"]),
                            Name = Convert.ToString(item["Description"])
                        });
                    }

                    foreach (DataRow row in dsData.Tables[1].Rows)
                    {
                        filterDto.BagSystemList.Add(new DropDownFilter
                        {
                            ID = ToInt32(row["BagSystemID"]),
                            Name = Convert.ToString(row["Name"])
                        });
                    }
                    foreach (DataRow row in dsData.Tables[2].Rows)
                    {
                        filterDto.ShortConnectList.Add(new DropDownFilter
                        {
                            ID = ToInt32(row["BagSystemID"]),
                            Name = Convert.ToString(row["Name"])
                        });
                    }
                    foreach (DataRow row in dsData.Tables[3].Rows)
                    {
                        filterDto.AfterChoxList.Add(new DropDownFilter
                        {
                            ID = ToInt32(row["BagSystemID"]),
                            Name = Convert.ToString(row["Name"])
                        });
                    }
                    foreach (DataRow row in dsData.Tables[4].Rows)
                    {
                        filterDto.DeletedBagsList.Add(new DropDownFilter
                        {
                            ID = ToInt32(row["BagSystemID"]),
                            Name = Convert.ToString(row["Name"])
                        });
                    }
                    foreach (DataRow row in dsData.Tables[5].Rows)
                    {
                        filterDto.DeletedBSMList.Add(new DropDownFilter
                        {
                            ID = ToInt32(row["BagSystemID"]),
                            Name = Convert.ToString(row["Name"])
                        });
                    }
                    foreach (DataRow row in dsData.Tables[6].Rows)
                    {
                        filterDto.FailedInSystemList.Add(new DropDownFilter
                        {
                            ID = ToInt32(row["BagSystemID"]),
                            Name = Convert.ToString(row["Name"])
                        });
                    }
                    foreach (DataRow row in dsData.Tables[7].Rows)
                    {
                        filterDto.FailedMissedList.Add(new DropDownFilter
                        {
                            ID = ToInt32(row["BagSystemID"]),
                            Name = Convert.ToString(row["Name"])
                        });
                    }
                    foreach (DataRow row in dsData.Tables[8].Rows)
                    {
                        filterDto.InboundITOList.Add(new DropDownFilter
                        {
                            ID = ToInt32(row["BagSystemID"]),
                            Name = Convert.ToString(row["Name"])
                        });
                    }
                    foreach (DataRow row in dsData.Tables[9].Rows)
                    {
                        filterDto.MissedBRSList.Add(new DropDownFilter
                        {
                            ID = ToInt32(row["BagSystemID"]),
                            Name = Convert.ToString(row["Name"])
                        });
                    }
                    foreach (DataRow row in dsData.Tables[10].Rows)
                    {
                        filterDto.InTargetList.Add(new DropDownFilter
                        {
                            ID = ToInt32(row["BagSystemID"]),
                            Name = Convert.ToString(row["Name"])
                        });
                    }
                    foreach (DataRow row in dsData.Tables[11].Rows)
                    {
                        filterDto.MyBagList.Add(new DropDownFilter
                        {
                            ID = ToInt32(row["BagSystemID"]),
                            Name = Convert.ToString(row["Name"])
                        });
                    }
                    foreach (DataRow row in dsData.Tables[12].Rows)
                    {
                        filterDto.OOGBagsList.Add(new DropDownFilter
                        {
                            ID = ToInt32(row["BagSystemID"]),
                            Name = Convert.ToString(row["Name"])
                        });
                    }


                }
            }

            return filterDto;
        }

        private static FilterCollection BindFilterDataToEntity(DataSet dsData)
        {
            if (dsData != null && dsData.Tables.Count > 0)
            {
                foreach (DataRow row in dsData.Tables[0].Rows)
                {
                    filterDto = new FilterCollection()
                    {
                        FilterID = ToInt32(row["Filter_ID"]),
                        UserID = Convert.ToString(row["Filter_user_ID"]),
                        MenuID = ToInt32(row["Filter_Menu_ID"]),
                        FilterText = Convert.ToString(row["Filter_Baggage"]),
                    };

                }
            }
            return filterDto;
        }


    }
}
