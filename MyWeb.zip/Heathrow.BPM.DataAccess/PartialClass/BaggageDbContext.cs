﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Security;
using System;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;

namespace Heathrow.BPM.DataAccess
{
    public partial class BaggageDbContext : DbContext
    {
        private static readonly string EncryptionKey = ConfigurationManager.AppSettings["EncryptionKey"];
        private static readonly string SConnString = ConfigurationManager.ConnectionStrings["BaggageDbContext"].ToString();
        private static string _sConnName;
        public static string ConnectionString
        {
            get
            {
                if (String.IsNullOrEmpty(_sConnName))
                {
                    AesEncryption sec = new AesEncryption();
                    _sConnName = sec.Decrypt(SConnString, EncryptionKey);
                    return _sConnName;
                }
                return _sConnName;
            }
        }
        public BaggageDbContext()
            : base(ConnectionString)
        {
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {

            modelBuilder.Entity<Favourites>().HasRequired(a => a.FavouriteLink);

        }


        public virtual ObjectResult<usp_GetMenu_Result> usp_GetMenu()
        {
            return ((IObjectContextAdapter)this).ObjectContext.ExecuteFunction<usp_GetMenu_Result>("usp_GetMenu");
        }

        public virtual ObjectResult<usp_GetFavourites_Result> usp_GetFavourites(string userId)
        {
            var userIdParameter = userId != null ?
                new ObjectParameter("User_ID", userId) :
                new ObjectParameter("User_ID", typeof(string));

            return ((IObjectContextAdapter)this).ObjectContext.ExecuteFunction<usp_GetFavourites_Result>("usp_GetFavourites", userIdParameter);
        }

        public virtual ObjectResult<int> usp_SaveFavourites(string userId, int menuId, int favouriesId)
        {
            var userIdParameter = userId != null ?
                new ObjectParameter("User_ID", userId) :
                new ObjectParameter("User_ID", typeof(string));

            return ((IObjectContextAdapter)this).ObjectContext.ExecuteFunction<int>("usp_SaveFavourites", userIdParameter);
        }
    }
}
