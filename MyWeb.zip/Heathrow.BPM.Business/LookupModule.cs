﻿/*using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Business
{
  public  class LookupModule
    {
        private static ILookup _lookup { get; set; }
        public LookupModule(ILookup lookup)
        {

            _lookup = lookup;
        }

        public List<LookupEnt> GetLookupById(int id)
        {
            return _lookup.GetLookupDetailsById(id);
        }
    }
}
*/