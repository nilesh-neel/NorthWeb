﻿using Heathrow.BPM.Core;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Business
{
    /// <summary>
    ///  Baggage filter business 
    /// </summary>
    public class FilterModule
    {
        private readonly IFilter FilterInstance;

        public FilterModule(IFilter filterData)
        {
            FilterInstance = filterData;
        }

        /// <summary>
        /// Create Filter business 
        /// </summary>
        /// <param name="filterEntity"></param>
        /// <returns></returns>
        public int SaveFilter(FilterCollection filterEntity)
        {
            return FilterInstance.SaveFilter(filterEntity);
        }

        /// <summary>
        /// Get Filter Business 
        /// </summary>
        /// <param name="menuID"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public FilterCollection GetFilterByMenu(int menuID, int userID)
        {
            return FilterInstance.GetFilterByMenuID(menuID, userID);
        }

        public FilterCollection GetAllFilterData()
        {
            return FilterInstance.GetAllFilter();

        }

        public FilterCollection GetAllUserDetails()
        {
            return FilterInstance.GetAllUserDetails();
        }

    }
}
