﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Business
{
    public class BagListModule
    {
        private static IBagList _baglist { get; set; }

        public BagListModule(IBagList bagList)
        {
            _baglist = bagList;
        }

        public int SaveBagTags(string Bagtags, string UserId)
        {
           return _baglist.SaveBagTags(Bagtags, UserId);
        }
        
        public int GetUserExistingbagtagsCnt(string UserId)
        {
            return _baglist.GetUserExistingBagtagsCnt(UserId);
        }

        public string GetUserExistingbagtags(string UserId)
        {
            return _baglist.GetUserExistingBagtags(UserId);
        }

        public int RemoveBagTags(string Bagtags, string UserId)
        {
            return _baglist.RemoveBagTags(Bagtags, UserId);
        }
        
    }
}
