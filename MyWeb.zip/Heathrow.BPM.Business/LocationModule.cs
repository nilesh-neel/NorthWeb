﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Business
{
    public class LocationModule
    {
       
        private static ILocation _location { get; set; }
        public LocationModule( ILocation location)
        {
            
            _location = location;
        }

        public IEnumerable<Location> GetAllLocation()
        {
            return _location.GetLocation();
        }
    }
}
