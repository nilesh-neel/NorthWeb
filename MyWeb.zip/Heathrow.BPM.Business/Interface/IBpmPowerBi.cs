﻿using Newtonsoft.Json.Linq;
using System.Collections.Specialized;
using System.IO;
using System.Threading.Tasks;

namespace Heathrow.BPM.Business.Interface
{
    public interface IBpmPowerBi
    {
        string AADAuthorityUri { get; set; }
        NameValueCollection GetAuthorizationCode();
        string RedirectOnAuthentication(string authorizationCode);
        string GetDashboardDetails(string _AccessToken);
        Task<string> GetUserAccessTokenAsync();
        Task<string> GetMyEmailAddress(string accessToken);

        Task<string> GetUserDetailsFromAzureServer(string accessToken);
        Task<Stream> GetUserProfilePhoto(string accessToken);
        Task<string> GetEmbadedToken();

    }
}
