﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Heathrow.BPM.Business
{
    public class FavouritesModule
    {
        private static IFavourites _favouritesRepo { get; set; }
        private static IRepository<Menu> _menuRepo { get; set; }

        public FavouritesModule(IFavourites fav, IRepository<Menu> menu)
        {
            _menuRepo = menu;
            _favouritesRepo = fav;
        }


        public async Task<IEnumerable<Favourites>> Save(Favourites fav)
        {
            var _menuDetails = _menuRepo.All().Where(a => a.MenuId.Equals(fav.FavouriteLink.MenuId));
            if (_menuDetails.Any())
            {
                var favMenuList = await _favouritesRepo.GetUserFavourites(fav.UserId);
                favMenuList.Append(new Favourites { UserId = fav.UserId, FavouriteLink = _menuDetails.FirstOrDefault() });
                return favMenuList != null ? await _favouritesRepo.Save(fav) == 0 ? favMenuList : null : null;
            }

            return null;
        }
     
        public async Task<IEnumerable<Favourites>> GetUserFavourites(string _userId)
        {
            try
            {
                return await _favouritesRepo.GetUserFavourites(_userId);
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
    }
}
