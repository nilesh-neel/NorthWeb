﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess;
using Heathrow.BPM.DataAccess.Common;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Heathrow.BPM.Business
{
    public class MenuModule
    {
        IRepository<Menu> _menu { get; set; }
        public MenuModule(IRepository<Menu> menu)
        {
            _menu = menu;
        }

        public async Task<IEnumerable<Menu>> GetAllMenu()
        {
            try
            {
                return await _menu.ExecuteQueryAsync(ProcedureConstants.GetAllMenu);
            }
            catch (Exception ex)
            {

                throw ex;
            }


        }

        //public IEnumerable<Menu> GetAllMenu()
        //{
        //    return _menu.All();
        //}
    }
}
