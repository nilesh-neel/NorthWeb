﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Business
{
    public class ShareModule
    {
        private static IShare _share { get; set; }

        public ShareModule(IShare share)
        {
            _share = share;
        }

        public IList<Share> GetAudienceGrp()  
        {
            return _share.FetchAudienceGrp();
        }

        public IList<Share> GetGrpRecipients(int Audiencegrpid)
        {
            return _share.FetchRecipients(Audiencegrpid);
        }
    }
}
