﻿using System.Collections.Generic;
using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using Heathrow.BPM.DataAccess;

namespace Heathrow.BPM.Business
{
   public class RegistrationModule
    {
     //   private static LookupRepository lr = new LookupRepository();
        private static IRegistration _registration { get; set; }
        private static ILookup _lookup { get; set; }
        public RegistrationModule(IRegistration registration,ILookup lookup)
        {
            _registration = registration;
            _lookup = lookup;
        }
        
        public int Save(Registration registration)
        {
      /*      List<LookupEnt> listobj = new List<LookupEnt>(); 
           listobj= lr.GetLookupDetailsById(1);
            foreach (LookupEnt le in listobj)
                System.Console.WriteLine(le.LookupTypeName);*/

            return _registration.Save(registration);
        }    
        
        public List<LookupEnt> locationlist()
        {
            return _lookup.GetLookupDetailsById(1);
        }

        public List<LookupEnt> rolelist()
        {
            return _lookup.GetLookupDetailsById(2);
        }
    }
}
