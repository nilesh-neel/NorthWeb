﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System.Collections.Generic;
using System.Linq;
namespace Heathrow.BPM.Business
{
    public class NotificationModule
    {

        private static ILookup _lookup { get; set; }

        private static INotification _notificationRepository { get; set; }
        public NotificationModule(INotification notification, ILookup lookup)
        {
            _notificationRepository = notification;
            _lookup = lookup;
        }

        public int Save(Notification notification)
        {
            return _notificationRepository.Save(notification);
        }

        public IEnumerable<Notification> GetNotificationById(string _notificationId)
        {
            //Get from repository based on id for topic,tip of the day
            //  _lookup.GetLookupDetailsById(TopicID);
            // _lookup.GetLookupDetailsById(TipID);

            var obj = _notificationRepository.GetNotificationByNotificationId(_notificationId);
           foreach(var item in obj)
            {
                var topicList = _lookup.GetLookupDetailsById(2).Select(LookupEnt => LookupEnt.LookupTypeName).ToList();
              //  item.Topic = GetLookupItemName();


            }
            return _notificationRepository.GetNotificationByNotificationId(_notificationId);
        }


        //get Todays Notification
        public IEnumerable<Notification> GetTodaysNotification()
        {       
            return _notificationRepository.GetTodaysNotification();
        }
    }
}
