﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System.Collections.Generic;

namespace Heathrow.BPM.Business
{
    public class AlertsModule 
    {
        private static IAlerts _alertsRepository;

        public AlertsModule(IAlerts alerts)
        {
            //_alertsRepository = alert;
            _alertsRepository = alerts;
            // CRUD oDAL = new CRUD();
        }

        public IEnumerable<Alerts> GetData()
        {
            // return null;//
            return _alertsRepository.GetAll();
        }
        public Alerts GetAlertsById(string id)
        {
            //  return null;// _alertsRepository.GetAlertsById(id);
            return _alertsRepository.GetAlertsById(id);
        }

        public int Save(Alerts alert)
        {
            return _alertsRepository.Save(alert);
        }
    }
}
