﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Heathrow.BPM.DataAccess.Common;
using Heathrow.BPM.Core;
using System.Data.SqlClient;
using System.Data;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Business
{
    
    public class SearchModule
    {

        private readonly ISearch searchInstance;
        public SearchModule(ISearch searchObj)
        {
            searchInstance = searchObj;
        }

        public IList<TextFilter> GetSearchData(string searchQuery, string searchPrefix)
        {
            return searchInstance.GetSearchData(searchQuery, searchPrefix);
        }

    
    }
}
