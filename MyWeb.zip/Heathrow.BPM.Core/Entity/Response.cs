﻿namespace Heathrow.BPM.Core.Entity
{
  public class Response
    {
        public bool isAcknowledge { get; set; }
        public bool isBlank { get; set; }
        public bool isIgnore { get; set; }
    }
}
