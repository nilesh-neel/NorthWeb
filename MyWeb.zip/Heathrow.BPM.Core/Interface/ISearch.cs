﻿using System.Collections.Generic;


namespace Heathrow.BPM.Core.Interface
{
    public interface ISearch
    {
      IList<TextFilter> GetSearchData(string searchText,string prefix);
    }
}
