﻿
using System.Collections.Generic;
using Heathrow.BPM.Core.Entity;


namespace Heathrow.BPM.Core.Interface
{
    public interface INotes
    {
         IList<Notes> SaveNotes(Notes _note);
        IList<Notes> FetchNotes(string Bagtag, string Flightnumber, string Organization);

        IList<Notes> DeleteNotes(int NotesId, string Bagtag, string Flightnumber, string Organization);
    }
}
