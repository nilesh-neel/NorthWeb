﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Core.Interface
{
    public interface IMenu
    {
        IEnumerable<Menu> GetAllMenu();
        Task<IEnumerable<Menu>> GetAllMenuAsync();
    }
}
