﻿using System.Web.Http;

namespace Heathrow.BPM.Web.Controllers.Api
{
    public class BaseApiController : ApiController
    {
       
    }
}
