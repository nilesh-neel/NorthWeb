﻿/****************************************************************************************************************
Class Name   : DashboardController.cs 
Purpose      : Dashboard file use to set the user pic and get the token for the power bi reports.
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using System;
using System.IO;
using System.Threading.Tasks;
using System.Web.Mvc;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Web.Controllers
{
    [Authorize]
  
    public class DashboardController : BaseController
    {
        private readonly IBpmPowerBi _bpmPowerBi;
        private readonly IUserModule _userModule;
        public DashboardController(IAuthProvider authProvider, IBpmPowerBi bpmPowerBi, IUserModule userModule)
        {
            _bpmPowerBi = bpmPowerBi;
            _userModule = userModule;
        }

        // GET: Dashboard
        public async Task<ActionResult> Index()
        {
            // Signal OWIN to send an authorization request to Azure.
            if (!Request.IsAuthenticated)
                RedirectToAction("SignIn", "Account");
            try
            {
                var objUser = await _userModule.GetUserDetailsAsync();
                ViewBag.DisplayName = objUser.DisplayName;
                byte[] byteArr = ((MemoryStream)await _userModule.GetUserProfilePhoto()).ToArray();
                ViewBag.userPic = byteArr;
                return View();
            }
            catch (Exception)
            {
                RedirectToAction("SignIn", "Account");
            }

            return View();
        }

        [HttpGet]
        [Authorize]
        public async Task<ActionResult> GetData()
        {
            var token = await _bpmPowerBi.GetEmbeddedToken();
            if (string.IsNullOrEmpty(token))
                RedirectToAction("SignIn", "Account");


            //var acceToken = await _bpmPowerBi.GetUserAccessTokenAsync();
            //var result = await _bpmPowerBi.GetUserDetailsFromAzureServer(acceToken);
            //var objUser = JsonConvert.DeserializeObject<AzureUserInfoVM>(result);
            //var userPic = await _bpmPowerBi.GetUserProfilePhoto(acceToken);
            //ViewBag.DisplayName = objUser.displayName;
            //byte[] byteArr = ((MemoryStream)userPic).ToArray();
            //ViewBag.userPic = byteArr;
            return Json(token, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Error(string message, string debug)
        {
            //Flash(message, debug);
            return RedirectToAction("Index");
        }
    }
}