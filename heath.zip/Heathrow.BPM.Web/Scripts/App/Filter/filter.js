﻿(function ($) {
    'use strict';

    var url = '';
    var requestType = '';
    var userFilterselection = [];
    var filterData = [];
    var actionResult = [];
    var userID = 'Admin';
    var filterID = 0;
    var filterResult = [];
    var filterEntityMode = { New: 1, Edit: 2 };
    var filterTypeEnum =
        {
            BagDetails: 3, BagListInBound: 5, BagListOutBound: 6, VOLSMR: 13, ADPDBD: 15, ADPDBDLocal: 14, ADPSMR: 16, ADPDLR: 17,
            BJPDBD: 18, BJPSMR: 19, BJPDLR: 20, NLBDBD: 22, NLBSMR: 23, NLBDLR: 24, DDPDBD: 25, DDPSMR: 26, DDPDLR: 27,
            BagListGeneral: 30, FlightDetailsInBound: 32, FlightDetailsOutBound: 33, BagListNLBA: 38, BTRInBound: 39,
            BTROutBound: 40, BSMSMR: 41, ITTDBD: 28, ITTDLR: 29, MDRSMR: 36, MDRDLR: 37, ARRDBDNext: 34, ARRDBD: 35
        };
    var FilterControlEnum =
        {
            Date: 1, Timeband: 2, PaxSurname: 3, BagTag: 4, NotLoadedCategory: 5, NotLoadedSubCategory: 6, OutboundFlight: 7, OutboundAircraft: 8,
            Destination: 9, OutboundAirline: 10, OutboundHandler: 11, OutboundTerminal: 12, InboundFlight: 13, InboundAirline: 14, InboundAircraft: 15,
            Origin: 16, InboundHandler: 17, InboundTerminal: 18, LastSeenLocation: 19, BagStatus: 20, BagType: 21, ShortConnect: 22, OOGBags: 23,
            SeenAfterChox: 24, ShowDeletedBags: 25, ShowMissedBRS: 26, ShowDelBSMs: 27, ShowMyBagList: 28, Route: 29, ProcessArea: 30,
            BaggageSystem: 31, RouteStartTime: 32, RouteEndTime: 33, InboundITO: 34, InTarget: 35, FailedThenMissed: 36, SeenAtStart: 37,
            SeenAtEnd: 38, NotLoadedFailedInSystem: 39, MDStatusLocation: 40
        };

    /* Multi drop down control **/
    var ddlNotLoaded = $('#selectNotLoaded'); var ddlNotLoadedSub = $('#selectNotLoadedSub'); var ddlOutbndAircraft = $('#selectOutbndAircraft');
    var ddlDestination = $('#selectDestination');
    var ddlOutbndAirline = $('#selectOutbndAirline');
    var ddlOutbndHandler = $('#selectOutbndHandler');
    var ddlOutbndTerminal = $('#selectOutbndTerminal');
    var ddlInbndAirline = $('#selectInbndAirline');
    var ddlInbndAircraft = $('#selectInbndAircraft');
    var ddlOrigin = $('#selectOrigin');
    var ddlInbndhandler = $('#selectInbndhandler');
    var ddlInbndTerminal = $('#selectInbndTerminal');
    var ddlLastLocation = $('#selectLastLocation');
    var ddlBagStatus = $('#selectBagStatus');
    var ddlProcessArea = $('#selectProcessArea');
    var ddlBaggageSystem = $('#selectBaggageSystem');
    var ddlAtStart = $('#selectAtStart');
    var ddlAtEnd = $('#selectAtEnd');
    var ddlselectMDStatus = $('#selectMDStatus');

    /* Single drop down control **/
    var ddlbagType = $('#selectBagType');
    var ddlShort = $('#selectShortConnect');
    var ddlOOGBags = $('#selectOOGBags');
    var ddlchox = $('#selectchox');
    var ddlDeleteBags = $('#selectDeleteBags');
    var ddlBRSonly = $('#selectBRSonly');
    var ddlDelBSM = $('#selectDelBSM');
    var ddlBagList = $('#selectBagList');
    var ddlInbndITO = $('#selectInbndITO');
    var ddlInTarget = $('#selectInTarget');
    var ddlFailedMissed = $('#selectFailedMissed');
    var ddlFailedSystem = $('#selectFailedSystem');
    var ddlRoute = $('#selectRoute');

    /* Text box search control **/
    var txtPaxName = $('#txtPaxName');
    var txtBagTag = $('#txtBagTag');
    var txtInbndFlight = $('#txtInbndFlight');
    var txtOutbndFlight = $('#txtOutbndFlight');
    var txtSingleDate = $('#txtSingleDate');
    var txtMultiDate = $('#txtMultiDate');


    /* time slicer  control **/
    var txtTimeBand = $('#txtTimeBand');
    var txtRouteStartTime = $('#txtRouteStartTime');
    var txtRouteEndTime = $('#txtRouteEndTime');
    var timeBandSlicerValue = 6;
    var startTimeSlicerValue = 8;
    var endTimeSlicerValue = 10;


    var date = ''; var timeband = '';
    var paxSurname = '';
    var bagTag = '';
    var notLoadedCategory = '';
    var notLoadedSubCategory = '';
    var outboundFlight = '';
    var outboundAircraft = '';
    var destination = '';
    var outboundAirline = '';
    var outboundHandler = '';
    var outboundTerminal = '';
    var inboundFlight = '';
    var inboundAirline = '';
    var inboundAircraft = '';
    var origin = '';
    var inboundHandler = '';
    var inboundTerminal = '';
    var lastSeenLocation = '';
    var bagStatus = '';
    var bagType = '';
    var shortConnect = '';
    var oOGBags = '';
    var seenAfterChox = '';
    var showDeletedBags = '';
    var showMissedBRS = '';
    var showDelBSMs = '';
    var showMyBagList = '';
    var route = '';
    var processArea = '';
    var baggageSystem = '';
    var routeStartTime = '';
    var routeEndTime = '';
    var inboundITO = '';
    var inTarget = '';
    var failedThenMissed = '';
    var seenAtStart = '';
    var seenAtEnd = '';
    var notLoadedFailedInSystem = '';
    var mDStatusLocation = '';


    $(document).ready(function () {

        Utility.multiDropDownConfiguration(ddlNotLoaded);
        Utility.multiDropDownConfiguration(ddlNotLoadedSub);
        Utility.multiDropDownConfiguration(ddlOutbndAircraft);
        Utility.multiDropDownConfiguration(ddlDestination);
        Utility.multiDropDownConfiguration(ddlOutbndAirline);
        Utility.multiDropDownConfiguration(ddlOutbndHandler);
        Utility.multiDropDownConfiguration(ddlOutbndTerminal);
        Utility.multiDropDownConfiguration(ddlInbndAirline);
        Utility.multiDropDownConfiguration(ddlInbndAircraft);
        Utility.multiDropDownConfiguration(ddlOrigin);
        Utility.multiDropDownConfiguration(ddlInbndhandler);
        Utility.multiDropDownConfiguration(ddlInbndTerminal);
        Utility.multiDropDownConfiguration(ddlLastLocation);
        Utility.multiDropDownConfiguration(ddlBagStatus);
        Utility.multiDropDownConfiguration(ddlProcessArea);
        Utility.multiDropDownConfiguration(ddlBaggageSystem);
        Utility.multiDropDownConfiguration(ddlAtStart);
        Utility.multiDropDownConfiguration(ddlAtEnd);
        Utility.multiDropDownConfiguration(ddlselectMDStatus);
        Utility.multiDropDownConfiguration(ddlRoute);

        setTimeSlicer(txtTimeBand, timeBandSlicerValue);
        setTimeSlicer(txtRouteStartTime, startTimeSlicerValue);
        setTimeSlicer(txtRouteEndTime, endTimeSlicerValue);
        dropDownEventHandler();
    });

    var dropDownEventHandler = function () {

        $('.combobox').combobox({
            select: function (event, ui) {
                // selected value -  ui.item.text
                // get the combobox - ui.item.firstChild.parentNode.parentElement.id
            }
        });
    }


    $('.filter').click(function () {
        $('#filterPanel').toggle();
        $('.filter').toggleClass('clickedIcons');
        $('.filter').toggleClass('customBorderSmall');

        if ($('#filterPanel').is(':visible')) {
            if (menuItemID !== 0) {
                loadFilterDropDown();
                loadReportFilter(menuItemID, filterResult, false);
                loadTextSearchFilter();
                loadFilterByUser(menuItemID);
            }

        }

    });

    $('#btnApply').click(function () {

        var powerBiUrl = sessionStorage.getItem('autoRefURL');
        var isReport = sessionStorage.getItem('autoRefURLIsReport');

        var dashboardPowerBiApi = new PowerBIAPP(powerBiUrl, isReport);

        var service = new Service('/Filter/GetFilterByMenuID?menuID=' + 30 + '&userID=0', 'application/html; charset=utf-8', 'html', null);
        service.get()
            .then(function (resp) {
                dashboardPowerBiApi.applyFilterToReport(resp);

            });
    });

    $('#pinIcon').click(function () {
        $('#pinIcon').toggleClass('Pin');
        $('#pinIcon').toggleClass('pinclicked');

        if ($('.pinclicked').is(':visible')) {

            saveFilterConfiguration();
        }
    });

    /* Pin Icon functionality in filters panel start */

    $('#pinIconLink').hover(function (event) {

        $(this).removeClass('hovered-content');
        if ($('#pinIcon').hasClass('Pinclicked')) {
            $('#pinIconLink').tooltip('hide');
            $(this).addClass('hovered-content');
        }
    });

    /* Range slider */

    var setTimeSlicer = function (controlField, fromValue) {

        var fieldName = '#' + controlField[0].id;
        $(fieldName).ionRangeSlider({
            type: 'double',
            min: 0,
            max: 24,
            from: fromValue,
            step: 2,
            from_min: 0,
            from_max: 24,
            from_shadow: true,
            to: 24,
            to_min: 6,
            to_max: 24,
            to_shadow: true,
            grid: true,
            grid_snap: true

        });
    }

    /* daterangePicker for single calender*/

    $('#txtSingleDate,#txtMultiDate').daterangepicker({

        singleDatePicker: true,
        showDropdowns: true

    });

    /* Pin Icon functionality in filters panel end */

    var loadRouteDropDown = function () {

        $('#selectRoute').multiselect('loadOptions', [{
            name: 'T2->T5',
            value: 't5',
            checked: false
        },
        {
            name: 'T3 Direct',
            value: 't3',
            checked: false
        },
        {
            name: 'T3->T2',
            value: 't2',
            checked: false
        }
        ]);
    };

    var bagTagList = [];
    var passengersList = [];
    var inBoundFlightList = [];
    var outBoundFlightList = [];
    var loadTextSearchFilter = function () {
        url = '/Filter/GetUserData';
        requestType = Utility.RequestType.Get
        var successCallback = function (data) {

            if (!Utility.isNullOrEmpty(data)) {
                actionResult = JSON.parse(data);

                // Fill Bag Tag  data into the control

                fillAutoCompleteList(bagTagList, actionResult.BagTagList);
                Utility.textSearchFilter(txtBagTag, bagTagList);

                // Fill Paxsurname data into the control

                fillAutoCompleteList(passengersList, actionResult.PassengersList);
                Utility.textSearchFilter(txtPaxName, passengersList);


                // Fill Inbound Flight data into the control
                fillAutoCompleteList(inBoundFlightList, actionResult.InBoundFlightList);
                Utility.textSearchFilter(txtInbndFlight, inBoundFlightList);

                // Fill Out bound Flight data into the control
                fillAutoCompleteList(outBoundFlightList, actionResult.OutBoundFlightList);
                Utility.textSearchFilter(txtOutbndFlight, outBoundFlightList);

            };
        }
        var errorCallbackHandler = function (data) {
            // alert(data);
        }

        Utility.makeAjaxCallWithoutParameter(url, requestType, successCallback, errorCallbackHandler);
    };

    var filterEntity = [];
    var saveFilterConfiguration = function () {
        url = '/Filter/SaveFilters';
        fillFilterValuesToLocalVariable();
        loadReportFilter(menuItemID, filterResult, true);
        filterEntity = { UserID: userID, FilterID: filterID, MenuID: menuItemID, FilterSelection: 1, FilterInput: userFilterselection };
        var successCallBackHandler = function (data) {
            if (!Utility.isNullOrEmpty(data)) {
                alert('Filter data is saved successfully');
            }
        };

        var errorCallbackHandler = function (data) {
            alert(data);
        }

        Utility.makeAjaxCall(url, Utility.RequestType.Post, JSON.stringify(filterEntity), successCallBackHandler, errorCallbackHandler);

    };


    var assignValuesToControls = function (valueList, menuID) {
        date = (valueList.Date == null) ? moment().format('DD-MM-YYYY') : valueList.Date

        switch (true) {
            case (filterTypeEnum.BagDetails === menuID):
                loadBagListDBDSelection(valueList);
                break;
            case (filterTypeEnum.BagListGeneral === menuID):
                loadBagListFilterSelection(valueList);
                break;
            case (filterTypeEnum.BagListInBound === menuID):
                loadBagListInboundSelection(valueList);
                break;
            case (filterTypeEnum.BagListOutBound === menuID):
                loadBagListOutboundSelection(valueList);
                break;
            case (filterTypeEnum.BagListNLBA === menuID):
                loadBagListNLBASelection(valueList);
                break;
            case (filterTypeEnum.FlightDetailsInBound === menuID):
                loadFlightInboundSelection(valueList);
                break;
            case (filterTypeEnum.FlightDetailsOutBound === menuID):
                loadFlightOutboundSelection(valueList);
                break;
            case (filterTypeEnum.BTRInBound === menuID):
                loadBTRInboundSelection(valueList);
                break;
            case (filterTypeEnum.BTROutBound === menuID):
                loadBTROutboundSelection(valueList);
                break;
            case (filterTypeEnum.ADPDBD === menuID):
                loadADPDashboardSelection(valueList);
                break;
            case (filterTypeEnum.ADPDBDLocal === menuID):
                loadADPLocalTransferSelection(valueList);
                break;
            case (filterTypeEnum.ADPSMR === menuID || filterTypeEnum.ADPDLR === menuID):
                loadADPDLRSMRSelection(valueList);
                break;
            case (filterTypeEnum.BJPDBD === menuID):
                loadBJPDBDSelection();
                break;
            case (filterTypeEnum.BJPSMR === menuID):
                loadBJPSMRSelection(valueList);
                break;
            case (filterTypeEnum.BJPDLR === menuID):
                loadBJPDLRSelection(valueList);
                break;
            case (filterTypeEnum.NLBDBD === menuID):
                loadNLBDashboardSelection(valueList);
                break;
            case (filterTypeEnum.NLBSMR === menuID):
                loadNLBSMRSelection(valueList);
                break;
            case (filterTypeEnum.DDPDBD === menuID):
                loadDDPDashboardSelection(valueList);
                break;
            case (filterTypeEnum.DDPSMR === menuID || filterTypeEnum.DDPDLR === menuID):
                loadDDPSMRDLRSelection(valueList);
                break;
            case (filterTypeEnum.BSMSMR === menuID):
                loadBSMSMRSelection(valueList);
                break;
            case (filterTypeEnum.ITTDBD === menuID):
                loadITTDBDSelection(valueList);
                break;
            case (filterTypeEnum.ITTDLR === menuID):
                loadITTDLRSelection(valueList);
                break;
            case (filterTypeEnum.MDRSMR === menuID):
                loadMDRSMRSelection(valueList);
                break;
            case (filterTypeEnum.MDRDLR === menuID):
                loadMDRDLRSelection(valueList);
                break;
            case (filterTypeEnum.ARRDBDNext === menuID || filterTypeEnum.ARRDBD === menuID):
                loadARRDBDSelection(valueList);
                break;
            case (filterTypeEnum.VOLSMR === menuID):
                loadVOLSMR(valueList);
                break;
            default:
                break;
        }
    };

    var loadValuesToControl = function (controlOrder, value) {
        switch (controlOrder) {
            case 1:
                ($('#dvSingleDate').is(':visible')) ? txtSingleDate.val(value) : txtMultiDate.val(value);
                break;
            case 2:
                setTimeSlicer(txtTimeBand, value);
                break;
            case 3:
                txtPaxName.val(value);
                break;
            case 4:
                txtBagTag.val(value);
                break;
            case 5:
                Utility.addValuesToMultiSelectDropDown(ddlNotLoaded, value);
                break;
            case 6:
                Utility.addValuesToMultiSelectDropDown(ddlNotLoadedSub, value);
                break;
            case 7:
                txtOutbndFlight.val(value);
                break;
            case 8:
                Utility.addValuesToMultiSelectDropDown(ddlOutbndAircraft, value);
                break;
            case 9:
                Utility.addValuesToMultiSelectDropDown(ddlDestination, value);
                break;
            case 10:
                Utility.addValuesToMultiSelectDropDown(ddlOutbndAirline, value);
                break;
            case 11:
                Utility.addValuesToMultiSelectDropDown(ddlOutbndHandler, value);
                break;
            case 12:
                Utility.addValuesToMultiSelectDropDown(ddlOutbndTerminal, value);
                break;
            case 13:
                txtInbndFlight.val(value);
                break;
            case 14:
                Utility.addValuesToMultiSelectDropDown(ddlInbndAirline, value);
                break;
            case 15:
                Utility.addValuesToMultiSelectDropDown(ddlInbndAircraft, value);
                break;
            case 16:
                Utility.addValuesToMultiSelectDropDown(ddlOrigin, value);
                break;
            case 17:
                Utility.addValuesToMultiSelectDropDown(ddlInbndhandler, value);
                break;
            case 18:
                Utility.addValuesToMultiSelectDropDown(ddlInbndTerminal, value);
                break;
            case 19:
                Utility.addValuesToMultiSelectDropDown(ddlLastLocation, value);
                break;
            case 20:
                Utility.addValuesToMultiSelectDropDown(ddlBagStatus, value);
                break;
            case 21:
                Utility.SetValuesToDropDown(ddlbagType, value);
                break;
            case 22:
                Utility.SetValuesToDropDown(ddlShort, value);
                break;
            case 23:
                Utility.SetValuesToDropDown(ddlOOGBags, value);
                break;
            case 24:
                Utility.SetValuesToDropDown(ddlchox, value);
                break;
            case 25:
                Utility.SetValuesToDropDown(ddlDeleteBags, value);
                break;
            case 26:
                Utility.SetValuesToDropDown(ddlBRSonly, value);
                break;
            case 27:
                Utility.SetValuesToDropDown(ddlDelBSM, value);
                break;
            case 28:
                Utility.SetValuesToDropDown(ddlBagList, value);
                break;
            case 29:
                Utility.addValuesToMultiSelectDropDown(ddlRoute, value);
                break;
            case 30:
                Utility.addValuesToMultiSelectDropDown(ddlProcessArea, value);
                break;
            case 30:
                Utility.addValuesToMultiSelectDropDown(ddlProcessArea, value);
                break;
            case 31:
                Utility.addValuesToMultiSelectDropDown(ddlBaggageSystem, value);
                break;
            case 32:
                setTimeSlicer(txtRouteStartTime, value);
                break;
            case 33:
                setTimeSlicer(txtRouteEndTime, value);
                break;
            case 34:
                Utility.SetValuesToDropDown(ddlInbndITO, value);
                break;
            case 35:
                Utility.SetValuesToDropDown(ddlInTarget, value);
                break;
            case 36:
                Utility.SetValuesToDropDown(ddlFailedMissed, value);
                break;
            case 37:
                Utility.addValuesToMultiSelectDropDown(ddlAtStart, value);
                break;
            case 38:
                Utility.addValuesToMultiSelectDropDown(ddlAtEnd, value);
                break;
            case 39:
                Utility.addValuesToMultiSelectDropDown(ddlFailedSystem, value);
                break;
            case 40:
                Utility.addValuesToMultiSelectDropDown(ddlselectMDStatus, value);
                break;
            default:
                break
        }
    };



    var loadFilterByUser = function (menuId) {
        url = '/Filter/GetFilterByMenuID';
        var actionResult = [];
        filterData = { MenuID: menuId, userID: 0 };
        var successCallBackHandler = function (data) {
            if (!Utility.isNullOrEmpty(data.result)) {
                actionResult = JSON.parse(data.result);
                filterID = actionResult.FilterID;

                if (actionResult.FilterInput != null) {
                    assignValuesToEntity(actionResult.FilterInput);
                    assignValuesToControls(actionResult.FilterInput, menuId)
                }
            }
        };


        var errorCallbackHandler = function (data) {
            // alert(data);
        }

        Utility.makeAjaxCall(url, Utility.RequestType.Get, filterData, successCallBackHandler, errorCallbackHandler);

    };

    var assignValuesToEntity = function (datasource) {

        date = (datasource.Date == null) ? moment().format('DD-MM-YYYY') : datasource.Date
        timeband = datasource.Timeband;
        paxSurname = datasource.PaxSurname;
        bagTag = datasource.BagTag;
        notLoadedCategory = datasource.NotLoadedCategory;
        notLoadedSubCategory = datasource.NotLoadedSubCategory;
        outboundFlight = datasource.OutboundFlight;
        outboundAircraft = datasource.OutboundAircraft;
        destination = datasource.Destination;
        outboundAirline = datasource.OutboundAirline;
        outboundHandler = datasource.OutboundHandler;
        outboundTerminal = datasource.OutboundTerminal;
        inboundFlight = datasource.InboundFlight;
        inboundAirline = datasource.InboundAirline;
        inboundAircraft = datasource.InboundAircraft;
        origin = datasource.Origin;
        inboundHandler = datasource.InboundHandler;
        inboundTerminal = datasource.InboundTerminal;
        lastSeenLocation = datasource.LastSeenLocation;
        bagStatus = datasource.BagStatus;
        bagTag = datasource.BagType;
        shortConnect = datasource.ShortConnect;
        oOGBags = datasource.OOGBags;
        seenAfterChox = datasource.SeenAfterChox;
        showDeletedBags = datasource.ShowDeletedBags;
        showMissedBRS = datasource.ShowMissedBRS;
        showDelBSMs = datasource.ShowDelBSMs;
        showMyBagList = datasource.ShowMyBagList;
        route = datasource.Route;
        processArea = datasource.ProcessArea;
        baggageSystem = datasource.BaggageSystem;
        routeStartTime = datasource.RouteStartTime;
        routeEndTime = datasource.RouteEndTime;
        inboundITO = datasource.InboundITO;
        inTarget = datasource.InTarget;
        failedThenMissed = datasource.FailedThenMissed;
        seenAtStart = datasource.SeenAtStart;
        seenAtEnd = datasource.SeenAtEnd;
        notLoadedCategory = datasource.NotLoadedFailedInSystem;
        mDStatusLocation = datasource.MDStatusLocation;

    };

    /**Load filter based on screen level **/

    var loadReportFilter = function (menuID, filterSource, isPinned) {

        if (date = '');
        date = moment().format('DD-MM-YYYY');
        switch (true) {
            case (filterTypeEnum.BagDetails === menuID):
                (!isPinned) ? loadBagDetailsFilter() : bagDetailSelection();
                break;
            case (filterTypeEnum.BagListInBound === menuID):
                (!isPinned) ? loadBagListInBoundFilter(filterSource) : bagListInboundSelection();
                break;
            case (filterTypeEnum.BagListGeneral === menuID):
                (!isPinned) ? loadBagListFilter(filterSource) : bagListSelection();
                break;
            case (filterTypeEnum.BagListOutBound === menuID):
                (!isPinned) ? loadBagListOutBoundFilter(filterSource) : bagListOutboundSelection();
                break;
            case (filterTypeEnum.BagListNLBA === menuID):
                (!isPinned) ? loadBagListNLBAFilter(filterSource) : bagListNLBASelection();
                break;
            case (filterTypeEnum.FlightDetailsInBound === menuID):
                (!isPinned) ? loadFlightDetailInBoundFilter() : flightInboundSelection();
                break;
            case (filterTypeEnum.FlightDetailsOutBound === menuID):
                (!isPinned) ? loadFlightDetailOutBoundFilter(filterSource) : flightOutboundSelection();
                break;
            case (filterTypeEnum.BTRInBound === menuID):
                (!isPinned) ? loadBTRInBoundFilter(filterSource) : BTRInboundSelection();
                break;
            case (filterTypeEnum.BTROutBound === menuID):
                (!isPinned) ? loadBTROutBoundFilter(filterSource) : BTROutboundSelection();
                break;
            case (filterTypeEnum.ADPDBD === menuID):
                (!isPinned) ? loadADPDashboardFilter(filterSource) : ADPDashboardSelection();
                break;
            case (filterTypeEnum.ADPDBDLocal === menuID):
                (!isPinned) ? loadADPDashboardLocalFilter(filterSource) : ADPLocalTransferSelection();
                break;
            case (filterTypeEnum.ADPSMR === menuID || filterTypeEnum.ADPDLR === menuID):
                (!isPinned) ? loadADPSMRFilter(filterSource) : ADPDLRSMRSelection();
                break;
            case (filterTypeEnum.BJPDBD === menuID):
                (!isPinned) ? loadBJPDashboardFilter() : BJPDBDSelection();
                break;
            case (filterTypeEnum.BJPSMR === menuID):
                (!isPinned) ? loadBJPSummaryFilter(filterSource) : BJPSMRSelection();
                break;
            case (filterTypeEnum.BJPDLR === menuID):
                (!isPinned) ? loadBJPDLRFilter(filterSource) : BJPDLRSelection();
                break;
            case (filterTypeEnum.NLBDBD === menuID):
                (!isPinned) ? loadNLBDBDFilter(filterSource) : NLBDashboardSelection();
                break;
            case (filterTypeEnum.NLBSMR === menuID):
                (!isPinned) ? loadNLBSMRFilter(filterSource) : NLBSMRSelection();
                break;
            case (filterTypeEnum.DDPDBD === menuID):
                (!isPinned) ? loadDDPDBDFilter(filterSource) : DDPDashboardSelection();
                break;
            case (filterTypeEnum.DDPSMR === menuID || filterTypeEnum.DDPDLR === menuID):
                (!isPinned) ? loadDDPSMRFilter(filterSource) : DDPSMRDLRSelection();
                break;
            case (filterTypeEnum.BSMSMR === menuID):
                (!isPinned) ? loadBSMSMRFilter(filterSource) : BSMSMRSelection();
                break;
            case (filterTypeEnum.ITTDBD === menuID):
                (!isPinned) ? loadITTDBDFilter(filterSource) : ITTDBDSelection();
                break;
            case (filterTypeEnum.ITTDLR === menuID):
                (!isPinned) ? loadITTDLRFilter(filterSource) : ITTDLRSelection();
                break;
            case (filterTypeEnum.MDRSMR === menuID):
                (!isPinned) ? loadMDRSMRFilter(filterSource) : MDRSMRSelection();
                break;
            case (filterTypeEnum.MDRDLR === menuID):
                (!isPinned) ? loadMDRDLRFilter(filterSource) : MDRDLRSelection();
                break;
            case (filterTypeEnum.ARRDBDNext === menuID || filterTypeEnum.ARRDBD === menuID):
                (!isPinned) ? loadARRDBDFilter(filterSource) : ARRDBDSelection();
                break;
            case (filterTypeEnum.VOLSMR === menuID):
                (!isPinned) ? loadVOLSMRFilter(filterSource) : VOLSMRSelection();
                break;
            default:
                // $("#dvButton,#dvMain").addClass("hidden");
                break;
        }
    };

    var loadFilterDropDown = function () {
        url = '/Filter/GetFilterData';
        var successCallback = function (data) {
            if (!Utility.isNullOrEmpty(data)) {
                filterResult = JSON.parse(data);
            }
        };
        var errorCallback = function (data) {
            errorMsg = data;
        }

        Utility.makeAjaxCallWithoutParameter(url, Utility.RequestType.Get, successCallback, errorCallback);
    };

    var fillAutoCompleteList = function (sourceList, valueList) {
        $.each(valueList, function (key, control) {
            sourceList.push(control.Text);
        });
    }


    /**Load filter selection based on page level **/

    var loadReportFilter = function (menuID, filterSource, isPinned) {
        //$("#dvButton,#dvMain").removeClass("hidden");
        //if (date = "");
        //date = moment().format("DD-MM-YYYY");
        switch (true) {
            case (filterTypeEnum.BagDetails === menuID):
                (!isPinned) ? loadBagDetailsFilter() : bagDetailSelection();
                break;
            case (filterTypeEnum.BagListInBound === menuID):
                (!isPinned) ? loadBagListInBoundFilter(filterSource) : bagListInboundSelection();
                break;
            case (filterTypeEnum.BagListGeneral === menuID):
                (!isPinned) ? loadBagListFilter(filterSource) : bagListSelection();
                break;
            case (filterTypeEnum.BagListOutBound === menuID):
                (!isPinned) ? loadBagListOutBoundFilter(filterSource) : bagListOutboundSelection();
                break;
            case (filterTypeEnum.BagListNLBA === menuID):
                (!isPinned) ? loadBagListNLBAFilter(filterSource) : bagListNLBASelection();
                break;
            case (filterTypeEnum.FlightDetailsInBound === menuID):
                (!isPinned) ? loadFlightDetailInBoundFilter() : flightInboundSelection();
                break;
            case (filterTypeEnum.FlightDetailsOutBound === menuID):
                (!isPinned) ? loadFlightDetailOutBoundFilter(filterSource) : flightOutboundSelection();
                break;
            case (filterTypeEnum.BTRInBound === menuID):
                (!isPinned) ? loadBTRInBoundFilter(filterSource) : BTRInboundSelection();
                break;
            case (filterTypeEnum.BTROutBound === menuID):
                (!isPinned) ? loadBTROutBoundFilter(filterSource) : BTROutboundSelection();
                break;
            case (filterTypeEnum.ADPDBD === menuID):
                (!isPinned) ? loadADPDashboardFilter(filterSource) : ADPDashboardSelection();
                break;
            case (filterTypeEnum.ADPDBDLocal === menuID):
                (!isPinned) ? loadADPDashboardLocalFilter(filterSource) : ADPLocalTransferSelection();
                break;
            case (filterTypeEnum.ADPSMR === menuID || filterTypeEnum.ADPDLR === menuID):
                (!isPinned) ? loadADPSMRFilter(filterSource) : ADPDLRSMRSelection();
                break;
            case (filterTypeEnum.BJPDBD === menuID):
                (!isPinned) ? loadBJPDashboardFilter() : BJPDBDSelection();
                break;
            case (filterTypeEnum.BJPSMR === menuID):
                (!isPinned) ? loadBJPSummaryFilter(filterSource) : BJPSMRSelection();
                break;
            case (filterTypeEnum.BJPDLR === menuID):
                (!isPinned) ? loadBJPDLRFilter(filterSource) : BJPDLRSelection();
                break;
            case (filterTypeEnum.NLBDBD === menuID):
                (!isPinned) ? loadNLBDBDFilter(filterSource) : NLBDashboardSelection();
                break;
            case (filterTypeEnum.NLBSMR === menuID):
                (!isPinned) ? loadNLBSMRFilter(filterSource) : NLBSMRSelection();
                break;
            case (filterTypeEnum.DDPDBD === menuID):
                (!isPinned) ? loadDDPDBDFilter(filterSource) : DDPDashboardSelection();
                break;
            case (filterTypeEnum.DDPSMR === menuID || filterTypeEnum.DDPDLR === menuID):
                (!isPinned) ? loadDDPSMRFilter(filterSource) : DDPSMRDLRSelection();
                break;
            case (filterTypeEnum.BSMSMR === menuID):
                (!isPinned) ? loadBSMSMRFilter(filterSource) : BSMSMRSelection();
                break;
            case (filterTypeEnum.ITTDBD === menuID):
                (!isPinned) ? loadITTDBDFilter(filterSource) : ITTDBDSelection();
                break;
            case (filterTypeEnum.ITTDLR === menuID):
                (!isPinned) ? loadITTDLRFilter(filterSource) : ITTDLRSelection();
                break;
            case (filterTypeEnum.MDRSMR === menuID):
                (!isPinned) ? loadMDRSMRFilter(filterSource) : MDRSMRSelection();
                break;
            case (filterTypeEnum.MDRDLR === menuID):
                (!isPinned) ? loadMDRDLRFilter(filterSource) : MDRDLRSelection();
                break;
            case (filterTypeEnum.ARRDBDNext === menuID || filterTypeEnum.ARRDBD === menuID):
                (!isPinned) ? loadARRDBDFilter(filterSource) : ARRDBDSelection();
                break;
            case (filterTypeEnum.VOLSMR === menuID):
                (!isPinned) ? loadVOLSMRFilter(filterSource) : VOLSMRSelection();
                break;
            default:
                //  $("#dvButton,#dvMain").addClass("hidden");
                break;
        }
    };


    var fillFilterValuesToLocalVariable = function () {
        date = ($('#dvMultiDate').is(':visible')) ? $('#txtMultiDate').val() : $('#txtSingleDate').val();
        timeband = ($('#dvTimeBand').is(':visible')) ? $('#txtTimeBand').val() : '';
        bagTag = ($('#dvBagTag').is(':visible')) ? $('#txtBagTag').val() : '';
        paxSurname = ($('#dvPaxName').is(':visible')) ? $('#txtPaxName').val() : '';
        notLoadedCategory = ($('#dvNotLoaded').is(':visible')) ? $('#selectNotLoaded option:selected').toArray().map(optionSelected).join('') : '';
        notLoadedSubCategory = ($('#dvNotLoadedSub').is(':visible')) ? $('#selectNotLoadedSub option:selected').toArray().map(optionSelected).join('') : '';
        outboundFlight = ($('#dvOutbndFlight').is(':visible')) ? $('#txtOutbndFlight').val() : '';
        outboundAircraft = ($('#dvOutbndAircraft').is(':visible')) ? $('#selectOutbndAircraft option:selected').toArray().map(optionSelected).join('') : '';
        outboundAirline = ($('#dvOutbndAirline').is(':visible')) ? $('#selectOutbndAirline option:selected').toArray().map(optionSelected).join('') : '';
        destination = ($('#dvDestination').is(':visible')) ? $('#selectDestination option:selected').toArray().map(optionSelected).join('') : '';
        outboundHandler = ($('#dvOutbndHandler').is(':visible')) ? $('#selectOutbndHandler option:selected').toArray().map(optionSelected).join('') : '';
        outboundTerminal = ($('#dvOutbndTerminal').is(':visible')) ? $('#selectOutbndTerminal option:selected').toArray().map(optionSelected).join() : '';
        inboundFlight = ($('#dvInbndFlight').is(':visible')) ? $('#txtInbndFlight').val() : '';
        inboundAirline = ($('#dvInbndAirline').is(':visible')) ? $('#selectInbndAirline option:selected').toArray().map(optionSelected).join() : '';
        inboundAircraft = ($('#dvInbndAircraft').is(':visible')) ? $('#selectInbndAircraft option:selected').toArray().map(optionSelected).join() : '';
        origin = ($('#dvOrigin').is(':visible')) ? $('#selectOrigin option:selected').toArray().map(optionSelected).join() : '';
        inboundHandler = ($('#dvInbndhandler').is(':visible')) ? $('#selectInbndhandler option:selected').toArray().map(optionSelected).join() : '';
        inboundTerminal = ($('#dvInbndTerminal').is(':visible')) ? $('#selectInbndTerminal option:selected').toArray().map(optionSelected).join() : '';
        lastSeenLocation = ($('#dvLastLocation').is(':visible')) ? $('#selectLastLocation option:selected').toArray().map(optionSelected).join() : '';
        bagStatus = ($('#dvBagStatus').is(':visible')) ? $('#selectBagStatus option:selected').toArray().map(optionSelected).join() : '';
        bagType = ($('#dvBagType').is(':visible')) ? $('#selectBagType + span').children('input')[0].value : '';
        shortConnect = ($('#dvShortConnect').is(':visible')) ? $('#selectShortConnect + span').children('input')[0].value : '';
        oOGBags = ($('#dvOOGBags').is(':visible')) ? $('#selectOOGBags  + span').children('input')[0].value : '';
        seenAfterChox = ($('#dvchox').is(':visible')) ? $('#selectchox + span').children('input')[0].value : '';
        showDeletedBags = ($('#dvDeleteBags').is(':visible')) ? $('#selectDeleteBags  + span').children('input')[0].value : '';
        showMissedBRS = ($('#dvBRSonly').is(':visible')) ? $('#selectBRSonly  + span').children('input')[0].value : '';
        showDelBSMs = ($('#dvDelBSM').is(':visible')) ? $('#selectDelBSM  + span').children('input')[0].value : '';
        showMyBagList = ($('#dvBagList').is(':visible')) ? $('#selectBagList  + span').children('input')[0].value : '';
        route = $('#dvRoute').is(':visible') ? $('#selectRoute option:selected').toArray().map(optionSelected).join() : '';
        processArea = ($('#dvProcessArea').is(':visible')) ? $('#selectProcessArea option:selected').toArray().map(optionSelected).join() : '';
        baggageSystem = ($('#dvBaggageSystem').is(':visible')) ? $('#selectBaggageSystem option:selected').toArray().map(optionSelected).join() : '';
        routeStartTime = ($('#dvRouteStartTime').is(':visible')) ? $('#txtRouteStartTime').val() : '';
        routeEndTime = ($('#dvRouteEndTime').is(':visible')) ? $('#txtRouteEndTime').val() : '';
        inboundITO = ($('#dvInbndITO').is(':visible')) ? $('#selectInbndITO  + span').children('input')[0].value : '';
        inTarget = ($('#dvInTarget').is(':visible')) ? $('#selectInTarget + span').children('input')[0].value : '';
        failedThenMissed = ($('#dvFailedMissed').is(':visible')) ? $('#selectFailedMissed  + span').children('input')[0].value : '';
        seenAtStart = ($('#dvAtStart').is(':visible')) ? $('#selectAtStart option:selected').toArray().map(optionSelected).join() : '';
        seenAtEnd = ($('#dvAtEnd').is(':visible')) ? $('#selectAtEnd option:selected').toArray().map(optionSelected).join() : '';
        notLoadedFailedInSystem = ($('#dvFailedSystem').is(':visible')) ? $('#selectFailedSystem  + span').children('input')[0].value : '';
        mDStatusLocation = ($('#dvMDStatus').is(':visible')) ? $('#selectMDStatus option:selected').toArray().map(optionSelected).join() : '';

    };

    function optionSelected(item) {
        return [item.value];
    }

    /** Bag Details -  Screen filter **/

    var bagDetailSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, BagTag: bagTag
            };
    };

    var loadbagDetailFilterSelection = function (datasource) {
        txtMultiDate.val(date);
        txtBagTag.val(datasource.BagTag);
    };

    /** Bag List - General Screen filter **/
    var bagListSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, BagTag: bagTag, PaxSurname: paxSurname, OutboundFlight: outboundFlight, OutboundTerminal: outboundTerminal,
                Destination: destination, OutboundAirline: outboundAirline, OutboundHandler: outboundHandler,
                InboundFlight: inboundFlight, InboundAirline: inboundAirline, InboundAircraft: inboundAircraft, Origin: origin,
                InboundHandler: inboundHandler, InboundTerminal: inboundTerminal, LastSeenLocation: lastSeenLocation,
                BagStatus: bagStatus, BagType: bagType, ShortConnect: shortConnect, OOGBags: oOGBags, SeenAfterChox: seenAfterChox,
                ShowDeletedBags: showDeletedBags, ShowMissedBRS: showMissedBRS, ShowMyBagList: showMyBagList
            };
    };

    var loadBagListFilterSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.PaxSurname, datasource.PaxSurname);
        loadValuesToControl(FilterControlEnum.BagTag, datasource.BagTag);
        loadValuesToControl(FilterControlEnum.OutboundFlight, datasource.OutboundFlight);
        //loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        //loadValuesToControl(FilterControlEnum.Destination, datasource.Destination);
        //loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        //loadValuesToControl(FilterControlEnum.OutboundHandler, datasource.OutboundHandler);
        //loadValuesToControl(FilterControlEnum.InboundFlight, datasource.InboundFlight);
        //loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
        //loadValuesToControl(FilterControlEnum.LastSeenLocation, datasource.LastSeenLocation);
        //loadValuesToControl(FilterControlEnum.BagStatus, datasource.BagStatus);
        //loadValuesToControl(FilterControlEnum.BagType, datasource.BagType);
        //loadValuesToControl(FilterControlEnum.ShortConnect, datasource.ShortConnect);
        //loadValuesToControl(FilterControlEnum.OOGBags, datasource.OOGBags);
        //loadValuesToControl(FilterControlEnum.SeenAfterChox, datasource.SeenAfterChox);
        //loadValuesToControl(FilterControlEnum.ShowDeletedBags, datasource.ShowDeletedBags);
        //loadValuesToControl(FilterControlEnum.ShowMissedBRS, datasource.ShowMissedBRS);
        //loadValuesToControl(FilterControlEnum.ShowMyBagList, datasource.ShowMyBagList);
    };


    /** Bag List - Inbound Screen filter **/
    var bagListInboundSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, BagTag: bagTag, OutboundFlight: outboundFlight, OutboundAirline: outboundAirline, OutboundTerminal: outboundTerminal,
                InboundFlight: inboundFlight, InboundAirline: inboundAirline, InboundAircraft: inboundAircraft,
                InboundHandler: inboundHandler, InboundTerminal: inboundTerminal, LastSeenLocation: lastSeenLocation,
                BagStatus: bagStatus, BagType: bagType, ShortConnect: shortConnect, OOGBags: oOGBags,
                ShowDeletedBags: showDeletedBags, ShowMyBagList: showMyBagList
            };
    };

    var loadBagListInboundSelection = function () {

        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.BagTag, datasource.BagTag);
        loadValuesToControl(FilterControlEnum.OutboundFlight, datasource.OutboundFlight);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.OutboundHandler, datasource.OutboundHandler);
        loadValuesToControl(FilterControlEnum.InboundFlight, datasource.InboundFlight);
        loadValuesToControl(FilterControlEnum.InboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
        loadValuesToControl(FilterControlEnum.InboundAircraft, datasource.InboundAircraft);
        loadValuesToControl(FilterControlEnum.LastSeenLocation, datasource.LastSeenLocation);
        loadValuesToControl(FilterControlEnum.BagStatus, datasource.BagStatus);
        loadValuesToControl(FilterControlEnum.BagType, datasource.BagType);
        loadValuesToControl(FilterControlEnum.ShortConnect, datasource.ShortConnect);
        loadValuesToControl(FilterControlEnum.OOGBags, datasource.OOGBags);
        loadValuesToControl(FilterControlEnum.ShowDeletedBags, datasource.ShowDeletedBags);
        loadValuesToControl(FilterControlEnum.ShowMyBagList, datasource.ShowMyBagList);
    };

    /** Bag List - Out bound Screen filter **/
    var bagListOutboundSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, BagTag: bagTag, OutboundFlight: outboundFlight, OutboundAircraft: outboundAircraft,
                OutboundAirline: outboundAirline, OutboundHandler: outboundHandler, OutboundTerminal: outboundTerminal,
                InboundFlight: inboundFlight, InboundAirline: inboundAirline, InboundTerminal: inboundTerminal, LastSeenLocation: lastSeenLocation,
                BagStatus: bagStatus, BagType: bagType, ShortConnect: shortConnect, OOGBags: oOGBags, SeenAfterChox: seenAfterChox,
                ShowDeletedBags: showDeletedBags, ShowMyBagList: showMyBagList
            };
    };

    var loadBagListOutboundSelection = function (datasource) {

        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.BagTag, datasource.BagTag);
        loadValuesToControl(FilterControlEnum.OutboundFlight, datasource.OutboundFlight);
        loadValuesToControl(FilterControlEnum.OutboundAircraft, datasource.OutboundAircraft);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.OutboundHandler, datasource.OutboundHandler);
        loadValuesToControl(FilterControlEnum.InboundFlight, datasource.InboundFlight);
        loadValuesToControl(FilterControlEnum.InboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
        loadValuesToControl(FilterControlEnum.LastSeenLocation, datasource.LastSeenLocation);
        loadValuesToControl(FilterControlEnum.BagStatus, datasource.BagStatus);
        loadValuesToControl(FilterControlEnum.BagType, datasource.BagType);
        loadValuesToControl(FilterControlEnum.ShortConnect, datasource.ShortConnect);
        loadValuesToControl(FilterControlEnum.OOGBags, datasource.OOGBags);
        loadValuesToControl(FilterControlEnum.SeenAfterChox, datasource.SeenAfterChox);
        loadValuesToControl(FilterControlEnum.ShowDeletedBags, datasource.ShowDeletedBags);
        loadValuesToControl(FilterControlEnum.ShowMyBagList, datasource.ShowMyBagList);
    };

    /** Bag List - NLBA Screen filter **/
    var bagListNLBASelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, BagTag: bagTag, NotLoadedCategory: notLoadedCategory, NotLoadedSubCategory: notLoadedSubCategory, OutboundFlight: outboundFlight,
                OutboundAirline: outboundAirline, OutboundHandler: outboundHandler, OutboundTerminal: outboundTerminal,
                InboundFlight: inboundFlight, InboundAirline: inboundAirline, InboundHandler: inboundHandler, InboundTerminal: inboundTerminal,
                LastSeenLocation: lastSeenLocation, BagType: bagType, ShortConnect: shortConnect, SeenAfterChox: seenAfterChox,
                ShowDelBSMs: showDelBSMs, ShowMyBagList: showMyBagList, Route: route, ProcessArea: processArea, BaggageSystem: baggageSystem
            };
    };

    var loadBagListNLBASelection = function (datasource) {

        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.BagTag, datasource.BagTag);
        loadValuesToControl(FilterControlEnum.NotLoadedCategory, datasource.NotLoadedCategory);
        loadValuesToControl(FilterControlEnum.NotLoadedSubCategory, datasource.NotLoadedSubCategory);
        loadValuesToControl(FilterControlEnum.OutboundFlight, datasource.OutboundFlight);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.OutboundHandler, datasource.OutboundHandler);
        loadValuesToControl(FilterControlEnum.InboundFlight, datasource.InboundFlight);
        loadValuesToControl(FilterControlEnum.InboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
        loadValuesToControl(FilterControlEnum.LastSeenLocation, datasource.LastSeenLocation);
        loadValuesToControl(FilterControlEnum.BagStatus, datasource.BagStatus);
        loadValuesToControl(FilterControlEnum.BagType, datasource.BagType);
        loadValuesToControl(FilterControlEnum.ShortConnect, datasource.ShortConnect);
        loadValuesToControl(FilterControlEnum.OOGBags, datasource.OOGBags);
        loadValuesToControl(FilterControlEnum.SeenAfterChox, datasource.SeenAfterChox);
        loadValuesToControl(FilterControlEnum.ShowDelBSMs, datasource.ShowDelBSMs);
        loadValuesToControl(FilterControlEnum.ShowMyBagList, datasource.ShowMyBagList);
        loadValuesToControl(FilterControlEnum.Route, datasource.processArea);
        loadValuesToControl(FilterControlEnum.BaggageSystem, datasource.BaggageSystem);
        loadValuesToControl(FilterControlEnum.ProcessArea, datasource.ProcessArea);
    };


    /**  Baglist Dashboard Screen filter **/

    var bagListDBDSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, BagTag: bagTag
            };
    };

    var loadBagListDBDSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.BagTag, datasource.BagTag);
    };

    /**  Flight Details - Inbound Screen filter **/
    var flightInboundSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, InboundFlight: inboundFlight
            };
    };

    var loadFlightInboundSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.InboundFlight, datasource.InboundFlight);
    };

    /**  Flight Details - Outbound Screen opearational/Biz screen filter **/
    var flightOutboundSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, OutboundFlight: outboundFlight
            };
    };

    var loadFlightOutboundSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.OutboundFlight, datasource.OutboundFlight);
    };

    /**     BTR - Inbound- Screen filter **/
    var BTRInboundSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, Timeband: timeband, InboundAirline: inboundAirline, InboundHandler: inboundHandler,
                InboundTerminal: inboundTerminal, BagStatus: bagStatus, InboundAircraft: inboundAircraft,
            };
    };

    var loadBTRInboundSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.Timeband, datasource.Timeband);
        loadValuesToControl(FilterControlEnum.InboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundHandler, datasource.InboundHandler);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
        loadValuesToControl(FilterControlEnum.BagStatus, datasource.BagStatus);
        loadValuesToControl(FilterControlEnum.InboundAircraft, datasource.InboundAircraft);
    };

    /**     BTR - outBound- Screen filter **/
    var BTROutboundSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, Timeband: timeband, OutboundAirline: outboundAirline, OutboundHandler: outboundHandler,
                OutboundTerminal: outboundTerminal, BagStatus: bagStatus, OutboundAircraft: outboundAircraft
            };
    };

    var loadBTROutboundSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.Timeband, datasource.Timeband);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.OutboundHandler, datasource.OutboundHandler);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.BagStatus, datasource.BagStatus);
        loadValuesToControl(FilterControlEnum.OutboundAircraft, datasource.OutboundAircraft);
    };

    /**    ADP - Dashboard Screen filter **/
    var ADPDashboardSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, InboundFlight: inboundFlight, InboundAirline: inboundAirline, InboundHandler: inboundHandler, InboundTerminal: inboundTerminal
            };
    };

    var loadADPDashboardSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.InboundFlight, datasource.InboundFlight);
        loadValuesToControl(FilterControlEnum.InboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundHandler, datasource.InboundHandler);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
    };

    /**     ADP - DBD - Local/Transfer Screen filter **/ //ADP DBD  local and transfer screen
    var ADPLocalTransferSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, Timeband: timeband, InboundFlight: inboundFlight, InboundAirline: inboundAirline, InboundHandler: inboundHandler, InboundTerminal: inboundTerminal
            };
    };

    var loadADPLocalTransferSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.Timeband, datasource.Timeband);
        loadValuesToControl(FilterControlEnum.InboundFlight, datasource.InboundFlight);
        loadValuesToControl(FilterControlEnum.InboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundHandler, datasource.InboundHandler);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
    };


    /**   ADP-Summary and  ADP-DLR Screen filter **/  // both  ADP details & summary screen
    var ADPDLRSMRSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, InboundFlight: inboundFlight, InboundAirline: inboundAirline, InboundAircraft: inboundAircraft,
                InboundHandler: inboundHandler, InboundTerminal: inboundTerminal
            };
    };


    /**   ADP-Summary and  ADP-DLR Screen filter **/  // both  ADP details & summary screen
    var loadADPDLRSMRSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.InboundFlight, datasource.InboundFlight);
        loadValuesToControl(FilterControlEnum.InboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundAircraft, datasource.InboundAircraft);
        loadValuesToControl(FilterControlEnum.InboundHandler, datasource.InboundHandler);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
    };


    /**    BJP - Dashboard Screen filter **/
    var BJPDBDSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date
            };
    };


    var loadBJPDBDSelection = function () {
        loadValuesToControl(FilterControlEnum.Date, date);
    };

    /**   BJP - Summary- Screen filter **/
    var BJPSMRSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, InboundTerminal: inboundTerminal, OutboundTerminal: outboundTerminal, Route: route,
                ProcessArea: processArea, BaggageSystem: baggageSystem, OOGBags: oOGBags
            };
    };

    var loadBJPSMRSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.Route, datasource.Route);
        loadValuesToControl(FilterControlEnum.ProcessArea, datasource.ProcessArea);
        loadValuesToControl(FilterControlEnum.BaggageSystem, datasource.BaggageSystem);
        loadValuesToControl(FilterControlEnum.OOGBags, datasource.OOGBags);
    };

    /**   BJP - Details - Screen filter **/
    var BJPDLRSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, InboundTerminal: inboundTerminal, OutboundTerminal: outboundTerminal, RouteStartTime: routeStartTime, OOGBags: oOGBags,
                RouteEndTime: routeEndTime, ProcessArea: processArea, BaggageSystem: baggageSystem, NotLoadedFailedInSystem: notLoadedFailedInSystem
            };
    };

    var loadBJPDLRSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.RouteStartTime, datasource.RouteStartTime);
        loadValuesToControl(FilterControlEnum.RouteEndTime, datasource.RouteEndTime);
        loadValuesToControl(FilterControlEnum.OOGBags, datasource.OOGBags);
        loadValuesToControl(FilterControlEnum.ProcessArea, datasource.ProcessArea);
        loadValuesToControl(FilterControlEnum.BaggageSystem, datasource.BaggageSystem);
        loadValuesToControl(FilterControlEnum.NotLoadedFailedInSystem, datasource.NotLoadedFailedInSystem);
    };


    /**    NLB - Dashboard Screen filter **/
    var NLBDashboardSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, Timeband: timeband, OutboundAirline: outboundAirline, OutboundHandler: outboundHandler, OutboundTerminal: outboundTerminal, InboundFlight: inboundFlight, InboundAirline: inboundAirline
            };
    };


    var loadNLBDashboardSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.Timeband, datasource.Timeband);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.OutboundHandler, datasource.OutboundHandler);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.InboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundFlight, datasource.InboundFlight);
    };

    /**   NLB-SMR Screen filter **/
    var NLBSMRSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, OutboundAirline: outboundAirline, OutboundHandler: outboundHandler, OutboundTerminal: outboundTerminal,
                InboundFlight: inboundFlight, InboundAirline: inboundAirline, InboundTerminal: inboundTerminal
            };
    };

    var loadNLBSMRSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.OutboundHandler, datasource.OutboundHandler);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.InboundFlight, datasource.InboundFlight);
        loadValuesToControl(FilterControlEnum.InboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);

    };

    /**    DDP - DBD Screen filter **/

    var DDPDashboardSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, Timeband: timeband, OutboundAirline: outboundAirline, OutboundHandler: outboundHandler, OutboundTerminal: outboundTerminal,
                OutboundFlight: outboundFlight
            };
    };

    var loadDDPDashboardSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.Timeband, datasource.Timeband);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.OutboundHandler, datasource.OutboundHandler);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.OutboundFlight, datasource.OutboundFlight);

    };

    /**    DDP - SMR  and DDP-DLR Screen filter **/  //The same filter config will apply both screen.
    var DDPSMRDLRSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, OutboundFlight: outboundFlight, OutboundAircraft: outboundAircraft,
                OutboundAirline: outboundAirline, OutboundHandler: outboundHandler, OutboundTerminal: outboundTerminal,
            };
    };

    var loadDDPSMRDLRSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.OutboundFlight, datasource.OutboundFlight);
        loadValuesToControl(FilterControlEnum.OutboundAircraft, datasource.OutboundAircraft);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
    };

    /**    BSM-SMR Screen filter **/

    var BSMSMRSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, OutboundFlight: outboundFlight, OutboundAirline: outboundAirline, OutboundHandler: outboundHandler,
                InboundFlight: inboundFlight, InboundAirline: inboundAirline, InboundHandler: inboundHandler
            };
    };

    var loadBSMSMRSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.OutboundFlight, datasource.OutboundFlight);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.OutboundHandler, datasource.OutboundHandler);
        loadValuesToControl(FilterControlEnum.InboundFlight, datasource.InboundFlight);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundHandler, datasource.InboundHandler);
    };

    /**   ITT-DBD Screen filter **/

    var ITTDBDSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, OutboundTerminal: outboundTerminal, InboundTerminal: inboundTerminal, InboundITO: inboundITO

            };
    };
    var loadITTDBDSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
        loadValuesToControl(FilterControlEnum.InboundITO, datasource.InboundITO);
    };
    /**   ITT-DLR Screen filter **/

    var ITTDLRSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, OutboundAirline: outboundAirline, OutboundHandler: outboundHandler, OutboundTerminal: outboundTerminal,
                InboundAirline: inboundAirline, InboundTerminal: inboundTerminal, InboundITO: inboundITO, InTarget: inTarget,
                FailedThenMissed: failedThenMissed, SeenAtStart: seenAtStart, SeenAtEnd: seenAtEnd
            };
    };

    var loadITTDLRSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.OutboundHandler, datasource.OutboundHandler);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.InboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
        loadValuesToControl(FilterControlEnum.InboundITO, datasource.InboundITO);
        loadValuesToControl(FilterControlEnum.InTarget, datasource.InTarget);
        loadValuesToControl(FilterControlEnum.FailedThenMissed, datasource.FailedThenMissed);
        loadValuesToControl(FilterControlEnum.SeenAtStart, datasource.SeenAtStart);
        loadValuesToControl(FilterControlEnum.SeenAtStart, datasource.SeenAtEnd);
    };

    /**    MDR-SMR Screen filter **/

    var MDRSMRSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, OutboundAirline: outboundAirline, OutboundHandler: outboundHandler, OutboundTerminal: outboundTerminal,
                InboundAirline: inboundAirline, InboundTerminal: inboundTerminal, InboundHandler: inboundHandler, LastSeenLocation: lastSeenLocation
            };
    };

    var loadMDRSMRSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.OutboundHandler, datasource.OutboundHandler);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.InboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
        loadValuesToControl(FilterControlEnum.InboundHandler, datasource.InboundHandler);
        loadValuesToControl(FilterControlEnum.LastSeenLocation, datasource.LastSeenLocation);
    };

    /**  MDR-DLR Screen filter **/

    var MDRDLRSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, OutboundAirline: outboundAirline, OutboundHandler: outboundHandler, OutboundTerminal: outboundTerminal,
                InboundAirline: inboundAirline, InboundTerminal: inboundTerminal, InboundHandler: inboundHandler, MDStatusLocation: mDStatusLocation
            };
    };

    var loadMDRDLRSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.OutboundHandler, datasource.OutboundHandler);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.InboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
        loadValuesToControl(FilterControlEnum.InboundHandler, datasource.InboundHandler);
        loadValuesToControl(FilterControlEnum.MDStatusLocation, datasource.MDStatusLocation);
    };

    /**   ARR-DBD-Next & ARR-DBD Screen filter - both screen will apply **/

    var ARRDBDSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, InboundAirline: inboundAirline, InboundFlight: inboundFlight, Origin: origin,
                InboundTerminal: inboundTerminal, InboundHandler: inboundHandler
            };
    };
    var loadARRDBDSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.InboundFlight, datasource.InboundFlight);
        loadValuesToControl(FilterControlEnum.InboundAirline, datasource.InboundAirline);
        loadValuesToControl(FilterControlEnum.InboundTerminal, datasource.InboundTerminal);
        loadValuesToControl(FilterControlEnum.InboundHandler, datasource.InboundHandler);
        loadValuesToControl(FilterControlEnum.Origin, datasource.Origin);
    };

    /**   VOL SMR Screen filter **/

    var VOLSMRSelection = function () {
        userFilterselection = [];

        userFilterselection =
            {
                Date: date, OutboundAirline: outboundAirline, OutboundTerminal: outboundTerminal, OutboundHandler: outboundHandler
            };
    };
    var loadVOLSMRSelection = function (datasource) {
        loadValuesToControl(FilterControlEnum.Date, date);
        loadValuesToControl(FilterControlEnum.OutboundAirline, datasource.OutboundAirline);
        loadValuesToControl(FilterControlEnum.OutboundTerminal, datasource.OutboundTerminal);
        loadValuesToControl(FilterControlEnum.OutboundHandler, datasource.OutboundHandler);
    };

    // #region ShowHideFilterControl

    /** Bag List - General Screen filter **/
    var loadBagListFilter = function (filterResult) {

        $('#dvSingleDate,#dvTimeBand,#dvNotLoaded,#dvNotLoadedSub,#dvOutbndAircraft,#dvRoute').addClass('hidden');
        $('#dvProcessArea,#dvBaggageSystem,#dvRouteStartTime,#dvRouteEndTime,#dvInbndITO,#dvInTarget').addClass('hidden');
        $('#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus,#dvDelBSM').addClass('hidden');

        $('#dvMultiDate,#dvBagTag,#dvPaxName,#dvOutbndFlight,#dvDestination,#dvOutbndAirline,#dvOutbndHandler,#dvOutbndTerminal').removeClass('hidden');
        $('#dvInbndFlight,#dvInbndAirline,#dvInbndAircraft,#dvOrigin,#dvInbndhandler,#dvInbndTerminal,#dvLastLocation').removeClass('hidden');
        $('#dvBagStatus,#dvBagType,#dvShortConnect,#dvOOGBags,#dvchox,#dvDeleteBags,#dvBRSonly,#dvBagList').removeClass('hidden');

        // auto complete - dvBagTag,dvPaxName,dvOutbndFlight,dvInbndFlight
        Utility.bindMultiDropDown(ddlDestination, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndHandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);

        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndAircraft, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOrigin, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndhandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlLastLocation, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlBagStatus, filterResult.BagSystemList);

        Utility.addValuesToDropDown(ddlbagType, filterResult.BagTypeList);
        Utility.addValuesToDropDown(ddlShort, filterResult.BagSystemList);
        Utility.addValuesToDropDown(ddlOOGBags, filterResult.OOGBagsList);
        Utility.addValuesToDropDown(ddlchox, filterResult.AfterChoxList);
        Utility.addValuesToDropDown(ddlDeleteBags, filterResult.DeletedBagsList);
        Utility.addValuesToDropDown(ddlBRSonly, filterResult.MissedBRSList);
        Utility.addValuesToDropDown(ddlDelBSM, filterResult.DeletedBSMList);
        Utility.addValuesToDropDown(ddlBagList, filterResult.MyBagList);
    };

    /** Bag List - Inbound Screen filter **/
    var loadBagListInBoundFilter = function (filterResult) {

        $('#dvMultiDate,#dvTimeBand,#dvPaxName,#dvNotLoaded,#dvNotLoadedSub,#dvOutbndAircraft,#dvDestination').addClass('hidden');
        $('#dvOutbndHandler,#dvOrigin,#dvchox,#dvBRSonly,#dvDelBSM,#dvRoute,#dvProcessArea,#dvBaggageSystem,#dvRouteStartTime').addClass('hidden');
        $('#dvRouteEndTime,#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus').addClass('hidden');

        $('#dvSingleDate,#dvBagTag,#dvOutbndFlight,#dvOutbndAirline,#dvOutbndTerminal,#dvInbndFlight').removeClass('hidden');
        $('#dvInbndAirline,#dvInbndAircraft,#dvInbndhandler,#dvInbndTerminal,#dvLastLocation').removeClass('hidden');
        $('#dvBagStatus,#dvBagType,#dvShortConnect,#dvOOGBags,#dvDeleteBags,#dvBagList').removeClass('hidden');

        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndAircraft, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndhandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlLastLocation, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlBagStatus, filterResult.BagSystemList);

        Utility.addValuesToDropDown(ddlbagType, filterResult.BagTypeList);
        Utility.addValuesToDropDown(ddlShort, filterResult.BagSystemList);
        Utility.addValuesToDropDown(ddlOOGBags, filterResult.OOGBagsList);
        Utility.addValuesToDropDown(ddlDeleteBags, filterResult.DeletedBagsList);
        Utility.addValuesToDropDown(ddlBagList, filterResult.MyBagList);
    };

    /** Bag List - Out bound Screen filter **/
    var loadBagListOutBoundFilter = function (filterResult) {

        $('#dvMultiDate,#dvTimeBand,#dvPaxName,#dvNotLoaded,#dvNotLoadedSub,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvInbndhandler,#dvInbndTerminal,#dvchox,#dvBRSonly,#dvDelBSM,#dvRoute,#dvProcessArea,#dvBaggageSystem,#dvRouteStartTime').addClass('hidden');
        $('#dvRouteEndTime,#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus').addClass('hidden');

        $('#dvSingleDate,#dvBagTag,#dvOutbndFlight,#dvOutbndAircraft,#dvOutbndAirline,#dvOutbndHandler').removeClass('hidden');
        $('#dvOutbndTerminal,#dvInbndFlight,#dvInbndAirline,#dvLastLocation').removeClass('hidden');
        $('#dvBagStatus,#dvBagType,#dvShortConnect,#dvOOGBags,#dvDeleteBags,#dvBagList').removeClass('hidden');

        //outboundflight
        Utility.bindMultiDropDown(ddlOutbndAircraft, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlBagStatus, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndHandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlLastLocation, filterResult.BagSystemList);

        Utility.addValuesToDropDown(ddlbagType, filterResult.BagTypeList);
        Utility.addValuesToDropDown(ddlShort, filterResult.BagSystemList);
        Utility.addValuesToDropDown(ddlOOGBags, filterResult.OOGBagsList);
        Utility.addValuesToDropDown(ddlDeleteBags, filterResult.DeletedBagsList);
        Utility.addValuesToDropDown(ddlBagList, filterResult.MyBagList);
    };

    /** Bag List - NLBA Screen filter **/
    var loadBagListNLBAFilter = function (filterResult) {

        $('#dvSingleDate,#dvTimeBand,#dvPaxName,#dvOutbndAircraft,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvDeleteBags,#dvBRSonly,#dvRouteStartTime,#dvRouteEndTime').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus').addClass('hidden');

        $('#dvMultiDate,#dvBagTag,#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvOutbndAirline,#dvOutbndHandler').removeClass('hidden');
        $('#dvOutbndTerminal,#dvInbndFlight,#dvInbndAirline,#dvInbndhandler,#dvInbndTerminal,#dvLastLocation').removeClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList,#dvRoute,#dvProcessArea,#dvBaggageSystem').removeClass('hidden');

        Utility.bindMultiDropDown(ddlNotLoaded, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlNotLoadedSub, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndHandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);

    };

    /**  Bag Details Screen filter **/
    var loadBagDetailsFilter = function () {

        $('#dvMultiDate,#dvTimeBand,#dvPaxName,#dvOutbndAircraft,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvDeleteBags,#dvBRSonly,#dvRouteStartTime,#dvRouteEndTime').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvOutbndAirline,#dvOutbndHandler').addClass('hidden');
        $('#dvOutbndTerminal,#dvInbndFlight,#dvInbndAirline,#dvInbndhandler,#dvInbndTerminal,#dvLastLocation').addClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList,#dvRoute,#dvProcessArea,#dvBaggageSystem').addClass('hidden');

        $('#dvSingleDate,#dvBagTag').removeClass('hidden');
        //bagtag

    };

    /**  Flight Details - Inbound Screen filter **/
    var loadFlightDetailInBoundFilter = function () {

        $('#dvMultiDate,#dvTimeBand,#dvPaxName,#dvOutbndAircraft,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvDeleteBags,#dvBRSonly,#dvRouteStartTime,#dvRouteEndTime').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvOutbndAirline,#dvOutbndHandler').addClass('hidden');
        $('#dvOutbndTerminal,#dvBagTag,#dvInbndAirline,#dvInbndhandler,#dvInbndTerminal,#dvLastLocation').addClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList,#dvRoute,#dvProcessArea,#dvBaggageSystem').addClass('hidden');

        $('#dvSingleDate,#dvInbndFlight').removeClass('hidden');
        //inbound flight auto complete
    };

    /**  Flight Details - Outbound Screen opearational/Biz filter **/
    var loadFlightDetailOutBoundFilter = function () {

        $('#dvMultiDate,#dvTimeBand,#dvPaxName,#dvOutbndAircraft,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvDeleteBags,#dvBRSonly,#dvRouteStartTime,#dvRouteEndTime').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvInbndFlight,#dvOutbndAirline,#dvOutbndHandler').addClass('hidden');
        $('#dvOutbndTerminal,#dvBagTag,#dvInbndAirline,#dvInbndhandler,#dvInbndTerminal,#dvLastLocation').addClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList,#dvRoute,#dvProcessArea,#dvBaggageSystem').addClass('hidden');

        $('#dvSingleDate,#dvOutbndFlight').removeClass('hidden');
        //outbound flight auto complete
    };


    /**   BJP - Summary- Screen filter **/
    var loadBJPSummaryFilter = function (filterResult) {

        $('#dvSingleDate,#dvTimeBand,#dvPaxName,#dvOutbndAircraft,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvDeleteBags,#dvBRSonly,#dvRouteStartTime,#dvRouteEndTime').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvOutbndAirline,#dvOutbndHandler').addClass('hidden');
        $('#dvInbndFlight,#dvBagTag,#dvInbndAirline,#dvInbndhandler,#dvLastLocation').addClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList').addClass('hidden');

        $('#dvMultiDate,#dvOutbndTerminal,#dvInbndTerminal,#dvOOGBags,#dvRoute,#dvProcessArea,#dvBaggageSystem').removeClass('hidden');

        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlProcessArea, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlBaggageSystem, filterResult.BagSystemList);
        Utility.addValuesToDropDown(ddlOOGBags, filterResult.OOGBagsList);
        loadRouteDropDown();
    };

    /**    BJP -Dashboard  Screen  filter **/
    var loadBJPDashboardFilter = function () {

        $('#dvSingleDate,#dvTimeBand,#dvPaxName,#dvOutbndAircraft,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvDeleteBags,#dvBRSonly,#dvRouteStartTime,#dvRouteEndTime').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvInbndFlight,#dvOutbndFlight,#dvOutbndAirline,#dvOutbndHandler').addClass('hidden');
        $('#dvOutbndTerminal,#dvBagTag,#dvInbndAirline,#dvInbndhandler,#dvInbndTerminal,#dvLastLocation').addClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList,#dvRoute,#dvProcessArea,#dvBaggageSystem').addClass('hidden');


        $('#dvMultiDate').removeClass('hidden');

    };


    /**     BTR - Inbound- Screen filter **/
    var loadBTRInBoundFilter = function (filterResult) {

        $('#dvSingleDate,#dvPaxName,#dvOutbndAircraft,#dvDestination,#dvOrigin,#dvOutbndTerminal').addClass('hidden');
        $('#dvDeleteBags,#dvBRSonly,#dvRouteStartTime,#dvRouteEndTime').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvOutbndAirline,#dvOutbndHandler').addClass('hidden');
        $('#dvInbndFlight,#dvBagTag,#dvOOGBags,#dvRoute,#dvLastLocation').addClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList,#dvProcessArea,#dvBaggageSystem').addClass('hidden');

        $('#dvMultiDate,#dvTimeBand,#dvInbndAirline,#dvInbndAircraft,#dvInbndTerminal,#dvInbndhandler,#dvBagStatus').removeClass('hidden');
        setTimeSlicer(txtTimeBand, timeBandSlicerValue);
        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndAircraft, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndhandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlBagStatus, filterResult.BagSystemList);
    };

    /**       BTR - Outbound- Screen filter **/
    var loadBTROutBoundFilter = function (filterResult) {

        $('#dvSingleDate,#dvPaxName,#dvDestination,#dvInbndAirline,#dvOrigin,#dvInbndhandler').addClass('hidden');
        $('#dvDeleteBags,#dvBRSonly,#dvRouteStartTime,#dvRouteEndTime').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvInbndAircraft,#dvInbndTerminal').addClass('hidden');
        $('#dvInbndFlight,#dvBagTag,#dvOOGBags,#dvRoute,#dvLastLocation').addClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList,#dvProcessArea,#dvBaggageSystem').addClass('hidden');

        $('#dvMultiDate,#dvTimeBand,#dvOutbndAircraft,#dvOutbndAirline,#dvOutbndHandler,#dvOutbndTerminal,#dvBagStatus').removeClass('hidden');

        setTimeSlicer(txtTimeBand, timeBandSlicerValue);
        Utility.bindMultiDropDown(ddlOutbndAircraft, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndHandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlBagStatus, filterResult.BagSystemList);
    };

    /**    ADP - Dashboard Screen filter **/
    var loadADPDashboardFilter = function (filterResult) {

        $('#dvMultiDate,#dvPaxName,#dvDestination,#dvOrigin,#dvOutbndAircraft,#dvOutbndAirline').addClass('hidden');
        $('#dvDeleteBags,#dvBRSonly,#dvRouteStartTime,#dvRouteEndTime,#dvOutbndTerminal').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvInbndAircraft,#dvOutbndHandler').addClass('hidden');
        $('#dvTimeBand,#dvBagTag,#dvOOGBags,#dvRoute,#dvLastLocation,#dvBagStatus').addClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList,#dvProcessArea,#dvBaggageSystem').addClass('hidden');

        $('#dvSingleDate,#dvInbndFlight,#dvInbndAirline,#dvInbndhandler,#dvInbndTerminal').removeClass('hidden');
        //inbound flight autocomplete
        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndAircraft, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndhandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
    };

    /**     ADP - DBD - Local/Transfer Screen filter **/ //ADP DBD  local and transfer screen
    var loadADPDashboardLocalFilter = function (filterResult) {

        $('#dvMultiDate,#dvPaxName,#dvDestination,#dvOrigin,#dvOutbndAircraft,#dvOutbndAirline').addClass('hidden');
        $('#dvDeleteBags,#dvBRSonly,#dvRouteStartTime,#dvRouteEndTime,#dvOutbndTerminal').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvInbndAircraft,#dvOutbndHandler').addClass('hidden');
        $('#dvBagTag,#dvOOGBags,#dvRoute,#dvLastLocation,#dvBagStatus').addClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList,#dvProcessArea,#dvBaggageSystem').addClass('hidden');

        $('#dvSingleDate,#dvTimeBand,#dvInbndFlight,#dvInbndAirline,#dvInbndhandler,#dvInbndTerminal').removeClass('hidden');
        //autocomplete inbnd flight
        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndhandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
        setTimeSlicer(txtTimeBand, timeBandSlicerValue);
    };

    /**   ADP-Summary and  ADP-DLR Screen filter **/  // both  ADP details & summary screen

    var loadADPSMRFilter = function (filterResult) {

        $('#dvSingleDate,#dvPaxName,#dvDestination,#dvOrigin,#dvOutbndAircraft,#dvOutbndAirline').addClass('hidden');
        $('#dvDeleteBags,#dvBRSonly,#dvRouteStartTime,#dvRouteEndTime,#dvOutbndTerminal').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvFailedSystem,#dvMDStatus').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvOutbndHandler,#dvTimeBand').addClass('hidden');
        $('#dvBagTag,#dvOOGBags,#dvRoute,#dvLastLocation,#dvBagStatus').addClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList,#dvProcessArea,#dvBaggageSystem').addClass('hidden');

        $('#dvMultiDate,#dvInbndFlight,#dvInbndAirline,#dvInbndAircraft,#dvInbndhandler,#dvInbndTerminal').removeClass('hidden');



        $('#txtMultiDate').val(date);
        //auto complete
        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndAircraft, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndhandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
    };

    /**   BJP-DLR Screen filter **/

    var loadBJPDLRFilter = function (filterResult) {

        $('#dvSingleDate,#dvTimeBand,#dvPaxName,#dvOutbndAircraft,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvDeleteBags,#dvBRSonly,#dvRoute').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvMDStatus').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvOutbndAirline,#dvOutbndHandler').addClass('hidden');
        $('#dvInbndFlight,#dvBagTag,#dvInbndAirline,#dvInbndhandler,#dvLastLocation').addClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList').addClass('hidden');

        $('#dvMultiDate,#dvOutbndTerminal,#dvInbndTerminal,#dvOOGBags,#dvProcessArea,#dvBaggageSystem,#dvRouteStartTime,#dvRouteEndTime,#dvFailedSystem').removeClass('hidden');
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlProcessArea, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlBaggageSystem, filterResult.BagSystemList);

        Utility.addValuesToDropDown(ddlOOGBags, filterResult.OOGBagsList);
        Utility.addValuesToDropDown(ddlFailedSystem, filterResult.FailedInSystemList);

        setTimeSlicer(txtRouteStartTime, startTimeSlicerValue);
        setTimeSlicer(txtRouteEndTime, endTimeSlicerValue);
    };

    /**   NLB - DBD Screen filter **/

    var loadNLBDBDFilter = function (filterResult) {

        $('#dvSingleDate,#dvPaxName,#dvOutbndAircraft,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvProcessArea,#dvBaggageSystem,#dvDeleteBags,#dvBRSonly,#dvRoute').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvMDStatus,#dvRouteStartTime').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvFailedSystem,#dvRouteEndTime').addClass('hidden');
        $('#dvInbndTerminal,#dvBagTag,#dvInbndhandler,#dvLastLocation').addClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList').addClass('hidden');

        $('#dvMultiDate,#dvTimeBand,#dvOutbndAirline,#dvOutbndHandler,#dvOutbndTerminal,#dvInbndFlight,#dvInbndAirline').removeClass('hidden');

        setTimeSlicer(txtTimeBand, timeBandSlicerValue);
        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndHandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
        //auto complete 
    };

    /**     NLB - SMR Screen filter **/
    var loadNLBSMRFilter = function (filterResult) {

        $('#dvSingleDate,#dvPaxName,#dvOutbndAircraft,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvProcessArea,#dvBaggageSystem,#dvDeleteBags,#dvBRSonly,#dvRoute').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvMDStatus,#dvRouteStartTime').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvFailedSystem,,#dvRouteEndTime').addClass('hidden');
        $('#dvBagTag,#dvInbndhandler,#dvLastLocation').addClass('hidden');
        $('#dvTimeBand,#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList').addClass('hidden');

        $('#dvMultiDate,#dvOutbndAirline,#dvOutbndHandler,#dvOutbndTerminal,#dvInbndFlight,#dvInbndAirline,#dvInbndTerminal').removeClass('hidden');
        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndHandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
        //auto complete 

    };

    /**    DDP - DBD Screen filter **/
    var loadDDPDBDFilter = function (filterResult) {

        $('#dvMultiDate,#dvPaxName,#dvOutbndAircraft,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvProcessArea,#dvBaggageSystem,#dvDeleteBags,#dvBRSonly,#dvRoute').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvMDStatus,#dvRouteStartTime').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvFailedSystem,#dvInbndFlight,#dvRouteEndTime').addClass('hidden');
        $('#dvBagTag,#dvInbndhandler,#dvLastLocation,#dvInbndAirline,#dvInbndTerminal').addClass('hidden');
        $('#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList').addClass('hidden');

        $('#dvSingleDate,#dvTimeBand,#dvOutbndFlight,#dvOutbndAirline,#dvOutbndHandler,#dvOutbndTerminal').removeClass('hidden');

        setTimeSlicer(txtTimeBand, timeBandSlicerValue);
        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndHandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);
        //auto complete
    };

    /**    DDP - SMR  and DDP-DLR Screen filter **/  //The same filter config will apply both screen. 
    var loadDDPSMRFilter = function (filterResult) {

        $('#dvSingleDate,#dvPaxName,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvProcessArea,#dvBaggageSystem,#dvDeleteBags,#dvBRSonly,#dvRoute').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvMDStatus,#dvRouteStartTime').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvFailedSystem,#dvRouteEndTime').addClass('hidden');
        $('#dvBagTag,#dvLastLocation,#dvInbndTerminal,#dvOutbndTerminal').addClass('hidden');
        $('#dvTimeBand,#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList,#dvOutbndAircraft').addClass('hidden');

        $('#dvMultiDate,#dvOutbndFlight,#dvOutbndAirline,#dvOutbndHandler,#dvInbndFlight,#dvInbndAirline,#dvInbndhandler').removeClass('hidden');

        //auto complete
        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndHandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndhandler, filterResult.BagSystemList);

    };

    /**   BSM-SMR Screen filter **/
    var loadBSMSMRFilter = function (filterResult) {

        $('#dvSingleDate,#dvPaxName,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvProcessArea,#dvBaggageSystem,#dvDeleteBags,#dvBRSonly,#dvRoute').addClass('hidden');
        $('#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvMDStatus,#dvRouteStartTime').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvFailedSystem,#dvOutbndTerminal,#dvRouteEndTime').addClass('hidden');
        $('#dvBagTag,#dvLastLocation,#dvOutbndAircraft,#dvInbndTerminal').addClass('hidden');
        $('#dvTimeBand,#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList').addClass('hidden');

        $('#dvMultiDate,#dvOutbndFlight,#dvOutbndAirline,#dvOutbndHandler,#dvInbndFlight,#dvInbndhandler,#dvInbndAirline').removeClass('hidden');

        //auto complete inbnd & outbndflight
        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndHandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndhandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
    };

    /**   ITT-DBD Screen filter **/
    var loadITTDBDFilter = function (filterResult) {

        $('#dvSingleDate,#dvPaxName,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvProcessArea,#dvBaggageSystem,#dvDeleteBags,#dvBRSonly,#dvRoute').addClass('hidden');
        $('#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd,#dvMDStatus,#dvRouteStartTime').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvFailedSystem,#dvOutbndFlight,#dvInbndAirline,#dvRouteEndTime').addClass('hidden');
        $('#dvBagTag,#dvLastLocation,#dvOutbndAircraft,#dvOutbndHandler,#dvInbndFlight,#dvOutbndAirline').addClass('hidden');
        $('#dvTimeBand,#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList,#dvInbndhandler').addClass('hidden');

        $('#dvMultiDate,#dvOutbndTerminal,#dvInbndTerminal,#dvInbndITO').removeClass('hidden');

        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);
        Utility.addValuesToDropDown(ddlInbndITO, filterResult.InboundITOList);
    };

    /**   ITT-DLR Screen filter **/
    var loadITTDLRFilter = function (filterResult) {

        $('#dvSingleDate,#dvPaxName,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvProcessArea,#dvBaggageSystem,#dvDeleteBags,#dvBRSonly,#dvRoute').addClass('hidden');
        $('#dvFailedSystem,#dvMDStatus,#dvRouteStartTime').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvRouteEndTime').addClass('hidden');
        $('#dvBagTag,#dvLastLocation,#dvOutbndAircraft,#dvInbndFlight').addClass('hidden');
        $('#dvTimeBand,#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList').addClass('hidden');

        $('#dvMultiDate,#dvOutbndAirline,#dvOutbndHandler,#dvOutbndTerminal,#dvInbndAirline,#dvInbndhandler').removeClass('hidden');
        $('#dvInbndTerminal,#dvInbndITO,#dvInTarget,#dvFailedMissed,#dvAtStart,#dvAtEnd').removeClass('hidden');

        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndHandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndhandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
        Utility.addValuesToDropDown(ddlInbndITO, filterResult.InboundITOList);
        Utility.addValuesToDropDown(ddlInTarget, filterResult.InTargetList);
        Utility.addValuesToDropDown(ddlFailedMissed, filterResult.FailedInSystemList);
        Utility.bindMultiDropDown(ddlAtStart, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlAtEnd, filterResult.BagSystemList);
    };


    /**  MDR-SMR Screen filter **/
    var loadMDRSMRFilter = function (filterResult) {

        $('#dvSingleDate,#dvPaxName,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvProcessArea,#dvBaggageSystem,#dvDeleteBags,#dvBRSonly,#dvRoute').addClass('hidden');
        $('#dvFailedMissed,#dvMDStatus,#dvRouteStartTime').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvRouteEndTime').addClass('hidden');
        $('#dvBagTag,#dvOutbndAircraft,#dvInbndFlight').addClass('hidden');
        $('#dvTimeBand,#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList').addClass('hidden');

        $('#dvMultiDate,#dvOutbndAirline,#dvOutbndHandler,#dvOutbndTerminal,#dvInbndAirline,#dvInbndhandler,#dvInbndTerminal,#dvLastLocation').removeClass('hidden');

        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndHandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndhandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlLastLocation, filterResult.BagSystemList);
    };

    /**  MDR-DLR Screen filter **/
    var loadMDRDLRFilter = function (filterResult) {

        $('#dvSingleDate,#dvPaxName,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvProcessArea,#dvBaggageSystem,#dvDeleteBags').addClass('hidden');
        $('#dvFailedMissed,#dvRouteStartTime,#dvBRSonly,#dvRoute').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvRouteEndTime').addClass('hidden');
        $('#dvBagTag,#dvOutbndAircraft,#dvInbndFlight,#dvLastLocation').addClass('hidden');
        $('#dvTimeBand,#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList').addClass('hidden');

        $('#dvMultiDate,#dvOutbndAirline,#dvOutbndHandler,#dvOutbndTerminal,#dvInbndAirline,#dvInbndhandler,#dvInbndTerminal,#dvMDStatus').removeClass('hidden');

        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndHandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndhandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlselectMDStatus, filterResult.BagSystemList);
    };

    /**  ARR-DBD-Next and ARR-DBD Screen filter **/  // Same filter will be applied both screens
    var loadARRDBDFilter = function (filterResult) {

        $('#dvMultiDate,#dvPaxName,#dvDestination,#dvInbndAircraft').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvProcessArea,#dvBaggageSystem,#dvDeleteBags').addClass('hidden');
        $('#dvFailedMissed,#dvRouteStartTime,#dvBRSonly,#dvRoute,#dvOutbndAirline,#dvOutbndHandler').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvRouteEndTime,#dvMDStatus').addClass('hidden');
        $('#dvBagTag,#dvOutbndAircraft,#dvOutbndTerminal,#dvLastLocation').addClass('hidden');
        $('#dvTimeBand,#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList').addClass('hidden');

        $('#dvSingleDate,#dvInbndFlight,#dvInbndAirline,#dvOrigin,#dvInbndhandler,#dvInbndTerminal').removeClass('hidden');

        //autocomplete
        Utility.bindMultiDropDown(ddlInbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOrigin, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndhandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlInbndTerminal, filterResult.BagSystemList);
    };

    /**  VOL-SMR Screen filter **/
    var loadVOLSMRFilter = function (filterResult) {

        $('#dvSingleDate,#dvPaxName,#dvDestination,#dvInbndAircraft,#dvOrigin').addClass('hidden');
        $('#dvBagStatus,#dvOOGBags,#dvProcessArea,#dvBaggageSystem,#dvDeleteBags').addClass('hidden');
        $('#dvFailedMissed,#dvRouteStartTime,#dvBRSonly,#dvRoute,#dvInbndTerminal').addClass('hidden');
        $('#dvNotLoaded,#dvNotLoadedSub,#dvOutbndFlight,#dvRouteEndTime,#dvInbndhandler').addClass('hidden');
        $('#dvBagTag,#dvOutbndAircraft,#dvInbndFlight,#dvLastLocation,#dvMDStatus').addClass('hidden');
        $('#dvTimeBand,#dvBagType,#dvShortConnect,#dvchox,#dvDelBSM,#dvBagList,#dvInbndAirline').addClass('hidden');

        $('#dvMultiDate,#dvOutbndAirline,#dvOutbndHandler,#dvOutbndTerminal').removeClass('hidden');

        Utility.bindMultiDropDown(ddlOutbndAirline, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndHandler, filterResult.BagSystemList);
        Utility.bindMultiDropDown(ddlOutbndTerminal, filterResult.BagSystemList);
    };



    // #endregion




})(jQuery);