﻿(function ($) {
    'use strict';
    //$(window).load(function () {
    //    var noteData = {};
    //    var updatedNotes = [];

    //    $.ajax({
    //        type: "GET",
    //        url: "/Share/Share",
    //        data: JSON.stringify(noteData),
    //        contentType: "application/json; charset=utf-8",
    //        dataType: "json",
    //        success: function (response) {
    //            if (response != null) {
    //                //CreateDynamicNotes(response);
    //                //GetDropDownData(response);
    //            }
    //        },
    //        failure: function (response) {
    //            alert("Error while data fetch.");
    //        },
    //        error: function (response) {
    //            alert("Error while data fetch.");
    //        }
    //    });
    //});

    //$(document).ready(function () {
    //    var noteData = { };
    //    var updatedNotes = [];

    //    $.ajax({
    //        type: "GET",
    //        url: "/Share/Share",
    //        data: JSON.stringify(noteData),
    //        contentType: "application/json; charset=utf-8",
    //        dataType: "json",
    //        success: function (response) {
    //            if (response != null) {
    //                //CreateDynamicNotes(response);
    //                //GetDropDownData(response);
    //            }
    //        },
    //        failure: function (response) {
    //            alert("Error while data fetch.");
    //        },
    //        error: function (response) {
    //            alert("Error while data fetch.");
    //        }
    //    });
    //});



    //$('.share').click(function () {
       
    //    var noteData = { user: "U1"};
    //    var updatedNotes = [];

    //    $.ajax({
    //        type: "GET",
    //        url: "/Share/Share",
    //        data: JSON.stringify(noteData),
    //        contentType: "application/json; charset=utf-8",
    //        dataType: "json",
    //        success: function (response) {
    //            if (response != null) {
    //                //CreateDynamicNotes(response);
    //                //GetDropDownData(response);
    //            }
    //        },
    //        failure: function (response) {
    //            alert("Error while data fetch.");
    //        },
    //        error: function (response) {
    //            alert("Error while data fetch.");
    //        }
    //    });
    //});

   
    //$(document).ready(function () {
    //    $('.share').click(function (event) {
    //        $("#sharepanel").toggle();
    //        $(".share").toggleClass("clickedIcons");
    //        $(".share").toggleClass("customBorderSmall");
    //    });
    //});


    //$("#liShare").off('click').on('click', function () {
    //    alert("1");

    //    //var noteData = { bagtag: 'Bt1', flightnumber: 'Fl1', organisation: "org1" };
    //    var noteData = {};
    //    var updatedNotes = [];

    //    $.ajax({
    //        type: "GET",
    //        url: "/Share/Share",
    //        data: JSON.stringify(noteData),
    //        contentType: "application/json; charset=utf-8",
    //        dataType: "json",
    //        success: function (response) {
    //            if (response != null) {
    //                //CreateDynamicNotes(response);
    //                GetDropDownData(response);
    //            }
    //        },
    //        failure: function (response) {
    //            alert("Error while data fetch.");
    //        },
    //        error: function (response) {
    //            alert("Error while data fetch.");
    //        }
    //    });

    //    function GetDropDownData() {
    //        var numbers = [1, 2, 3, 4, 5];
    //        var option = '';
    //        for (var i = 0; i < numbers.length; i++) {
    //            option += '<option value="' + numbers[i] + '">' + numbers[i] + '</option>';
    //        }
    //        $('#items').append(option);
    //        });
    //    }

    //});

})(jQuery);