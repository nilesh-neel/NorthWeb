﻿//----------------------------------------------------------------------
//Class Name   : PowerBIAPP
//Purpose      : PowerBIAPP js use to embedded the power bi report in web app.
//Created By   : Nilesh More
//Created Date : 18/Sep/2018
//Version      : 1.0
//History      :
//Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
//<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
//----------------------------------------------------------------------
var PowerBIAPP = (function () {

    'use strict';
    var service;
    PowerBIAPP = function (url, isReport) {
        this.embedUrl = (_.isNull(url) || _.isUndefined(url)) ? 'https://app.powerbi.com/reportEmbed?reportId=712a0da8-9c45-4792-92f3-57d37b80520c' : url;
        this.id = _.split(_.split(this.embedUrl, '=')[1], '&')[0];
        this.type = (isReport === 'true') ? 'report' : 'dashboard',
            this.accessToken;


    };

    PowerBIAPP.prototype.embedPowerBIApi = function () {

        var models = window['powerbi-client'].models;


        $('#viewContainer').hide();
        $('#dvPowerBiEmbed').show();

        if (this.embedUrl === '')
            return;

        var config = {
            type: this.type,
            id: this.id,
            tokenType: models.TokenType.Aad,
            accessToken: this.accessToken,
            embedUrl: this.embedUrl,
            permissions: models.Permissions.All /*gives maximum permissions*/,
            viewMode: models.ViewMode.Edit,
            settings: {
                filterPaneEnabled: false,
                navContentPaneEnabled: false
            }
        };

        ////check query string is available in url for the report filter options.
        //if (!_.isNull(location.search) && !_.isUndefined(location.search) && !_.isEmpty(location.search)) {
        //    var filters = PowerBIAPP.prototype.applyFilterToReport.call(this);
        //    config.filters = filters;
        //};


        // Grab the reference to the div HTML element that will host the dashboard.
        var powerBiContainer = document.getElementById('embedContainer');
        powerbi.reset(powerBiContainer);

        // Check and get the session token and Embed the dashboard/report and display it within the div container.

        service = new Service('/Dashboard/GetData');
        service.get()
            .then(function (resp) {
                config.accessToken = resp;
                var powerBiApi = powerbi.embed(powerBiContainer, config)
                powerBiApi.on('error', function (event) {
                    alert(JSON.stringify(event.detail, null, '  '));
                });

                powerBiApi.off("saved");
                powerBiApi.on("saved",
                    function (event) {
                        ///console.log(event.detail);
                        if (event.detail.saveAs) {
                            alert("Save");
                        }
                    });
            })
            .catch(function (jqXHR, textStatus, err) {
                alert('Error : ' + textStatus);
            });
    };

    PowerBIAPP.prototype.applyFilterToReport = function (jsonFilterObject) {
        //id=30&filter=BagItemSummaryFact/BagItemID eq 25106 //normal form
        //id%3D30%26filter%3DBagItemListFact%2FBagItemID%20eq%2025106 //UrlEncryption form
        //var filterJson = Utility.QueryStringToJSON();

        $('#viewContainer').hide();
        $('#dvPowerBiEmbed').show();


        var filterList = [];
        var filerValues = JSON.parse(jsonFilterObject.result).FilterItemSelection;

        _.map(filerValues,
            function (filter) {
                var baseFilter = {
                    $schema: 'http://powerbi.com/product/schema#basic',
                    target: {
                        table: filter.TableName,
                        column: filter.ColumnName,
                    },
                    operator: 'In',
                    values: _.castArray(filter.ColumnValue)

                };
                filterList.push(baseFilter);
            });

        // iamAFilter is dummy data for the testing to be delete after testing.
        //var iamAFilter = {
        //    $schema: "http://powerbi.com/product/schema#basic",
        //    target: {
        //        table: "BagItemListFact",
        //        column: "BagLastSeenProcessAreaIdentifier"
        //    },
        //    operator: "In",
        //    values: ["(S)OOG Build Output", "2.HBS_DIRL3"]
        //}
        //filterList.push(iamAFilter);


        var embedContainer = $('#embedContainer')[0];

        // Get a reference to the embedded report.
        var report = powerbi.get(embedContainer);

        report.setFilters(filterList);
    };

    PowerBIAPP.prototype.getAccessToken = function () {

        service = new Service('/Dashboard/GetData');
        service.get()
            .then(function (resp) {
                return resp;
            })
            .catch(function (jqXHR, textStatus, err) {
                alert('Error : ' + textStatus);
            });
    };

    PowerBIAPP.prototype.printReport = function () {

        // Get a reference to the embedded report HTML element
        var embedContainer = $('#embedContainer')[0];

        // Get a reference to the embedded report.
        var report = powerbi.get(embedContainer);

        // Retrieve the page collection and get the visuals for the first page.
        report.print();

        //----------------------------------------------------------------------
        /* To Download div content in pdf format we can use below code.
         This code is not support to download the iFrame content.
     
        <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.4.1/jspdf.min.js"></script>
     
        html2canvas(embedContainer, {
            onrendered: function (canvas) {
                //document.body.appendChild(canvas);
                var imgData = canvas.toDataURL("image/jpeg");
                var pdf = new jsPDF();
                pdf.addImage(imgData, 'JPEG', 0, 0, -180, -180);
                pdf.save(this.id);
            }
        });
        */
        //----------------------------------------------------------------------
    };

    PowerBIAPP.prototype.exportToCSV = function () {

        // Get models. models contains enums that can be used.
        var models = window['powerbi-client'].models;

        models.createReport()

        // Get a reference to the embedded report HTML element
        var embedContainer = $('#embedContainer')[0];

        // Get a reference to the embedded report.
        var report = powerbi.get(embedContainer);

        // Retrieve the page collection and get the visuals for the first page.
        report.getPages()
            .then(function (pages) {

                // Retrieve active page.
                var activePage = pages.find(function (page) {
                    return page.isActive
                });

                activePage.getVisuals()
                    .then(function (visuals) {

                        // Retrieve the wanted visual.
                        var visual = visuals.find(function (visual) {
                            return visual.name === 'VisualContainer3';
                        });

                        // Exports visual data
                        visual.exportData(models.ExportDataType.Underlying)
                            .then(function (result) {
                                // console.log(result.data);
                                exportFile(result.data);
                            })
                            .catch(function (errors) {
                                // Log.log(errors);
                            });
                    })
                    .catch(function (errors) {
                        alert('Error Occured...' + error);
                    });
            })
            .catch(function (errors) {
                alert('Error Occured...' + error);
            });

        report.activePage.prototype


    };

    PowerBIAPP.prototype.exportFile = function (data) {
        var csv = data;//this.convertToCSV(jsonObject);

        var exportedFilenmae = 'sample.csv' || 'export.csv';

        var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        if (navigator.msSaveBlob) { // IE 10+
            navigator.msSaveBlob(blob, exportedFilenmae);
        } else {
            var link = document.createElement('a');
            if (link.download !== undefined) { // feature detection
                // Browsers that support HTML5 download attribute
                var url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', exportedFilenmae);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }
    }

    PowerBIAPP.prototype.exportPdf = function (data) {
        var exportedFilenmae = 'sample.pdf' || 'export.pdf';
        var blob = new Blob([data], { type: 'application/pdf;charset=utf-8;' });
        if (navigator.msSaveBlob) { // IE 10+
            navigator.msSaveBlob(blob, exportedFilenmae);
        } else {
            var link = document.createElement('a');
            if (link.download !== undefined) { // feature detection
                // Browsers that support HTML5 download attribute
                var url = URL.createObjectURL(blob);
                link.setAttribute('href', url);
                link.setAttribute('download', exportedFilenmae);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }

    }

    PowerBIAPP.prototype.exportToExcel = function () {
        // Retrieve the page collection and get the visuals for the first page.
        report.getPages()
            .then(function (pages) {
                // Retrieve active page.
                var activePage = pages.find(function (page) {
                    return page.isActive;
                });

                activePage.getVisuals()
                    .then(function (visuals) {

                        // Retrieve the wanted visual.
                        var visual = visuals.find(function (visual) {
                            return visual.name === 'VisualContainer3';
                        });

                        // Exports visual data
                        visual.exportData(models.ExportDataType.Summarized)
                            .then(function (result) {
                                // Log.logCsv(result.data);
                            })
                            .catch(function (errors) {
                                // Log.log(errors);
                            });
                    })
                    .catch(function (errors) {
                        // Log.log(errors);
                    });
            })
            .catch(function (errors) {
                // Log.log(errors);
            });
    };

    PowerBIAPP.prototype.refreshReport = function () {
        //var models = window['powerbi-client'].models;

        // models.createReport()

        // Get a reference to the embedded report HTML element
        var embedContainer = $('#embedContainer')[0];

        // Get a reference to the embedded report.
        var report = powerbi.get(embedContainer);

        // Retrieve the page collection and get the visuals for the first page.
        report.refresh();
    }

    return PowerBIAPP;
})();