﻿/****************************************************************************************************************
Class Name   : Global.cs 
Purpose      : This is the mail startup file in the application. To handle all startup even in web app like
               Dependency injection, Route config / web api registrations etc...
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/
using System;
using System.Web;
using System.Web.Routing;
using System.Web.Http;
using System.Web.Optimization;
using Heathrow.BPM.Web.Configuration;

namespace Heathrow.BPM.Web
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            Bootstrap.Initialise();


            //AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
        }
    }
}