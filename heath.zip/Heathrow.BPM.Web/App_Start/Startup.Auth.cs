﻿/****************************************************************************************************************
Class Name   : Startup.cs 
Purpose      : Used as Owin Startup class to implements authentication and authorization in Application. 
Created By   : Nilesh More 
Created Date : 04/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/

using Microsoft.IdentityModel.Tokens;
using Owin;
using Heathrow.BPM.Core.Entity;
using Microsoft.Owin.Security;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.OpenIdConnect;
using Microsoft.Identity.Client;
using System.Web;
using System.IdentityModel.Claims;
using System.IO;
using Heathrow.BPM.Business.Infrastructure;
using System.Threading.Tasks;
using Heathrow.BPM.Business;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.Owin.Security.Notifications;

namespace Heathrow.BPM.Web
{
    public partial class Startup
    {
        //public static void ConfigureAuth(IAppBuilder app)
        //{

        //    app.SetDefaultSignInAsAuthenticationType(CookieAuthenticationDefaults.AuthenticationType);

        //    app.UseCookieAuthentication(new CookieAuthenticationOptions());

        //    app.UseWindowsAzureActiveDirectoryBearerAuthentication(
        //        new WindowsAzureActiveDirectoryBearerAuthenticationOptions
        //        {

        //            Tenant = AzureADConfig.AzureADTenant,
        //            TokenValidationParameters = new TokenValidationParameters
        //            {
        //                ValidAudience = AzureADConfig.ClientId
        //            },

        //        });

        //}

        /// <summary>
        /// In this method application validate the user credential against azure ad with OWIN middleware using OpenIdConnect authentication option.
        /// </summary>
        /// <param name="app"></param>
        public void ConfigureAuth(IAppBuilder app)
        {
            app.SetDefaultSignInAsAuthenticationType(CookieAuthenticationDefaults.AuthenticationType);

            app.UseCookieAuthentication(new CookieAuthenticationOptions());

            app.UseOpenIdConnectAuthentication(
                new OpenIdConnectAuthenticationOptions
                {

                    // The `Authority` represents the Microsoft v2.0 authentication and authorization service.
                    // The `Scope` describes the permissions that your app will need. See https://azure.microsoft.com/documentation/articles/active-directory-v2-scopes/                    
                    ClientId = AzureAdConfig.ClientId,
                    Authority = AzureAdConfig.AadAuthorityUri,
                    PostLogoutRedirectUri = PowerBiConfig.RedirectUrl,
                    RedirectUri = PowerBiConfig.RedirectUrl,
                    Scope = "openid email profile offline_access " + AzureAdConfig.AzureGraphScopes,
                    TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = false,
                        // In a real application you would use IssuerValidator for additional checks, 
                        // like making sure the user's organization has signed up for your app.
                        //     IssuerValidator = (issuer, token, tvp) =>
                        //     {
                        //         if (MyCustomTenantValidation(issuer)) 
                        //             return issuer;
                        //         else
                        //             throw new SecurityTokenInvalidIssuerException("Invalid issuer");
                        //     },
                    },
                    Notifications = new OpenIdConnectAuthenticationNotifications
                    {
                        AuthorizationCodeReceived = OnAuthorizationCodeReceivedAsync,
                        AuthenticationFailed = OnAuthenticationFailedAsync
                    }
                });

        }

        private static Task OnAuthenticationFailedAsync(AuthenticationFailedNotification<OpenIdConnectMessage,
            OpenIdConnectAuthenticationOptions> notification)
        {
            notification.HandleResponse();
            string redirect = $"/Home/Error?message={notification.Exception.Message}";
            if (notification.ProtocolMessage != null && !string.IsNullOrEmpty(notification.ProtocolMessage.ErrorDescription))
            {
                redirect += $"&debug={notification.ProtocolMessage.ErrorDescription}";
            }
            notification.Response.Redirect(redirect);
            return Task.FromResult(0);
        }

        private static async Task OnAuthorizationCodeReceivedAsync(AuthorizationCodeReceivedNotification notification)
        {
            // Get the signed in user's id and create a token cache
            string signedInUserId = notification.AuthenticationTicket.Identity.FindFirst(ClaimTypes.NameIdentifier).Value;
            SessionTokenCache tokenStore = new SessionTokenCache(signedInUserId,
                notification.OwinContext.Environment["System.Web.HttpContextBase"] as HttpContextBase);

            var idClient = new ConfidentialClientApplication(AzureAdConfig.ClientId, PowerBiConfig.RedirectUrl,
                new ClientCredential(AzureAdConfig.ClientSecret), tokenStore.GetMsalCacheInstance(), null);

            try
            {
                string[] scopes = AzureAdConfig.AzureGraphScopes.Split(new char[] { ' ' });

                var result = await idClient.AcquireTokenByAuthorizationCodeAsync(
                    notification.Code, scopes);

                var userDetails = await UserModule.GetUserDetailsAsync(result.AccessToken);

                var cachedUser = new CachedUser()
                {
                    DisplayName = userDetails.DisplayName,
                    Email = string.IsNullOrEmpty(userDetails.Mail) ?
                    userDetails.UserPrincipalName : userDetails.Mail,
                    Avatar = null
                };

                tokenStore.SaveUserDetails(cachedUser);
            }
            catch (MsalException ex)
            {
                const string message = "AcquireTokenByAuthorizationCodeAsync threw an exception";
                notification.HandleResponse();
                notification.Response.Redirect($"/Dashboard/Error?message={message}&debug={ex.Message}");
            }
           
        }
    }
}