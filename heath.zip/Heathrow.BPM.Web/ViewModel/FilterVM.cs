﻿using Heathrow.BPM.Core;
using Heathrow.BPM.Core.Interface;
using System.Collections.Generic;
using System.Linq;
namespace Heathrow.BPM.Web
{
    public class FilterVM
    {
        /// <summary>
        /// Filter ID
        /// </summary>
        public long FilterID { get; set; }

        /// <summary>
        /// UserID
        /// </summary>
        public string UserID { get; set; }

        /// <summary>
        /// Menu ID
        /// </summary>
        public int MenuID { get; set; }

        /// <summary>
        /// MenuName
        /// </summary>
        public string MenuName { get; set; }

        /// <summary>
        /// Filter Text
        /// </summary>
        public string FilterText { get; set; }


        /// <summary>
        /// Filter Selection
        /// </summary>
        public short FilterSelection { get; set; }


        public IList<FilterSelection> FilterItemSelection { get; set; }

        public IList<TextFilter> BagTagList { get; set; }

        public IList<TextFilter> PassengersList { get; set; }
        public IList<TextFilter> InBoundFlightList { get; set; }
        public IList<TextFilter> OutBoundFlightList { get; set; }

        public IList<DropDownFilter> BagTypeList { get; set; }
        public IList<DropDownFilter> BagSystemList { get; set; }
        public IList<DropDownFilter> ShortConnectList { get; set; }
        public IList<DropDownFilter> OOGBagsList { get; set; }
        public IList<DropDownFilter> AfterChoxList { get; set; }
        public IList<DropDownFilter> DeletedBagsList { get; set; }
        public IList<DropDownFilter> MissedBRSList { get; set; }
        public IList<DropDownFilter> DeletedBSMList { get; set; }
        public IList<DropDownFilter> MyBagList { get; set; }
        public IList<DropDownFilter> InboundITOList { get; set; }

        public IList<DropDownFilter> InTargetList { get; set; }

        public IList<DropDownFilter> FailedMissedList { get; set; }
        public IList<DropDownFilter> FailedInSystemList { get; set; }
    }



    public class FilterSelection
    {
        public string TableName { get; set; }
        public string ColumnName { get; set; }
        public IList<string> ColumnValue { get; set; }

        public string Operator { get; set; }
    }

    public class FilterMapping : IMapper<FilterVM, FilterCollection>
    {
        public FilterVM MapFrom(FilterCollection filterData)
        {
            return TransformEntityToViewModel(filterData);
        }
        public FilterCollection MapTo(FilterVM viewModelData)
        {
            return TransformViewModelToEntity(viewModelData);
        }

        public IEnumerable<FilterCollection> MapTo(IEnumerable<FilterVM> viewModelData)
        {
            return viewModelData.Select(m => TransformViewModelToEntity(m));
            // return new IEnumerable<FilterCollection>();
        }

        public IEnumerable<FilterVM> MapFrom(IEnumerable<FilterCollection> collParam)
        {
            return collParam.Select(y => TransformEntityToViewModel(y));
        }

        private static FilterVM TransformEntityToViewModel(FilterCollection filterColl)
        {
            if (filterColl == null)
            {
                return null;
            }

            var filterData = (filterColl.FilterText != null) ? Newtonsoft.Json.JsonConvert.DeserializeObject<IList<FilterSelection>>(filterColl.FilterText) : null;

            return new FilterVM()
            {
                BagSystemList = filterColl.BagSystemList,
                BagTypeList = filterColl.BagTypeList,
                AfterChoxList = filterColl.AfterChoxList,
                DeletedBagsList = filterColl.DeletedBagsList,
                DeletedBSMList = filterColl.DeletedBSMList,
                FailedInSystemList = filterColl.FailedInSystemList,
                MissedBRSList = filterColl.MissedBRSList,
                FailedMissedList = filterColl.FailedMissedList,
                InboundITOList = filterColl.InboundITOList,
                InTargetList = filterColl.InTargetList,
                MyBagList = filterColl.MyBagList,
                OOGBagsList = filterColl.OOGBagsList,
                ShortConnectList = filterColl.ShortConnectList,
                FilterID = filterColl.FilterID,
                MenuID = filterColl.MenuID,
                UserID = filterColl.UserID,
                FilterItemSelection = filterData,
                BagTagList = filterColl.BagTagList,
                PassengersList = filterColl.PassengersList,
                InBoundFlightList = filterColl.InBoundFlightList,
                OutBoundFlightList = filterColl.OutBoundFlightList

            };
        }



        /// <summary>
        /// 
        /// </summary>
        /// <param name="viewModel"></param>
        /// <returns></returns>
        private static FilterCollection TransformViewModelToEntity(FilterVM viewModel)
        {
            if (viewModel == null) return null;

            var filterSelection = (viewModel.FilterItemSelection != null) ? Newtonsoft.Json.JsonConvert.SerializeObject(viewModel.FilterItemSelection) : string.Empty;

            return new FilterCollection()
            {
                FilterSelection = viewModel.FilterSelection,
                MenuID = viewModel.MenuID,
                MenuName = viewModel.MenuName,
                UserID = viewModel.UserID,
                FilterText = filterSelection,
                FilterID = viewModel.FilterID
            };
        }

    }

}