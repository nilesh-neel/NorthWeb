﻿using System.Collections.Generic;
using Heathrow.BPM.Core.Entity;

namespace Heathrow.BPM.Core.Interface
{
    public interface IAssignHomePage
    {
        int Save(AssignHomePage _assignHomePage);
        IEnumerable<AssignHomePage> Get();
    }
}
