﻿
using System;

namespace Heathrow.BPM.Core.Entity
{
    /// <summary>
    /// Notes DTO
    /// </summary>
    public class Notes
    {
        /// <summary>
        /// NotesId
        /// </summary>
        public int NotesId { get; set; }
        /// <summary>
        /// Notedesc
        /// </summary>
        public string Notedesc { get; set; }
        public string Bagtag { get; set; }
        public string Flightnumber { get; set; }
        public string Organization { get; set; }
        public int Ispublic { get; set; }
        public int Isdeleted { get; set; }
        public string UserId { get; set; }

        public  DateTime CreatedDate { get; set; }

        //public List<Notes> NotesListVal { get; set; }



    }
}
