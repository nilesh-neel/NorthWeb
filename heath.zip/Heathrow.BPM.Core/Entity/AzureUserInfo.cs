﻿using System;
using System.Collections.Generic;

namespace Heathrow.BPM.Core.Entity
{
    public class AzureUserInfo
    {
        public string OdataContext { get; set; }
        public string Id { get; set; }
        public IList<string> BusinessPhones { get; set; }
        public string DisplayName { get; set; }
        public string GivenName { get; set; }
        public string JobTitle { get; set; }
        public string Mail { get; set; }
        public object MobilePhone { get; set; }
        public object OfficeLocation { get; set; }
        public object PreferredLanguage { get; set; }
        public string Surname { get; set; }
        public string UserPrincipalName { get; set; }
        public string Address { get; set; }
    }
    public class FileInfo
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string SharingLink { get; set; }
    }

    public class Message
    {
        public string Subject { get; set; }
        public ItemBody Body { get; set; }
        public List<Recipient> ToRecipients { get; set; }
        // public List<Attachment> Attachments { get; set; }
    }

    public class Recipient
    {
        public AzureUserInfo EmailAddress { get; set; }
    }

    public class ItemBody
    {
        public string ContentType { get; set; }
        public string Content { get; set; }
    }

    public class MessageRequest
    {
        public Message Message { get; set; }
        public bool SaveToSentItems { get; set; }
    }

    //public class Attachment
    //{
    //    [JsonProperty(PropertyName = "@odata.type")]
    //    public string ODataType { get; set; }
    //    public byte[] ContentBytes { get; set; }
    //    public string Name { get; set; }
    //}

    public class PermissionInfo
    {
        public SharingLinkInfo Link { get; set; }
    }

    public class SharingLinkInfo
    {
        public SharingLinkInfo(string type)
        {
            Type = type;
        }

        public string Type { get; set; }
        public string WebUrl { get; set; }
    }
}
