﻿using Heathrow.BPM.Security;
using System;
using System.Configuration;

namespace Heathrow.BPM.Core.Entity
{
    public class PowerBiConfig : AzureAdConfig
    {
        private static readonly string UserName = ConfigurationManager.AppSettings["PowerBiUserName"];
        private static readonly string Password = ConfigurationManager.AppSettings["PowerBiUserPassword"];
        private static string _user = string.Empty;
        private static string _pass = string.Empty;

        private static readonly string EncryptionKey = ConfigurationManager.AppSettings["EncryptionKey"];
        public static string PowerBiApiResource => ConfigurationManager.AppSettings["PowerBiAPIResource"];
        public static string PowerBiAuthorityUri => ConfigurationManager.AppSettings["PowerBiAuthorityUri"];
        public static string PowerBiDataset => ConfigurationManager.AppSettings["PowerBiDataset"];
        public static string PowerBiApiUrl => ConfigurationManager.AppSettings["PowerBiApiUrl"];
        public static string WorkspaceId => ConfigurationManager.AppSettings["PowerBiAPIResource"];
        public static string ReportId => ConfigurationManager.AppSettings["ReportId"];
        public static string RedirectUrl => ConfigurationManager.AppSettings["RedirectUrl"];

        public static string PowerBiUserName
        {
            get
            {
                if (!string.IsNullOrEmpty(_user)) return _user;
                AesEncryption sec = new AesEncryption();
                _user = sec.Decrypt(UserName, EncryptionKey);
                return _user;
            }
        }

        public static string PowerBiUserPassword
        {
            get
            {
                if (!String.IsNullOrEmpty(_pass)) return _pass;
                AesEncryption sec = new AesEncryption();
                _pass = sec.Decrypt(Password, EncryptionKey);
                return _pass;
            }
        }
    }
}
