﻿using Heathrow.BPM.Business.Interface;
using Heathrow.BPM.Core.Interface;

namespace Heathrow.BPM.Business
{
    public class BagListModule : IBagListModule
    {
        private static IBagList _baglist { get; set; }

        public BagListModule(IBagList bagList)
        {
            _baglist = bagList;
        }

        public int SaveBagTags(string Bagtags, string UserId)
        {
           return _baglist.SaveBagTags(Bagtags, UserId);
        }
        
        public int GetUserExistingbagtagsCnt(string UserId)
        {
            return _baglist.GetUserExistingBagtagsCnt(UserId);
        }

        public string GetUserExistingbagtags(string UserId)
        {
            return _baglist.GetUserExistingBagtags(UserId);
        }

        public int RemoveBagTags(string Bagtags, string UserId)
        {
            return _baglist.RemoveBagTags(Bagtags, UserId);
        }
        
    }
}
