﻿/****************************************************************************************************************
Class Name   : UserModule.cs 
Purpose      : This class use to fetch the login in user details for the azure ad with use of azure graph services.
Created By   : Nilesh More 
Created Date : 10/Oct/2018
Version      : 1.0
History      :
Modified By        | CR <CR NO  : NAME>/BUG ID/Interaction No  | Date(dd/MMM/yyyy) | Comments
<EMP Name(EMP ID)> | <CR <CR NO : NAME>/BUG ID/Interaction No> |  dd/MMM/yyyy      | <Reason For Modifications>
****************************************************************************************************************/


using System;
using System.IO;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Heathrow.BPM.Business.Interface;
using Microsoft.Graph;


namespace Heathrow.BPM.Business
{
    public class UserModule : IUserModule
    {
        private readonly IAuthProvider _authProvider;

        public UserModule(IAuthProvider authProvider)
        {
            _authProvider = authProvider;
        }

        public async Task<User> GetUserDetailsAsync() => await _authProvider.GetGraphServiceClient().Me.Request().GetAsync();

        // Get a specified user.
        public async Task<User> GetUser(string id)
        {
            // Get the specific user.
            return await _authProvider.GetGraphServiceClient().Users[id].Request().GetAsync();
        }

        // Get the profile photo of the current user (from the user's mailbox on Exchange Online). 
        public async Task<Stream> GetUserProfilePhoto()
        {
            try
            {
                return await _authProvider.GetGraphServiceClient().Me.Photo.Content.Request().GetAsync() ??
                       System.IO.File.OpenRead(System.Web.Hosting.HostingEnvironment.MapPath("/images/Icons/userProfile.png"));
            }
            catch (Exception)
            {
                return System.IO.File.OpenRead(System.Web.Hosting.HostingEnvironment.MapPath("/images/Icons/userProfile.png"));
            }

        }

        public static async Task<User> GetUserDetailsAsync(string accessToken)
        {
            var graphClient = new GraphServiceClient(
                new DelegateAuthenticationProvider(async (requestMessage) =>
                {
                    requestMessage.Headers.Authorization =
                        new AuthenticationHeaderValue("Bearer", accessToken);
                }));

            return await graphClient.Me.Request().GetAsync();
        }
    }
}
