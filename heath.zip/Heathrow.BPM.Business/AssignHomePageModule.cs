﻿using Heathrow.BPM.Core.Entity;
using Heathrow.BPM.Core.Interface;
using System.Collections.Generic;
using Heathrow.BPM.Business.Interface;

namespace Heathrow.BPM.Business
{
   public class AssignHomePageModule : IAssignHomePageModule
    {
       

        private static IAssignHomePage _assignHomePageRepository { get; set; }
        public AssignHomePageModule(IAssignHomePage assignhomepage)
        {
            _assignHomePageRepository = assignhomepage;
           
        }

        public int Save(AssignHomePage assignhomepage)
        {
            return _assignHomePageRepository.Save(assignhomepage);
        }

     

        //get Todays Notification
        public IEnumerable<AssignHomePage> Get()
        {
            return _assignHomePageRepository.Get();
        }
    }
}
