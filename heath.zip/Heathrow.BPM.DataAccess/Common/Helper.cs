﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Heathrow.BPM.DataAccess.Common
{
    public class Helper
    {
        public static SqlParameter CreateParameter(string paramName, DbType paramType, object paramValue = null, ParameterDirection direction = ParameterDirection.Input, int? size = null, byte? precision = null)
        {
            SqlParameter parameter = new SqlParameter
            {
                ParameterName = paramName
            };

            if (paramValue != DBNull.Value)
            {
                switch (paramType)
                {
                    case DbType.Int32:
                        paramValue = CheckParamValue<int>(Convert.ToInt32(paramValue));
                        break;

                    case DbType.String:
                        paramValue = CheckParamValue<string>(Convert.ToString(paramValue));
                        break;

                    case DbType.Double:
                        paramValue = CheckParamValue<double>(Convert.ToDouble(paramValue));//double
                        break;

                    case DbType.DateTime:
                        paramValue = CheckParamValue<DateTime>((DateTime)paramValue);
                        break;
                }
            }
            parameter.SqlDbType = DbTypeToSqlDbType(paramType);
            parameter.Value = paramValue;
            parameter.Direction = direction;
            if (size != null)
                parameter.Size = Convert.ToInt32(size);
            if (precision != null)
                parameter.Precision = Convert.ToByte(precision);
            return parameter;
        }
        protected static object CheckParamValue<T>(T paramValue)
        {
            if ((typeof(T) == typeof(string) && paramValue.Equals(NullConstants.NullString))
                || (typeof(T) == typeof(int) && paramValue.Equals(NullConstants.NullInt))
                || (typeof(T) == typeof(long) && paramValue.Equals(NullConstants.NullLong))
                || (typeof(T) == typeof(decimal) && paramValue.Equals(NullConstants.NullDecimal))
                || (typeof(T) == typeof(double) && paramValue.Equals(NullConstants.NullDouble))
                || (typeof(T) == typeof(float) && paramValue.Equals(NullConstants.NullFloat))
                || (typeof(T) == typeof(DateTime) && paramValue.Equals(NullConstants.NullDateTime))
                || (typeof(T) == typeof(Guid) && paramValue.Equals(NullConstants.NullGuid))
                )
            {
                return DBNull.Value;
            }
            return paramValue;
        }

        private static SqlDbType DbTypeToSqlDbType(DbType oDbType)
        {
            SqlParameter oSqlParam = new SqlParameter();
            try
            {
                oSqlParam.DbType = oDbType;
            }
            catch (Exception)
            {
                // can't map
            }
            return oSqlParam.SqlDbType;
        }

    }
    public sealed class NullConstants
    {
        public static string NullString = string.Empty;
        public static int NullInt = -2147483648;
        public static long NullLong = -9223372036854775808L;
        public static decimal NullDecimal = -79228162514264337593543950335M;
        public static double NullDouble = double.MinValue;
        public static float NullFloat = float.MinValue;
        public static DateTime NullDateTime = DateTime.MinValue;
        public static Guid NullGuid = Guid.Empty;
        public static DateTime DbMaxDate = new DateTime(0xfa0, 1, 1, 0x17, 0x3b, 0x3b);
        public static DateTime DbMinDate = new DateTime(0x76c, 1, 1, 0, 0, 0);
    }
}
