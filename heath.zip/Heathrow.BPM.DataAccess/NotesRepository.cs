﻿using System.Collections.Generic;
using Heathrow.BPM.DataAccess.Common;
using Heathrow.BPM.Core.Entity;
using System;
using System.Data;
using System.Data.SqlClient;
using static System.Convert;

namespace Heathrow.BPM.DataAccess
{
    public class NotesRepository : Core.Interface.INotes
    {
        public NotesRepository() { }


        public IList<Notes> SaveNotes(Notes notes)
        {
            DbConnection oDal = null;
            DataSet dsNotesList = null;
            //_notes.Flightnumber = "Fl1";
            //_notes.Organization = "org1";
            //_notes.Bagtag = "Bt1";
            try
            {
                if (!string.IsNullOrEmpty(notes.Notedesc))
                {
                    oDal = new DbConnection();
                    dsNotesList = new DataSet();

                    oDal.ExecuteDataSet(ProcedureConstants.InsertNotes, out dsNotesList,
                       new List<SqlParameter>()
                       {
                       new SqlParameter() { ParameterName = "@Notedesc", DbType = DbType.String, Value = notes.Notedesc },
                       new SqlParameter() { ParameterName = "@Bagtag", DbType = DbType.String, Value = notes.Bagtag },
                       new SqlParameter() { ParameterName = "@Flightnumber", DbType = DbType.String, Value =  notes.Flightnumber },
                       new SqlParameter() { ParameterName = "@Organization", DbType = DbType.String, Value = notes.Organization },
                       new SqlParameter() { ParameterName = "@Ispublic", DbType = DbType.Int16, Value = notes.Ispublic },
                       new SqlParameter() { ParameterName = "@UserId", DbType = DbType.String, Value = notes.UserId }

                       });

                    if ((dsNotesList != null) && (dsNotesList.Tables.Count > 0) && (dsNotesList.Tables[0].Rows.Count > 0))
                    {
                        // Dataset Data to collection
                        return ConvertDatatoCollection(dsNotesList);
                    }
                    else
                        return new List<Notes> { };
                }
                else
                    return new List<Notes> { };
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
            //return noteList;
        }



        /// <summary>
        /// Retrieve Note from data source
        /// </summary>
        /// <param name="bagtag"></param>
        /// <param name="flightnumber"></param>
        /// <param name="organization"></param>
        /// <returns></returns>
        public IList<Notes> FetchNotes(string bagtag, string flightnumber, string organization)
        {
            DbConnection oDal = null;
            DataSet dsNotesList = null;
            try
            {

                oDal = new DbConnection();
                dsNotesList = new DataSet();
                oDal.ExecuteDataSet(ProcedureConstants.FetchNotes, out dsNotesList,
                 new List<SqlParameter>()
                 {
                       new SqlParameter() { ParameterName = "@Bagtag", DbType = DbType.String, Value = bagtag },
                       new SqlParameter() { ParameterName = "@Flightnumber", DbType = DbType.String, Value = flightnumber },
                       new SqlParameter() { ParameterName = "@Organization", DbType = DbType.String, Value = organization },

                 });

                if ((dsNotesList != null) && (dsNotesList.Tables.Count > 0) && (dsNotesList.Tables[0].Rows.Count > 0))
                {
                    // Dataset Data to collection
                    return ConvertDatatoCollection(dsNotesList);
                }
                else
                    return new List<Notes> { };

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }


        public IList<Notes> DeleteNotes(int notesId, string bagtag, string flightnumber, string organization)
        {
            DbConnection oDal = null;
            try
            {

                oDal = new DbConnection();
                DataSet dsNotesList = new DataSet();
                oDal.ExecuteDataSet(ProcedureConstants.DeleteNotes, out dsNotesList,
                       new List<SqlParameter>()
                       {
                        new SqlParameter() { ParameterName = "@Notesid", DbType = DbType.Int32, Value =notesId },
                        new SqlParameter() { ParameterName = "@Bagtag", DbType = DbType.String, Value = bagtag },
                        new SqlParameter() { ParameterName = "@Flightnumber", DbType = DbType.String, Value = flightnumber },
                        new SqlParameter() { ParameterName = "@Organization", DbType = DbType.String, Value = organization },
                       });

                if ((dsNotesList != null) && (dsNotesList.Tables.Count > 0) && (dsNotesList.Tables[0].Rows.Count > 0))
                {
                    // Dataset Data to collection
                    return ConvertDatatoCollection(dsNotesList);
                }
                else
                    return new List<Notes> { };
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                oDal.CloseConnection();
            }
        }

        private IList<Notes> ConvertDatatoCollection(DataSet ds)
        {
            IList<Notes> noteList = null;
            if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                noteList = new List<Notes>();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    noteList.Add(new Notes
                    {
                        NotesId = ToInt32(row["Notes_Id"]),
                        Notedesc = Convert.ToString(row["Notes_Desc"]),
                        Bagtag = Convert.ToString(row["Bag_Tag"]),
                        Flightnumber = Convert.ToString(row["Flight_Number"]),
                        Organization = Convert.ToString(row["Organization"]),
                        Ispublic = ToInt16(row["Is_Public"]),
                        Isdeleted = ToInt16(row["Is_Deleted"]),
                        UserId = Convert.ToString(row["Created_User"]),
                        CreatedDate = ToDateTime(row["Created_Datetime"]),
                    });
                }
            }
            return noteList;
        }



        //private List<Notes> BindDataToEntity(DataSet dsNotes, string _userId)
        //{
        //    try
        //    {
        //        return (from drAlert in dsNotes.Tables[0].AsEnumerable()
        //                select (new Notes
        //                {
        //                    NotesId = Convert.ToInt32(dsNotes.Tables[0].Rows[0]["Notes_ID"]),
        //                    Notedesc = Convert.ToString(dsNotes.Tables[0].Rows[0]["Notes_Desc"]),
        //                    Bagtag = Convert.ToString(dsNotes.Tables[0].Rows[0]["Bag_Tag"]),
        //                    Flightnumber = Convert.ToString(dsNotes.Tables[0].Rows[0]["Flight_Number"]),
        //                    Organization = Convert.ToString(dsNotes.Tables[0].Rows[0]["Organization"]),
        //                    Ispublic = Convert.ToInt16(dsNotes.Tables[0].Rows[0]["Is_Public"]),
        //                    Isdeleted = Convert.ToInt16(dsNotes.Tables[0].Rows[0]["Is_Deleted"]),
        //                    UserId = _userId
        //                })).ToList();
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }
        //}
    }
}
